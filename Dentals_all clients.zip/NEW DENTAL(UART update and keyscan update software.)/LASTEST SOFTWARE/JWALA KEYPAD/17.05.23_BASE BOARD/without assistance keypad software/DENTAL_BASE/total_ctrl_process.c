 #include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"
extern void delay(unsigned char dly);
void up_dwn_actutor_current_position_store(void);
void fwd_rev_actutor_current_position_store(void);
extern void eeprom_write(unsigned char,unsigned char);
void zero_gaugle_process_actuator_position_store();
void total_ctrl_process()
{
	if(tumbler_sw_flag)							//TUMBLER_KEY
	{
		if(!tumbler_prgm_mode_delay_flag)
		{
			tumbler_prgm_dly = 60;		
			tumbler_prgm_mode_delay_flag = SET;
			//tumbler_on_flag = SET;
			
		}
		else
		{
			if(tumbler_prgm_dly <=0)
			{			
				TMBLR_ON;
				tumbler_prgm_on_flag =SET;
				BUZZER_ON;
			}
		}
	}
	else
	{
		if(tumbler_prgm_mode_delay_flag)
		{
			if(tumbler_prgm_dly <=0)
			{
				tumbler_prgm_on_flag = CLEAR;
				eeram_tumbler_prgm_on_delay=tumbler_prgm_on_delay;
				tumbler_prgm_on_delay=0;
				eeram_tumbler_save_flag=SET;
				TMBLR_OFF;
				tumbler_prgm_mode_delay_flag=CLEAR;
			}
			else
			{
				
				tumb_on_dly=eeram_tumbler_prgm_on_delay;
				if((tumb_on_dly>0)AND(p2_2==0)AND(!tumbler_repeat_flag))
				{
					TMBLR_ON;				
					tumbler_on_flag = SET;			//FOR RESEND LED & DISPLAY UPDATE TO TRAY BRD
				}
				tumbler_prgm_mode_delay_flag=CLEAR;
			}
		}
	}
	if(spit_sw_flag)								//SPITOON_KEY
	{
		if(!spit_prgm_mode_delay_flag)
		{
			spit_prgm_dly = 60;
			spit_prgm_mode_delay_flag = SET;
			
		}
		else		
		{
			if(spit_prgm_dly <=0)
			{
				spit_prgm_on_flag =SET;
				SPITOON_ON;
				BUZZER_ON;
			}	
		}
	}
	else
	{
		if(spit_prgm_mode_delay_flag)
		{
			if(spit_prgm_dly <=0)
			{
				spit_prgm_on_flag = CLEAR;				
				eeram_spit_prgm_on_delay=spit_prgm_on_delay;
				spit_prgm_on_delay=0;
				SPITOON_OFF;
				eeram_spit_save_flag=SET;				
				spit_prgm_mode_delay_flag = CLEAR;
			}
			else
			{
				spit_on_dly=eeram_spit_prgm_on_delay;
				if((spit_on_dly)AND(!spitoon_repeat_flag))
				{
					SPITOON_ON;	
					spit_on_flag=SET;			//FOR RESEND LED & DISPLAY UPDATE TO TRAY BRD						
				}							
				spit_prgm_mode_delay_flag = CLEAR;
			}
		}
	}
	if((lamp_sw_flag)OR(sensor_lamp_flag))										//LAMP_SWITCH
	{
		if(!conti_lamp_flag)
		{
			sensor_lamp_flag = CLEAR;
			conti_lamp_flag = SET;
			lamp_sw_flag=CLEAR;
			if(!lamp_low_sw_flag)
			{
				LAMP_LOW_ON;
				lamp_low_sw_flag = SET;
			//	lamp_sw_flag=CLEAR;
			}
			else if(!lamp_high_sw_flag)
			{
			//	LAMP_LOW_OFF;
				LAMP_HIGH_ON;			
				lamp_high_sw_flag = SET;
			//	lamp_sw_flag=CLEAR;
			}
			else
			{
				LAMP_LOW_OFF;
				LAMP_HIGH_OFF;
			//	lamp_sw_flag=CLEAR;
				lamp_low_sw_flag = CLEAR;
				lamp_high_sw_flag = CLEAR;
			}
		}
	}
	if((act_up_flag)OR(foot_up_sw_flag)OR(asst_act_up_flag))
	{
		if(((!UP_ACTUATOR)OR(!DWN_ACTUATOR))AND(!up_act_flag)AND(!dwn_act_flag)AND(!up_dn_pulse_error_flag))
		{
			if((p1_7==1)AND(up_dwn_err_rmv_flag))
			{				
				if(up_down_counter1<10000)
				{
					up_down_counter1++;
						
				}
				pulse_timer_up_dn=0;
			}
			up_dwn_err_rmv_flag1=CLEAR;
			up_dwn_err_rmv_flag=CLEAR;						//ACTUATOR_UP_KEY			
			int1en=1;
			up_act_flag=SET;
			up_act_off_flag=SET;
			up_act_display_send_flag=SET;
			UP_ACTUATOR_ON;	
			up_dwn_act_off_timer=0;
		
		}		
	}
	else
	{
		if(up_act_off_flag)
		{
			up_dwn_act_off_timer=0;	
			UP_ACTUATOR_OFF;
			up_dwn_err_rmv_flag1=SET;
		//	up_act_flag=CLEAR;
			up_act_off_flag=CLEAR;	
			up_dn_pulse_error_flag=CLEAR;		
			pulse_timer_up_dn=0X00;	
			up_act_flag=CLEAR;
			up_dwn_act_off_timer=0;
			/*uart_receive_input_flag=CLEAR;
			key_status_changed_flag=CLEAR;
			temp_serial_received_data=KEYPAD_DATA;*/
			//keysense_resume_delay=2;
			up_dwn_actutor_current_position_store();
		}
	}
	if((act_dwn_flag )OR(foot_dwn_sw_flag)OR(aast_act_dwn_flag))
	{
		if(((!UP_ACTUATOR)OR(!DWN_ACTUATOR))AND(!up_act_flag)AND(!dwn_act_flag)AND(!up_dn_pulse_error_flag))
		{
			if((p1_7==1)AND(up_dwn_err_rmv_flag1))
			{
				
				if(up_down_counter1>0)
				{
					up_down_counter1--;
				
				}
				pulse_timer_up_dn=0;
			}
			up_dwn_err_rmv_flag1=CLEAR;
			up_dwn_err_rmv_flag=CLEAR;								//ACTUATOR_DWN_KEY		
			int1en=1;
			dwn_act_flag=SET;
			dwn_act_off_flag=SET;
			dwn_act_display_send_flag=SET;
			DWN_ACTUATOR_ON;
			up_dwn_act_off_timer=0;
				
		}			
	}
	else
	{
		if(dwn_act_off_flag)
		{
			up_dwn_act_off_timer=0;	
			DWN_ACTUATOR_OFF;
		//	dwn_act_flag=CLEAR;
			up_dwn_err_rmv_flag=SET;
			dwn_act_off_flag=CLEAR;	
			up_dn_pulse_error_flag=CLEAR;
			pulse_timer_up_dn=0X00;	
			up_dwn_act_off_timer=0;
			dwn_act_flag=CLEAR;
			/*uart_receive_input_flag=CLEAR;
			key_status_changed_flag=CLEAR;
			temp_serial_received_data=KEYPAD_DATA;*/
		//	keysense_resume_delay=2;
			up_dwn_actutor_current_position_store();
		}
	}
	if((act_fwd_flag )OR(foot_fwd_sw_flag)OR(asst_act_fwd_flag))
	{
		if(((!FWD_ACTUATOR)OR(!REV_ACTUATOR))AND(!fwd_act_flag)AND(!rev_act_flag)AND(!fwd_rev_pulse_error_flag))
		{
			
			if((p4_5==1)AND(err_rmv_flag))
			{	
				/*if(fwd_rev_counter>0)
				{
					fwd_rev_counter++;	
				}*/
				if(fwd_rev_counter>0)
				{
					fwd_rev_counter--;
					
					//test_rama_count++;
				}
					pulse_timer = 0x00;	
			}
			
			err_rmv_flag=CLEAR;
			err_rmv_flag1=CLEAR;			
			int0en=1;								//ACTUATOR_FWD_KEY
			fwd_act_flag=SET;							
			fwd_act_off_flag=SET;
			fwd_act_display_send_flag=SET;
			gaugle_key_flag = CLEAR;
			FWD_ACTUATOR_ON;
			act_off_timer=0;
		
		}
	}
	else
	{
		if(fwd_act_off_flag)
		{						
			err_rmv_flag1=SET;
			act_off_timer=0;		
			fwd_act_off_flag=CLEAR;
			FWD_ACTUATOR_OFF;
			fwd_rev_pulse_error_flag=CLEAR;
			pulse_timer = 0x00;
			act_off_timer=0;
			fwd_act_flag=CLEAR;
			/*uart_receive_input_flag=CLEAR;
			key_status_changed_flag=CLEAR;
			temp_serial_received_data=KEYPAD_DATA;*/
			//keysense_resume_delay=2;
			fwd_rev_actutor_current_position_store();
		}
	}
	if((act_rev_flag )OR(foot_rev_sw_flag)OR(asst_act_rev_flag))
	{
		if(((!FWD_ACTUATOR)OR(!REV_ACTUATOR))AND(!fwd_act_flag)AND(!rev_act_flag)AND(!fwd_rev_pulse_error_flag))	
		{
				
			if((p4_5==1)AND(err_rmv_flag1))
			{
				/*if(fwd_rev_counter>0)
				{
					fwd_rev_counter--;
				}*/
				if(fwd_rev_counter<=10000)
				{
					fwd_rev_counter++;				
				}
					pulse_timer = 0x00;
			}
			err_rmv_flag1=CLEAR;
			err_rmv_flag=CLEAR;	
			rev_act_flag=SET;				
			int0en=1;								//ACTUATOR_REV_KEY						
			rev_act_off_flag=SET;
			rev_act_display_send_flag=SET;
			gaugle_key_flag = CLEAR;
			REV_ACTUATOR_ON;
			act_off_timer=0;
							
		}
	}
	else
	{
		if(rev_act_off_flag)
		{
			rev_act_off_flag=CLEAR;		
			act_off_timer=0;			
			err_rmv_flag=SET;				
			REV_ACTUATOR_OFF;
			fwd_rev_pulse_error_flag=CLEAR;	
			pulse_timer = 0x00;
			act_off_timer=0;
			rev_act_flag = CLEAR;
			/*uart_receive_input_flag=CLEAR;
			key_status_changed_flag=CLEAR;
			temp_serial_received_data=KEYPAD_DATA;*/
			//keysense_resume_delay=2;
			fwd_rev_actutor_current_position_store();		
		}
	}
/***********************PROGRAM1_SW************************/
/*	if((!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)AND(!dwn_pgm2_eql_wait_flag))
	{
		if(pgm1_sw_flag)									
		{
			if(!pgm1_prgm_mode_delay_flag)
			{
				if(pgm1_repeat_flag)
				pgm1_repeat_flag=CLEAR;
				pgm1_prgm_dly = 60;
				pgm1_prgm_mode_delay_flag = SET;
			}
			else
			{
				if(pgm1_prgm_dly<=0)
				{
					pgm1_prgm_on_flag=SET;							//FOR SEND THE UART DATA FUNCTION
					pgm1_up_down_counter1=up_down_counter1;
					pgm1_fwd_rev_counter=fwd_rev_counter;
					BUZZER_ON;
				}
			}
		}
		else 
		{		
			if(pgm1_prgm_mode_delay_flag)
			{
				if(pgm1_prgm_dly <=0)
				{
					pgm1_prgm_on_flag = CLEAR;
					eeram_pgm1_up_down_counter1=pgm1_up_down_counter1;
					eeram_pgm1_fwd_rev_counter=pgm1_fwd_rev_counter;
					pgm1_prgm_mode_delay_flag = CLEAR;
					eeram_pgm1_save_flag=SET;
				}
				else 
				{
					if(pgm1_prgm_dly <=45)
					{									
						if((pgm1_up_down_counter1!=up_down_counter1)AND(!pgm1_repeat_flag))
						{
							//if(up_down_counter1<pgm1_up_down_counter1)
							if(pgm1_up_down_counter1>up_down_counter1)
							{
								//if(!UP_ACTUATOR)
								{
									if((p1_7==1)AND(up_dwn_err_rmv_flag))
									{
										if(up_down_counter1>0)
										{
											up_down_counter1++;
										}
									}
									up_dwn_err_rmv_flag=CLEAR;
									up_dwn_err_rmv_flag1=SET;
									int1en=1;
									up_act_flag=SET;
									dwn_act_flag=CLEAR;
									up_pgm1_eql_wait_flag=SET;
									pgm1_prgm_mode_delay_flag = CLEAR;
									pgm1_up_dwn_disp_flag = SET;
									pgm1_up_dwn_pulse_err_flag = SET;						
									UP_ACTUATOR_ON;									
									up_dwn_act_off_timer=0;
									pulse_timer_up_dn=0;
								}
							}
							//else if(up_down_counter1>pgm1_up_down_counter1)
							else 
							{				
								if(pgm1_up_down_counter1<up_down_counter1)									
								//if(!DWN_ACTUATOR)
								{
									if((p1_7==1)AND(up_dwn_err_rmv_flag1))
									{								
										if(up_down_counter1>0)
										{
											up_down_counter1--;
										}
									}
									up_dwn_err_rmv_flag1=CLEAR;							
									up_dwn_err_rmv_flag=SET;
									int1en=1;
									dwn_act_flag=SET;
									up_act_flag=CLEAR;
									dwn_pgm1_eql_wait_flag=SET;
									pgm1_prgm_mode_delay_flag = CLEAR;
									pgm1_up_dwn_disp_flag = SET;
									pgm1_up_dwn_pulse_err_flag = SET;
									DWN_ACTUATOR_ON;
									up_dwn_act_off_timer=0;
									pulse_timer_up_dn=0;
								}
						
							}			
						}
						if((pgm1_fwd_rev_counter!=fwd_rev_counter)AND(!pgm1_repeat_flag))
						{
							//if(fwd_rev_counter>pgm1_fwd_rev_counter)
							if(fwd_rev_counter<pgm1_fwd_rev_counter)
							{
								//if(!REV_ACTUATOR)
								{
							
									if((p4_5==1)AND(err_rmv_flag1))
									{										
										if(fwd_rev_counter<=10000)
										{
											fwd_rev_counter++;
										}
									}													
									err_rmv_flag1=CLEAR;												
									int0en=1;
									rev_act_flag=SET;
									fwd_act_flag=CLEAR;
									err_rmv_flag = SET;							
									rev_pgm1_eql_wait_flag=SET;						
									pgm1_prgm_mode_delay_flag = CLEAR;
							//		pgm1_fwd_rev_act_on_flag=SET;
									pgm1_fwd_rev_disp_flag = SET;
									pgm1_fwd_rev_pulse_err_flag = SET;
									REV_ACTUATOR_ON;
									act_off_timer=0;
									pulse_timer = 0x00;
								}
							}
							else
							{
								//if(fwd_rev_counter<pgm1_fwd_rev_counter)
								if(fwd_rev_counter>pgm1_fwd_rev_counter)
								{
									//if(!FWD_ACTUATOR)
									{
										if((p4_5==1)AND(err_rmv_flag))
										{											
											if(fwd_rev_counter>0)
											{
												fwd_rev_counter--;
											}
										}					
										int0en=1;
										fwd_act_flag=SET;
										rev_act_flag=CLEAR;
										err_rmv_flag1 = SET;
										err_rmv_flag=CLEAR;						
										fwd_pgm1_eql_wait_flag=SET;							
										pgm1_prgm_mode_delay_flag = CLEAR;
									//	pgm1_fwd_rev_act_on_flag=SET;
										pgm1_fwd_rev_disp_flag = SET;
										pgm1_fwd_rev_pulse_err_flag=SET;
										FWD_ACTUATOR_ON;
										act_off_timer=0;
										pulse_timer = 0x00;
									}
								}				
							}
						}
					}
				}	
			}
		}
	}*/
/*****************************PROGRAM2_SW***********************************************/
/*	if((!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag))
	{
		if(pgm2_sw_flag)									
		{
			if(!pgm2_prgm_mode_delay_flag)
			{
				if(pgm2_repeat_flag)
				pgm2_repeat_flag=CLEAR;
				pgm2_prgm_dly = 60;
				pgm2_prgm_mode_delay_flag = SET;
			}
			else
			{
				if(pgm2_prgm_dly<=0)
				{
					pgm2_prgm_on_flag=SET;							//FOR SEND THE UART DATA FUNCTION
					pgm2_up_down_counter1=up_down_counter1;
					pgm2_fwd_rev_counter=fwd_rev_counter;
					BUZZER_ON;
				}
			}
		}
		else
		{		
			if(pgm2_prgm_mode_delay_flag)
			{
				if(pgm2_prgm_dly <=0)
				{
					pgm2_prgm_on_flag=CLEAR;	
					eeram_pgm2_up_down_counter1=pgm2_up_down_counter1;
					eeram_pgm2_fwd_rev_counter=pgm2_fwd_rev_counter;
					pgm2_prgm_mode_delay_flag = CLEAR;
					eeram_pgm2_save_flag=SET;
				}
				else
				{
					if(pgm2_prgm_dly <=45)
					{
						if((pgm2_up_down_counter1!=up_down_counter1)AND(!pgm2_repeat_flag))
						{
							if(pgm2_up_down_counter1>up_down_counter1)
							{
								//if(!UP_ACTUATOR)
								{
									if((p1_7==1)AND(up_dwn_err_rmv_flag))
									{
										if(up_down_counter1>0)
										{
											up_down_counter1++;
										}
									}
									up_dwn_err_rmv_flag=CLEAR;
									up_dwn_err_rmv_flag1=SET;
									int1en=1;
									up_act_flag=SET;
									dwn_act_flag=CLEAR;
									up_pgm2_eql_wait_flag=SET;
									pgm2_prgm_mode_delay_flag = CLEAR;
									pgm2_up_dwn_disp_flag = SET;
									pgm2_up_dwn_pulse_err_flag = SET;
									UP_ACTUATOR_ON;
									up_dwn_act_off_timer=0;
									pulse_timer_up_dn=0;
								}
							}
							else 
							{		
								if(pgm2_up_down_counter1<up_down_counter1)				
								//if(!DWN_ACTUATOR)
								{
									if((p1_7==1)AND(up_dwn_err_rmv_flag1))
									{								
										if(up_down_counter1>0)
										{
											up_down_counter1--;
										}
									}
									up_dwn_err_rmv_flag1=CLEAR;							
									up_dwn_err_rmv_flag=SET;
									int1en=1;
									dwn_act_flag=SET;
									up_act_flag=CLEAR;
									dwn_pgm2_eql_wait_flag=SET;
									pgm2_prgm_mode_delay_flag = CLEAR;
									pgm2_up_dwn_disp_flag = SET;
									pgm2_up_dwn_pulse_err_flag = SET;
									DWN_ACTUATOR_ON;
									up_dwn_act_off_timer=0;
									pulse_timer_up_dn=0;
								}						
							}			
						}
			
						if((pgm2_fwd_rev_counter!=fwd_rev_counter)AND(!pgm2_repeat_flag))
						{
							//if(fwd_rev_counter>pgm2_fwd_rev_counter)
							if(fwd_rev_counter<pgm2_fwd_rev_counter)
							{
								//if(!REV_ACTUATOR)
								{
									if((p4_5==1)AND(err_rmv_flag1))
									{										
										if(fwd_rev_counter<=10000)
										{
											fwd_rev_counter++;
										}
									}													
									err_rmv_flag1=CLEAR;											
									int0en=1;
									rev_act_flag=SET;
									fwd_act_flag=CLEAR;
									err_rmv_flag = SET;							
									rev_pgm2_eql_wait_flag=SET;
									pgm2_prgm_mode_delay_flag = CLEAR;
									pgm2_fwd_rev_disp_flag = SET;
									pgm2_fwd_rev_pulse_err_flag=SET;
									REV_ACTUATOR_ON;
									act_off_timer=0;
									pulse_timer = 0x00;
								}
							}
							else
							{
								//if(fwd_rev_counter<pgm2_fwd_rev_counter)
								if(fwd_rev_counter>pgm2_fwd_rev_counter)
								{
									//if(!FWD_ACTUATOR)
									{
										if((p4_5==1)AND(err_rmv_flag))
										{											
											if(fwd_rev_counter>0)
											{
												fwd_rev_counter--;
											}										
										}	
										int0en=1;
										fwd_act_flag=SET;
										rev_act_flag=CLEAR;
										err_rmv_flag1 = SET;
										err_rmv_flag=CLEAR;						
										fwd_pgm2_eql_wait_flag=SET;
										pgm2_prgm_mode_delay_flag = CLEAR;
										pgm2_fwd_rev_disp_flag = SET;
										pgm2_fwd_rev_pulse_err_flag=SET;
										FWD_ACTUATOR_ON;
										act_off_timer=0;
										pulse_timer = 0x00;
									}
								}
							}
						}
					}
				}	
			}
		}
	}*/
/******************************************PROGRAM3_SW*********************************/	
	/*if(pgm3_sw_flag)									
	{
		if(!pgm3_prgm_mode_delay_flag)
		{
			if(pgm3_repeat_flag)
			pgm3_repeat_flag=CLEAR;
			pgm3_prgm_dly =60;
			pgm3_prgm_mode_delay_flag = SET;
		}
		else
		{
			if(pgm3_prgm_dly<=0)
			{
				pgm3_prgm_on_flag=SET;
				pgm3_up_down_counter1=up_down_counter1;
				pgm3_fwd_rev_counter=fwd_rev_counter;
				BUZZER_ON;
			}
		}
	}
	else
	{
		if(pgm3_prgm_mode_delay_flag)
		{
			if(pgm3_prgm_dly <=0)
			{	
				pgm3_prgm_on_flag=CLEAR;
				eeram_pgm3_up_down_counter1=pgm3_up_down_counter1;
				eeram_pgm3_fwd_rev_counter=pgm3_fwd_rev_counter;
				pgm3_prgm_mode_delay_flag = CLEAR;
				eeram_pgm3_save_flag=SET;
			}
			else
			{
				if(pgm3_prgm_dly<=45)
				{
					if((pgm3_up_down_counter1!=up_down_counter1)AND(!pgm3_repeat_flag))
					{
						if(up_down_counter1<pgm3_up_down_counter1)
						{
							if(!UP_ACTUATOR)
							{
								if((p1_7==1)AND(up_dwn_err_rmv_flag))
								{
									if(up_down_counter1>0)
									{
										up_down_counter1++;
									}
								}
								up_dwn_err_rmv_flag=CLEAR;
								up_dwn_err_rmv_flag1=SET;
								int1en=1;
								up_act_flag=SET;
								dwn_act_flag=CLEAR;
								up_pgm3_eql_wait_flag=SET;
								pgm3_prgm_mode_delay_flag = CLEAR;
								pgm3_up_dwn_disp_flag = SET;
								pgm3_up_dwn_pulse_err_flag = SET;
								UP_ACTUATOR_ON;
							}
						}
						else 
						{	
							if(up_down_counter1>pgm3_up_down_counter1)
							{					
								if(!DWN_ACTUATOR)
								{
									if((p1_7==1)AND(up_dwn_err_rmv_flag1))
									{							
										if(up_down_counter1>0)
										{
											up_down_counter1--;
										}
									}
									up_dwn_err_rmv_flag1=CLEAR;							
									up_dwn_err_rmv_flag=SET;
									int1en=1;
									dwn_act_flag=SET;
									up_act_flag=CLEAR;
									dwn_pgm3_eql_wait_flag=SET;
									pgm3_prgm_mode_delay_flag = CLEAR;
									pgm3_up_dwn_disp_flag = SET;
									pgm3_up_dwn_pulse_err_flag = SET;
									DWN_ACTUATOR_ON;
								}
							}
						
						}			
					}
					if((pgm3_fwd_rev_counter!=fwd_rev_counter)AND(!pgm3_repeat_flag))
					{
						if(fwd_rev_counter>pgm3_fwd_rev_counter)
						{
							if(!REV_ACTUATOR)
							{
								if((p4_5==1)AND(err_rmv_flag1))
								{
									if(fwd_rev_counter>0)
									{
										fwd_rev_counter--;
									}
								}													
								err_rmv_flag1=CLEAR;											
								int0en=1;
								rev_act_flag=SET;
								fwd_act_flag=CLEAR;
								err_rmv_flag = SET;							
								rev_pgm3_eql_wait_flag=SET;
								pgm3_prgm_mode_delay_flag = CLEAR;
								pgm3_fwd_rev_disp_flag = SET;
								pgm3_fwd_rev_pulse_err_flag=SET;
								REV_ACTUATOR_ON;
							}
						}
						else
						{
						
							if(fwd_rev_counter<pgm3_fwd_rev_counter)
							{
								if(!FWD_ACTUATOR)
								{
									if((p4_5==1)AND(err_rmv_flag))
									{
										if(fwd_rev_counter>0)
										{
											fwd_rev_counter++;
										}
									}	
									int0en=1;
									fwd_act_flag=SET;
									rev_act_flag=CLEAR;
									err_rmv_flag1 = SET;
									err_rmv_flag=CLEAR;						
									fwd_pgm3_eql_wait_flag=SET;
									pgm3_prgm_mode_delay_flag = CLEAR;
									pgm3_fwd_rev_disp_flag = SET;
									pgm3_fwd_rev_pulse_err_flag=SET;
									FWD_ACTUATOR_ON;
								}
							}
						}
					}
				}
			}
		}	
	}*/
/**********************************ZERO_SW********************************************/
	if((zero_sw_flag)OR(foot_zero_sw_flag))									
	{
		zero_prgm_mode_delay_flag=CLEAR;
		if(!zero_prgm_mode_delay_flag)
		{
			zero_prgm_mode_delay_flag = SET;
			zero_on_delay=60;
			if(zero_repeat_flag)
			{
				zero_repeat_flag = CLEAR;
				
			}
		}		
	}
	else
	{
		if(zero_on_delay<=45)
		{
			if(!zero_repeat_flag)
			{
				if(zero_prgm_mode_delay_flag)
				{	
				//	spit_sw_flag = SET;	
					LAMP_LOW_OFF;
					LAMP_HIGH_OFF;
					lamp_sw_flag=CLEAR;
					lamp_low_sw_flag = CLEAR;
					lamp_high_sw_flag = CLEAR;
					spit_on_dly=eeram_spit_prgm_on_delay;
					if((spit_on_dly)AND(!spitoon_repeat_flag))
					{
						SPITOON_ON;	
						spit_on_flag=SET;			//FOR RESEND LED & DISPLAY UPDATE TO TRAY BRD
						
					}										
					if(!DWN_ACTUATOR)
					{
						if((p1_7==1)AND(up_dwn_err_rmv_flag1))
						{								
							if(up_down_counter1>0)
							{
								up_down_counter1--;
							}
						}
						int1en=1;
						dwn_act_flag=SET;
						up_act_flag=CLEAR;
						zero_eql_wait_flag=SET;
						err_rmv_flag=SET;
						zero_prgm_mode_delay_flag = CLEAR;
						zero_up_dwn_disp_flag = SET;
						zero_up_dwn_pulse_err_flag = SET;
						DWN_ACTUATOR_ON;
						up_dwn_act_off_timer=0;
						pulse_timer_up_dn=0;
					}
					if(!FWD_ACTUATOR)
					//if(!REV_ACTUATOR)
					{
						if((p4_5==1)AND(err_rmv_flag))
						{
							/*if(fwd_rev_counter>0)
							{
								fwd_rev_counter++;
							}*/
							if(fwd_rev_counter>0)
							{
								fwd_rev_counter--;
							}
						}	
						int0en=1;
						fwd_act_flag=SET;
						rev_act_flag=CLEAR;
						//fwd_act_flag=CLEAR;
						//rev_act_flag=SET;
						//err_rmv_flag=SET;
						up_dwn_err_rmv_flag1=SET;
						fwd_zero_eql_wait_flag=SET;
						zero_prgm_mode_delay_flag = CLEAR;
						zero_fwd_rev_disp_flag = SET;
						zero_fwd_rev_pulse_err_flag=SET;
						FWD_ACTUATOR_ON;
						act_off_timer=0;
						pulse_timer = 0x00;
						//REV_ACTUATOR_ON;
					}
				}
			}
		}
	}
/*************************************SHARK_KEY*****************************************/
	/*if(shark_sw_flag)									
	{
		if(!shark_prgm_mode_delay_flag)
		{
			shark_prgm_mode_delay_flag = SET;
			shark_on_delay=60;
			if(shark_repeat_flag)
				shark_repeat_flag=CLEAR;
		}
	}
	else
	{
		if(shark_on_delay<=45)
		{
			 if(!shark_repeat_flag)
			 {
				if(shark_prgm_mode_delay_flag)
				{				
					if(!UP_ACTUATOR)
					{
						if((p1_7==1)AND(up_dwn_err_rmv_flag))
						{
							if(up_down_counter1>0)
							{
								up_down_counter1++;
							}
						}
						up_dwn_err_rmv_flag=CLEAR;
						up_dwn_err_rmv_flag1=SET;
						int1en=1;
						up_act_flag=SET;
						dwn_act_flag=CLEAR;
						up_shark_eql_wait_flag=SET;
						shark_prgm_mode_delay_flag = CLEAR;
						shark_up_dwn_disp_flag = SET;
						shark_up_dwn_pulse_err_flag = SET;			//FOR SEND THE UART DATA AND UNEXPECTED PULSE ERROR ACTUATOR OFF FLAG
						UP_ACTUATOR_ON;
					}		
					if(!REV_ACTUATOR)
					{
						if((p4_5==1)AND(err_rmv_flag1))
						{
							if(fwd_rev_counter>0)
							{
								fwd_rev_counter--;
							}
						}													
						err_rmv_flag1=CLEAR;											
						int0en=1;
						rev_act_flag=SET;
						fwd_act_flag=CLEAR;
						err_rmv_flag = SET;	
						rev_shark_eql_wait_flag=SET;
						shark_fwd_rev_disp_flag = SET;
						shark_fwd_rev_pulse_err_flag=SET;	//FOR SEND THE UART DATA AND UNEXPECTED PULSE ERROR ACTUATOR OFF FLAG
						shark_prgm_mode_delay_flag = CLEAR;
						REV_ACTUATOR_ON;
					}
				}	
			}
		}
	}*/
/************************************Gaugle_KEY***************************************/
	if(gaugle_sw_flag)									
	{
		if(!gaugle_prgm_mode_delay_flag)
		{
			if(gaugle_repeat_flag)
			gaugle_repeat_flag=CLEAR;
			gaugle_prgm_dly = 60;
			gaugle_prgm_mode_delay_flag = SET;
		}
/*		else
		{
			if(gaugle_prgm_dly<=0)
			{	
				gaugle_prgm_on_flag=SET;			
				gaugle_fwd_rev_counter=fwd_rev_counter;
				BUZZER_ON;
			}
		}*/
	}
	else
	{
		if(gaugle_prgm_mode_delay_flag)
		{
		/*	if(gaugle_prgm_dly <=0)
			{	
				gaugle_prgm_on_flag=CLEAR;		
				eeram_gaugle_fwd_rev_counter=gaugle_fwd_rev_counter;
				gaugle_prgm_mode_delay_flag = CLEAR;
				eeram_gaugle_save_flag=SET;
			}
			else */
			{
				if(gaugle_prgm_dly <=45)
				{
					if(!gaugle_repeat_flag)
					{
						if(gaugle_key_flag)
						{
						//	if(temp_gaugle_fwd_rev_counter<gaugle_fwd_rev_counter)
							{								
								LAMP_LOW_ON;
								lamp_low_sw_flag = SET;
								spit_on_dly=eeram_spit_prgm_on_delay;
								if((spit_on_dly)AND(!spitoon_repeat_flag))
								{
									SPITOON_ON;	
									spit_on_flag=SET;			//FOR RESEND LED & DISPLAY UPDATE TO TRAY BRD								
								}
								if(!REV_ACTUATOR)
								{
									if((p4_5==1)AND(err_rmv_flag1))
									{
										/*if(fwd_rev_counter>0)
										{
											fwd_rev_counter--;
										}*/
										if(fwd_rev_counter<=10000)
										{
											fwd_rev_counter++;
										}
									}													
									err_rmv_flag1=CLEAR;											
									int0en=1;
									rev_act_flag=SET;
									fwd_act_flag=CLEAR;
									err_rmv_flag = SET;	
									//err_rmv_flag1=SET;
									REV_ACTUATOR_ON;
									rev_gaugle_eql_wait_flag=SET;
									gaugle_fwd_rev_disp_flag = SET;
									gaugle_fwd_rev_pulse_err_flag=SET;
									gaugle_key_flag = CLEAR;
									gaugle_prgm_mode_delay_flag = CLEAR;
									act_off_timer=0;
									pulse_timer = 0x00;
								}	
							}
						}
						else
						{
							temp_gaugle_fwd_rev_counter = fwd_rev_counter;
						//	if(gaugle_fwd_rev_counter>temp_gaugle_fwd_rev_counter)
							{
								LAMP_LOW_OFF;
								LAMP_HIGH_OFF;
								lamp_sw_flag=CLEAR;
								lamp_low_sw_flag = CLEAR;
								lamp_high_sw_flag = CLEAR;
								if(!FWD_ACTUATOR)
								{
									if((p4_5==1)AND(err_rmv_flag))
									{
										/*if(fwd_rev_counter>0)
										{
											fwd_rev_counter++;
										}*/
										if(fwd_rev_counter>0)
										{
											fwd_rev_counter--;
										}
									}	
									int0en=1;
									fwd_act_flag=SET;
									rev_act_flag=CLEAR;
									err_rmv_flag1 = SET;
									err_rmv_flag=CLEAR;								
									FWD_ACTUATOR_ON;
									gaugle_key_flag = SET;																
									fwd_gaugle_eql_wait_flag=SET;
									gaugle_fwd_rev_disp_flag = SET;
									gaugle_fwd_rev_pulse_err_flag=SET;
									gaugle_prgm_mode_delay_flag = CLEAR;										
									act_off_timer=0;
									pulse_timer = 0x00;
								}
							}
						}						
					}
				}			
			}			
		}			
	}
}	

void up_dwn_actutor_current_position_store()
{
	temp_up_down_counter1 = up_down_counter1;
	eeprom_write(eeprom_up_dwn_actuator_position_one1,temp_up_down_counter1);
	//delay(0x02);
	temp_up_down_counter1 = temp_up_down_counter1>>8;
	eeprom_write(eeprom_up_dwn_actuator_position_two,temp_up_down_counter1);		
	/*delay(0x02);
	INDICATOR_OFF;	
	delay(0x02);	
	INDICATOR_ON;*/
}

void fwd_rev_actutor_current_position_store()
{
	temp_fwd_rev_counter = fwd_rev_counter;
	eeprom_write(eeprom_fwd_rev_actuator_position_one,temp_fwd_rev_counter);
	//delay(0x02);
	temp_fwd_rev_counter = temp_fwd_rev_counter>>8;
	eeprom_write(eeprom_fwd_rev_actuator_position_two,temp_fwd_rev_counter);
	/*INDICATOR_OFF;	
	delay(0x02);	
	INDICATOR_ON;*/
}

void zero_gaugle_process_actuator_position_store()
{
	/*if(zero_eql_wait_flag)
	{
		up_dwn_actutor_current_position_store();
	}
	if((fwd_zero_eql_wait_flag)OR(rev_gaugle_eql_wait_flag)OR(fwd_gaugle_eql_wait_flag))
	{
		fwd_rev_actutor_current_position_store();
	}*/
}	

void tumbler_test_mode()
{
	if(tumbler_test_mode_flag)
	{
		if(tumbler_test_mode_on_time<=0)
		{
			TMBLR_OFF;
			tumbler_test_mode_on_time=40;
			tumbler_test_mode_flag=CLEAR;
		}
	}
	else
	{
		if(tumbler_test_mode_on_time<=0)
		{
			TMBLR_ON;
			tumbler_test_mode_on_time=100;
			tumbler_test_mode_flag=SET;
		}
	}
}

void spitoon_test_mode()
{
	if(spitoon_test_mode_flag)
	{
		if(spitoon_test_mode_on_time<=0)
		{
			SPITOON_OFF;
			spitoon_test_mode_on_time=40;
			spitoon_test_mode_flag=CLEAR;
		}
	}
	else
	{
		if(spitoon_test_mode_on_time<=0)
		{
			SPITOON_ON;
			spitoon_test_mode_on_time=100;
			spitoon_test_mode_flag=SET;
		}
	}
}