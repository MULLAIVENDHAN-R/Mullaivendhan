#ifndef MACROS_H
#define MACROS_H

extern unsigned char iot_compenent_name[10];

#define AND 			&&
#define OR 			||
#define EQUAL_TO		==
#define NOT_EQUAL_TO		!=
#define SET			1
#define CLEAR			0
#define HIGH			1
#define LOW			0
#define ON			1
#define OFF			0

#define BUZZER			P3.1
#define BUZZER_ON		BUZZER=1
#define BUZZER_OFF		BUZZER=0

#define TURN_TABLE_OP		P5.3
#define TURN_TABLE_OP_ON	TURN_TABLE_OP=1,iot_compenent_name[2]=HIGH
#define TURN_TABLE_OP_OFF	TURN_TABLE_OP=0,iot_compenent_name[2]=HIGH

#define EXHAUST_FAN_OP		P5.2
#define EXHAUST_FAN_OP_ON	EXHAUST_FAN_OP=1	
#define EXHAUST_FAN_OP_OFF	EXHAUST_FAN_OP=0

#define IND_LIGHT_OP		P5.0
#define IND_LIGHT_OP_ON		IND_LIGHT_OP=1
#define IND_LIGHT_OP_OFF	IND_LIGHT_OP=0

#define BURNER_OP		P5.1
#define BURNER_OP_ON		BURNER_OP=1,burner_on_flag=SET,iot_compenent_name[4]=HIGH
#define BURNER_OP_OFF		BURNER_OP=0,burner_on_flag=CLEAR,iot_compenent_name[4]=HIGH

#define BUZZER_OP		P5.7
#define BUZZER_OP_ON		BUZZER_OP=1
#define BUZZER_OP_OFF		BUZZER_OP=0

#define STEAM_SOLE_OP		P5.6
#define STEAM_SOLE_OP_ON	STEAM_SOLE_OP=1
#define STEAM_SOLE_OP_OFF	STEAM_SOLE_OP=0

#define BLOWER_OP		P5.4	
#define BLOWER_OP_ON		BLOWER_OP=1,iot_compenent_name[3]=HIGH
#define BLOWER_OP_OFF		BLOWER_OP=0,iot_compenent_name[3]=HIGH

/*#define BLOWER_OP_FWD		P2.4
#define BLOWER_OP_REV		P2.5
#define BLOWER_OP_PWM		P2.6
#define BLOWER_CRNT_SENSE	P2.7
#define BLOWER_OP_FWD_ON	BLOWER_OP_FWD=1,BLOWER_OP_REV=0,BLOWER_OP_PWM=1
#define BLOWER_OP_REV_ON	BLOWER_OP_FWD=0,BLOWER_OP_REV=1,BLOWER_OP_PWM=1
#define BLOWER_OP_OFF		BLOWER_OP_FWD=0,BLOWER_OP_REV=0,BLOWER_OP_PWM=0*/


#define EXTRA_OP1		P5.5
#define EXTRA_OP1_ON		EXTRA_OP1=1
#define EXTRA_OP1_OFF		EXTRA_OP1=0

#define EXTRA_OP2		P1.7
#define EXTRA_OP2_ON		EXTRA_OP2=1
#define EXTRA_OP2_OFF		EXTRA_OP2=0

#define EXTRA_OP3		P1.6
#define EXTRA_OP3_ON		EXTRA_OP3=1
#define EXTRA_OP3_OFF		EXTRA_OP3=0

#define EXTRA_OP4		P1.5
#define EXTRA_OP4_ON		EXTRA_OP4=1
#define EXTRA_OP4_OFF		EXTRA_OP4=0

#define EXTRA_OP5		P1.4
#define EXTRA_OP5_ON		EXTRA_OP5=1
#define EXTRA_OP5_OFF		EXTRA_OP5=0

#define EXTRA_OP6		P1.3
#define EXTRA_OP6_ON		EXTRA_OP6=1
#define EXTRA_OP6_OFF		EXTRA_OP6=0

#define EXTRA_OP7		P1.0
#define EXTRA_OP7_ON		EXTRA_OP7=1
#define EXTRA_OP7_OFF		EXTRA_OP7=0

#define EXTRA_OP8		P10.1
#define EXTRA_OP8_ON		EXTRA_OP8=1
#define EXTRA_OP8_OFF		EXTRA_OP8=0

#define EXTRA_OP9		P11.0
#define EXTRA_OP9_ON		EXTRA_OP9=1
#define EXTRA_OP9_OFF		EXTRA_OP9=0

#define EXTRA_OP10		P11.1
#define EXTRA_OP10_ON		EXTRA_OP10=1
#define EXTRA_OP10_OFF		EXTRA_OP10=0

#define EXTRA_OP11		P14.6
#define EXTRA_OP11_ON		EXTRA_OP11=1
#define EXTRA_OP11_OFF		EXTRA_OP11=0

#define EXTRA_OP12		P14.7
#define EXTRA_OP12_ON		EXTRA_OP12=1
#define EXTRA_OP12_OFF		EXTRA_OP12=0

#define ALL_OUTPUTS_ON		BUZZER_ON,TURN_TABLE_OP_ON,BLOWER_OP_ON,EXHAUST_FAN_OP_ON,IND_LIGHT_OP_ON,BURNER_OP_ON,BUZZER_OP_ON,STEAM_SOLE_OP_ON
#define ALL_OUTPUTS_OFF		BUZZER_OFF,TURN_TABLE_OP_OFF,BLOWER_OP_OFF,EXHAUST_FAN_OP_OFF,IND_LIGHT_OP_OFF,BURNER_OP_OFF,BUZZER_OP_OFF,STEAM_SOLE_OP_OFF;//,bake_start_flag=0//temp_baking_time=temp_steam_time=0

#define ALL_INPUTS_FINE		((!emergency_switch_close_flag)AND(ctemp<350)AND(!blower_trip_switch_close_flag)AND(!tt_trip_switch_close_flag)AND(!thermo_trip_switch_close_flag)AND(!burner_trip_switch_close_flag)AND(err_occured_flag)) 	


#define DOOR_SWITCH		P4.1
#define TURN_TABLE_SWITCH	P4.2

#define BLOWER_TRIP_SWITCH	P4.3
#define TURNTABLE_TRIP_SWITCH	P4.4
#define THERMOSTAT_TRIP_SWITCH	P12.4
#define BURNER_TRIP_SWITCH	P12.3
#define EMERGENCY_SWITCH	P13.7
#define TT_MANUAL_SWITCH	P12.2

#define EXTRA_SW1		P12.1
#define EXTRA_SW2		P7.7
#define EXTRA_SW3		P7.6
#define EXTRA_SW4		P7.5
#define EXTRA_SW5		P7.4
#define EXTRA_SW6		P7.3
#define EXTRA_SW7		P7.2
#define EXTRA_SW8		P7.1
#define EXTRA_SW9		P7.0
#define EXTRA_SW10		P4.5
#define EXTRA_SW11		P4.6
#define EXTRA_SW12		P4.7
#define EXTRA_SW13		P12.0

#define TEMP_SENSE1		P2.2
#define TEMP_SENSE2		P2.3

#define HYSTERSIS_TEMP		3



/*************************************RTC******************************/

#define SCL			P6.0
#define SDA			P6.1
#define SDA_INPUT		PM6.1=1  
#define SDA_OUTPUT		PM6.1=0


#define RTC_WRITE 			0x64
#define RTC_READ        		0x65

#define EEPROM_WRITE    		0xa6
#define EEPROM_READ     		0Xa7

#define RTC_SECONDS 			0x10
#define RTC_MINUTES			0x11
#define RTC_HOURS			0x12
#define RTC_DAY				0x13
#define RTC_DATE			0x14
#define RTC_MONTH			0x15
#define RTC_YEAR			0x16


#define SUNDAY				0x01
#define MONDAY				0x02
#define TUESDAY				0x03
#define WEDNESDAY			0x04
#define THURSDAY			0x05
#define FRIDAY				0x06
#define SATURDAY			0x07


#define eeprom_rtc_year			10

/*************************************RTC******************************/

#define TEMP_DELAY 		10  // mullai

/***********************************STEP SEQUENCE*************************/
#define TURN_TABLE_ON		1
#define BLOWER_BURNER_ON	2
#define TEMP_MAINTAINING	3

/*********************************CHECK_OUTPUTS*****************************/
#define TURN_TABLE_ON_OFF	1
#define BLOWER_ON_OFF		2
#define STEAM_VAL_ON_OFF	3
#define EXHAUST_FAN_ON_OFF	4
#define INDI_LIGHT_ON_OFF	5
#define BURNER_ON_OFF		6
#define MQTT_TEST_MODE_ON_OFF	9

/*********************************CHECK_OUTPUTS*****************************/


#endif