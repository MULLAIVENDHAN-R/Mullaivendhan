/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_timer_user.c
* Version      : CodeGenerator for RL78/G13 V2.05.06.02 [08 Nov 2021]
* Device(s)    : R5F100JE
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for TAU module.
* Creation Date: 10/15/2023
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTTM00 r_tau0_channel0_interrupt
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_timer.h"
/* Start user code for include. Do not edit comment generated here */
#include "X_variables.h"
#include "MACROS.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */

unsigned int live_status_counter,i2c_read_sensor_counter;
extern  boolean   SHT20_humidity_flag,SHT20_temp_flag,mcp_presure_flag,mcp_temp_flag;
boolean toggle_flag;
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: r_tau0_channel0_interrupt
* Description  : This function is INTTM00 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void r_tau0_channel0_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
   	
    	
	
	if(++one_mili_second_counter > 20)			//1ms
	{
		one_mili_second_counter = 0;
		
		if(sh_count>0)
			sh_count--;
			
		if(trasmit_dly>0)
		trasmit_dly--;
		
		if(delay>0)
		delay--;
			
		
		if(++door_open_check_timer >= 250)
		door_open_check_timer=0;
		
		if(++door_close_check_timer >= 250)
		door_close_check_timer=0;
		
		if(++one_sec_counter>=1000)				// one sec
		{
			one_sec_counter=0;
			
			if((handshake_ok_flag)AND(machine_ready_ok_flag))
			{
				
				if(++heart_beat_counter>=HEARTBEAT_SEC)	
				{
				    heart_beat_counter=0;
				    heart_beat_send_flag=SET;
				}
				if(!send_temperature_flag)
				{
					if(++send_temperature_counter>=TEMP_SEC)
					{
						send_temperature_flag=SET;
						send_temperature_counter=0;
					}
					
				}
				if(live_enter_ok_flag)
				{
					if((!output_status_flag)AND(!input_status_flag))
					live_status_counter++;
					
					if(live_status_counter==1)
						output_status_flag=SET;
						
					else if(live_status_counter==2)
					{
						input_status_flag=SET;
						live_status_counter=0;
					}
				}
				if((!sensors_read_flag)AND(!humidity_read_flag))
				{					
					if((!sensors_read_flag)AND(!toggle_flag))	
					{	
						i2c_read_sensor_counter++;
//						if(i2c_read_sensor_counter==1)
//						mcp_presure_flag=SET;
//						else
						if(i2c_read_sensor_counter==2)
						{
							mcp_temp_flag=SET;
							toggle_flag=SET;
						}
						if(i2c_read_sensor_counter)
						sensors_read_flag=SET;
						
					}					
					else if((!humidity_read_flag)AND(toggle_flag))	
					{	
						i2c_read_sensor_counter++;
						if(i2c_read_sensor_counter==3)						
						SHT20_humidity_flag=SET;
						else if(i2c_read_sensor_counter==4)						
						SHT20_temp_flag=SET;
						else if(i2c_read_sensor_counter>=5)
						{
							i2c_read_sensor_counter=0;
							toggle_flag=CLEAR;
						}
						if(i2c_read_sensor_counter)
						humidity_read_flag=SET;
					}					
					
				}
			}			
			if(handshake_ok_flag)
			{				
				if(machine_ready_delay>0)
				machine_ready_delay--;				
			}
			
			if(input_status_flag)			
				input_status_count++;
			
		}		
	}
	if(++fifty_milli_sec_counter>=1000)			// fifty mili sec
	{
		fifty_milli_sec_counter=0;
		if(process_start_flag)
		{
			if(steps_timing>0)
			steps_timing--;
		}
		
		if(fwd_pause_flag_flag)
		{
			if(motor_fwd_pause_time>0)
			motor_fwd_pause_time--;
		}
		
		if(fwd_on_time_flag)
		{		
			if(motor_fwd_on_time>0)
			motor_fwd_on_time--;
		}
		 
		if(rev_pause_flag_flag)
		{
			if(motor_rev_pause_time>0)
			motor_rev_pause_time--;
		}
		
		if(rev_on_time_flag)
		{
			if(motor_rev_on_time>0)
			motor_rev_on_time--;
		}		
		
	}
	
		 
			
	
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
