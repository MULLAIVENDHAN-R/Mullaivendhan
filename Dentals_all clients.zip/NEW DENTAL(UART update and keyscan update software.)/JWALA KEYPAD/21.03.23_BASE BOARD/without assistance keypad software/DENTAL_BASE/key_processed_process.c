#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"


extern void delay(unsigned char dly);
void uart_key_pressed_process();
void foot_key_pressed_process();


void uart_key_pressed_process()
{
	if(key_status_changed_flag)
	{
		key_status_changed_flag=CLEAR;	
		if(temp_serial_received_data!=KEYPAD_DATA)	
		{
			if((temp_serial_received_data&TUMB_SW_KEY)==0x00000000)
			{
				if(!tumb_sudden_enter_stop_flag)
				{
					if(!tumbler_on_flag)
					{
						tumbler_sw_flag = SET;
						tumbler_repeat_flag=CLEAR;
					}
					else if(tumbler_on_flag)
					{
						TMBLR_OFF;
						tumbler_on_flag=CLEAR;
						tumbler_repeat_flag=CLEAR;
						tumbler_sw_flag=CLEAR;
						tumb_on_dly=0x00;
						tumbler_prgm_dly=0x00;
						tumbler_prgm_mode_delay_flag=CLEAR;
						tumbler_prgm_on_flag = CLEAR;
						tumbler_prgm_on_delay=0;
//						tumb_sudden_enter_stop_flag = SET;
						/*uart_receive_input_flag=CLEAR;
						key_status_changed_flag=CLEAR;
						temp_serial_received_data=0x00000000;
//						keysense_resume_delay=5;*/
					}
				}						
			}
			else if((temp_serial_received_data&SPIT_SW_KEY)==0x00000000)
			{
				if(!spit_sudden_enter_stop_flag)
				{
					if(!spit_on_flag)
					{
						spit_sw_flag = SET;	
						spitoon_repeat_flag=CLEAR;					
					}
					else
					{
						if(spit_on_flag)
						{
							SPITOON_OFF;
							spit_on_flag=CLEAR;
							spitoon_repeat_flag=CLEAR;
							spit_sw_flag=CLEAR;
							spit_on_dly=0x00;
							spit_prgm_dly=0x00;
							spit_prgm_mode_delay_flag = CLEAR;
							spit_prgm_on_flag = CLEAR;
							spit_prgm_on_delay=0;
							/*uart_receive_input_flag=CLEAR;
							key_status_changed_flag=CLEAR;
							temp_serial_received_data=0x00000000;
//							keysense_resume_delay=5;*/
//							spit_sudden_enter_stop_flag=SET;
						}
					/*	else if(spitoon_repeat_flag)
						{
							spitoon_repeat_flag=CLEAR;
						}*/
					}
				}		
			}
			/*else if(((temp_serial_received_data&PGM2_SW_KEY)==0x00000000)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag)
					AND(!asst_act_up_flag)AND(!aast_act_dwn_flag)AND(!asst_act_fwd_flag)AND(!asst_act_rev_flag)AND(!foot_rev_sw_flag)AND(!foot_up_sw_flag)AND(!foot_dwn_sw_flag)AND(!foot_fwd_sw_flag))
			{
				pgm2_sw_flag = SET;	
				gaugle_key_flag = CLEAR;
				if((rev_pgm2_eql_wait_flag)OR(fwd_pgm2_eql_wait_flag)OR(up_pgm2_eql_wait_flag)OR(dwn_pgm2_eql_wait_flag))	
				{
					if((rev_pgm2_eql_wait_flag)OR(fwd_pgm2_eql_wait_flag))
					fwd_rev_pgm2_off_flag=SET;
					if((up_pgm2_eql_wait_flag)OR(dwn_pgm2_eql_wait_flag))
					up_dwn_pgm2_off_flag=SET;
				}
						
			}*/
			else if((temp_serial_received_data&ACT_UP_KEY)==0x00000000)
			{
				act_up_flag = SET;
			//	if((!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))	
			//	gaugle_key_flag = CLEAR;											
			}
			else if(((temp_serial_received_data&ZERO_SW_KEY)==0x00000000)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)AND(!dwn_pgm2_eql_wait_flag)
					AND(!asst_act_up_flag)AND(!aast_act_dwn_flag)AND(!asst_act_fwd_flag)AND(!asst_act_rev_flag)AND(!foot_rev_sw_flag)AND(!foot_up_sw_flag)AND(!foot_dwn_sw_flag)AND(!foot_fwd_sw_flag))
			{			
				zero_sw_flag = SET;	
				gaugle_key_flag = CLEAR;
				spitoon_repeat_flag=CLEAR;
				fwd_rev_zero_off_flag=CLEAR;
				up_dwn_zero_off_flag=CLEAR;
				if((fwd_zero_eql_wait_flag)OR(zero_eql_wait_flag))
				{
					if(fwd_zero_eql_wait_flag)
					fwd_rev_zero_off_flag=SET;
					if(zero_eql_wait_flag)
					up_dwn_zero_off_flag=SET;	
				}					
			}
			/*else if((temp_serial_received_data&0x00080000)==0x00000000)
			{
				aeroter_sw_flag=SET;			//AERO_SW_KEY							   
			}*/
			else if((temp_serial_received_data&ACT_DWN_KEY)==0x00000000)
			{
				act_dwn_flag = SET;	
				//if((!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
			//	gaugle_key_flag = CLEAR;	   
			}
	/*		else if((temp_serial_received_data&PGM3_SW_KEY)==0x00000000)
			{
				pgm3_sw_flag = SET;
				gaugle_key_flag = CLEAR;
				if((rev_pgm3_eql_wait_flag)OR(fwd_pgm3_eql_wait_flag)OR(up_pgm3_eql_wait_flag)OR(dwn_pgm3_eql_wait_flag))	
				{
					fwd_rev_pgm3_off_flag=SET;
					up_dwn_pgm3_off_flag=SET;
				}
			}*/
			/*else if(((temp_serial_received_data&GARGLE_SW_KEY)==0x00000000)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)
					AND(!asst_act_up_flag)AND(!aast_act_dwn_flag)AND(!asst_act_fwd_flag)AND(!asst_act_rev_flag)AND(!foot_rev_sw_flag)AND(!foot_up_sw_flag)AND(!foot_dwn_sw_flag)AND(!foot_fwd_sw_flag))
			{
				gaugle_sw_flag = SET;
				spitoon_repeat_flag=CLEAR;
				if((fwd_gaugle_eql_wait_flag)OR(rev_gaugle_eql_wait_flag))
				{
					fwd_rev_gaugle_off_flag=SET;
				}
			}*/
			else if((temp_serial_received_data&ACT_REV_KEY)==0x00000000)
			{
				act_rev_flag = SET;	
				gaugle_key_flag = CLEAR;			
			}
	/*		else if((temp_serial_received_data&SHARK_SW_KEY)==0x00000000)
			{
				shark_sw_flag = SET;
				gaugle_key_flag = CLEAR;
				if((rev_shark_eql_wait_flag)OR(up_shark_eql_wait_flag))	
				{
					fwd_rev_shark_off_flag=SET;
					up_dwn_shark_off_flag=SET;
				}
			}*/
			/*else if(((temp_serial_received_data&PGM1_SW_KEY)==0x00000000)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag)AND(!dwn_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)
					AND(!asst_act_up_flag)AND(!aast_act_dwn_flag)AND(!asst_act_fwd_flag)AND(!asst_act_rev_flag)AND(!foot_rev_sw_flag)AND(!foot_up_sw_flag)AND(!foot_dwn_sw_flag)AND(!foot_fwd_sw_flag))
			{
				pgm1_sw_flag = SET;	
				gaugle_key_flag = CLEAR;
				
				if((rev_pgm1_eql_wait_flag)OR(fwd_pgm1_eql_wait_flag)OR(up_pgm1_eql_wait_flag)OR(dwn_pgm1_eql_wait_flag))	
				{
					if((rev_pgm1_eql_wait_flag)OR(fwd_pgm1_eql_wait_flag))
					fwd_rev_pgm1_off_flag=SET;
					if((up_pgm1_eql_wait_flag)OR(dwn_pgm1_eql_wait_flag))
					up_dwn_pgm1_off_flag=SET;
				}							
			}*/			
			else if((temp_serial_received_data&LAMP_SW_KEY)==0x00000000)
			{			
				lamp_sw_flag = SET;				//LAMP_SW_KEY									
			}
			else if((temp_serial_received_data&ACT_FWD_KEY)==0x00000000)
			{
				act_fwd_flag = SET;	
				gaugle_key_flag = CLEAR;							
			}
		}	
	}		
 }
void foot_key_pressed_process()
{
	if(foot_key_status_changed_flag)
	{
		foot_key_status_changed_flag=CLEAR;
		if((temp_foot_key_data==0x1E)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
		{
			//foot_zero_sw_flag= SET;		
			foot_rev_sw_flag= SET;		//rev
		}
		/*if(temp_foot_key_data==0x3C)//3A
		{
			//foot_up_sw_flag = SET;		
			foot_zero_sw_flag= SET;		//zero
		}*/
		else if((temp_foot_key_data==0x3A)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))	//36	
		{
			//foot_dwn_sw_flag= SET;		
			foot_up_sw_flag = SET;		//UP
		}
		else if((temp_foot_key_data==0x36)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))//3A
		{
			//foot_fwd_sw_flag= SET;				
			foot_dwn_sw_flag= SET;		//DN
		}
		else if((temp_foot_key_data==0x2E)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))//1E
		{
			//foot_rev_sw_flag= SET;			
			foot_fwd_sw_flag= SET;		//FW
		}
	}	
}

void assistance_key_pressed_process()
{
	assistance_key_status_changed_flag = CLEAR;	
		/*if(temp_assistance_key_data==0xb1)
		{
			zero_sw_flag = SET;
			gaugle_key_flag = CLEAR;
			if((fwd_zero_eql_wait_flag)OR(zero_eql_wait_flag))
			{
				fwd_rev_zero_off_flag=SET;
				up_dwn_zero_off_flag=SET;	
			}
		}*/
		if(temp_assistance_key_data==ASST_TUMBLER_KEY)
		{
			if(!tumb_sudden_enter_stop_flag)
			{
				if(!tumbler_on_flag)
				{
					tumbler_sw_flag = SET;
					tumbler_repeat_flag=CLEAR;
				}
				else if(tumbler_on_flag)
				{
					TMBLR_OFF;				
					tumbler_repeat_flag=CLEAR;
					tumbler_on_flag=CLEAR;
					tumbler_sw_flag=CLEAR;
					tumb_on_dly=0x00;				
					tumbler_prgm_dly=0x00;
					tumbler_prgm_mode_delay_flag=CLEAR;
					tumbler_prgm_on_flag = CLEAR;
					tumbler_prgm_on_delay=0;
//					tumb_sudden_enter_stop_flag = SET;
					/*uart_receive_input_flag=CLEAR;
					key_status_changed_flag=CLEAR;
					temp_serial_received_data=0x00000000;
					keysense_resume_delay=10;*/
				}
			}			
		}
		else
		tumbler_sw_flag=CLEAR;
		if(temp_assistance_key_data==ASST_SPITOON_KEY)
		{
			if(!spit_sudden_enter_stop_flag)
			{
				if(!spit_on_flag)
				{
					spit_sw_flag = SET;	
					spitoon_repeat_flag=CLEAR;					
				}
				else
				{
					if(spit_on_flag)
					{
						SPITOON_OFF;
						spit_on_flag=CLEAR;
						spitoon_repeat_flag=CLEAR;
						spit_sw_flag=CLEAR;
						spit_on_dly=0x00;
						spit_prgm_dly=0x00;
						spit_prgm_mode_delay_flag = CLEAR;
						spit_prgm_on_flag = CLEAR;
						spit_prgm_on_delay=0;
						/*uart_receive_input_flag=CLEAR;
						key_status_changed_flag=CLEAR;
						temp_serial_received_data=0x00000000;
						keysense_resume_delay=10;*/
//						spit_sudden_enter_stop_flag = SET;
					}				
				}
			}
		}
		else
		{
			spit_sw_flag=CLEAR;
		}
		/*if(temp_assistance_key_data==0x99)
		{
			gaugle_sw_flag = SET;
			if((fwd_gaugle_eql_wait_flag)OR(rev_gaugle_eql_wait_flag))
			{
				fwd_rev_gaugle_off_flag=SET;
			}
		}*/
		if(temp_assistance_key_data==ASST_LAMP_KEY)
		{
			lamp_sw_flag = SET;
			//conti_lamp_flag=CLEAR;
		}
		
		if((temp_assistance_key_data==ASST_ACTUP_KEY)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
		{
			asst_act_up_flag = SET;	
			//if((!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
			//gaugle_key_flag = CLEAR;											
		}
		else
		asst_act_up_flag=CLEAR;		
		
		if((temp_assistance_key_data==ASST_ACTDWN_KEY)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
		{
			aast_act_dwn_flag = SET;
			//if((!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))	
			//gaugle_key_flag = CLEAR;	   
		}
		else
		aast_act_dwn_flag=CLEAR;
				
		if((temp_assistance_key_data==ASST_ACTFWD_KEY)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
		{
			asst_act_fwd_flag = SET;	
			if((!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
			gaugle_key_flag = CLEAR;							
		}	
		else
		asst_act_fwd_flag=CLEAR;
		
		if((temp_assistance_key_data==ASST_ACTREV_KEY)AND(!fwd_pgm1_eql_wait_flag)AND(!rev_pgm1_eql_wait_flag)AND(!up_pgm1_eql_wait_flag)AND(!dwn_pgm1_eql_wait_flag)AND(!fwd_pgm2_eql_wait_flag)AND(!rev_pgm2_eql_wait_flag)AND(!up_pgm2_eql_wait_flag)
			AND(!dwn_pgm2_eql_wait_flag)AND(!zero_eql_wait_flag)AND(!fwd_zero_eql_wait_flag)AND(!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))
		{
			asst_act_rev_flag = SET;
			if((!fwd_gaugle_eql_wait_flag)AND(!rev_gaugle_eql_wait_flag))	
			gaugle_key_flag = CLEAR;			
		}
		else
		asst_act_rev_flag=CLEAR;			
}