#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"

void init_processor();                             /* Declaration of interrupts and functions */
void uart0_init(void);

void init_processor()
{
                              
	asm("FCLR I");                           /* Interrupt disable */
	prc0=1;                                  /* Protect off */

	/****************************************/
	/*          CPU Clock Setting	        */
	/****************************************/
	/* Note: Include asm("nop")for oscillator's stabilization period after clock setting is done. */
	
	fra20=0;fra21=0;fra22=0;                 /* Divide by 2 mode selected */
	cm13=0;cm05=1;cm02=0;cm14=0;ocd0=0;ocd1=0;fra00=1;fra01=1;/* High speed on-chip oscillator selected(cm0 bit 2 and 5, cm1 bit 4, ocd bit 0 and 1 and fra0 bit 0 and 1) */
	ocd2=1;                                  /* High speed on-chip oscillator selected(ocd bit 2) */
	cm16=0;cm17=0;cm06=0;                    /* No division selected(cm0 bit 6,cm1 bit 6 and 7) */
	

	prc0=0;                                 /* Protect on */          
			            

	
	prc2=1;                                  /* Enable write to PD0 */
	pd0=0x00;                                /* Port P0 direction register */
	pd1=0x5F;                                /*  Port P1 direction register */
	pd2=0xFF;                                /*  Port P2 direction register */
	p2drr=0x00;                              /*  Port P2 drive capacity control register */
	pd3=0x47;//0xBB;                                /*  Port P3 direction register */
	pd4=0x00;                                /*  Port P4 direction register */
	pd6=0xFF;
	p0=0x00; 	
//	p1=0x00;
	p2=0x00;
	//p3=0x00;
	//p4=0x00;
	p6=0xF0;		  
	/****************************************/
	/*	   Timer RA Setting                 */	
	/****************************************/
//	trapre=249;          //10msec               /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
//	tra=99;                                  /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
//	trapre=199;          //100Usec               /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
//	tra=9;                                  /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
	trapre=99;          //50Usec               /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
	tra=9;                                  /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
	tmod0_tramr=0;tmod1_tramr=0;tmod2_tramr=0;/* Timer mode selected(tramr bit 0, 1 and 2) */
	tck0_tramr=0;tck1_tramr=0;tck2_tramr=0;  /* Count source f8 selected(tramr bit 4, 5 and 6) */
	traic=0x04;                              /* Set interrupt priority level 6(traic) */
	tstart_tracr=1; //;	     		/* Set tstart_tracr=1 to start Timer RA counting */
	/* Note: Timer RA does not start yet for event counter mode. The first active edge of external signal is used not to decrement the timer count register but to start timer RA. The second active edge will trigger the first decrement on timer count register. */
   /****************************************/
	/*          INT1 Interrupt Setting      */
	/****************************************/
	/* Note: Set INT1 hardware interrupt pins to input. */
	/* Note:By default, INT1 pin is at P1_7 pin. */
	/* Note:To change to INT1 pin at P1_5 pin, set tiosel_traioc=1. */
	
	int1ic=0x17;                             /* Set interrupt priority level and active edge(int1ic) */
	int1en=1;                                /* Input enable disabled(inten bit 2) */
	int1pl=0;
	tiosel_traioc=0;                          /* One edge selected(inten bit 3) */
	int1f0=1; int1f1=1;                      /* sampling3 selected(intf bit 2 and 3) */
	

	/****************************************/
	/*          INT0 Interrupt Setting      */
	/****************************************/
	/* Note:Set INT0 hardware interrupt pins to input */
	 
	int0ic=0x16;                             /* Set interrupt priority level and active edge(int0ic) */
	int0en=1;                                /* Input enable disabled(inten bit 6) */
	int0pl=0;                                /* One edge selected(inten bit 7) */
	int0f0=1;int0f1=1;                      /* sampling selected(intf bit 6 and 7) */
	                          
								  
     /*VOLTAGE MONITER 1 POWER DOWN SAVE INTERRUPT*/ 
	 prc3 = 1;
	 vw1c0 = 1;
//	 vw1c1 = 1; 
	 vw1c2 = 1;
//	 vw1c3 = 1;
	 vw1c6 = 0; 
	 vw1c7 = 1;
	 vca26 = 1;
	 vw1c3 = 1;
//	 vw1c = 0x85;   
	asm("FSET I");									/* Protect on */   
	
}
void uart0_init(void)
{
	                  	//UART 0 Settings  
  lincr = 0x00;	
	smd0_u0mr=1;smd1_u0mr=0;smd2_u0mr=1;     /* UART mode transfer data 8 bits long selected(u0mr bit 0, 1 and 2) */
	ckdir_u0mr=0;                            /* Internal clock selected(u0mr bit 3) */
	stps_u0mr=0;                             /* 1 stop bit selected(u0mr bit 4) */
	prye_u0mr=0;                             /* Parity disabled(u0mr bit 6) */
	clk0_u0c0=0;
	clk1_u0c0=0;                 /* BRG count source f1 selected(u0c0 bit 0 and 1) */
	nch_u0c0=0;                              /* TXD0 pin CMOS output(u0c0 bit 5) */
	uform_u0c0=0;                            /* Transfer LSB first(u0c0 bit 7) */
	u0brg=42;  //57600-21   //19200-64  //9600-129    /* Setting UART0 baud rate generator(max 255). Calculated value is round to the nearest whole number */
	te_u0c1=1;
	re_u0c1=1;                     /* Transmission enabled(u0c1 bit 0) */	
//	u0rrm_u0c1 = 1;							//UART0 continuous receive mode enabled
	s0tic=0x00;                              /* Set UART0 transmit interrupt priority level 0(s0tic) */
	s0ric=0x05;                              /* Set UART0 receive interrupt priority level 6(s0ric) */
//	asm("FSET I");		                /* Interrupt enabled */	
		
}
void uart1_init(void)
{
	                  	//UART 0 Settings 
	
	smd0_u1mr=1;smd1_u1mr=0;smd2_u1mr=1;u1pinsel=1;u1sr=0x0F;     /* UART mode transfer data 8 bits long selected(u1mr bit 0, 1 and 2) */
	ckdir_u1mr=0;                            /* Internal clock selected(u1mr bit 3) */
	stps_u1mr=0;                             /* 1 stop bit selected(u1mr bit 4) */
	prye_u1mr=0;                             /* Parity disabled(u1mr bit 6) */
	clk0_u1c0=0;clk1_u1c0=0;                 /* BRG count source f8 selected(u1c0 bit 0 and 1) */
	nch_u1c0=0;                              /* TXD0 pin CMOS output(u1c0 bit 5) */
	uform_u1c0=0;                            /* Transfer LSB first(u1c0 bit 7) */
	u1brg=129;        //19200-64  //9600-129  /* Setting UART1 baud rate generator(max 255). Calculated value is round to the nearest whole number */
	te_u1c1=1;re_u1c1=1;                     /* Transmission enabled(u1c1 bit 0) */	
	u1rrm_u1c1 = 0;	
	u1irs_u1c1 = 0;						//UART1 continuous receive mode enabled
	s1tic=0x00;                              /* Set UART1 transmit interrupt priority level 0(s0tic) */
	s1ric=0x05;                             /* Set UART1 receive interrupt priority level 6(s0ric) */
//	asm("FSET I");		                /* Interrupt enabled */	

}
