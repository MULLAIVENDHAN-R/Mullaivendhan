#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include <stdlib.h>


char hex_code_conversion(char string_buf[],char index,char check_upto);


char *string_to_char[]={
			"    ",
			"IGM1",		/* 1 */
			"IGM2",		/* 2 */
			"IGM3",		/* 3 */
			"IGM4",		/* 4 */
			"IGM5",		/* 5 */
			"IGM6",		/* 6 */
			"IGM7",		/* 7 */
			"IGM8",		/* 8 */
			"IGM9",		/* 9 */
			"IGM10",	/* 10 */
			"IGM11",	/* 11 */
			"IGM12",	/* 12 */
			"IGM13",	/* 13 */
			"IGM14",	/* 14 */
			"IGM15",	/* 15 */
			"IGM16",	/* 16 */
			"IGM17",	/* 17 */
			"IGM18",	/* 18 */
			"IGM19",	/* 19 */
			"IGM20",	/* 20 */
			"IGM21",	/* 21 */
			"IGM22",	/* 22 */
			"IGM23",	/* 23 */
			"IGM24",	/* 24 */
			"IGM25",	/* 25 */
			"IGM26",	/* 26 */
			"IGM27",	/* 27 */
			"IGM28",	/* 28 */
			"IGM29",	/* 29 */
			"IGM30",	/* 30 */
			"IGM31",	/* 31 */
			"IGM32",	/* 32 */
			"IGM33",	/* 33 */
			"IGM34",	/* 34 */
			"IGM35",	/* 35 */			
			"IGM1S",	/* 36 */
			"IGM2S",	/* 37 */
			"IGM3S",	/* 38 */
			"IGM4S",	/* 39 */
			"IGM5S",	/* 40 */
			"IGM6S",	/* 41 */
			"IGM7S",	/* 42 */
			"IGM8S",	/* 43 */
			"IGM9S",	/* 44 */
			"IGM10S",	/* 45 */
			"IGM11S",	/* 46 */
			"IGM12S",	/* 47 */
			"IGM13S",	/* 48 */
			"IGM14S",	/* 49 */
			"IGM15S",	/* 50 */
			"IGM16S",	/* 51 */
			"IGM17S",	/* 52 */
			"IGM18S",	/* 53 */
			"IGM19S",	/* 54 */
			"IGM20S",	/* 55 */
			"IGM21S",	/* 56 */
			"IGM22S",	/* 57 */
			"IGM23S",	/* 58 */
			"IGM24S",	/* 59 */
			"IGM25S",	/* 60 */
			"IGM26S",	/* 61 */
			"IGM27S",	/* 62 */
			"IGM28S",	/* 63 */
			"IGM29S",	/* 64 */
			"IGM30S",	/* 65 */
			"IGM31S",	/* 66 */
			"IGM32S",	/* 67 */
			"IGM33S",	/* 68 */
			"IGM34S",	/* 69 */
			"IGM35S",	/* 70 */
			"IGM37SOL",	/* 71 */
			
			"IDLELOCK",	/* 72 */
			"LOCK",		/* 73 */
			"CKM",		/* 74 */			
						
			"LDM1",		/* 75 */		
			"LDM2",		/* 76 */
			"LDM3",		/* 77 */		
			"LDM4",		/* 78 */
			"LDM5",		/* 79 */		
			"LDM6",		/* 80 */			
			"VTM1",		/* 81 */	
			"VTM2",		/* 82 */	
			"VTM3",		/* 83 */
			
			
			"FMT",		/* 84 */
			"IDLE",		/* 85 */
			"STM1",		/* 86 */	
			"STM2",		/* 87 */	
			"STM3",		/* 88 */			
			"HTR1",		/* 89 */	
			"HTR2",		/* 90 */	
			"HTR3",		/* 91 */
			"IGM36HTR",	/* 92 */
			
			"OPB",		/* 93 */			
			"WPB",		/* 94 */
			
			"KTM1",		/* 95 */
			"KTM2",		/* 96 */
			"KHTR",		/* 97 */
					
			};


void str_to_process_buf_conversion()
{
	char i,j,byte=0,pipe_symbol_came=0;
	long int val;
	for(i=0,j=0;i<strlen(string_process_data_buf);i++)
	{
		if(!frame_err_flag)
		{
			if(string_process_data_buf[i]!='|')
			temp_string[j++]= string_process_data_buf[i];
			else
			{					
				if(((app_id==0X04)OR(app_id==0X02)OR(app_id==0X03))AND(i<=5))
				{
					pipe_symbol_came++;
					pipe_symbol_came++;
				}
				pipe_symbol_came++;
				if(pipe_symbol_came==1)			//cooker no
				{
					if(strcmp(temp_string,"C1")==0)
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"C2")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"C3")==0)
					process_data_buf[byte]=3;
					else
					frame_err_flag=SET;
				}
				if(pipe_symbol_came==2)			//step count
				{
					if((process_data_buf[0]==1)AND(!dish1_data_flag))
					c1_step_count=atoi(temp_string);
					if((process_data_buf[0]==2)AND(!dish2_data_flag))
					c2_step_count=atoi(temp_string);
					if((process_data_buf[0]==3)AND(!dish3_data_flag))
					c3_step_count=atoi(temp_string);
					byte--;
				}
				if(pipe_symbol_came==3)			//motor code
				{
					if((temp_string[0]=='I')AND(temp_string[1]=='D')AND(temp_string[4]=='L'))
					process_data_buf[byte]=hex_code_conversion(temp_string,IDLELOCK,IDLELOCK);
					else if((temp_string[0]=='I')AND(temp_string[1]=='D'))
					process_data_buf[byte]=hex_code_conversion(temp_string,IDLE,IDLE);					
					else if((temp_string[0]=='I')AND(temp_string[1]=='G')AND(temp_string[5]=='H'))
					process_data_buf[byte]=hex_code_conversion(temp_string,IGM36HTR,IGM36HTR);
					else if((temp_string[0]=='I')AND(temp_string[1]=='G')AND(temp_string[5]=='S')AND(temp_string[6]=='O'))
					process_data_buf[byte]=hex_code_conversion(temp_string,IGM37SOL,IGM37SOL);
					else if((temp_string[0]=='I')AND(temp_string[1]=='G')AND((temp_string[4]!='S')AND(temp_string[5]!='S')))
					process_data_buf[byte]=hex_code_conversion(temp_string,IGM1,IGM35);
					else if((temp_string[0]=='I')AND(temp_string[1]=='G')AND((temp_string[4]=='S')OR(temp_string[5]=='S')))
					process_data_buf[byte]=hex_code_conversion(temp_string,IGM1S,IGM35S);
					else if(temp_string[0]=='H')
					process_data_buf[byte]=hex_code_conversion(temp_string,HTR1,HTR3);
					
					else if((temp_string[0]=='L')AND(temp_string[1]=='O'))
					process_data_buf[byte]=hex_code_conversion(temp_string,LOCK,LOCK);
					else if((temp_string[0]=='L')AND(temp_string[1]=='D'))
					{
						if((temp_string[3]=='1')OR(temp_string[3]=='2'))
						process_data_buf[byte]=hex_code_conversion(temp_string,LDM1,LDM2);
						else if((temp_string[3]=='3')OR(temp_string[3]=='4'))
						process_data_buf[byte]=hex_code_conversion(temp_string,LDM3,LDM4);		// new added rb
						else if((temp_string[3]=='5')OR(temp_string[3]=='6'))
						process_data_buf[byte]=hex_code_conversion(temp_string,LDM5,LDM6);
						else
						frame_err_flag=SET;
						
					}
					else if(temp_string[0]=='V')
					process_data_buf[byte]=hex_code_conversion(temp_string,VTM1,VTM3);
					else if(temp_string[0]=='S')
					process_data_buf[byte]=hex_code_conversion(temp_string,STM1,STM3);
					else if(temp_string[0]=='F')
					process_data_buf[byte]=hex_code_conversion(temp_string,FMT,FMT);
					else if(temp_string[0]=='C')
					process_data_buf[byte]=hex_code_conversion(temp_string,CKM,CKM);
					else if(temp_string[0]=='O')
					{
						process_data_buf[byte]=hex_code_conversion(temp_string,OPB,OPB);
						if((is_model_1)AND(!frame_err_flag))
						process_data_buf[byte]=IGM35;						//IGM35 used as oil pump in model 1
					}						
					else if(temp_string[0]=='W')
					process_data_buf[byte]=hex_code_conversion(temp_string,WPB,WPB);
					else if((temp_string[0]=='K')AND(temp_string[1]=='T'))
					process_data_buf[byte]=hex_code_conversion(temp_string,KTM1,KTM2);
					else if((temp_string[0]=='K')AND(temp_string[1]=='H'))
					process_data_buf[byte]=hex_code_conversion(temp_string,KHTR,KHTR);
					else
					frame_err_flag=SET;
				}
				if(pipe_symbol_came==4)			//direction
				{
					if(strcmp(temp_string,"FWD")==0)
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"REV")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"POS1")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"POS2")==0)
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"POS3")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"NO")==0)
					process_data_buf[byte]=0;
					else
					frame_err_flag=SET;
					
				}
				if(pipe_symbol_came==5)			//action based (time/switch/pulse)
				{
					if(strcmp(temp_string,"TIM")==0)
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"LSW1")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW2")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW3")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW4")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW5")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW6")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW7")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW8")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW9")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW10")==0)
					process_data_buf[byte]=2;
					
					else if(strcmp(temp_string,"LSW11")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW12")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW13")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW14")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW15")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW16")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW17")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW18")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW19")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"LSW20")==0)
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"PUL")==0)
					process_data_buf[byte]=3;
					else if(strcmp(temp_string,"NO")==0)
					process_data_buf[byte]=0;
					else
					frame_err_flag=SET;					
					
				}
				if(pipe_symbol_came==6)			//Time Unit
				{
					if(strcmp(temp_string,"MS")==0)			//milli sec
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"P")==0)		//pulse
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"G")==0)		//grams
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"S")==0)		//secs
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"M")==0)		//mins
					process_data_buf[byte]=3;
					else if(strcmp(temp_string,"NO")==0)		//no time unit
					process_data_buf[byte]=0;
					else
					frame_err_flag=SET;
				}					
				byte++;
				j=0;
				memset(temp_string,0,sizeof(temp_string));				
			}
		}
	}
	if(!frame_err_flag)
	{
		if(temp_string[0]!='B')	//BOARD_ER Data
		{
			if(temp_string[0]=='O')
			{
				if(strcmp(temp_string,"ON")==0)
				process_data_buf[byte]=1;
				else if(strcmp(temp_string,"OFF")==0)
				process_data_buf[byte]=0;
				else
				frame_err_flag=SET;
			}
			else
			{
				val=atol(temp_string);
				process_data_buf[byte++]=val>>16;
				process_data_buf[byte++]=val>>8;
				process_data_buf[byte]=val;
			}
		}
		else
		frame_err_flag=SET;
	}
	memset(string_process_data_buf,0,sizeof(string_process_data_buf));
	string_process_data_flag=SET;
	
	
}
char hex_code_conversion(char string_buf[],char index,char check_upto)		//it returns index of pointer array which is motor code
{
	unsigned char byte;
	char *ptr,string_matched_flag;
	for(;index<check_upto+1;index++)
	{
		ptr=string_to_char[index];
		string_matched_flag=SET;
		for(byte=0;byte<strlen(string_buf);byte++)
		{
			if((*ptr++)!=string_buf[byte])
			{
				string_matched_flag=CLEAR;
				break;
			}
		}
		if(string_matched_flag)		
		return index;	
	}
	if(!string_matched_flag)
	frame_err_flag=SET;
}