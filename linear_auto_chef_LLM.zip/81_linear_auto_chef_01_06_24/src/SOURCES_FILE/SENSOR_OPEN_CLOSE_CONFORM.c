/*
 *  sensor_open_close_conform.h
 *
 *  Created on: Dec 11, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "../HEADER_FILE/Macros.H"
#include "../HEADER_FILE/IO.H"

_Bool
sw1,
sw2,
sw3,
sw4,
sw5,
sw6,
sw2,
sw7,
sw8,
sw9,
sw10,
sw11,
sw12,
sw13,
sw14,
sw15,
sw16,
sw17,
sw18,
sw19,
sw20,
sw21,
sw22,
sw23,
sw24,

kadai_1_switch_flag,
kadai_2_switch_flag,

kadai_1_cw_acw_switch_flag,
kadai_2_cw_acw_switch_flag,

kadai_homing_switch_flag,


cooker_1_switch_flag,
cooker_2_switch_flag,
cooker_3_switch_flag,

lid_1_switch_flag,
lid_2_switch_flag,
lid_3_switch_flag,

veg_1_switch_flag,
veg_2_switch_flag,
veg_3_switch_flag,

collecting_tray_A_switch_flag,
collecting_tray_B_switch_flag,

collecting_bin_switch_flag,

kadai_1_left_right_switch_close_flag,
kadai_2_left_right_switch_close_flag,

kadai_1_clock_anticlock_switch_close_flag,
kadai_2_clock_anticlock_switch_close_flag,

kadai_homing_position_close_flag,

cooker1_switch_close_flag,
cooker2_switch_close_flag,
cooker3_switch_close_flag,

lid_1_switch_close_flag,
lid_2_switch_close_flag,
lid_3_switch_close_flag,

veg_1_switch_close_flag,
veg_2_switch_close_flag,
veg_3_switch_close_flag,

collecting_1_switch_close_flag,
collecting_2_switch_close_flag,

collecting_bin_switch_close_flag,


VEG_TRAY1_SWITCH,
VEG_TRAY2_SWITCH,
VEG_TRAY3_SWITCH,

LID1_SWITCH,
LID2_SWITCH,
LID3_SWITCH,

COOKER1_SWITCH,
COOKER2_SWITCH,
COOKER3_SWITCH,

KADAI_1_LR_SWITCH,
KADAI_2_LR_SWITCH,

KADAI_1_CA_SWITCH,
KADAI_2_CA_SWITCH,

KADAI_HOMING_SWITCH,

COLLECTING_A_SWITCH,
COLLECTING_B_SWITCH,

COLLECTING_BIN;




/***************************INPUT SWITCHES**************************/

unsigned char
vegtray1_switch_open_conform_time,
vegtray1_switch_close_conform_time,

vegtray2_switch_open_conform_time,
vegtray2_switch_close_conform_time,

vegtray3_switch_open_conform_time,
vegtray3_switch_close_conform_time,

lid_1_switch_open_conform_time,
lid_1_switch_close_conform_time,

lid_2_switch_open_conform_time,
lid_2_switch_close_conform_time,

lid_3_switch_open_conform_time,
lid_3_switch_close_conform_time,

cooker1_switch_open_conform_time,
cooker1_switch_close_conform_time,

cooker2_switch_open_conform_time,
cooker2_switch_close_conform_time,

cooker3_switch_open_conform_time,
cooker3_switch_close_conform_time,


collecting_1_switch_open_conform_time,
collecting_1_switch_close_conform_time,

collecting_2_switch_open_conform_time,
collecting_2_switch_close_conform_time,

collecting_bin_switch_open_conform_time,
collecting_bin_switch_close_conform_time,

kadai_1_left_right_switch_open_conform_time,
kadai_1_left_right_switch_close_conform_time,



kadai_2_left_right_switch_open_conform_time,
kadai_2_left_right_switch_close_conform_time,


kadai_homing_switch_open_conform_time,
kadai_homing_switch_close_conform_time;
unsigned int
kadai_1_clock_anticlock_switch_open_conform_time,
kadai_1_clock_anticlock_switch_close_conform_time,
kadai_2_clock_anticlock_switch_open_conform_time,
kadai_2_clock_anticlock_switch_close_conform_time;
void sensor_open_close_conform();

void sensor_open_close_conform()
{

//    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_15,&sw1);  //1
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_00,&sw2); //2
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_01,&sw3);//3
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_06,&sw4);//4
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_09,&sw5);//5
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_05,&sw6);//6
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_02,&sw7);//7
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_06,&sw8);//8
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_08,&sw9);//9
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_03,&sw10);//10
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_12,&sw11);//11
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_01_PIN_13,&sw12);//12
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_02,&sw13);//13
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_04,&sw14);//14
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_04,&sw15);//15
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_05,&sw16);//16
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_05,&sw17);//17
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_05,&sw18);//18
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_06,&sw19);//19
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_03,&sw20);//20
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_13,&sw21);//21
//
//      g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_04,&sw22);//22


    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_15,&VEG_TRAY1_SWITCH);  //1

      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_00,&VEG_TRAY2_SWITCH); //2

      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_01,&VEG_TRAY3_SWITCH);//3

      g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_06,&COOKER1_SWITCH);//4

      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_09,&COOKER2_SWITCH);//5

      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_05,&COOKER3_SWITCH);//6

      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_02,&LID1_SWITCH);//7

      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_06,&LID2_SWITCH);//8

      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_08,&LID3_SWITCH);//9

      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_03,&KADAI_1_CA_SWITCH);//10

      g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_12,&KADAI_2_CA_SWITCH);//11

      g_ioport.p_api->pinRead(IOPORT_PORT_01_PIN_13,&COLLECTING_BIN);//12

   //   g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_02,&sw13);//13

      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_04,&COLLECTING_B_SWITCH);//14

  //    g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_04,&sw15);//15

     // g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_05,&sw16);//16

      g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_05,&KADAI_1_LR_SWITCH);//17

      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_05,&KADAI_2_LR_SWITCH);//18

//      g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_06,&sw19);//19

      g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_03,&KADAI_HOMING_SWITCH);//20

      g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_13,&COLLECTING_A_SWITCH);//21

     // g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_04,&sw22);//22

//    g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_05,&KADAI_1_CA_SWITCH);  //1
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_04,&KADAI_2_CA_SWITCH); //2
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_03,&COLLECTING_BIN);//3
//
//    //g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_02,&sw4);//4
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_09,&COLLECTING_B_SWITCH);//5
//
////    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_05,&sw6);//6
////
////    g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_02,&sw7);//7
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_04,&KADAI_1_LR_SWITCH);//8
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_03,&KADAI_2_LR_SWITCH);//9
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_04,&VEG_TRAY1_SWITCH);//10
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_12,&VEG_TRAY2_SWITCH);//11
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_00,&VEG_TRAY3_SWITCH);//12
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_06,&COOKER1_SWITCH);//13
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_07_PIN_01,&COOKER2_SWITCH);//14
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_05,&COOKER3_SWITCH);//15
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_06,&LID1_SWITCH);//16
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_05,&LID2_SWITCH);//17
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_08,&LID3_SWITCH);//18
//
//    g_ioport.p_api->pinRead(IOPORT_PORT_01_PIN_13,&COLLECTING_A_SWITCH);//19
//
////    g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_06,&sw20);//20
////
////    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_15,&sw21);//21
////
//    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_13,&KADAI_HOMING_SWITCH);//22
        if (!VEG_TRAY1_SWITCH)
        {
            if(vegtray1_switch_open_conform_time>5)
            {
                veg_1_switch_close_flag=CLR;
                vegtray1_switch_close_conform_time=0;
            }
        }
        else
        {
            if(vegtray1_switch_close_conform_time>5)
            {
                veg_1_switch_close_flag=SET;
                vegtray1_switch_open_conform_time=0;
            }
        }

        if(!VEG_TRAY2_SWITCH)
        {
            if(vegtray2_switch_open_conform_time>5)
            {
                veg_2_switch_close_flag=CLR;
                vegtray2_switch_close_conform_time=0;
            }
        }
        else
        {
            if(vegtray2_switch_close_conform_time>5)
            {
                veg_2_switch_close_flag=SET;
                vegtray2_switch_open_conform_time=0;
            }
        }

        if(!VEG_TRAY3_SWITCH)
        {
            if(vegtray3_switch_open_conform_time>5)
            {
                veg_3_switch_close_flag=CLR;
                vegtray3_switch_close_conform_time=0;
            }
        }
        else
        {
            if(vegtray3_switch_close_conform_time>5)
            {
                veg_3_switch_close_flag=SET;
                vegtray3_switch_open_conform_time=0;
            }
        }
        if(!LID1_SWITCH)
        {
            if(lid_1_switch_open_conform_time>150) //50//5
            {
                lid_1_switch_close_flag=CLR;
                lid_1_switch_open_conform_time=0;
            }
        }
        else
        {
            if(lid_1_switch_close_conform_time>150)//5
            {
                lid_1_switch_close_flag=SET;
                lid_1_switch_close_conform_time=0;
            }
        }

        if(!LID2_SWITCH)
        {
           if(lid_2_switch_open_conform_time>150)//5
           {
               lid_2_switch_close_flag=CLR;
               lid_2_switch_open_conform_time=0;
           }
        }
        else
        {
           if(lid_2_switch_close_conform_time>150)//5
           {
               lid_2_switch_close_flag=SET;
               lid_2_switch_close_conform_time=0;
           }
        }

        if(!LID3_SWITCH)
        {
           if(lid_3_switch_open_conform_time>150)//5
           {
               lid_3_switch_close_flag=CLR;
               lid_3_switch_open_conform_time=0;
           }
        }
        else
        {
           if(lid_3_switch_close_conform_time>150)//5
           {
               lid_3_switch_close_flag=SET;
               lid_3_switch_close_conform_time=0;
           }
        }


        if(!COOKER1_SWITCH)
        {
            if(cooker1_switch_open_conform_time>5)
            {
                cooker1_switch_close_flag=CLR;
                cooker1_switch_close_conform_time=0;
            }
        }
        else
        {
            if(cooker1_switch_close_conform_time>5)
            {
                cooker1_switch_close_flag=SET;
                cooker1_switch_open_conform_time=0;
            }
        }
        if(!COOKER2_SWITCH)
        {
            if(cooker2_switch_open_conform_time>5)
            {
                cooker2_switch_close_flag=CLR;
                cooker2_switch_close_conform_time=0;
            }
        }
        else
        {
            if(cooker2_switch_close_conform_time>5)
            {
                cooker2_switch_close_flag=SET;
                cooker2_switch_open_conform_time=0;
            }
        }
        if(!COOKER3_SWITCH)
        {
          if(cooker3_switch_open_conform_time>5)
          {
              cooker3_switch_close_flag=CLR;
              cooker3_switch_close_conform_time=0;
          }
        }
        else
        {
          if(cooker3_switch_close_conform_time>5)
          {
              cooker3_switch_close_flag=SET;
              cooker3_switch_open_conform_time=0;
          }
        }

        if(!COLLECTING_A_SWITCH)
        {
            if(collecting_1_switch_open_conform_time>5)
            {
                collecting_1_switch_close_flag=CLR;
                collecting_1_switch_open_conform_time=0;
            }
        }
        else
        {
            if(collecting_1_switch_close_conform_time>5)
            {
                collecting_1_switch_close_flag=SET;
                collecting_1_switch_close_conform_time=0;
            }
        }

        if(!COLLECTING_B_SWITCH)
        {
            if(collecting_2_switch_open_conform_time>5)
            {
                collecting_2_switch_close_flag=CLR;
                collecting_2_switch_open_conform_time=0;
            }
        }
        else
        {
            if(collecting_2_switch_close_conform_time>5)
            {
                collecting_2_switch_close_flag=SET;
                collecting_2_switch_close_conform_time=0;
            }
        }
        if(!KADAI_1_LR_SWITCH)
        {
            if(kadai_1_left_right_switch_open_conform_time>100)
            {
                kadai_1_left_right_switch_close_flag=CLR;
                kadai_1_left_right_switch_close_conform_time=0;
            }
        }
        else
        {
            if(kadai_1_left_right_switch_close_conform_time>100)
            {
                kadai_1_left_right_switch_close_flag=SET;
                kadai_1_left_right_switch_open_conform_time=0;
            }
        }
        if(!KADAI_1_CA_SWITCH)
        {
            if(kadai_1_clock_anticlock_switch_open_conform_time>500)
            {
                kadai_1_clock_anticlock_switch_close_flag=CLR;
                kadai_1_clock_anticlock_switch_close_conform_time=0;
            }
        }
        else
        {
            if(kadai_1_clock_anticlock_switch_close_conform_time>500)
            {
                kadai_1_clock_anticlock_switch_close_flag=SET;
                kadai_1_clock_anticlock_switch_open_conform_time=0;
            }
        }
        if(!KADAI_2_LR_SWITCH)
        {
            if(kadai_2_left_right_switch_open_conform_time>100)
            {
                kadai_2_left_right_switch_close_flag=CLR;
                kadai_2_left_right_switch_close_conform_time=0;
            }
        }
        else
        {
            if(kadai_2_left_right_switch_close_conform_time>100)
            {
                kadai_2_left_right_switch_close_flag=SET;
                kadai_2_left_right_switch_open_conform_time=0;
            }
        }
        if(!KADAI_2_CA_SWITCH)
        {
            if(kadai_2_clock_anticlock_switch_open_conform_time>500)
            {
                kadai_2_clock_anticlock_switch_close_flag=CLR;
                kadai_2_clock_anticlock_switch_close_conform_time=0;
            }
        }
        else
        {
            if(kadai_2_clock_anticlock_switch_close_conform_time>500)
            {
                kadai_2_clock_anticlock_switch_close_flag=SET;
                kadai_2_clock_anticlock_switch_open_conform_time=0;
            }
        }
        if(!COLLECTING_BIN)
        {
            if(collecting_bin_switch_open_conform_time>1)
            {
                collecting_bin_switch_close_flag=CLR;
                collecting_bin_switch_close_conform_time=0;
            }
        }
        else
        {
            if(collecting_bin_switch_close_conform_time>1)
            {
                collecting_bin_switch_close_flag=SET;
                collecting_bin_switch_open_conform_time=0;
            }
        }
        if(!KADAI_HOMING_SWITCH)
        {
            if(kadai_homing_switch_open_conform_time>100)
            {
                kadai_homing_position_close_flag=CLR;
                kadai_homing_switch_close_conform_time=0;
            }
        }
        else
        {
            if(kadai_homing_switch_close_conform_time>100)
            {
                kadai_homing_position_close_flag=SET;
                kadai_homing_switch_open_conform_time=0;
            }
        }

}
