#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "string.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include "stdio.h"

void keyscan();
void keyscan()
{
	static boolean key_pressed_flag;
	if(!TT_MANUAL_SWITCH)
	{
		if(!delayflag)
		{
			delayflag = SET;
			key_scan_delay_hm=0;			
		}
		if(key_scan_delay_hm>=2)
		key_pressed_flag=SET;
	}	
	else
	{
		if((key_pressed_flag)AND(!tt_trip_switch_close_flag))
		{
			TURN_TABLE_OP_ON;
			key_pressed_flag=CLEAR;
			if((!bake_start_flag)OR(door_switch_close_flag))
			{
				manual_opearate_flag=SET;
				if(!tt_switch_close_flag)
				{
					delay=40;		//delay for turn table ON from the switch
					while(delay);
				}
			}
		}
		delayflag=CLEAR;
	}
}
