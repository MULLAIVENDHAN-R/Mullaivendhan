#ifndef MACROS_H
#define MACROS_H

extern unsigned char iot_compenent_name[10];

#define AND 			&&
#define OR 			||
#define EQUAL_TO		==
#define NOT_EQUAL_TO		!=
#define SET			1
#define CLEAR			0
#define HIGH			1
#define LOW			0
#define ON			1
#define OFF			0

#define FWD			1
#define REV			2


#define BOWL_FWD		P5.1
#define BOWL_FWD_ON		BOWL_FWD=1,BOWL_REV_OFF,bowl_on_off_status=1,iot_compenent_name[3]=HIGH
#define BOWL_FWD_OFF		BOWL_FWD=0,BOWL_ON_OFF_DELAY=800,bowl_on_off_status=0,iot_compenent_name[3]=HIGH

#define BOWL_REV		P5.0
#define BOWL_REV_ON		BOWL_REV=1,BOWL_FWD_OFF,bowl_on_off_status=1,iot_compenent_name[3]=HIGH
#define BOWL_REV_OFF		BOWL_REV=0,BOWL_ON_OFF_DELAY=800,bowl_on_off_status=0,iot_compenent_name[3]=HIGH

#define BOWL_FWD_REV_OFF	BOWL_FWD=0,BOWL_REV=0,BOWL_ON_OFF_DELAY=800,bowl_on_off_status=0,iot_compenent_name[3]=HIGH



#define SPRIAL_HIGH_OP		P5.2
#define SPRIAL_HIGH_OP_ON	SPRIAL_HIGH_OP=1,SPRIAL_SLOW_OP_OFF,spiral_high_on_flag=SET,spiral_on_off_status=1,iot_compenent_name[2]=HIGH,iot_compenent_name[1]=HIGH
#define SPRIAL_HIGH_OP_OFF	SPRIAL_HIGH_OP=0,spiral_high_on_flag=CLEAR,SPIRAL_ON_OFF_DELAY=800,spiral_on_off_status=0,iot_compenent_name[2]=HIGH

#define SPRIAL_SLOW_OP		P5.3
#define SPRIAL_SLOW_OP_ON	SPRIAL_SLOW_OP=1,SPRIAL_HIGH_OP_OFF,spiral_low_on_flag=SET,spiral_on_off_status=1,iot_compenent_name[2]=HIGH,iot_compenent_name[0]=HIGH
#define SPRIAL_SLOW_OP_OFF	SPRIAL_SLOW_OP=0,spiral_low_on_flag=CLEAR,SPIRAL_ON_OFF_DELAY=800,spiral_on_off_status=0,iot_compenent_name[2]=HIGH

#define SPRIAL_OFF   		SPRIAL_SLOW_OP_OFF,SPRIAL_HIGH_OP_OFF,SPIRAL_ON_OFF_DELAY=800,spiral_on_off_status=0,iot_compenent_name[2]=HIGH
           

// 5.3  slow
// 5.2  high
// 5.0  fwd
// 5.1  rev


#define ALL_OUTPUTS_OFF		SPRIAL_SLOW_OP_OFF,SPRIAL_HIGH_OP_OFF,BOWL_FWD_REV_OFF,temp_direction=0


#define DOOR_SWITCH		P4.1   	// door
#define SPIRAL_TRIP_SWITCH	P4.2   	// spiral high
#define BOWL_TRIP_SWITCH	P12.4//P4.3	// bowl trip
#define EMERGENCY_SWITCH	P4.4  	// emergency

/*************************************RTC******************************/

#define SCL			P6.0
#define SDA			P6.1
#define SDA_INPUT		PM6.1=1  
#define SDA_OUTPUT		PM6.1=0


#define RTC_WRITE 			0x64
#define RTC_READ        		0x65

#define EEPROM_WRITE    		0xa6
#define EEPROM_READ     		0Xa7

#define RTC_SECONDS 			0x10
#define RTC_MINUTES			0x11
#define RTC_HOURS			0x12
#define RTC_DAY				0x13
#define RTC_DATE			0x14
#define RTC_MONTH			0x15
#define RTC_YEAR			0x16


#define SUNDAY				0x01
#define MONDAY				0x02
#define TUESDAY				0x03
#define WEDNESDAY			0x04
#define THURSDAY			0x05
#define FRIDAY				0x06
#define SATURDAY			0x07


#define eeprom_rtc_year			10

/*************************************RTC******************************/

#define TEMP_DELAY 		10  // mullai

/*******************************CHECK_OUTPUTS*****************************/

#define SPRIAL_HIGH_ON_OFF	2
#define SPRIAL_SLOW_ON_OFF	1

#define BOWL_FWD_ON_OFF 	3
#define BOWL_REV_ON_OFF 	4
#define BOWL_DIRECTION	 	5



/*********************************CHECK_OUTPUTS*****************************/

/***********************************STEP SEQUENCE*************************/
#define LOW_SPEED_ON		1
#define LOW_SPEED_OFF		2
#define HIGH_SPEED_ON		3
#define HIGH_SPEED_OFF		4
/***********************************STEP SEQUENCE*************************/

#endif