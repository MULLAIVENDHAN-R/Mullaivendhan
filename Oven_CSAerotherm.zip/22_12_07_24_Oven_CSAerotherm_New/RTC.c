#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"


extern void eeprom_write(unsigned int, unsigned char);
__boolean write_iic(unsigned char , unsigned char );
__boolean read_iic(unsigned char , unsigned char );
void sendRTC();
void heartBeat();
extern void form_send_buf(char,char);


void time_date_update()
{
	if(timeDate_save_flag)
	{
		write_rtc_buf[RTC_SECONDS] =receiveRTC[0];	
		write_rtc_buf[RTC_MINUTES] =receiveRTC[5];	
		write_rtc_buf[RTC_HOURS]   =receiveRTC[4];
		write_rtc_buf[RTC_DAY]     =MONDAY;						
		write_rtc_buf[RTC_DATE]    =receiveRTC[1];		
		write_rtc_buf[RTC_MONTH]   =receiveRTC[2];
		write_rtc_buf[RTC_YEAR]    =receiveRTC[3];
		disp_addr          	   =RTC_SECONDS;
		ram_addr             	   =&write_rtc_buf[RTC_SECONDS];
		write_iic(RTC_WRITE,7);
		timeDate_save_flag=CLEAR;
	}
}

void sendRTC()
{
	if(time_update_flag)
	{
		time_update_flag=CLEAR;	
		disp_addr = RTC_SECONDS;			
		ram_addr  = &read_rtc_buf[RTC_SECONDS];
		read_iic(RTC_READ,7);
		
		
		temp_send_buf[tx_data++]= ((read_rtc_buf[RTC_DATE] & 0xf0) >> 4) + 0X30 ;	//Date
		temp_send_buf[tx_data++]= (read_rtc_buf[RTC_DATE] & 0x0f) + 0X30 ;		//Date
		temp_send_buf[tx_data++]='|';
		temp_send_buf[tx_data++]= ((read_rtc_buf[RTC_MONTH] & 0xf0) >> 4) + 0X30 ;	//Month
		temp_send_buf[tx_data++]= (read_rtc_buf[RTC_MONTH] & 0x0f) + 0X30 ;		//Month
		temp_send_buf[tx_data++]='|';
		temp_send_buf[tx_data++]= ((year & 0xf0) >> 4) + 0X30 ;				//year
		temp_send_buf[tx_data++]= (year & 0x0f) + 0X30 ;				//year
		temp_send_buf[tx_data++]= ((read_rtc_buf[RTC_YEAR] & 0xf0) >> 4) + 0X30 ;	//year
		temp_send_buf[tx_data++]= (read_rtc_buf[RTC_YEAR] & 0x0f) + 0X30 ;		//year
		temp_send_buf[tx_data++]='|';
		temp_send_buf[tx_data++]= ((read_rtc_buf[RTC_HOURS] & 0xf0) >> 4) + 0X30 ;	//hour
		temp_send_buf[tx_data++]= (read_rtc_buf[RTC_HOURS] & 0x0f) + 0X30 ;		//hour
		temp_send_buf[tx_data++]='|';
		temp_send_buf[tx_data++]= ((read_rtc_buf[RTC_MINUTES] & 0xf0) >> 4) + 0X30 ;	//Min
		temp_send_buf[tx_data++]= (read_rtc_buf[RTC_MINUTES] & 0x0f) + 0X30 ;		//Min		
		RTC_SEND_APPID_FUNID;
		form_send_buf(DATA_RES,tx_data);
		tx_data=0;		
		if(read_rtc_buf[RTC_MINUTES]==0X00)	//when minutes 0 it reaches one hour
		{
			ONE_HOUR_REMIND_APPID_FUNID;
			form_send_buf(COMMAND_RES,ONE_HOUR_REMIND_DATA);
		}
		
	}
	if(eeprom_store_flag)
	{
		eeprom_write(eeprom_rtc_year,year);
		eeprom_store_flag=CLEAR;
	}
}
void heartBeat()
{
	if(heart_beat_send_flag)
    	{
	        heart_beat_send_flag=CLEAR;
	        HEART_BEAT_APPID_FUNID;
	        form_send_buf(COMMAND_RES,HEART_BEAT_DATA);
    	}
}