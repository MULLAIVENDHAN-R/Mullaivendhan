#ifndef UART_MACROS_H
#define UART_MACROS_H


#define START_BYTE		0X2A
#define END_BYTE		0X23
#define STUFF_BYTE		0X1C
#define SEND_HEADER_BYTE	0X80

#define	HEADER_BYTE 		0x80


#define START_FROM		2
#define DATA_START		6
#define	HEADER 			1
#define MAX_FUN_ID		12
#define TOTAL_APP_ID 		11

#define MAX_SIZE_RX_BUF		160
#define FIXED_DATA_LENGTH	160

/******************         APP ID   *******************/


#define HANDSHAKE_APP_ID	0X01 
#define MACHINE_READY_APP_ID	0X02
#define HEART_BEAT_APP_ID	0X03
#define ST_ENTER_EXIT_APP_ID	0X04
#define SETTING_APP_ID		0X05
#define OUTPUT_APP_ID		0X06
#define INPUT_APP_ID		0X07
#define LIVE_APP_ID		0X08
#define ERROR_APP_ID		0X09
#define PROCESS_DATA_APP_ID	0X0A
#define INFROMATION_APP_ID	0X0B

/******************         APP ID   *******************/




/******************         FUN ID   *******************/

#define HANDSHAKE_ACK_FUN_ID	0X01 
#define VERSION_ACK_FUN_ID	0X02 

#define MACHINE_ACK_FUN_ID	0X01

#define HEART_BEAT_ACK_FUN_ID	0X01

#define ST_ENTER_ACK_FUN_ID	0X01
#define ST_EXIT_ACK_FUN_ID	0X02 

#define FACTOR_SETTING_ACK_FUN_ID	0X01

#define OUTPUT_IO_STATUS_ACK_FUN_ID	0X01 
#define OUTPUT_ON_OFF_ACK_FUN_ID	0X02

#define INPUT_ENTER_ACK_FUN_ID	0X01 
#define INPUT_DATA_ACK_FUN_ID	0X02
#define INPUT_EXIT_ACK_FUN_ID	0x03

#define LIVE_ENTER_ACK_FUN_ID	0X01 
#define LIVE_IN_DATA_FUN_ID	0X02
#define LIVE_OUT_DATA_FUN_ID	0X03
#define LIVE_EXIT_ACK_FUN_ID	0x04

#define WARNING_DATA_ACK_FUN_ID	0x01
#define ERROR_DATA_ACK_FUN_ID	0x02



#define PROCESS_INIT_FUN_ID	0x01
#define DOOR_ACK_FUN_ID		0x02
#define START_ACK_FUN_ID	0x03
#define DATA_ACK_FUN_ID		0x04
#define STOP_ACK_FUN_ID		0x05
#define PAUSE_ACK_FUN_ID	0x06
#define RESUME_ACK_FUN_ID	0x07
#define RESET_ACK_FUN_ID	0x08
#define COMPLETE_ACK_FUN_ID	0x09
#define TEMPERATURE_ACK_FUN_ID	0x0A
#define STEP_NO_ACK_FUN_ID	0x0B
#define STEP_COMPLETE_FUN_ID	0x0C


#define IN_ENTER_ACK_FUN_ID	0x01
#define IN_REMOVE_ACK_FUN_ID	0x02

/******************         FUN ID   *******************/

/**********************RESPOND DATA *****************/

#define DATA_RES	0
#define COMMAND_RES	1

/**********************RESPOND DATA *****************/


/***************** string data   *************/

#define ACK_DATA		0
#define MACHINE_READY		1
#define HEART_BEAT		2
#define DOOR_CLOSE		3
#define DOOR_OPEN		4
#define H_S_VERSION		5
#define COMPLETE		6
#define START			7
#define STEP_COMPLETE		8

/***************** string data  *************/

#endif
