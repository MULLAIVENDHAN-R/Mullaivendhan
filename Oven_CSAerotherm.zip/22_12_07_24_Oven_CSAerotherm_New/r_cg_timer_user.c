/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_timer_user.c
* Version      : CodeGenerator for RL78/G13 V2.05.06.02 [08 Nov 2021]
* Device(s)    : R5F100PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for TAU module.
* Creation Date: 7/9/2024
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTTM00 r_tau0_channel0_interrupt
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_timer.h"
/* Start user code for include. Do not edit comment generated here */
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
extern void blower_speed_variation();
extern void form_send_buf(char,char);
extern boolean iot_send_flag;
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: r_tau0_channel0_interrupt
* Description  : This function is INTTM00 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void r_tau0_channel0_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    //blower_speed_variation();
    if(++hundred_usec_sec_counter>=2)
    {			
	if(temp_delay>0)
	temp_delay--;	
	hundred_usec_sec_counter=0;
    }
    if(++one_milli_sec_counter>=20)
    {
	    one_milli_sec_counter=0;
/****************OUTPUTS TIMER**************************/
	    if(temp_baking_time>0)
	    temp_baking_time--;
	    if(temp_steam_time>0)
	    temp_steam_time--;
/****************OUTPUTS TIMER**************************/
	    if(door_switch_open_conform_time<250)
	    door_switch_open_conform_time++;
	    if(door_switch_close_conform_time<250)
	    door_switch_close_conform_time++;
	    if(tt_switch_open_conform_time<250)
	    tt_switch_open_conform_time++;
	    if(tt_switch_close_conform_time<250)
	    tt_switch_close_conform_time++;
	    
	    if(blower_trip_switch_open_conform_time<250)
	    blower_trip_switch_open_conform_time++;
	    if(blower_trip_switch_close_conform_time<250)
	    blower_trip_switch_close_conform_time++;
	    
	    if(tt_trip_switch_open_conform_time<250)
	    tt_trip_switch_open_conform_time++;
	    if(tt_trip_switch_close_conform_time<250)
	    tt_trip_switch_close_conform_time++;
		
	    if(thermo_trip_switch_open_conform_time<250)
	    thermo_trip_switch_open_conform_time++;
	    if(thermo_trip_switch_close_conform_time<250)
	    thermo_trip_switch_close_conform_time++;
	    if(burner_trip_switch_open_conform_time<250)
	    burner_trip_switch_open_conform_time++;
	    if(burner_trip_switch_close_conform_time<250)
	    burner_trip_switch_close_conform_time++;
	    if(emergency_switch_open_conform_time<250)
	    emergency_switch_open_conform_time++;
	    if(emergency_switch_close_conform_time<250)
	    emergency_switch_close_conform_time++;
	    if(tt_manual_switch_open_conform_time<250)
	    tt_manual_switch_open_conform_time++;
	    if(tt_manual_switch_close_conform_time<250)
	    tt_manual_switch_close_conform_time++;  
	    
/****************UART TIMER**************************/
	    if(trasmit_dly>0)
	    trasmit_dly--;
	    if(uart_error_clear_count>0)
	    {
		uart_error_clear_count--;
		if(uart_error_clear_count<=0)
		data=0;				
	    }
/****************UART TIMER**************************/
	    if(++fifty_milli_sec_counter>=50)
	    {
		    fifty_milli_sec_counter=0;
		    
		    if(homeScreenDelay>0)
		    homeScreenDelay--;
		    
//		    if(!adc_read_flag)
//		    adc_read_flag=SET;
		    /*if(err_occured_flag)
		    {
			    if(++buzzer_on_time>=100)
			    {
				    buzzer_on_time=0;
				    BUZZER_OP_OFF;
				    BUZZER_OFF;
				    err_occured_flag=CLEAR;
			    }
		    }*/
		    if(delayflag)
		    key_scan_delay_hm++;
		    if(++one_sec_counter>=20)
		    {
			    one_sec_counter=0;
			    if(!adc_read_flag)
		    	    adc_read_flag=SET;
			    if(!fuel_adc_read_flag)
			    fuel_adc_read_flag=SET;
			    if(!iot_send_flag)
			    iot_send_flag=SET;
			    if(handshake_ok_flag)
			    {
				    if(++heart_beat_counter>=80)	// + 20 sec with rtc	
				    {
					    heart_beat_counter=0;
					    heart_beat_send_flag=SET;
				    }
				    if(++rtc_send_counter>=5)
				    {
					   rtc_send_counter=0;
					//  time_update_flag=SET;
					   if((iot_compenent_name[1]==0)AND(fuel_changed_flag))
					   {
					   	iot_compenent_name[1]=HIGH; 
					   	fuel_changed_flag=CLEAR;
					   }					// 3sec
				    }
				   if(temp_on_delay>0)  // mullai
				   temp_on_delay--;
			    }
			    
		    }
		    if(temp_changed_flag)
		    {
			    if(++send_temp_with_delay_counter>=40)
			    {
				    send_temp_with_delay_counter=0;
				    temp_send_flag=SET;
				    temp_changed_flag=CLEAR;
			    }
		    }
		    if(delay>0)
		    delay--;
	    }
    }
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
