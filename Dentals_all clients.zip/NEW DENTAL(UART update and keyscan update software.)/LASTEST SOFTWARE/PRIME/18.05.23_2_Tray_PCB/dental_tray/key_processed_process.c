#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"


void detect_key_pressed();
extern void on_off_function();
extern void fwd_rev_function();
extern void hand_foot_fuction();
extern void xray_function();
extern void	scalar_function();

void detect_key_pressed()
{
	if(key_status_changed_flag)
	{
		key_status_changed_flag=CLEAR;
		
		/**if(((serial_received_data&ON_OFF_KEY)==0x00000000)AND(!micro_motor_complete_off_flag)AND(!micro_motor_slow_off_flag))
		{
			on_off_sw_flag=SET;					//ON_OFF-KEY
		//	xray_function();
		}*/
		if((serial_received_data&POWER_ON_OFF)==0x00000000)
		{
			if(!power_on_off_sw_flag)
			{
				power_on_off_sw_flag=SET;
				MAIN_LED_ON;
			}
			else
			{
				power_on_off_sw_flag=CLEAR;
				MAIN_LED_OFF;
			}
		}
		if(power_on_off_sw_flag)
		{
			send_uart_data_flag=SET;
			if(serial_received_data==0xfffffe)//ON_OFF_KEY MICRO MOTOR
				{
					if((!micro_motor_slow_off_flag)AND(!micro_motor_complete_off_flag))
					on_off_sw_flag=SET;
				}
			else if((serial_received_data&INC_SW_KEY)==0x00000000)
			{
				if(on_off_flag)
				{			
	//				speed_inc_delay_flag=SET;
					inc_sw_key_flag=SET;		
				//	inc_function();					//INC_SW_KEY
					
				}			
			}
			else if((serial_received_data&DEC_SW_KEY)==0x00000000)
			{
				if(on_off_flag)
				{
					dec_sw_key_flag=SET;
				//	dec_function();					//DEC_SW_KEY;
				}					
			}
			else if((serial_received_data&FWD_REV_KEY)==0x00000000)
			{
				if(on_off_flag)	
				{	
					fwd_rev_key_pressed_flag=SET;			
					fwd_rev_function();				//FWD_REV_KEY
				}									
			}
			else if((serial_received_data&XRAY_SW_KEY)==0x00000000)
			{	
				xray_function();					//XRAY_SW_KEY		
			}
			else if((serial_received_data&HAND_FOOR_KEY)==0x00000000)
			{
				if(on_off_flag)
				{
						//HAND_FOOT_KEY					
									
					hand_foot_key_pressed_flag=SET;				
					hand_foot_fuction();
					
				}			   
			}
			else if((serial_received_data&SCALAR_SW)==0x00000000)
			{
				scalar_function();
			}
			else if((serial_received_data&AERO_SW_KEY)==0x00000000)
			{
				aeroter_sw_flag=SET;				//AERO_SW_KEY
				ON_OFF_LED_OFF;
				BAR_LED_ONE_OFF;
				BAR_LED_TWO_OFF;
				BAR_LED_THREE_OFF;
				BAR_LED_FOUR_OFF;
				BAR_LED_FIVE_OFF;
				BAR_LED_SIX_OFF;
				BAR_LED_SEVEN_OFF;
				HAND_LED_OFF;
				MTR_FWD_LED_OFF;
				MTR_REV_LED_OFF;
				MTR_ENABLE_OFF;
				FOOT_LED_OFF;
				MTR_FWD_OFF;
				MTR_REV_OFF;
				BAR_LED_ALL_OFF;
				foot_sw_flag=CLEAR;
			//	prev_value=PREV_VALUE;
				prev_value=led_op_variable&(0x000000EF);	//comment by rama												
				direct_uart_send_data = ((direct_uart_send_data)&(0xffffffd0));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}		
		}
	}	
}