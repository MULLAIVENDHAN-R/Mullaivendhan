#ifndef GUI_MACROS_H
#define GUI_MACROS_H

#define START_BYTE	0X2A
#define END_BYTE	0X23
#define STUFF_BYTE	0X1C
#define HEADER_BYTE	1
#define START_FROM	2
#define DATA_START	6
#define MAX_SIZE_RX_BUF	57


#define TOTAL_APP_ID		7
#define MAX_FUN_ID		15
#define FIXED_DATA_LENGTH	57


#define APP_ID_BYTE		4
#define FUN_ID_BYTE		5

#define DATA 			0


/**********************RESPOND DATA *****************/

#define DATA_RES	0
#define COMMAND_RES	1

/**********************RESPOND DATA *****************/


/********************STRING DATA*******************************************/

#define ACK_DATA		0
#define DISPLAY_READY_DATA	1
#define HANDSHAKE_DATA		2
#define CLOSE_DATA		3
#define OPEN_DATA		4
#define START_DATA		5
#define STOP_DATA		6
#define IO_STATUS_DATA		7
#define TEMP_DATA		8
#define DONE_DATA		9

/*************************ERR SEND DATA*********************************/
#define SPIRAL_ERR_DATA		10
#define LIMIT_SWITCH_DATA	11
#define BLOW_TRIP_DATA		12
#define THERMO_TRIP_DATA	13
#define BURNER_TRIP_DATA	14
#define EMERGENCY_DATA		15
/*************************ERR SEND DATA*********************************/
#define HEART_BEAT_DATA		16
#define COMPLETE_DATA		17
#define ERR_CLOSED_DATA		18

#define EMERGENCY_POPUP_MSG	19
#define ALERT_POPUP_MSG		20
#define ONE_HOUR_REMIND_DATA	21
#define PROCESS_RESTART_DATA	22
#define HIGHSPEED_KEY_DATA	27
#define SCREEN_ON 		28
#define SCREEN_OFF		29



/*********************************APP IDs**********************************/  

#define BOOTING_TIME_APP_ID	0X01            //Booting time
#define BAKING_TIME_APP_ID	0X02		//Baking time
#define SETTINGS_APP_ID		0X03		//Settings
#define ERROR_APP_ID		0X04		//Errors
#define MESSAGE_POPUP_APP_ID	0X05
#define IOT_SEND_DATA_APP_ID	0X06
#define HIGHSPEED_DATA_APP_ID   0X07
#define SCREEN_FRZ_DATA_APP_ID  0X08

/*********************************APP IDs**********************************/ 

/********************************FUN IDs**********************************/

#define HANDSHAKE_RES_FUN_ID	0X01  	//Booting time
#define HEART_BEAT_FUN_ID	0X02


#define PROCESS_START_FUN_ID	0X01   	//mixing time
#define PROCESS_DATA_FUN_ID	0X02
#define DATA_ACK_FUN_ID		0X03
#define PROCESS_STOP_FUN_ID	0X04
#define DONE_ACK_FUN_ID		0X06
#define UPDATE_DATA_FUN_ID	0X07
#define PROCESS_COMPLETE_FUN_ID	0X08
#define ERR_AT_PROCESS_FUN_ID	0X09
#define POPUP_CLOSED_ACK_FUN_ID	0X0A
#define POPUP_CLOSED_FUN_ID	0X0B
#define RESUME_PROCESS_FUN_ID	0X0C
#define PRCS_DIR_FUN_ID		0X0D
#define PRCS_RESTART_FUN_ID	0X0E
	

#define IO_STATUS_FUN_ID	0X01	//Settings 
#define IO_CHECK_FUN_ID		0X02
#define WATER_FLOW_FUN_ID	0X04

#define ERR_AT_IDLE_FUN_ID	0X01	//Errors

#define EMER_POPUP_ACK_FUN_ID	0X01
#define ALERT_POPUP_FUN_ID	0X02


#define IOT_SEND_DATA_FUN_ID	0X01  //IOT

#define HIGHSPEED_PROCESS_DATA_FUN_ID   	0X01
#define HIGHSPEED_N_PRO_START_DATA_FUN_ID   	0X02
#define HIGHSPEED_N_PRO_STP_DATA_FUN_ID   	0X03


#define SCREEN_FRZ_DATA_FUN_ID			0X01
/********************************FUN IDs**********************************/

/*******************************UART SEND APPID AND FUNID*******************/
#define DOOR_STATUS_APPID_FUNID		received_app_id=0X02,received_fun_id=0X01,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define DONE_APPID_FUNID		received_app_id=0X02,received_fun_id=0X06,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define ERR_SEND_APPID_FUNID		received_app_id=0X04,received_fun_id=0X01,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define ERR_AT_PROCESS_APPID_FUNID	received_app_id=0X02,received_fun_id=0X09,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define HEART_BEAT_APPID_FUNID		received_app_id=0X01,received_fun_id=0X02,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define ERR_CLOSED_APPID_FUNID		received_app_id=0X02,received_fun_id=0X0A,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define EMERGENY_POPUP_APPID_FUNID	received_app_id=0X05,received_fun_id=0X01,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0
#define SCREEN_FREZZE_APPID_FUNID	received_app_id=0X08,received_fun_id=0X01,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0


#define IO_STATUS_APPID_FUNID		received_app_id=0X03,received_fun_id=0X01

#define IOT_DATA_APPID_FUNID		received_app_id=0X06,received_fun_id=0X01


#endif