#include "sfr_r825.h"
#include "cstartdef.h" 
#include "xvariables.h"
#include "macro.h"


void init_machine();
extern void delay(unsigned char dly);
extern unsigned char eeprom_read(unsigned char address);
extern void eeprom_write(unsigned char,unsigned char);
void init_machine()
{
	
	temp_read=eeprom_read(0X25);
	if(temp_read==0xff)
	{
		for(i=0;i<0x26;i++)
		{
				eeprom_write(i,0);
				check_counter=5;
				while(check_counter);
		}
	}
	/********************* PROG 1 *********************/
	pgm1_fwd_rev_counter = eeprom_read(eeprom_prog1_fwd_bak_adrs_two);
	pgm1_fwd_rev_counter = (pgm1_fwd_rev_counter<<8);
	pgm1_fwd_rev_counter = (pgm1_fwd_rev_counter|eeprom_read(eeprom_prog1_fwd_bak_adrs_one));
	
	pgm1_up_down_counter1 = eeprom_read(eeprom_prog1_up_dn_adrs_two);
	pgm1_up_down_counter1 = (pgm1_up_down_counter1<<8);
	pgm1_up_down_counter1 = (pgm1_up_down_counter1|eeprom_read(eeprom_prog1_up_dn_adrs_one));

/*	if((pgm1_position_fwd_bak >0)OR(pgm1_position_up_dwn>0))
	pgm1_prog_flag = SET;

/********************PROG 2**********************/
	pgm2_fwd_rev_counter = eeprom_read(eeprom_prog2_fwd_bak_adrs_two);
	pgm2_fwd_rev_counter = (pgm2_fwd_rev_counter<<8);
	pgm2_fwd_rev_counter = (pgm2_fwd_rev_counter|eeprom_read(eeprom_prog2_fwd_bak_adrs_one));
	
	pgm2_up_down_counter1 = eeprom_read(eeprom_prog2_up_dn_adrs_two);
	pgm2_up_down_counter1 = (pgm2_up_down_counter1<<8);
	pgm2_up_down_counter1 = (pgm2_up_down_counter1|eeprom_read(eeprom_prog2_up_dn_adrs_one));
	
/*	if((pgm2_position_fwd_bak>0)OR(pgm2_position_up_dwn>0))
	pgm2_prog_flag = SET;

/********************ZERO PROGRAM**********************/	
/*	zero_fwd_rev_counter = eeprom_read(eeprom_zero_fwd_bak_adrs_two);
	zero_fwd_rev_counter = (zero_fwd_rev_counter<<8);
	zero_fwd_rev_counter = (zero_fwd_rev_counter|eeprom_read(eeprom_zero_fwd_bak_adrs_one));
	
	zero_up_down_counter1 = eeprom_read(eeprom_zero_up_dn_adrs_two);
	zero_up_down_counter1 = (zero_up_down_counter1<<8);
	zero_up_down_counter1 = (zero_up_down_counter1|eeprom_read(eeprom_zero_up_dn_adrs_one));
	
/*	if((zero_position_fwd_bak >0)OR(zero_position_up_dwn>0))
	zero_prog_flag = SET;

/********************SHARK**********************/
/*	shark_fwd_rev_counter = eeprom_read(eeprom_shark_fwd_bak_adrs_two);
	shark_fwd_rev_counter = (shark_fwd_rev_counter<<8);
	shark_fwd_rev_counter = (shark_fwd_rev_counter|eeprom_read(eeprom_shark_fwd_bak_adrs_one));
	
	shark_up_down_counter1 = eeprom_read(eeprom_shark_up_dn_adrs_two);
	shark_up_down_counter1 = (shark_up_down_counter1<<8);
	shark_up_down_counter1 = (shark_up_down_counter1|eeprom_read(eeprom_shark_up_dn_adrs_one));*/
	
/*	if((shark_position_fwd_bak >0)OR(shark_position_up_dwn>0))
	shark_prog_flag = SET;

/********************GAUGLE**********************/

	gaugle_fwd_rev_counter = eeprom_read(eeprom_gaugle_dis_adrs_two);
	gaugle_fwd_rev_counter = (gaugle_fwd_rev_counter<<8);
	gaugle_fwd_rev_counter = (gaugle_fwd_rev_counter|eeprom_read(eeprom_gaugle_dis_adrs_one));
/*	if(gaugle_position>0)
	gaugle_prog_flag = SET;
	
/********************TUMBLER**********************/
	delay(0x02);
	eeram_tumbler_prgm_on_delay = eeprom_read(eeprom_tumbler_adrs_two);
	eeram_tumbler_prgm_on_delay = (eeram_tumbler_prgm_on_delay<<8);
	delay(0x02);
	eeram_tumbler_prgm_on_delay = (eeram_tumbler_prgm_on_delay|eeprom_read(eeprom_tumbler_adrs_one));
	
/********************SPITOON**********************/
	delay(0x02);
	eeram_spit_prgm_on_delay = eeprom_read(eeprom_spit_adrs_two);
	eeram_spit_prgm_on_delay = (eeram_spit_prgm_on_delay<<8);
	delay(0x02);
	eeram_spit_prgm_on_delay = (eeram_spit_prgm_on_delay|eeprom_read(eeprom_spit_adrs_one));

/********************PROG 3**********************/
	pgm3_fwd_rev_counter = eeprom_read(eeprom_prog3_fwd_bak_adrs_two);
	pgm3_fwd_rev_counter = (pgm3_fwd_rev_counter<<8);
	pgm3_fwd_rev_counter = (pgm3_fwd_rev_counter|eeprom_read(eeprom_prog3_fwd_bak_adrs_one));
	
	pgm3_up_down_counter1 = eeprom_read(eeprom_prog3_up_dn_adrs_two);
	pgm3_up_down_counter1 = (pgm3_up_down_counter1<<8);
	pgm3_up_down_counter1 = (pgm3_up_down_counter1|eeprom_read(eeprom_prog3_up_dn_adrs_one));
	
/*	if((pgm3_position_fwd_bak>0)OR(pgm3_position_up_dwn>0))
	pgm3_prog_flag = SET;*/
/**************************actuator_positions********************************/
	
	
	fwd_rev_counter = eeprom_read(eeprom_fwd_rev_actuator_position_two);
	fwd_rev_counter = (fwd_rev_counter<<8);
	fwd_rev_counter = (fwd_rev_counter|eeprom_read(eeprom_fwd_rev_actuator_position_one));
	
	up_down_counter1 = eeprom_read(eeprom_up_dwn_actuator_position_two);
	up_down_counter1 = (up_down_counter1<<8);
	up_down_counter1 = (up_down_counter1|eeprom_read(eeprom_up_dwn_actuator_position_one1));
}	