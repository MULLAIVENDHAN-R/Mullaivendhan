#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"

void gen_pulse();
void gen_pulse_1();
void load_pwm_period(char period);
void load_pwm_period_1(char period_1);
void load_pwm_period_2(char period_2);

void gen_pulse()
{
if((speed>0)AND((hand_sw_flag)AND(on_off_flag)OR(foot_signal_flag))) 
	{
		MTR_ENABLE = ON;
		if(pulse_counter <= ON_TIME)
		{
			if(!pulse_on_flag)
			{
				pulse_on_flag = SET;
				PWM = ON;
			}
		}
		else
		{
			if(pulse_counter<ON_TIME+OFF_TIME)
			{
				if(pulse_on_flag)
				{
					pulse_on_flag = CLEAR;
					PWM = OFF;
				}
			}
			else
			pulse_counter = 0;
		}
	}
	else
	{
		MTR_ENABLE = OFF;
		PWM = OFF;
		pulse_counter = 0;
	}
}

void gen_pulse_1()
{
	if(MICRO_MOTOR_OFF>0)
	{
		MTR_ENABLE = ON;
		if(pulse_counter_1 <= ON_TIME_1)
		{
			if(!pulse_on_flag)
			{
				pulse_on_flag = SET;
				PWM = ON;
			}
		}
		else
		{
			if(pulse_counter_1<ON_TIME_1+OFF_TIME_1)
			{
				if(pulse_on_flag)
				{
					pulse_on_flag = CLEAR;
					PWM = OFF;
				}
			}
			else
			pulse_counter_1 = 0;
		}
	}
	else
	{
		MTR_ENABLE = OFF;
		PWM = OFF;
		pulse_counter_1 = 0;
	}
}

void load_pwm_period(char period)
{
	if(period)
	{
		//if(!micro_motor_slow_off_flag)
		{
			if((inc_key_sw_flag)OR(inc_dec_flag)OR(speed_on_flag))
			{
				switch(period)
				{
				/*	case(1):
							ON_TIME = 6;
							OFF_TIME = 242;
							BAR_LED_TWO_ON;
							break;
					case(2):
							ON_TIME = 18;
							OFF_TIME = 235;
							break*/
					case(1):
							ON_TIME = 32;
							OFF_TIME = 223;	
							BAR_LED_TWO_ON;					
							break;
					case(2):
							ON_TIME = 44;
							OFF_TIME = 209;
							BAR_LED_TWO_ON;
							break;
					case(3):
							ON_TIME = 57;
							OFF_TIME = 197;						
							break;
					case(4):
							ON_TIME = 69;
							OFF_TIME = 184;						
							break;
					case(5):
							ON_TIME = 82;
							OFF_TIME = 170;
							BAR_LED_TWO_ON;
							break;
					case(6):
							ON_TIME = 96;
							OFF_TIME = 159;	
							BAR_LED_THREE_ON;				
							break;
					case(7):
							ON_TIME = 108;
							OFF_TIME = 147;
						
							break;
					case(8):
							ON_TIME = 121;
							OFF_TIME =132;
							BAR_LED_THREE_ON;
							break;
					case(9):
							ON_TIME = 134;
							OFF_TIME = 121;	
							BAR_LED_FOUR_ON;				
							break;	
					case(10):
							ON_TIME = 147;
							OFF_TIME = 108;
						
							break;
					case(11):
							ON_TIME = 159;
							OFF_TIME = 96;
							BAR_LED_FOUR_ON;
							break;
					case(12):
							ON_TIME = 170;
							OFF_TIME = 82;	
							BAR_LED_FIVE_ON;				
							break;
					case(13):
							ON_TIME = 184;
							OFF_TIME = 70;
						
							break;
					case(14):
							ON_TIME = 197;
							OFF_TIME = 58;
							BAR_LED_FIVE_ON;
							break;
					case(15):
							ON_TIME = 209;
							OFF_TIME = 50;	
							BAR_LED_SIX_ON;				
							break;
					case(16):
							ON_TIME = 220;
							OFF_TIME = 49;
							BAR_LED_SIX_ON;
							break;
					case(17):
							ON_TIME = 233;
							OFF_TIME = 48;
							BAR_LED_SEVEN_ON;
							break;
					case(18):
							ON_TIME = 242;
							OFF_TIME = 47;	
							BAR_LED_SEVEN_ON;				
							break;
					case(19):
							ON_TIME = 242;
							OFF_TIME = 47;
							BAR_LED_SEVEN_ON;											
							break;					
				}
			}
			else
			{
				if((dec_key_sw_flag)OR(inc_dec_flag)OR(speed_on_flag))
				{
					switch(period)
					{
						case(1):
								ON_TIME = 32;
								OFF_TIME = 223;
								BAR_LED_TWO_OFF;	
								break;
						case(2):
								ON_TIME = 44;
								OFF_TIME = 209;
								BAR_LED_TWO_OFF;								
								break;
						case(3):
								ON_TIME = 57;
								OFF_TIME = 197;	
								BAR_LED_TWO_OFF;					
								break;
						case(4):
								ON_TIME = 69;
								OFF_TIME = 184;															
								break;
						case(5):
								ON_TIME = 82;
								OFF_TIME = 170;	
								BAR_LED_THREE_OFF;															
								break;
						case(6):
								ON_TIME = 96;
								OFF_TIME = 159;	
								BAR_LED_THREE_OFF;										
								break;
						case(7):
								ON_TIME = 108;
								OFF_TIME = 147;	
													
								break;
						case(8):
								ON_TIME = 121;
								OFF_TIME =132;
								BAR_LED_FOUR_OFF;	
								break;
						case(9	):
								ON_TIME = 134;
								OFF_TIME = 121;					
								break;	
						case(10):
								ON_TIME = 147;
								OFF_TIME = 108;
								BAR_LED_FIVE_OFF;						
								break;
						case(11):
								ON_TIME = 159;
								OFF_TIME = 96;							
								break;
						case(12):
								ON_TIME = 170;
								OFF_TIME = 82;	
								BAR_LED_FIVE_OFF;				
								break;
						case(13):
								ON_TIME = 184;
								OFF_TIME = 70;
								BAR_LED_SIX_OFF;							
								break;
						case(14):
								ON_TIME = 197;
								OFF_TIME = 58;							
								break;
						case(15):
								ON_TIME = 209;
								OFF_TIME = 50;	
								BAR_LED_SIX_OFF;				
								break;
						case(16):
								ON_TIME = 220;
								OFF_TIME = 49;	
								//BAR_LED_SIX_OFF;
								BAR_LED_SEVEN_OFF;						
								break;
						case(17):
								ON_TIME = 233;
								OFF_TIME = 48;
								BAR_LED_SEVEN_OFF;
								break;
						case(18):
								ON_TIME = 242;
								OFF_TIME = 47;
								BAR_LED_SEVEN_OFF;					
								break;
						case(19):
								ON_TIME = 242;
								OFF_TIME = 47;
								BAR_LED_SEVEN_OFF;												
								break;
						default:
								ON_TIME=0;
								OFF_TIME=0;
								break;			
					}
				}
			}
		}		
	}
}	

void load_pwm_period_1(char period_1)   //slowly off 
{
	switch(period_1)
	{
					case(1):
							ON_TIME = 32;
							OFF_TIME = 223;	
							BAR_LED_ONE_OFF;					
							break;
					case(2):
							ON_TIME = 44;
							OFF_TIME = 209;
							BAR_LED_ONE_OFF;
							break;
					case(3):
							ON_TIME = 57;
							OFF_TIME = 197;	
							BAR_LED_TWO_OFF	;				
							break;
					case(4):
							ON_TIME = 69;
							OFF_TIME = 184;						
							break;
					case(5):
							ON_TIME = 82;
							OFF_TIME = 170;
							BAR_LED_TWO_OFF;
							break;
					case(6):
							ON_TIME = 96;
							OFF_TIME = 159;	
							BAR_LED_THREE_OFF;				
							break;
					case(7):
							ON_TIME = 108;
							OFF_TIME = 147;
						
							break;
					case(8):
							ON_TIME = 121;
							OFF_TIME =132;
							BAR_LED_THREE_OFF;
							break;
					case(9):
							ON_TIME = 134;
							OFF_TIME = 121;	
							BAR_LED_FOUR_OFF;				
							break;	
					case(10):
							ON_TIME = 147;
							OFF_TIME = 108;						
							break;
					case(11):
							ON_TIME = 159;
							OFF_TIME = 96;
							BAR_LED_FOUR_OFF;
							break;
					case(12):
							ON_TIME = 170;
							OFF_TIME = 82;	
							BAR_LED_FIVE_OFF;				
							break;
					case(13):
							ON_TIME = 184;
							OFF_TIME = 70;
							BAR_LED_FIVE_OFF;
							break;
					case(14):
							ON_TIME = 197;
							OFF_TIME = 58;
							BAR_LED_FIVE_OFF;
							break;
					case(15):
							ON_TIME = 209;
							OFF_TIME = 50;	
							BAR_LED_SIX_OFF;				
							break;
					case(16):
							ON_TIME = 220;
							OFF_TIME = 49;
							//BAR_LED_SIX_OFF;
							BAR_LED_SEVEN_OFF;
							break;
					case(17):
							ON_TIME = 233;
							OFF_TIME = 48;
							BAR_LED_SEVEN_OFF;
							break;
					case(18):
							ON_TIME = 242;
							OFF_TIME = 47;	
							BAR_LED_SEVEN_OFF;				
							break;
					case(19):
							ON_TIME = 242;
							OFF_TIME = 47;
							BAR_LED_SEVEN_OFF;											
							break;	
					/*default:
							ON_TIME=0;
							OFF_TIME=0;
							break;	*/
	}
}
void load_pwm_period_2(char period_2)
{
		switch(period_2)
				{
					case(1):
							ON_TIME = 6;
							OFF_TIME = 242;
							BAR_LED_TWO_ON;
							break;
					case(2):
							ON_TIME = 18;
							OFF_TIME = 235;
							break;
					case(3):
							ON_TIME = 32;
							OFF_TIME = 223;						
							break;
					case(4):
							ON_TIME = 44;
							OFF_TIME = 209;
							BAR_LED_TWO_ON;
							break;
					case(5):
							ON_TIME = 57;
							OFF_TIME = 197;						
							break;
					case(6):
							ON_TIME = 69;
							OFF_TIME = 184;						
							break;
					case(7):
							ON_TIME = 82;
							OFF_TIME = 170;
							BAR_LED_THREE_ON;
							break;
					case(8):
							ON_TIME = 96;
							OFF_TIME = 159;					
							break;
					case(9):
							ON_TIME = 108;
							OFF_TIME = 147;
						
							break;
					case(10):
							ON_TIME = 121;
							OFF_TIME =132;
							BAR_LED_FOUR_ON;
							break;
					case(11	):
							ON_TIME = 134;
							OFF_TIME = 121;					
							break;	
					case(12):
							ON_TIME = 147;
							OFF_TIME = 108;
						
							break;
					case(13):
							ON_TIME = 159;
							OFF_TIME = 96;
							BAR_LED_FIVE_ON;
							break;
					case(14):
							ON_TIME = 170;
							OFF_TIME = 82;					
							break;
					case(15):
							ON_TIME = 184;
							OFF_TIME = 70;
						
							break;
					case(16):
							ON_TIME = 197;
							OFF_TIME = 58;
							BAR_LED_SIX_ON;
							break;
					case(17):
							ON_TIME = 209;
							OFF_TIME = 50;					
							break;
					case(18):
							ON_TIME = 220;
							OFF_TIME = 49;
							BAR_LED_SEVEN_ON;
							break;
					case(19):
							ON_TIME = 233;
							OFF_TIME = 48;
							BAR_LED_SEVEN_ON;
							break;
					case(20):
							ON_TIME = 242;
							OFF_TIME = 47;	
								BAR_LED_SEVEN_ON;				
							break;
					case(21):
							ON_TIME = 242;
							OFF_TIME = 47;
							BAR_LED_SEVEN_ON;											
							break;		
				speed_changed_flag=1;
				}
			
}