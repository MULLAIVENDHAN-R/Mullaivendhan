#ifndef MACROS_H
#define MACROS_H

//ROM : 3595H byte(s) real data
//RAM : 9EBH 

#define AND 			&&
#define OR 			||
#define EQUAL_TO		==
#define NOT_EQUAL_TO		!=
#define SET			1
#define CLEAR			0
#define HIGH			1
#define LOW			0
#define ON			1
#define OFF			0

#define MILI_SECOND		20   	// sec
#define MINITUES		1200   	// MIN

#define HEARTBEAT_SEC	 	60
#define TEMP_SEC		2 	// SEC

#define FWD			1
#define REV			2

#define UNI_D			1
#define BI_D			2
#define COOLING			1
#define HEATING			2

#define STEP_1			1
#define STEP_2			2
#define STEP_3			3
#define STEP_4			4
#define STEP_5			5

#define MAX_NO_OF_STEP		5

/****************************************OUTPUTS************************************************/

#define MOTOR_FWD 		P7.1       	//1

#define MOTOR_FWD_ON		MOTOR_FWD=0
#define MOTOR_FWD_OFF		MOTOR_FWD=1

#define MOTOR_REV 		P7.0		//2

#define MOTOR_REV_ON		MOTOR_REV=0
#define MOTOR_REV_OFF		MOTOR_REV=1

#define ELECTRIC_HEATER	 	P7.4		//3

#define ELECTRIC_HEATER_ON	ELECTRIC_HEATER=0
#define ELECTRIC_HEATER_OFF	ELECTRIC_HEATER=1

#define GAS_BURNER		P0.0		//4

#define GAS_BURNER_ON		GAS_BURNER=0
#define GAS_BURNER_OFF		GAS_BURNER=1

#define STEAM_VALVE		P0.0		//5

#define STEAM_VALVE_ON		STEAM_VALVE=0
#define STEAM_VALVE_OFF		STEAM_VALVE=1


#define COOLING_FAN 		P7.6		//6

#define COOLING_FAN_ON		COOLING_FAN=0
#define COOLING_FAN_OFF		COOLING_FAN=1

#define BLOWER 			P0.0		//7

#define BLOWER_ON		BLOWER=0
#define BLOWER_OFF		BLOWER=1

#define VFD 			P0.0		//8

#define VFD_ON			VFD=0
#define VFD_OFF			VFD=1

#define ALARM 			P0.0		//9

#define ALARM_ON		ALARM=0
#define ALARM_OFF		ALARM=1

#define SUPPRESSION_VALVE 	P0.0		//10

#define SUPPRESSION_VALVE_ON	SUPPRESSION_VALVE=0
#define SUPPRESSION_VALVE_OFF	SUPPRESSION_VALVE=1

/****************************************OUTPUTS************************************************/

/****************************************INPUTS************************************************/

#define DOOR_SWITHCH   	P0.0
#define LINT_FILTER	P0.0


/****************************************INPUTS************************************************/

/****************************************HEATER_TYPE*******************************************/

#define ELECTRIC 	1
#define GAS		2
#define STEAM		3

/****************************************HEATER_TYPE*******************************************/

#define RELOAD_CLEAR_PROCESS_VALUES_AND_FLAGS	fwd_on_time_flag=fwd_pause_flag_flag=rev_on_time_flag=rev_pause_flag_flag=motor_fwd_on_time=motor_rev_on_time=motor_rev_pause_time=motor_fwd_pause_time=CLEAR

#define ALL_OUTPUT_OFF		COOLING_FAN_OFF,ELECTRIC_HEATER_OFF,MOTOR_REV_OFF,MOTOR_FWD_OFF
#define RESET_PROCESS		ALL_OUTPUT_OFF,fwd_on_time_flag=rev_on_time_flag=fwd_pause_flag_flag=rev_pause_flag_flag=cooling_flag=heating_flag=process_start_flag=SET
#define RESUME_PROCESS		P7.1=motor_fwd_pin_status,P7.0=motor_rev_pin_status,P7.6=cooling_pin_status,P7.4=heater_pin_status,fwd_on_time_flag=waiting_fwd_on_time_flag,rev_on_time_flag=waiting_rev_on_time_flag,fwd_pause_flag_flag=waiting_fwd_pause_flag_flag,rev_pause_flag_flag=waiting_rev_pause_flag_flag,steps_timing=waiting_steps_timing,total_no_of_steps=waiting_total_no_of_steps,process_start_flag=SET
#define PAUSE_PROCESS 		motor_fwd_pin_status=P7.1,motor_rev_pin_status=P7.0,cooling_pin_status=P7.6,heater_pin_status=P7.4,ALL_OUTPUT_OFF,waiting_fwd_on_time_flag=fwd_on_time_flag,waiting_rev_on_time_flag=rev_on_time_flag,waiting_fwd_pause_flag_flag=fwd_pause_flag_flag,waiting_rev_pause_flag_flag=rev_pause_flag_flag,waiting_steps_timing=steps_timing,waiting_total_no_of_steps=total_no_of_steps,fwd_on_time_flag=rev_on_time_flag=fwd_pause_flag_flag=rev_pause_flag_flag=cooling_fan_on_flag=process_start_flag=CLEAR
#define STOP_PROCESS		ALL_OUTPUT_OFF,fwd_on_time_flag=fwd_pause_flag_flag=rev_on_time_flag=rev_pause_flag_flag=total_no_of_steps=steps_timing=motor_fwd_on_time=motor_rev_on_time=motor_rev_pause_time=motor_fwd_pause_time=set_temperature=set_rpm=set_splits=set_direction=cooling_fan_on_flag=process_start_flag=CLEAR


/********************************I2C START*************************/

#define	SCL		P6.0
#define	SDA		P6.1

#define SDA_INPUT	PM6.1=1 		
#define SDA_OUTPUT	PM6.1=0


#define	SCL_INPUT	PM6.0=1
#define	SCL_OUTPUT	PM6.0=0
/********************************I2C END**************************/



/**************************** I2C START*************************/

#define SHT20_READ		0XE7
#define SHT20_WRITE		0XE6

#define SHT20_DEVICE_ADDRESS	0X40


#define SHT20_TEMP		0XF3
#define SHT20_HUMI		0XF5

#define SHIFTED_DIVISOR 	0x988000

#define MIM_TEMP_VALUE 	 		14075//13870 



#endif