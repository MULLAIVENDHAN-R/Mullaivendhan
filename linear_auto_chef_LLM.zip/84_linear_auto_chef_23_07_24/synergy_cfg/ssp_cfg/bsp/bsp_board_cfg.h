/* generated configuration header file - do not edit */
#ifndef BSP_BOARD_CFG_H_
#define BSP_BOARD_CFG_H_
void bsp_init(void *p_args);
#endif /* BSP_BOARD_CFG_H_ */
