#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h" 
#include "GUI_XVariables.h" 

void water_level_filling();
void water_heater_control();

void water_level_filling()
{
	if(!cooker3_switch_close_flag)
	{
		if(water_pump_on_flag)
		{
			/*if((water_level_sensor_close_ctr>60)AND(cooker3_switch_close_flag))
			{
				WATER_PUMP_OFF;
				water_level_sensor_close_ctr=0;
				water_pump_on_flag=CLEAR;
				init_filling_flag=CLEAR;
			}*/
		}
		else
		{
			if(water_level_sensor_open_ctr>20)
			{
				WATER_PUMP_ON;
				water_pump_on_flag=SET;
				water_level_sensor_open_ctr=0;
				
			}
		}
	}
	else
	{
		if(((water_level_sensor_close_ctr>20)AND(water_pump_on_flag))OR((water_level_sensor_close_ctr>20)AND(init_filling_flag)))
		{
			WATER_PUMP_OFF;
			water_level_sensor_close_ctr=0;
			water_pump_on_flag=CLEAR;
			init_filling_flag=CLEAR;
		}
	}
}

void water_heater_control()
{
	acc_temp[m] =(int)((1023-ad_result)/PER_DEG_COUNTS);	// to change count as temperature. //clamp_20k_sensor_calibration(ad_result);
	m++;
	if(!TEST_MODE)
	{
		if(m>1)
		{
			m=0x00;
			crnt_temp[t] = ((acc_temp[0]+acc_temp[1])/2);
			t++;
			if(t>1)
			{
				t=0;
				if(crnt_temp[0]==crnt_temp[1])
				{				
					ctemp  =(unsigned char)(crnt_temp[0]);					
				}
			}
		}
	}
	else
	ctemp=90;	
	
	if(((ctemp<=(SET_TEMP-2))AND(!heater_on_off_flag))OR(init_heating_flag))
	{
		ING37_MTR_ON;
		heater_on_off_flag=SET;
	}
	else
	{
		if((ctemp>SET_TEMP)AND(heater_on_off_flag))
		{
			ING37_MTR_OFF;
			heater_on_off_flag=CLEAR;
			init_heating_flag=CLEAR;
		}
	}
}