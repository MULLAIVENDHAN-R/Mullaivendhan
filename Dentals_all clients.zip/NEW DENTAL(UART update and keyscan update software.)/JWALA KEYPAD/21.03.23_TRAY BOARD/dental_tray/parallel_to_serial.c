#include "sfr_r825.h"
#include "cstartdef.h" 
#include "xvariables.h"
#include "macro.h"

void load_parallel_inputs();

/*void load_parallel_inputs()
{
	
	SHLD = LOW;
	CLK = LOW;
	
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	CLK = HIGH;
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	SHLD = HIGH;
	
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	counter = 0;
	serial_receiving_data = 0X00000000;
	get_ser_bit =0;
	while(counter<24)
	{		
	
		get_ser_bit = (FNL_SER_OP);
		CLK = LOW;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		CLK = HIGH;
		serial_receiving_data = (serial_receiving_data|get_ser_bit);
		serial_receiving_data=serial_receiving_data&0x00ffffff;
		serial_receiving_data <<=1;		
		counter++;	
		
	}
//	serial_receiving_data >>=1;
	serial_receiving_data = (serial_receiving_data|fw_rev_key );
	temp_serial_received_data=serial_receiving_data;

}
void load_led_data()
{
	temp_led_op_variable=led_op_variable;
	temp_led_op_variable1=temp_led_op_variable;
	STROBE = LOW;
	intt_var=0;
	while(intt_var<32)
	{	
		intt_var++;
		STROBE = LOW;
		temp_led_op_variable1=temp_led_op_variable1&0x80000000;
		temp_led_op_variable1>>=31;
		LED_DATA=temp_led_op_variable1;
		temp_led_op_variable=temp_led_op_variable<<1;
		temp_led_op_variable1=temp_led_op_variable;
		HEF4094_CLK=LOW;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
	/*	asm ("NOP");
		asm ("NOP");
		asm ("NOP");
			asm ("NOP");
		asm ("NOP");
		asm ("NOP");
			asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		HEF4094_CLK=HIGH;
	}
	STROBE = HIGH;	
}*/