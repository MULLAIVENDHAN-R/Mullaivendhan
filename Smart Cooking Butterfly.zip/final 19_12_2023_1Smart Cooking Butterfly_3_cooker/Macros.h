#ifndef MACROS_H
#define MACROS_H

#define AND 			&&
#define OR 			||
#define EQUAL_TO		==
#define NOT_EQUAL_TO		!=
#define SET			1
#define CLEAR			0
#define HIGH			1
#define LOW			0
#define ON			1
#define OFF			0


#define TEST_MODE		0 
#define HARDWARE_TEST		0
#define SHORT_CIRCUIT_TEST	0

#if TEST_MODE
#define SECONDS			1
#define MILLI_SECONDS		1000
#else
#define SECONDS			60
#define MILLI_SECONDS		1000
#endif

#define PER_DEG_COUNTS		7.5//6.800 //7.500 (count incresing at same time degere incres)4lane
#define SET_TEMP		85

#define BUBBER_TIME		1  // sec
#define BUBBER_TIME_SECONDS	10  
#define BUBBER_TIME_MINUTES	60 
/***************************************ALL OUTPUTS*******************************/

#define BUZZER			P4.4
#define BUZZER_ON		BUZZER=1
#define BUZZER_OFF		BUZZER=0

#define COOKER_MOTOR_FWD	P6.1
#define COOKER_MOTOR_FWD_ON	COOKER_MOTOR_FWD=0,COOKER_MOTOR_REV=1
#define COOKER_MOTOR_REV	P6.2		// water  
#define COOKER_MOTOR_REV_ON	COOKER_MOTOR_REV=0,COOKER_MOTOR_FWD=1
#define COOKER_MOTOR_OFF	COOKER_MOTOR_FWD=1,COOKER_MOTOR_REV=1,cooker_mtr_time=0

#define WATER_PUMP		P6.3
#define WATER_PUMP_ON		WATER_PUMP=0,water_pump_used_flag=SET//lid2_vegtray2_used_flag=SET
#define WATER_PUMP_OFF		WATER_PUMP=1,temp_water_pump_time=0,water_pump_used_flag=CLEAR//lid2_vegtray2_used_flag=CLEAR

#define OIL_PUMP		P13.0
#define OIL_PUMP_ON		OIL_PUMP=0,lid2_vegtray2_used_flag=SET	
#define OIL_PUMP_OFF		OIL_PUMP=1,temp_oil_pump_time=0,lid2_vegtray2_used_flag=CLEAR

#define HEATER_A		P6.7
#define HEATER_A_ON		HEATER_A=0
#define HEATER_A_OFF		HEATER_A=1,temp_htr1_time=0

#define HEATER_B		P6.6
#define HEATER_B_ON		HEATER_B=0
#define HEATER_B_OFF		HEATER_B=1,temp_htr2_time=0

#define HEATER_C		P6.5//P6.5
#define HEATER_C_ON		HEATER_C=0
#define HEATER_C_OFF		HEATER_C=1,temp_htr3_time=0

#define HEATER_D		P6.4//P6.4
#define HEATER_D_ON		HEATER_D=0
#define HEATER_D_OFF		HEATER_D=1,temp_htr4_time=0


/***************NEGATIVE SWITCHING MOSFET MOTOTS**********/


#define ING_MOTOR1		P7.3
#define ING_MOTOR1_ON		ING_MOTOR1=1
#define ING_MOTOR1_OFF		ING_MOTOR1=0

#define ING_MOTOR2		P7.2
#define ING_MOTOR2_ON		ING_MOTOR2=1
#define ING_MOTOR2_OFF		ING_MOTOR2=0

#define ING_MOTOR3		P7.1
#define ING_MOTOR3_ON		ING_MOTOR3=1
#define ING_MOTOR3_OFF		ING_MOTOR3=0

#define ING_MOTOR4		P7.0
#define ING_MOTOR4_ON		ING_MOTOR4=1
#define ING_MOTOR4_OFF		ING_MOTOR4=0

#define ING_MOTOR5		P8.1
#define ING_MOTOR5_ON		ING_MOTOR5=1
#define ING_MOTOR5_OFF		ING_MOTOR5=0

#define ING_MOTOR6		P8.0
#define ING_MOTOR6_ON		ING_MOTOR6=1
#define ING_MOTOR6_OFF		ING_MOTOR6=0

#define ING_MOTOR7		P0.5
#define ING_MOTOR7_ON		ING_MOTOR7=1
#define ING_MOTOR7_OFF		ING_MOTOR7=0

#define ING_MOTOR8		P0.6
#define ING_MOTOR8_ON		ING_MOTOR8=1
#define ING_MOTOR8_OFF		ING_MOTOR8=0

/***************NEGATIVE SWITCHING MOSFET MOTOTS**********/

/***************POSITIVE SWITCHING MOSFET MOTOTS**********/

#define ING_MOTOR_POS1		P7.5
#define ING_MOTOR_POS1_ON	ING_MOTOR_POS1=1
#define ING_MOTOR_POS1_OFF	ING_MOTOR_POS1=0

#define ING_MOTOR_POS2		P7.4
#define ING_MOTOR_POS2_ON	ING_MOTOR_POS2=1
#define ING_MOTOR_POS2_OFF	ING_MOTOR_POS2=0

#define ING_MOTOR_POS3		P7.6
#define ING_MOTOR_POS3_ON	ING_MOTOR_POS3=1
#define ING_MOTOR_POS3_OFF	ING_MOTOR_POS3=0

#define ING_MOTOR_POS4		P7.7
#define ING_MOTOR_POS4_ON	ING_MOTOR_POS4=1
#define ING_MOTOR_POS4_OFF	ING_MOTOR_POS4=0

#define ING_MOTOR_POS5		P8.2
#define ING_MOTOR_POS5_ON	ING_MOTOR_POS5=1
#define ING_MOTOR_POS5_OFF	ING_MOTOR_POS5=0


/***************POSITIVE SWITCHING MOSFET MOTOTS**********/


#define ING1_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR1_ON
#define	ING1_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR1_OFF       

#define ING2_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR2_ON
#define	ING2_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR2_OFF		

#define ING3_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR3_ON
#define	ING3_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR3_OFF		

#define ING4_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR4_ON
#define	ING4_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR4_OFF			

#define ING5_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR5_ON
#define	ING5_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR5_OFF

#define ING6_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR6_ON
#define	ING6_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR6_OFF

#define ING7_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR7_ON
#define	ING7_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR7_OFF

#define ING8_MTR_ON		ING_MOTOR_POS1_ON,ING_MOTOR8_ON
#define	ING8_MTR_OFF		ING_MOTOR_POS1_OFF,ING_MOTOR8_OFF





#define ING9_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR1_ON
#define	ING9_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR1_OFF

#define ING10_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR2_ON
#define	ING10_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR2_OFF

#define ING11_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR3_ON
#define	ING11_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR3_OFF

#define ING12_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR4_ON
#define	ING12_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR4_OFF 	

#define ING13_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR5_ON
#define	ING13_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR5_OFF

#define ING14_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR6_ON
#define	ING14_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR6_OFF

#define ING15_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR7_ON
#define	ING15_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR7_OFF

#define ING16_MTR_ON		ING_MOTOR_POS2_ON,ING_MOTOR8_ON
#define	ING16_MTR_OFF		ING_MOTOR_POS2_OFF,ING_MOTOR8_OFF






#define ING17_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR1_ON
#define	ING17_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR1_OFF

#define ING18_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR2_ON
#define	ING18_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR2_OFF	

#define ING19_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR3_ON
#define	ING19_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR3_OFF

#define ING20_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR4_ON
#define	ING20_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR4_OFF

#define ING21_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR5_ON
#define	ING21_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR5_OFF

#define ING22_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR6_ON
#define	ING22_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR6_OFF

#define ING23_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR7_ON
#define	ING23_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR7_OFF

#define ING24_MTR_ON		ING_MOTOR_POS3_ON,ING_MOTOR8_ON
#define	ING24_MTR_OFF		ING_MOTOR_POS3_OFF,ING_MOTOR8_OFF





#define ING25_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR1_ON
#define	ING25_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR1_OFF	

#define ING26_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR2_ON
#define	ING26_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR2_OFF

#define ING27_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR3_ON
#define	ING27_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR3_OFF

#define ING28_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR4_ON
#define	ING28_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR4_OFF	

#define ING29_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR5_ON
#define	ING29_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR5_OFF

#define ING30_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR6_ON
#define	ING30_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR6_OFF	

#define ING31_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR7_ON
#define	ING31_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR7_OFF	

#define ING32_MTR_ON		ING_MOTOR_POS4_ON,ING_MOTOR8_ON
#define	ING32_MTR_OFF		ING_MOTOR_POS4_OFF,ING_MOTOR8_OFF	





#define ING33_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR1_ON
#define	ING33_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR1_OFF	

#define ING34_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR2_ON
#define	ING34_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR2_OFF	

#define ING35_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR3_ON
#define	ING35_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR3_OFF	

#define ING36_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR4_ON	//used as the hotwater solenoid
#define	ING36_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR4_OFF		

#define ING37_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR5_ON	//used as the heater
#define	ING37_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR5_OFF	

#define ING38_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR6_ON
#define	ING38_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR6_OFF		

#define ING39_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR7_ON
#define	ING39_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR7_OFF	

#define ING40_MTR_ON		ING_MOTOR_POS5_ON,ING_MOTOR8_ON
#define	ING40_MTR_OFF		ING_MOTOR_POS5_OFF,ING_MOTOR8_OFF	






#define ALL_NMOS_MOTORS_OFF	ING_MOTOR1_OFF,ING_MOTOR2_OFF,ING_MOTOR3_OFF,ING_MOTOR4_OFF,ING_MOTOR5_OFF,ING_MOTOR6_OFF,ING_MOTOR7_OFF,ING_MOTOR8_OFF
#define ALL_PMOS_MOTORS_OFF	ING_MOTOR_POS1_OFF,ING_MOTOR_POS2_OFF,ING_MOTOR_POS3_OFF,ING_MOTOR_POS4_OFF,ING_MOTOR_POS5_OFF
#define ALL_ING_MOTORS_OFF	ALL_NMOS_MOTORS_OFF,ALL_PMOS_MOTORS_OFF,ing_motor_time=0




#define DC_FAN			P8.4
#define DC_FAN_ON		DC_FAN=1
#define DC_FAN_OFF		DC_FAN=0,temp_fan_time=0


#define VEG_TRAY1_FWD		P14.7
#define VEG_TRAY1_FWD_ON	VEG_TRAY1_FWD=1,VEG_TRAY1_REV=0,lid1_vegtray1_used_flag=SET
#define VEG_TRAY1_REV		P14.6
#define VEG_TRAY1_REV_ON	VEG_TRAY1_REV=1,VEG_TRAY1_FWD=0,lid1_vegtray1_used_flag=SET

#define VEG_TRAY1_BRAKE		VEG_TRAY1_FWD=1,VEG_TRAY1_REV=1
#define VEG_TRAY1_STOP		VEG_TRAY1_FWD=0,VEG_TRAY1_REV=0

#define VEG_TRAY1_OFF		VEG_TRAY1_STOP,vegtray1_time=0,lid1_vegtray1_used_flag=CLEAR


#define VEG_TRAY2_FWD		P15.6
#define VEG_TRAY2_FWD_ON	VEG_TRAY2_FWD=1,VEG_TRAY2_REV=0,lid2_vegtray2_used_flag=SET
#define VEG_TRAY2_REV		P10.0
#define VEG_TRAY2_REV_ON	VEG_TRAY2_REV=1,VEG_TRAY2_FWD=0,lid2_vegtray2_used_flag=SET

#define VEG_TRAY2_BRAKE		VEG_TRAY2_FWD=1,VEG_TRAY2_REV=1
#define VEG_TRAY2_STOP		VEG_TRAY2_FWD=0,VEG_TRAY2_REV=0

#define VEG_TRAY2_OFF		VEG_TRAY2_STOP,vegtray2_time=0,lid2_vegtray2_used_flag=CLEAR

#define VEG_TRAY3_FWD		P15.4
#define VEG_TRAY3_FWD_ON	VEG_TRAY3_FWD=1,VEG_TRAY3_REV=0,lid3_vegtray3_used_flag=SET
#define VEG_TRAY3_REV		P15.5
#define VEG_TRAY3_REV_ON	VEG_TRAY3_REV=1,VEG_TRAY3_FWD=0,lid3_vegtray3_used_flag=SET

#define VEG_TRAY3_BRAKE		VEG_TRAY3_FWD=1,VEG_TRAY3_REV=1
#define VEG_TRAY3_STOP		VEG_TRAY3_FWD=0,VEG_TRAY3_REV=0

#define VEG_TRAY3_OFF		VEG_TRAY3_STOP,vegtray3_time=0,lid3_vegtray3_used_flag=CLEAR



#define LID_UP			P11.1
#define LID_UP_ON		LID_UP=1,LID_DWN=0,lid1_vegtray1_used_flag=SET
#define LID_DWN			P11.0
#define LID_DWN_ON		LID_DWN=1,LID_UP=0,lid1_vegtray1_used_flag=SET

#define LID_UP_DWN_STOP		LID_UP=0,LID_DWN=0
#define LID_UP_DWN_BRAKE	LID_UP=1,LID_DWN=1

#define LID_UP_DWN_OFF		LID_UP_DWN_STOP,lid_up_dwn_time=0,lid1_vegtray1_used_flag=CLEAR

#define LID_FWD			P10.1
#define LID_FWD_ON		LID_FWD=1,LID_REV=0,lid1_vegtray1_used_flag=SET
#define LID_REV			P1.0
#define LID_REV_ON		LID_REV=1,LID_FWD=0,lid1_vegtray1_used_flag=SET

#define LID_FWD_REV_STOP	LID_FWD=0,LID_REV=0
#define LID_FWD_REV_BRAKE	LID_FWD=1,LID_REV=1

#define LID_FWD_REV_OFF		LID_FWD_REV_STOP,lid_fwd_rev_time=0,lid1_vegtray1_used_flag=CLEAR




#define LID1_UP			P0.0
#define LID1_UP_ON		LID1_UP=1,LID1_DWN=0,lid2_vegtray2_used_flag=SET
#define LID1_DWN		P0.1
#define LID1_DWN_ON		LID1_DWN=1,LID1_UP=0,lid2_vegtray2_used_flag=SET

#define LID1_UP_DWN_STOP	LID1_UP=0,LID1_DWN=0
#define LID1_UP_DWN_BRAKE	LID1_UP=1,LID1_DWN=1

#define LID1_UP_DWN_OFF		LID1_UP_DWN_STOP,lid1_up_dwn_time=0,lid2_vegtray2_used_flag=CLEAR

#define LID1_FWD		P14.4
#define LID1_FWD_ON		LID1_FWD=1,LID1_REV=0,lid2_vegtray2_used_flag=SET
#define LID1_REV		P14.5
#define LID1_REV_ON		LID1_REV=1,LID1_FWD=0,lid2_vegtray2_used_flag=SET

#define LID1_FWD_REV_STOP	LID1_FWD=0,LID1_REV=0
#define LID1_FWD_REV_BRAKE	LID1_FWD=1,LID1_REV=1

#define LID1_FWD_REV_OFF	LID1_FWD_REV_STOP,lid1_fwd_rev_time=0,lid2_vegtray2_used_flag=CLEAR



#define LID2_UP			P14.2
#define LID2_UP_ON		LID2_UP=1,LID2_DWN=0,lid3_vegtray3_used_flag=SET
#define LID2_DWN		P14.3
#define LID2_DWN_ON		LID2_DWN=1,LID2_UP=0,lid3_vegtray3_used_flag=SET

#define LID2_UP_DWN_STOP	LID2_UP=0,LID2_DWN=0
#define LID2_UP_DWN_BRAKE	LID2_UP=1,LID2_DWN=1

#define LID2_UP_DWN_OFF		LID2_UP_DWN_STOP,lid2_up_dwn_time=0,lid3_vegtray3_used_flag=CLEAR

#define LID2_FWD		P14.0
#define LID2_FWD_ON		LID2_FWD=1,LID2_REV=0,lid3_vegtray3_used_flag=SET
#define LID2_REV		P14.1
#define LID2_REV_ON		LID2_REV=1,LID2_FWD=0,lid3_vegtray3_used_flag=SET

#define LID2_FWD_REV_STOP	LID2_FWD=0,LID2_REV=0
#define LID2_FWD_REV_BRAKE	LID2_FWD=1,LID2_REV=1

#define LID2_FWD_REV_OFF	LID2_FWD_REV_STOP,lid2_fwd_rev_time=0,lid3_vegtray3_used_flag=CLEAR

#define KADAI_FWD		P15.0
#define KADAI_FWD_ON		KADAI_FWD=1,KADAI_REV=0,kadai_used_flag=SET
#define KADAI_REV		P15.1
#define KADAI_REV_ON		KADAI_REV=1,KADAI_FWD=0,kadai_used_flag=SET

#define KADAI_FWD_REV_STOP	KADAI_REV=0,KADAI_FWD=0
#define KADAI_FWD_REV_BRAKE	KADAI_REV=1,KADAI_FWD=1

#define KADAI_FWD_REV_OFF    	KADAI_FWD_REV_STOP,kadai_fwd_rev_time=0,kadai_used_flag=CLEAR
 
#define KADAI_CC		P2.2
#define KADAI_CC_ON		KADAI_CC=1,KADAI_CCW=0,kadai_used_flag=SET
#define KADAI_CCW		P2.3
#define KADAI_CCW_ON		KADAI_CCW=1,KADAI_CC=0,kadai_used_flag=SET


#define KADAI_CC_CCW_STOP	KADAI_CC=0,KADAI_CCW=0
#define KADAI_CC_CCW_BRAKE	KADAI_CC=1,KADAI_CCW=1

#define KADAI_CC_CCW_OFF    	KADAI_CC_CCW_STOP,kadai_cc_ccw_time=0,kadai_used_flag=CLEAR

#define STIRRER1_FWD		P15.3
#define STIRRER1_FWD_ON		STIRRER1_FWD=1,STIRRER1_REV=0
#define STIRRER1_REV		P15.2
#define STIRRER1_REV_ON		STIRRER1_REV=1,STIRRER1_FWD=0

#define STIRRER1_STOP		STIRRER1_FWD=0,STIRRER1_REV=0
#define STIRRER1_BRAKE		STIRRER1_FWD=1,STIRRER1_REV=1

#define STIRRER1_OFF		STIRRER1_STOP,str1_mtr_time=0

#define STIRRER2_FWD		P2.7
#define STIRRER2_FWD_ON		STIRRER2_FWD=1,STIRRER2_REV=0
#define STIRRER2_REV		P2.6
#define STIRRER2_REV_ON		STIRRER2_REV=1,STIRRER2_FWD=0

#define STIRRER2_STOP		STIRRER2_FWD=0,STIRRER2_REV=0
#define STIRRER2_BRAKE		STIRRER2_FWD=1,STIRRER2_REV=1

#define STIRRER2_OFF		STIRRER2_STOP,str2_mtr_time=0

#define STIRRER3_FWD		P2.5
#define STIRRER3_FWD_ON		STIRRER3_FWD=1,STIRRER3_REV=0
#define STIRRER3_REV		P2.4
#define STIRRER3_REV_ON		STIRRER3_REV=1,STIRRER3_FWD=0

#define STIRRER3_STOP		STIRRER3_FWD=0,STIRRER3_REV=0
#define STIRRER3_BRAKE		STIRRER3_FWD=1,STIRRER3_REV=1

#define STIRRER3_OFF		STIRRER3_STOP,str3_mtr_time=0

#define MOTOR9_FWD		P13.0
#define MOTOR9_FWD_ON		MOTOR9_FWD=1,MOTOR9_REV=0
#define MOTOR9_REV		P13.0
#define MOTOR9_REV_ON		MOTOR9_REV=1,MOTOR9_FWD=0
#define MOTOR9_OFF		MOTOR9_FWD=0,MOTOR9_REV=0

#define MOTOR10_FWD		P13.0
#define MOTOR10_FWD_ON		MOTOR10_FWD=1,MOTOR10_REV=0
#define MOTOR10_REV		P13.0
#define MOTOR10_REV_ON		MOTOR10_REV=1,MOTOR10_FWD=0
#define MOTOR10_OFF		MOTOR10_FWD=0,MOTOR10_REV=0


#define ALL_INDEP_OP_FLAG_CLEAR		htr1_on_flag=CLEAR,htr2_on_flag=CLEAR,htr3_on_flag=CLEAR,htr4_on_flag=CLEAR,wtr_htr_on_flag=CLEAR,dc_fan_on_flag=CLEAR,htr1_eeprom_store_flag=htr2_eeprom_store_flag=htr3_eeprom_store_flag=htr4_eeprom_store_flag=water_htr_eeprom_store_flag=dc_fan_eeprom_store_flag=c1_idle_eeprom_store_flag=c2_idle_eeprom_store_flag=c3_idle_eeprom_store_flag=SET
#define ALL_DUAL_DIR_MTR_OFF		VEG_TRAY1_OFF,VEG_TRAY2_OFF,VEG_TRAY3_OFF,LID_UP_DWN_OFF,LID_FWD_REV_OFF,STIRRER1_OFF,STIRRER2_OFF,STIRRER3_OFF//,MOTOR9_OFF,MOTOR10_OFF
#define ALL_OUTPUTS_OFF			COOKER_MOTOR_OFF,WATER_PUMP_OFF,OIL_PUMP_OFF,HEATER_A_OFF,HEATER_B_OFF,HEATER_C_OFF,HEATER_D_OFF,ALL_ING_MOTORS_OFF,DC_FAN_OFF,ALL_DUAL_DIR_MTR_OFF,ALL_INDEP_OP_FLAG_CLEAR



/***************************************ALL OUTPUTS*******************************/


/***************************LIMIT SWITCHES**************************/

#define VEG_TRAY1_SWITCH	P12.2
#define VEG_TRAY2_SWITCH	P12.1
#define VEG_TRAY3_SWITCH	P1.3
#define LID_UP_SWITCH		P12.0
#define LID_DWN_SWITCH		P12.4
#define LID_FWD_SWITCH		P12.3
#define LID_REV_SWITCH		P13.7
#define COOKER1_SWITCH		P1.4			//used as proximity sensor in 3 cooker model for cooker position 
#define COOKER2_SWITCH		P1.5			//used as limit switch in 3 cooker model for cooker position 
#define COOKER3_SWITCH		0			//used as float sensor for all model

//#define DUMMY_SWITCH1		P1.7			//As of now not used
//#define DUMMY_SWITCH2		P5.7			//As of now not used

#define LID1_UP_SWITCH		P4.1
#define LID1_DWN_SWITCH		P4.2
#define LID1_FWD_SWITCH		P4.3
#define LID1_REV_SWITCH		P4.5

#define LID2_UP_SWITCH		P4.6
#define LID2_DWN_SWITCH		P10.2
#define LID2_FWD_SWITCH		P0.4
#define LID2_REV_SWITCH		P8.5


//#define KADAI_CCW_SWITCH	P5.7			//used as kadai UP switch 
#define KADAI_CW_SWITCH		P1.7			//used as kadai DOWN switch
#define KADAI_REV_SWITCH	P1.6//P4.7		//used as kadai forward switch	(FLOWMWTER 1 )

/***************************LIMIT SWITCHES**************************/

/**************************EEPROM***********************************/
#define EEPROM_WRITE    0xa6
#define EEPROM_READ     0Xa7

#define SCL			P5.4
#define SDA			P5.3
#define SDA_INPUT		PM5.3=1  
#define SDA_OUTPUT		PM5.3=0

#define eeprom_htr1_on_off_state	10
#define eeprom_htr2_on_off_state	11
#define eeprom_htr3_on_off_state	12
#define eeprom_water_htr_on_off_state	13
#define eeprom_dc_fan_on_off_state	14
#define eeprom_c1_idle			15
#define eeprom_c2_idle			16
#define eeprom_c3_idle			17
#define eeprom_cooker_model		18
#define eeprom_htr4_on_off_state	19
#define eeprom_c1_lock			20
#define eeprom_c2_lock			21
#define eeprom_c3_lock			22
/**************************EEPROM***********************************/


/*************************************RTC******************************/

#define RTC_WRITE 			0x64
#define RTC_READ        		0x65

#define RTC_SECONDS 			0x10
#define RTC_MINUTES			0x11
#define RTC_HOURS			0x12
#define RTC_DAY				0x13
#define RTC_DATE			0x14
#define RTC_MONTH			0x15
#define RTC_YEAR			0x16


#define SUNDAY				0x01
#define MONDAY				0x02
#define TUESDAY				0x03
#define WEDNESDAY			0x04
#define THURSDAY			0x05
#define FRIDAY				0x06
#define SATURDAY			0x07

/*************************************RTC******************************/



/***********************************PROCESS DATA******************************/

#define COOKER1			1
#define COOKER2			2
#define COOKER3			3


#define IGM1			1
#define IGM2			2
#define IGM3			3
#define IGM4			4
#define IGM5			5
#define IGM6			6
#define IGM7			7
#define IGM8			8
#define IGM9			9
#define IGM10			10
#define IGM11			11
#define IGM12			12
#define IGM13			13
#define IGM14			14
#define IGM15			15
#define IGM16			16
#define IGM17			17
#define IGM18			18
#define IGM19			19
#define IGM20			20
#define IGM21			21
#define IGM22			22
#define IGM23			23
#define IGM24			24
#define IGM25			25
#define IGM26			26
#define IGM27			27
#define IGM28			28
#define IGM29			29
#define IGM30			30
#define IGM31			31
#define IGM32			32
#define IGM33			33
#define IGM34			34
#define IGM35			35
#define IGM1S			36
#define IGM2S			37
#define IGM3S			38
#define IGM4S			39
#define IGM5S			40
#define IGM6S			41
#define IGM7S			42
#define IGM8S			43
#define IGM9S			44
#define IGM10S			45
#define IGM11S			46
#define IGM12S			47
#define IGM13S			48
#define IGM14S			49
#define IGM15S			50
#define IGM16S			51
#define IGM17S			52
#define IGM18S			53
#define IGM19S			54
#define IGM20S			55
#define IGM21S			56
#define IGM22S			57
#define IGM23S			58
#define IGM24S			59
#define IGM25S			60
#define IGM26S			61
#define IGM27S			62
#define IGM28S			63
#define IGM29S			64
#define IGM30S			65
#define IGM31S			66
#define IGM32S			67
#define IGM33S			68
#define IGM34S			69
#define IGM35S			70
#define IGM37SOL		71

#define IDLELOCK		72		//lock to proceed with same cooker for particular time
#define LOCK			73		//lock to proceed with same cooker for particular steps
#define CKM			74

#define LDM1			75
#define LDM2			76
#define LDM3			77
#define LDM4			78
#define LDM5			79
#define LDM6			80
#define VTM1			81
#define VTM2			82
#define VTM3			83


#define FMT			84
#define IDLE			85		//allow to proceed other cooker
#define STM1			86
#define STM2			87
#define STM3			88
#define HTR1			89
#define HTR2			90
#define HTR3			91
#define IGM36HTR		92

#define OPB			93
#define WPB			94

#define	KTM1			95
#define	KTM2			96
#define KHTR			97

#define ALL_ING_MOTORS		1

#define OP_GETS_ON		1
#define OP_GETS_OFF		0

/***************************COOKING CONDITIONS******************************************/

/***************************COOKING CONDITIONS******************************************/

/***************************COOKING CONDITIONS******************************************/

#define IS_COOKER1_MOVE_OK		((!water_pump_used_flag)AND(c2_in_idle_condition_flag)AND(c3_in_idle_condition_flag)AND(!ing_motor_used_flag)AND(!lid2_vegtray2_used_flag)AND(!lid3_vegtray3_used_flag)AND((motor_code1==IDLELOCK)OR(motor_code1==CKM)OR((motor_code1==LOCK)AND(!c2_lock_flag)AND(!c3_lock_flag)AND(cooker1_switch_close_flag)AND(cooker2_switch_close_flag))))
#define IS_COOKER1_INGREDIENTS_OK	((!c2_lock_flag)AND(!c3_lock_flag)AND(!water_pump_used_flag)AND(c2_in_idle_condition_flag)AND(c3_in_idle_condition_flag)AND(!ing_motor_used_flag)AND((motor_code1>=IGM1)AND(motor_code1<=IGM37SOL)))
#define IS_COOKER1_LID_VEG_OK		((!c2_lock_flag)AND(!c3_lock_flag)AND(!water_pump_used_flag)AND(c2_in_idle_condition_flag)AND(c3_in_idle_condition_flag)AND((((motor_code1==LDM1)OR(motor_code1==LDM2)OR(motor_code1==VTM1))AND(cooker1_switch_close_flag)AND(cooker2_switch_close_flag))OR((motor_code1==VTM3)OR(motor_code1==VTM2))))
#define IS_COOKER1_INDEPENDENTS_OK	((motor_code1>=FMT)OR((motor_code1==IDLELOCK)AND(c1_lock_release_flag)))


#define IS_COOKER2_MOVE_OK		((!water_pump_used_flag)AND(c1_in_idle_condition_flag)AND(c3_in_idle_condition_flag)AND(!ing_motor_used_flag)AND(!lid1_vegtray1_used_flag)AND(!lid3_vegtray3_used_flag)AND((motor_code2==IDLELOCK)OR(motor_code2==CKM)OR((motor_code2==LOCK)AND(!c1_lock_flag)AND(!c3_lock_flag)AND(cooker1_switch_close_flag)AND(cooker2_switch_close_flag))))
#define IS_COOKER2_INGREDIENTS_OK	((!c1_lock_flag)AND(!c3_lock_flag)AND(!water_pump_used_flag)AND(c1_in_idle_condition_flag)AND(c3_in_idle_condition_flag)AND(!ing_motor_used_flag)AND((motor_code2>=IGM1)AND(motor_code2<=IGM37SOL)))
#define IS_COOKER2_LID_VEG_OK		((!c1_lock_flag)AND(!c3_lock_flag)AND(!water_pump_used_flag)AND(c1_in_idle_condition_flag)AND(c3_in_idle_condition_flag)AND((((motor_code2==LDM3)OR(motor_code2==LDM4)OR(motor_code2==VTM2)OR(motor_code2==OPB)OR(motor_code2==WPB))AND(cooker1_switch_close_flag)AND(cooker2_switch_close_flag))OR((motor_code2==VTM1)OR(motor_code2==VTM3))))
#define IS_COOKER2_INDEPENDENTS_OK	/*(((motor_code2>=FMT)AND(motor_code2<=IGM36HTR))*/((motor_code2>=FMT)OR((motor_code2==IDLELOCK)AND(c2_lock_release_flag)))


#define IS_COOKER3_MOVE_OK		((!water_pump_used_flag)AND(c1_in_idle_condition_flag)AND(c2_in_idle_condition_flag)AND(!ing_motor_used_flag)AND(!lid1_vegtray1_used_flag)AND(!lid2_vegtray2_used_flag)AND((motor_code3==IDLELOCK)OR(motor_code3==CKM)OR((motor_code3==LOCK)AND(!c2_lock_flag)AND(!c1_lock_flag)AND(cooker1_switch_close_flag)AND(cooker2_switch_close_flag))))
#define IS_COOKER3_INGREDIENTS_OK	((!c1_lock_flag)AND(!c2_lock_flag)AND(!water_pump_used_flag)AND(c1_in_idle_condition_flag)AND(c2_in_idle_condition_flag)AND(!ing_motor_used_flag)AND((motor_code3>=IGM1)AND(motor_code3<=IGM37SOL)))
#define IS_COOKER3_LID_VEG_OK		((!c2_lock_flag)AND(!c1_lock_flag)AND(!water_pump_used_flag)AND(c2_in_idle_condition_flag)AND(c1_in_idle_condition_flag)AND((((motor_code3==LDM5)OR(motor_code3==LDM6)OR(motor_code3==VTM3))AND(cooker1_switch_close_flag)AND(cooker2_switch_close_flag))OR((motor_code3==VTM1)OR(motor_code3==VTM2))))
#define IS_COOKER3_INDEPENDENTS_OK	((motor_code3>=FMT)OR((motor_code3==IDLELOCK)AND(c3_lock_release_flag)))



	 
#define IS_THIS_FINE_START_D1 	((( IS_COOKER1_MOVE_OK)  OR  (IS_COOKER1_INGREDIENTS_OK)  OR  (IS_COOKER1_LID_VEG_OK)  OR  (IS_COOKER1_INDEPENDENTS_OK)) OR (is_model_1) )

#define IS_THIS_FINE_START_D2	((( IS_COOKER2_MOVE_OK)  OR  (IS_COOKER2_INGREDIENTS_OK)  OR  (IS_COOKER2_LID_VEG_OK)  OR  (IS_COOKER2_INDEPENDENTS_OK)) OR (is_model_1) )

#define IS_THIS_FINE_START_D3	((( IS_COOKER3_MOVE_OK)  OR  (IS_COOKER3_INGREDIENTS_OK)  OR  (IS_COOKER3_LID_VEG_OK)  OR  (IS_COOKER3_INDEPENDENTS_OK)) OR (is_model_1) )


/***************************COOKING CONDITIONS******************************************/

/***************************KADAI CONDITIONS******************************************/
#define C1_KADAI_FAILURE    	(((c1_in_idle_condition_flag)AND(c1_lock_flag))AND((c2_in_idle_condition_flag)AND(!c2_lock_flag))AND((c3_in_idle_condition_flag)AND(!c3_lock_flag)))
#define C2_KADAI_FAILURE	(((c1_in_idle_condition_flag)AND(!c1_lock_flag))AND((c2_in_idle_condition_flag)AND(c2_lock_flag))AND((c3_in_idle_condition_flag)AND(!c3_lock_flag)))
#define C3_KADAI_FAILURE	(((c1_in_idle_condition_flag)AND(!c1_lock_flag))AND((c2_in_idle_condition_flag)AND(!c2_lock_flag))AND((c3_in_idle_condition_flag)AND(c3_lock_flag)))
/***************************KADAI CONDITIONS******************************************/

/***********************************PROCESS DATA******************************/

/*****************************ACTION BASED********************/

#define TIME_BASED		1
#define SWITCH_BASED		2
#define PULSE_BASED		3

/*****************************ACTION BASED********************/

/****************************DIRECTION************************/

#define FWD			1
#define REV			2

/****************************DIRECTION************************/



#define CKR1_STR		0X31		//it means 1 in hex format
#define CKR2_STR		0X32		//it means 2 in hex format
#define CKR3_STR		0X33		//it means 3 in hex format





/*********************************APP IDs**********************************/  

#define HANDSHAKE_APP_ID	0X01            //Handshake process
#define VEG_TRAY_ADJ_APP_ID	0X02		//Veg tray position adjustment
#define LID_ADJ_APP_ID		0X03		//lid position adjustment
#define LOAD_TEST_APP_ID	0X04		//Load test process
#define RECEIPE_PREP_APP_ID	0X05		//receipe preparation process
#define HEART_BEAT_APP_ID	0X06		//heart beat data
#define ERR_APP_ID		0X09		//error data send process

/*********************************APP IDs**********************************/ 

/********************************FUN IDs**********************************/

#define ERR_FUN_ID				0X01		//error data send process

#define DISPLAY_ST_FUN_ID			0X01		//Handshake process
#define HNDSHKE_ACK_FUN_ID			0X01
#define PENDING_RESTART_FUN_ID			0X02


#define POS_REQ_FUN_ID				0X01		//Veg tray position adjustment and lid position adjustment
#define ADJ_DATA_FUN_ID				0X02


#define TEST_DATA_FUN_ID			0X01		//Load test process
#define TEST_STOP_FUN_ID			0X02
#define SINGLE_MULTI_COOKER_SELECT_FUN_ID	0X03

#define STEP_DATA_FUN_ID			0X01		//receipe preparation process
#define DONE_ACK_FUN_ID				0X02
#define PREP_STOP_FUN_ID			0X03
#define ALL_STEPS_DONE				0X04	
#define STEPS_START				0X05
#define STEP_TIMER_ACK				0X06

#define HEART_BEAT_FUN_ID			0X01		//heart beat data
#define RTC_SEND_ACK_FUNID			0X02
#define RTC_RECEIVE_FUNID			0X03


/********************************FUN IDs**********************************/


#endif
