#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include "X_variables.h"
#include <stdlib.h>
#include "string.h"

unsigned int Sht20_reading; 	  
__boolean  SHT20_temp_flag, SHT20_humidity_flag,device_ack_ok_flag,command_ok_flag,dummy_write_ok_flag,check_sum_ok_flag,mcp_presure_flag,mcp_temp_flag; 
float Sht20_temp_float_value,Sht20_humid_float_value;
unsigned short int Sht20_real_temp,Sht20_real_humid;
unsigned char sht20_out[2],SHT20_count,msb_value,lsb_value,sht_check_sum;

void start_iic();
void stop();
void clock (void);
void iic_delay(unsigned char);
__boolean ack (void);
char Sht20_CheckCrc (unsigned char[],unsigned char, unsigned char );
__boolean sht20_address_write(unsigned char sht_20);
__boolean sht20_address_read(unsigned char device, unsigned char no_bytes );
void rec_data (void);
void data_trans(unsigned char tr_data, unsigned char tmp_bits);
void send_ack (char status);
__boolean  presure_read_iic(unsigned char , unsigned char );
__boolean presure_write_iic(unsigned char , unsigned char );
__boolean  address_write_fun(unsigned char);
void read_data_fun();
void send_ack(char);
int bit_test(unsigned char);
void one_shot_mode(unsigned char);


void humidity_sensor()
{		
	char sht20_sensor_address;	
	
	if(humidity_read_flag)
	{			
		if(SHT20_temp_flag)
		sht20_sensor_address=SHT20_TEMP;
		else if(SHT20_humidity_flag)
		sht20_sensor_address=SHT20_HUMI;	
		start_iic();
		device_ack_ok_flag=(sht20_address_write((SHT20_DEVICE_ADDRESS<<1)&0xFE));  		// write device address 
		if(device_ack_ok_flag)
		{
			command_ok_flag=(sht20_address_write(sht20_sensor_address));
			if(command_ok_flag)
			{
				sh_count=100;
				while(sh_count);
				stop();
				iic_delay(0x0f);
				start_iic();
				dummy_write_ok_flag=(sht20_address_write(((SHT20_DEVICE_ADDRESS << 1) + 1)));				
				if(dummy_write_ok_flag)
				sht20_address_read(0x81,3);
				else
				sht20_sensor_address=SHT20_humidity_flag=SHT20_temp_flag=CLEAR;
				stop();
			}
		}
		else
		{
			stop();
			sht20_sensor_address=SHT20_humidity_flag=SHT20_temp_flag=CLEAR;			
		}
		
		sht20_out[0]=msb_value;
		sht20_out[1]=lsb_value;
		check_sum_ok_flag=(Sht20_CheckCrc(sht20_out,2,sht_check_sum));
		if(check_sum_ok_flag)
		{			
			Sht20_reading = (msb_value);				 
			Sht20_reading=(Sht20_reading<<8)|lsb_value;
			if(SHT20_humidity_flag)
			{
				Sht20_humid_float_value = Sht20_reading * (125.0 / 65536.0);
				Sht20_humid_float_value = Sht20_humid_float_value - 6.0;
				Sht20_real_humid=(int)Sht20_humid_float_value;
				humidity_data=Sht20_real_humid;
			}											
			else if(SHT20_temp_flag)
			{
				Sht20_temp_float_value=Sht20_reading *(175.72 / 65536.0);		
	   			Sht20_temp_float_value= Sht20_temp_float_value - 46.85;
				Sht20_real_temp=(int)Sht20_temp_float_value;
				out_temperature_data=Sht20_real_temp;				
			}
			Sht20_reading=msb_value=lsb_value=sht_check_sum=SHT20_humidity_flag=SHT20_temp_flag=CLEAR;	
		}
		else 
		Sht20_reading=msb_value=lsb_value=sht_check_sum=SHT20_temp_flag=sht20_sensor_address=SHT20_humidity_flag=CLEAR;
		memset(sht20_out,0,sizeof(sht20_out));
		humidity_read_flag=CLEAR;
	}
}	

void sensors_read()
{
	if(sensors_read_flag)
	{
		unsigned char k=0 ;
		if(mcp_presure_flag)
		channel=3;
		else if(mcp_temp_flag)
		channel=4;
		
		one_shot_mode(channel);							//Channel config
		if(address_write_confirm_flag)
		{
			address_write_confirm_flag=CLEAR;		
			start_iic();			
			read_address_ack_flag = address_write_fun(0xd1);		//write_iic(0xd1,1);
			if(read_address_ack_flag)			
				presure_read_iic(0xd1,3);				//Data Read
			if(bit_test(ready_status))  					//if RDY = 1, New conversion not ready
			{
				do
				{					
					ready_status_check_flag=SET;
					presure_read_iic(0xd1,1);  			//read Status
					if(++k>15)
					break;
				} 
				while(bit_test(ready_status)); 				//until RDY = 0
				ready_status_check_flag=CLEAR;
				send_ack(0);						//out_data3=read_iic(0xd1,0);  //read Status, do nack
				stop();  						//send I2C stop
				if(k<15)
				{
					start_iic();  					//send I2C start
					read_address_ack_flag = presure_write_iic(0xd1,1);//send read command			
					presure_read_iic(0xd1,3);
					read_data_fun();
				}				
			}
			else
			read_data_fun();
			if(k>=15)
			read_data_fun();			
			send_ack(0);	
	   		stop();  			
			read_address_ack_flag=CLEAR;
		}
		mcp_temp_flag=mcp_presure_flag=sensors_read_flag = CLEAR;
	}	
}
void one_shot_mode(unsigned char address)
{
	//if(!address_ack_flag)
	start_iic();
	address_ack_flag=address_write_fun(0xd0);	//write_iic(0xd0,1);
	if(address_ack_flag)
	{
		if(address==1)
		write_ack_flag=presure_write_iic(0xcb,1);	//0xcb For CH3	0xbb For CH2	0xdb For CH3
		else if(address==2)
		write_ack_flag=presure_write_iic(0xab,1);	//0xab For CH2	0xbb For CH2	0xdb For CH3
		else if(address==3)
		write_ack_flag=presure_write_iic(0x8b,1);	//0x1b For CH1	0xbb For CH2	0xdb For CH3	0x1b
		else if(address==4)
		write_ack_flag=presure_write_iic(0xe8,1);
	}
	if(write_ack_flag)
	{
		stop();
		address_write_confirm_flag=SET;
		//channel++;
	}	
	//else 
	//channel=3;
	write_ack_flag=CLEAR;
}
void read_data_fun()
{  	
	float temperature_per_count;
	if(channel==3)
	{
		presure_data=ch3_out[0];
		presure_data=presure_data<<8;
		presure_data=presure_data|ch3_out[1];
		ready_status=ch3_out[2];		
	}
	else if(channel==4)
	{
		temp_data=ch4_out[0];
		temp_data=temp_data<<8;
		temp_data=temp_data|ch4_out[1];
		ready_status=ch4_out[2];
		temperature_reading=temp_data;
		
		if((temperature_reading>13770)AND(temperature_reading<14167))  			//(-20~c to 0~c)
		temperature_per_count=21.0; //
		
		else if((temperature_reading>14167)AND(temperature_reading<14750)) 		//(0~c to 30~c)
		temperature_per_count=19.2; 		
		
		else if((temperature_reading>14750)AND(temperature_reading<15200)) 		//(30~c to 50~c)
		temperature_per_count=19.8;  //19.5
		
		else if((temperature_reading>15200)AND(temperature_reading<16130))		//(50~c to 100~c)
		temperature_per_count=19.7;
		
		else if((temperature_reading>16130)AND(temperature_reading<17130))		//(100~c to 150~c)
		temperature_per_count=19.1;
		
		else if((temperature_reading>17130)AND(temperature_reading<18130))		//(150~c to 200~c)
		temperature_per_count=18.5;
		
		temperature_reading= temp_data-MIM_TEMP_VALUE;
		temperature_degree=(int)(temperature_reading/temperature_per_count);					// 
		current_temperature=temperature_degree-20;					//(-20~) its calibirate in 20~c
	}	
	memset(ch4_out,0,sizeof(ch4_out));
	memset(ch3_out,0,sizeof(ch3_out));
	ready_status=0;
		
}
int bit_test(unsigned char status)
{
	status=status&0x80;
	return(status);
}
void bit_read_fun()
{
	ready_status_check_flag=SET;
	presure_read_iic(0xd1,1);  //read Status
	if(!bit_test(ready_status)); //until RDY = 0
	{
		send_ack(0);//out_data3=read_iic(0xd1,0);  //read Status, do nack
		stop();  //send I2C stop
	}
	ready_status_check_flag=CLEAR;
}

__boolean presure_read_iic(unsigned char device_addr, unsigned char no_bytes)
{
	char i=0;
	char temp = 1;
	while(1)
	{
		clock_low_flag = SET;
		receive_bit_counter = 1;
		received_data = 0;
		SDA_INPUT;
		rec_data();
		SDA_OUTPUT;
		if(ready_status_check_flag)
		{
			ready_status=(char)received_data;
			if(!bit_test(ready_status))
			{
				send_ack(0);
				stop();	
				return(1);
			}
		}
		else
		{
			if(channel==1)
			{
				ch1_out[i++]=(char)received_data;
				ready_status=ch1_out[2];
			}
			else if(channel==2)
			{
				ch2_out[i++]=(char)received_data;
				ready_status=ch2_out[2];
			}
			else if(channel==3)
			{
				ch3_out[i++]=(char)received_data;
				ready_status=ch3_out[2];
			}
			else if(channel==4)
			{
				ch4_out[i++]=(char)received_data;
				ready_status=ch4_out[2];
			}
		}
		temp++;
		if (temp > no_bytes)
		{
//			send_ack(0);
//			stop();	
			//if(!ready_status_check_flag)
			send_ack(1);
			return(1);
		}
		else
		{
			send_ack(1);
		}			
	}
}
__boolean presure_write_iic(unsigned char device_addr, unsigned char no_bytes) 
{
	data_trans(device_addr, 0x08);//memory location address in the device;	
	if (! ack())
	{
		stop();//no ack;
		return(0);
	}
	if(SDA == LOW)//after ack,then SDA pulls up to 1;
	{
		SDA = 1;
		iic_delay(0x5f);
	}
	return(1);
} 
__boolean address_write_fun(unsigned char mcp_342x)
{
	data_trans(mcp_342x, 0x08);//adress of the device;
	if (! ack())
	{
		stop();
		return(0);
	}
	if(SDA == LOW)//after ack,then SDA pulls up to 1;
    	{
	   	SDA = 1;
       		iic_delay(0x5f);
	}
	return(1);
}
void start_iic (void)
{
	SCL = 1;
	SDA = 1;//falling edge of SDA when SCL=1;
	iic_delay(0x3F);

	SDA = 0;
	iic_delay(0x3F);

	SCL = 0;
	iic_delay(0x3f);
}
__boolean sht20_address_write(unsigned char sht_20)
{
	data_trans(sht_20 , 0x08);//adress of the device;
	if (! ack())
	{
		stop();
		return(0);
	}
	if(SDA == LOW)//after ack,then SDA pulls up to 1;
    	{
	   	SDA = 1;
       		iic_delay(0x5f);
	}
	return(1);
}
void stop (void)
{
	SDA = 0;
	iic_delay(0x0F);//rising edge of SDA when SCL=1;

	SCL = 1;
	SDA = 0;
	iic_delay(0x0F);

	SDA = 1;
	iic_delay(0x0F);
}
void clock (void)
{
	SCL = 1;
	iic_delay(0x07);//high to low;
	SCL = 0;
	iic_delay(0x07);
}


void iic_delay(unsigned char time)
{
	ACC = time*0x0f;//*0x0a;	//for renesas
while (ACC)
	{
		ACC--;
		//asm("clrwdt");
	}
}
__boolean ack (void)
{
	//__boolean ack_received_flag;
	
	SDA_INPUT;//SDA;
	//pd3_0=0;
	SDA = 1;
	iic_delay(0x0F);
	
	ACC = 0x3F*0x0f;//*0x0a;	//for renesas
	while (ACC)
	{
		//asm("clrwdt");
		ACC--;
		if (SDA == 0)//slave pulls SDA=0,when all datas are received by slave;
		{
			ack_received_flag = 1;
			break;
		}
		else
		{
			ack_received_flag = 0;
		}
	}	
	SCL = HIGH;
	iic_delay(0x7);
	SCL = 0;
	iic_delay(0x7);
	//TRISC = 0X06;
	SDA_OUTPUT;
	//pd3_0=1;
	return ack_received_flag;
} 
__boolean sht20_address_read(unsigned char device, unsigned char no_bytes )
{
	char i=0;
	char temp = 1;
	while(1)
	{
		clock_low_flag = SET;
		receive_bit_counter = 1;
		received_data = 0;
		SDA_INPUT;
		rec_data();
		SDA_OUTPUT;
		
		if(temp==1)
		msb_value=received_data;
		
		else if(temp==2)
		lsb_value=received_data;
		
		else if(temp==3)
		sht_check_sum=received_data;
		
		temp++;
		if (temp > no_bytes)
		{			
			send_ack(0);
			return(1);
		}
		else
		{
			send_ack(1);
		}		
	}
}
void rec_data (void)
{
	while (1)
	{
		if (clock_low_flag == SET)
		{
			clock_low_flag = CLEAR;
			SCL = HIGH;
			iic_delay(0x0f);	//0X0F
			sda_status_flag = CLEAR;
			if (SDA == HIGH)
			{
				sda_status_flag = SET;
			}
			iic_delay(0x0f);	//0X0F
		}
		else
		{
			clock_low_flag = SET;
			SCL = LOW;
			ACC = received_data;
			ACC = ACC << 1;
			if(sda_status_flag)
			{
				ACC |= 0x01;
			}
			received_data =(unsigned char)(ACC);
			receive_bit_counter++;
			if(receive_bit_counter > 8)
				break;
			iic_delay(0x0f);
		}	
	}
}
void data_trans(unsigned char tr_data, unsigned char tmp_bits)
{
	unsigned char tmp_tr_data,tmp_tr_data1;
	
	while (tmp_bits)   //changing of msb into lsb,bcoz msb is trd first and then trd;
	{			
		tmp_tr_data = tr_data;		//tmp_tr_data is just used as a variable not as eeprom address
  		tmp_tr_data1 = tmp_tr_data;
		tmp_tr_data1 >>=7;
		SDA = tmp_tr_data1;
		tr_data = tmp_tr_data<<1;
		iic_delay(0x50);	//3F);	
		clock();
		tmp_bits--;		
	}
}
void send_ack (char status)
{
	SCL = LOW;
	iic_delay (0x0F);
	if (status == HIGH)
		SDA = LOW;
	else
		SDA = HIGH;
	iic_delay (0x0F);
	SCL = HIGH;
	iic_delay (0xF);
	iic_delay (0xf);
	SCL = LOW;
	iic_delay (0x0F);	
	SDA = HIGH;
	iic_delay (0x0F);
}
char Sht20_CheckCrc (unsigned char data[], unsigned char nbrOfBytes, unsigned char checksum)
{
	char crc = 0;
	char byteCtr,a;

	for (byteCtr = 0; byteCtr < nbrOfBytes; ++byteCtr)
	{ 
	 crc ^= (data[byteCtr]);
	 for (a = 8; a > 0; --a)
	 {
		if (crc & 0x80)
		crc =(char)((crc << 1) ^ 0x131 );///
		else 
		crc = (crc << 1);
	 }
	}
	if (crc != sht_check_sum) 
	return 0;  			//error means RETURN '0'
	else 
	return 1;
}