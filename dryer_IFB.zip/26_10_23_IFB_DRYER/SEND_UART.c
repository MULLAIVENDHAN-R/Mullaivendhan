#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include "string.h"
#include <stdlib.h>
#include "X_variables.h"
#include "r_cg_serial.h"
#include <stdio.h>

char add_checksum(char);
char add_stuff_byte(char);
void send_uart();
void resend();
void send_current_temperature();
void output_status();
void Input_status();
void step_complete();


char *send_string_data[]={
			"ACK",					/* 0 */
			"MACHINE_READY",			/* 1 */
			"HEART_BEAT",				/* 2 */
			"DOOR_CLOSE",				/* 3 */
			"DOOR_OPEN",				/* 4 */	
			"1.0|1.0",				/* 5 */			
			"COMPLETE",				/* 6 */	
			"START",				/* 7 */	
			"COMPLETE|",				/* 8 */				
};

unsigned char
					
		send_buf[MAX_SIZE_RX_BUF],
		input_send_buf[MAX_SIZE_RX_BUF],
		total_send_bytes,
		back_send_bytes,
		frame_buffer1_size,
		frame_buffer2_size,
		resend_backup_buffer_size,
		tx_data,
		
		
		temp_send_buf[MAX_SIZE_RX_BUF],
		send_back_buffer[MAX_SIZE_RX_BUF],
		send_ack_buffer[MAX_SIZE_RX_BUF],
		frame_back_buffer1[MAX_SIZE_RX_BUF],
		frame_back_buffer2[MAX_SIZE_RX_BUF],
		send_buf[MAX_SIZE_RX_BUF],		
		resend_back_buffer[MAX_SIZE_RX_BUF];
		
 char		
		step_count_buf[20];
		
__boolean form_ok_flag;		

void frame_send_data(char respond_format,char index,char received_app_id,char received_fun_id )
{
	unsigned char byte=0,i,j,data_len;
	char *ptr;
	
	if(respond_format)
	{
		ptr=send_string_data[index];
		for(i=0;i<strlen(send_string_data[index]);i++)
		temp_send_buf[i]=*ptr++;
	}
	else
	{	
		for(i=0;i<index;i++)
		temp_send_buf[i]=temp_send_buf[i];
	}
	if((received_app_id==0X0A)AND(received_fun_id==0X0C))    //
	{		
		for(j=0;j<strlen(step_count_buf);i++,j++)
		temp_send_buf[i]=step_count_buf[j];		
	}
	data_len=i;
	memset(send_buf,0,sizeof(send_buf));
	send_buf[byte++]=START_BYTE;
	send_buf[byte++]=SEND_HEADER_BYTE;
	send_buf[byte++]=0X00;
	send_buf[byte++]=data_len;	
	send_buf[byte++]=received_app_id;
	send_buf[byte++]=received_fun_id;
	for(i=0;i<data_len;byte++,i++)
	send_buf[byte]=temp_send_buf[i];
	send_buf[byte++]=add_checksum(byte);
	memcpy(temp_send_buf,send_buf,sizeof(send_buf));
	byte=add_stuff_byte(byte);
	send_buf[byte++]=END_BYTE;
	total_send_bytes=byte;
	byte=0;	
	form_ok_flag=SET;
	send_uart();
	
}

void send_uart()
{	
	static __boolean 
			frist_buffer_flag,second_buffer_flag;			
		
	if((uart_send_flag)AND(trasmit_dly<=0)AND(!resend_flag))
	{	
			
			if(frist_buffer_flag)
			{
				memcpy(send_back_buffer,frame_back_buffer1,sizeof(frame_back_buffer1));
				back_send_bytes=frame_buffer1_size;				
				memset(frame_back_buffer1,0,sizeof(frame_back_buffer1));
				frame_buffer1_size=0;
				frist_buffer_flag=CLEAR;
			}
			else if(second_buffer_flag)
			{
				memcpy(send_back_buffer,frame_back_buffer2,sizeof(frame_back_buffer2));
				back_send_bytes=frame_buffer2_size;				
				memset(frame_back_buffer2,0,sizeof(frame_back_buffer2));
				frame_buffer2_size=0;
				second_buffer_flag=CLEAR;
			}			
			if(((send_back_buffer[3]==0x01)OR(send_back_buffer[3]==0x02)OR(send_back_buffer[3]==0x07)OR(send_back_buffer[3]==0x0A))AND(send_back_buffer[5]!='A')AND(send_back_buffer[7]!='K')AND(!resend_flag))
			{	
				resend_count=0;
				memset(resend_back_buffer,0,sizeof(resend_back_buffer));
				memcpy(resend_back_buffer,send_back_buffer,sizeof(send_back_buffer));
				resend_backup_buffer_size=back_send_bytes;	
				resend_flag=SET;				
			}			
			if((!frist_buffer_flag)AND(!second_buffer_flag))
			uart_send_flag=CLEAR;
			
			R_UART0_Send(send_back_buffer,back_send_bytes);
			trasmit_dly=250;			
			heart_beat_counter=0;				
				
						
	}
	else if(resend_flag)
	resend();
	
	if(form_ok_flag)
	{		
		if(!frist_buffer_flag)
		{
			memset(frame_back_buffer1,0,sizeof(frame_back_buffer1));
			memcpy(frame_back_buffer1,send_buf,sizeof(send_buf));
			frame_buffer1_size=total_send_bytes;
			frist_buffer_flag=SET;
		}
		else if(!second_buffer_flag)
		{
			memset(frame_back_buffer2,0,sizeof(frame_back_buffer2));
			memcpy(frame_back_buffer2,send_buf,sizeof(send_buf));
			frame_buffer2_size=total_send_bytes;
			second_buffer_flag=SET;
		}
		form_ok_flag=CLEAR;
		uart_send_flag=SET;
	}
	
}
char add_checksum(char len)
{
	char temp_check_sum=0,count,byte;
	for(byte=START_FROM,count=0;byte<len;byte++,count++)
	temp_check_sum=(temp_check_sum+(count^(send_buf[byte])));
	temp_check_sum=~(temp_check_sum+send_buf[HEADER]);
	return temp_check_sum;
}
char add_stuff_byte(char len)
{
	unsigned char byte,i,stuff_byte;
	
	
	for(byte=1,i=1,stuff_byte=0;byte<(len+stuff_byte);i++,byte++)
	{
		if((temp_send_buf[i]==STUFF_BYTE)OR(temp_send_buf[i]==START_BYTE)OR(temp_send_buf[i]==END_BYTE))
		{
			send_buf[byte++]=STUFF_BYTE;
			send_buf[byte]=~temp_send_buf[i];
			stuff_byte++;
		}
		else
		send_buf[byte]=temp_send_buf[i];
	}
	return byte;
}

void Input_output_status()
{
	output_status();
 	Input_status();
	
}
void output_status()
{	
		
	if(output_status_flag)
	{
		unsigned char
		tx_data=0,
		output_send_data[50];
	
		memset(output_send_data,0,sizeof(output_send_data));
		output_send_data[tx_data++]='1';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=(~ELECTRIC_HEATER)+0X30;
		
		output_send_data[tx_data++]='|';
		
		output_send_data[tx_data++]='2';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=0+0X30;//(~BLOWER)+0X30;
		
		output_send_data[tx_data++]='|';
			
		output_send_data[tx_data++]='3';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=0+0X30;//(~FAN)+0X30;
		
		output_send_data[tx_data++]='|';
			
		output_send_data[tx_data++]='4';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=(~MOTOR_FWD)+0X30;
		
		output_send_data[tx_data++]='|';
		
		output_send_data[tx_data++]='5';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=(~MOTOR_REV)+0X30;
		
		output_send_data[tx_data++]='|';
			
		output_send_data[tx_data++]='6';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=0+0X30;//(~ALARM)+0X30;
		
		output_send_data[tx_data++]='|';
			
		output_send_data[tx_data++]='7';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=0+0X30;//(~INLET_VALVE)+0X30;
		
		output_send_data[tx_data++]='|';
		
		output_send_data[tx_data++]='8';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=0+0X30;//(~OUTLET_VALVE)+0X30;
		
		output_send_data[tx_data++]='|';
			
		output_send_data[tx_data++]='9';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=(~COOLING_FAN)+0X30;
		
		output_send_data[tx_data++]='|';
		
		output_send_data[tx_data++]='1';
		output_send_data[tx_data++]='0';
		output_send_data[tx_data++]=':';	
		output_send_data[tx_data++]=0+0X30;//
		
		memcpy(temp_send_buf,output_send_data,sizeof(output_send_data));
		output_status_flag=CLEAR;
		if(!live_enter_ok_flag)
		frame_send_data(DATA_RES,tx_data,OUTPUT_APP_ID,OUTPUT_IO_STATUS_ACK_FUN_ID);
		else if(live_enter_ok_flag)
		frame_send_data(DATA_RES,tx_data,LIVE_APP_ID,LIVE_OUT_DATA_FUN_ID);
		
	}
	
}
void Input_status()
{
	if((input_status_flag)AND(input_status_count>=5))
	{
		 char  str_buffer[40],data=0,j=0;	
		
		
		memset(str_buffer,0,sizeof(str_buffer));
		sprintf(str_buffer,"%d",presure_data);	
		for(j=0;j<strlen(str_buffer);data++,j++)
		input_send_buf[data]=str_buffer[j];
		input_send_buf[data++]='|';				//presure	
		
		
		memset(str_buffer,0,sizeof(str_buffer));
		sprintf(str_buffer,"%d",current_temperature);	
		for(j=0;j<strlen(str_buffer);data++,j++)
		input_send_buf[data]=str_buffer[j];
		input_send_buf[data++]='|';                  		//In_temperature	
		
		
		memset(str_buffer,0,sizeof(str_buffer));
		sprintf(str_buffer,"%d",out_temperature_data);	
		for(j=0;j<strlen(str_buffer);data++,j++)
		input_send_buf[data]=str_buffer[j];
		input_send_buf[data++]='|'; 				//out_temperature
		
		
		memset(str_buffer,0,sizeof(str_buffer));
		sprintf(str_buffer,"%d",humidity_data);	
		for(j=0;j<strlen(str_buffer);data++,j++)
		input_send_buf[data]=str_buffer[j];				//humidity
		
		input_status_count=0;
		input_status_flag=CLEAR;
		
		memcpy(temp_send_buf,input_send_buf,sizeof(input_send_buf));
		if(!live_enter_ok_flag)
		frame_send_data(DATA_RES,data,INPUT_APP_ID,INPUT_DATA_ACK_FUN_ID); 
		else if(live_enter_ok_flag)
		frame_send_data(DATA_RES,data,LIVE_APP_ID,LIVE_IN_DATA_FUN_ID); 
	}
}

void check_door_status()
{
	if(Door_status_flag)
	{
		if(!door_open_flag)
		frame_send_data(COMMAND_RES,DOOR_CLOSE,PROCESS_DATA_APP_ID,DOOR_ACK_FUN_ID);
		else 
		frame_send_data(COMMAND_RES,DOOR_OPEN,PROCESS_DATA_APP_ID,DOOR_ACK_FUN_ID);
		
		Door_status_flag=CLEAR;
	}
}
void heart_beat()
{
	if(heart_beat_send_flag)
	{
		heart_beat_send_flag=CLEAR;	       
		frame_send_data(COMMAND_RES,HEART_BEAT,HEART_BEAT_APP_ID,HEART_BEAT_ACK_FUN_ID);  
	}
}
void resend()
{
	if((resend_count>0)AND(resend_count<=5)AND(resend_flag))
	{
		R_UART0_Send(resend_back_buffer,resend_backup_buffer_size);
		trasmit_dly=250;			
		heart_beat_counter=0;
		resend_count++;
	}
	else
	{
		if((resend_count>=5)AND(resend_flag))
		{
			resend_count=0;
			resend_flag=CLEAR;
			back_send_bytes=0;
			memset(send_back_buffer,0,sizeof(send_back_buffer));
			//memset(resend_back_buffer,0,sizeof(resend_back_buffer));				
			resend_backup_buffer_size=0;	
//			resend_count=0;
//			resend_flag=CLEAR;
//			R_UART0_Stop();
//			delay=5;
//			while(delay);
//			R_UART0_Start();
			
		}
	}
}
void send_current_temperature()
{
	if((send_temperature_flag))//AND(process_start_flag))
	{
		 char temp_buffer[15],i=0,j=0;	
				
		memset(temp_buffer,0,sizeof(temp_buffer));
		memset(temp_send_buf,0,sizeof(temp_send_buf));
		sprintf(temp_buffer,"%d",current_temperature);	
		for(j=0,i=0;j<strlen(temp_buffer);i++,j++)
		temp_send_buf[i]=temp_buffer[j];		
		frame_send_data(DATA_RES,i,PROCESS_DATA_APP_ID,TEMPERATURE_ACK_FUN_ID); 
		send_temperature_flag=CLEAR;		
	}
}
void step_complete()
{	
	char step_count_buf[10];
	char j=0,data=0;
	memset(step_count_buf,0,sizeof(step_count_buf));
	sprintf(step_count_buf,"%d",current_send_step_count);			
	for(j=0;j<strlen(step_count_buf);data++,j++)
	step_count_buf[data]=step_count_buf[j];	
	frame_send_data(COMMAND_RES,STEP_COMPLETE,0x0A,0X0C); 
	
}
void send_step()
{		
	char send_step_count[15],j=0,data=0;
	if(cycle)
	{		
		current_send_step_count=cycle-1;
		memset(send_step_count,0,sizeof(send_step_count));
		memset(temp_send_buf,0,sizeof(temp_send_buf));
		sprintf(send_step_count,"%d",current_send_step_count);			
		for(j=0;j<strlen(send_step_count);data++,j++)
		temp_send_buf[data]=send_step_count[j];
		frame_send_data(DATA_RES,data,0x0A,0X0B);
	}
}
void check_all_input_status()
{
	if(!DOOR_SWITHCH)
	{
		if(door_open_check_timer>=20)
		door_open_check_timer=0;
		door_open_flag=SET;		
	}
	else 
	{
		if(door_close_check_timer>=20)
		door_close_check_timer=0;
		door_open_flag=CLEAR;
	}
	if(!LINT_FILTER)
	{
		if(lint_open_check_timer>=20)
		lint_open_check_timer=0;
		lint_filter_open_flag=SET;
	}
	else 
	{
		if(lint_close_check_timer>=20)
		lint_close_check_timer=0;
		lint_filter_open_flag=CLEAR;
	}
}