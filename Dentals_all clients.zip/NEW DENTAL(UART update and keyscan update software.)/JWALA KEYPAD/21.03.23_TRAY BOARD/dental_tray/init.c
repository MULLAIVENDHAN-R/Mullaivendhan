#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"

void init_processor();                             /* Declaration of interrupts and functions */
void uart1_init(void);

void init_processor()
{
	int i;	
	asm("FCLR I");                           /* Interrupt disabled */
	prc0=1;                                  /* Protect off */

	
	/****************************************/
	/*          CPU Clock Setting	        */			//FOR WITHOUT CRYSTEL
	/****************************************/
	/* Note: Include asm("nop") for oscillator's stabilization period after clock setting is done */
	
	//FOR WITHOUT CRYSTEL
	
	fra20=0;fra21=0;fra22=0;                 /* High-speed on-chip frequency switching selects divide by 2 mode(fra2 bit 0, 1 and 2) */
	cm13=0;cm05=1;cm02=0;cm14=0;ocd0=0;ocd1=0;fra00=1;fra01=1;/* High speed on-chip oscillator selected(cm0 bit 2 and 5, cm1 bit 4, ocd bit 0 and 1 and fra0 bit 0 and 1) */
	ocd2=1;                                  /* High speed on-chip oscillator selected(ocd bit 2) */
	cm16=0;cm17=0;cm06=0;                    /* NO DIVISION selected for CPU clock(cm0 bit 6) */

	
  	adcon0=0X00;
	pu11=1;
  	prc2=1; 	
//	LED_OUTPUT_INIT;
//	pd6_6=1;
//	p6_6=0;	    
	
	p6=0x00;   
	//p0=0x00; 
//	pu11=1;	
	prc2=1; 
	//pd0=0x00;
	pd0=0xFF;
	p2drr=0x00;
	pd1=0x5F;
	pd2=0xFD;	
	pd3=0xFF;
	pd4=0x38;
	pd6=0x7F;
	p0=0xFF;
	p1=0x00;
	p2=0x03;
	p3=0x00;
	p4=0x00;
	p6_6=1;	
	pu03 = 1;
	prc0=0;	

	
                         /* Protect on */
	
	  
	/****************************************/
	/*	   Timer RA Setting                 */	
	/****************************************/
	
	//trapre=249;          //10msec               /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
//	tra=99;                                  /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
//	trapre=199;          //100Usec               /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
//	tra=9;                                  /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
	trapre=99;          //50Usec               /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
	tra=9;                                  /* Set timer value(for timer mode)/half period timing(for pulse output mode) to trapre and tra */
	tmod0_tramr=0;tmod1_tramr=0;tmod2_tramr=0;/* Timer mode selected(tramr bit 0, 1 and 2) */
	tck0_tramr=0;tck1_tramr=0;tck2_tramr=0;  /* Count source f8 selected(tramr bit 4, 5 and 6) */
	traic=0x04;                              /* Set interrupt priority level 6(traic) */
	tstart_tracr=1; //;	     		/* Set tstart_tracr=1 to start Timer RA counting */
	/* Note: Timer RA does not start yet for event counter mode. The first active edge of external signal is used not to decrement the timer count register but to start timer RA. The second active edge will trigger the first decrement on timer count register. */
                                  /* Protect on */
               
	
}
void uart0_init(void)
{
	                  	//UART 0 Settings  
	
	smd0_u0mr=1;smd1_u0mr=0;smd2_u0mr=1;     /* UART mode transfer data 8 bits long selected(u0mr bit 0, 1 and 2) */
	ckdir_u0mr=0;                            /* Internal clock selected(u0mr bit 3) */
	stps_u0mr=0;                             /* 1 stop bit selected(u0mr bit 4) */
	prye_u0mr=0;                             /* Parity disabled(u0mr bit 6) */
	clk0_u0c0=0;clk1_u0c0=0;                 /* BRG count source f1 selected(u0c0 bit 0 and 1) */
	nch_u0c0=0;                              /* TXD0 pin CMOS output(u0c0 bit 5) */
	uform_u0c0=0;                            /* Transfer LSB first(u0c0 bit 7) */
	u0brg=42;     //19200-64  //9600-129    /* Setting UART0 baud rate generator(max 255). Calculated value is round to the nearest whole number */
	te_u0c1=1;re_u0c1=1;                     /* Transmission enabled(u0c1 bit 0) */	
//	u1rrm_u1c1 = 1;							//UART1 continuous receive mode enabled
	s0tic=0x00;                              /* Set UART0 transmit interrupt priority level 0(s0tic) */
	s0ric=0x06;                              /* Set UART0 receive interrupt priority level 6(s0ric) */
//	asm("FSET I");		                /* Interrupt enabled */	
		
}
void uart1_init(void)
{
	                  	//UART 0 Settings  
	
	smd0_u1mr=1;smd1_u1mr=0;smd2_u1mr=1;u1pinsel=1;u1sr=0x0F;     /* UART mode transfer data 8 bits long selected(u1mr bit 0, 1 and 2) */
	ckdir_u1mr=0;                            /* Internal clock selected(u1mr bit 3) */
	stps_u1mr=0;                             /* 1 stop bit selected(u1mr bit 4) */
	prye_u1mr=0;                             /* Parity disabled(u1mr bit 6) */
	clk0_u1c0=0;clk1_u1c0=0;                 /* BRG count source f8 selected(u1c0 bit 0 and 1) */
	nch_u1c0=0;                              /* TXD0 pin CMOS output(u1c0 bit 5) */
	uform_u1c0=0;                            /* Transfer LSB first(u1c0 bit 7) */
	u1brg=42;     //57600-21   //19200-64  //9600-129  /* Setting UART1 baud rate generator(max 255). Calculated value is round to the nearest whole number */
	te_u1c1=1;re_u1c1=1;                     /* Transmission enabled(u1c1 bit 0) */	
//	u1rrm_u1c1 = 0;		//both bit should be masked for uart transmission&reception
//	u1irs_u1c1 = 1;						//UART1 continuous receive mode enabled
	s1tic=0x00;                              /* Set UART1 transmit interrupt priority level 0(s0tic) */
	s1ric=0x07;                             /* Set UART1 receive interrupt priority level 6(s0ric) */
//	asm("FSET I");		                /* Interrupt enabled */	

}
