#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include <stdlib.h>

void str_to_process_buf_conversion()
{
	char i,j,byte=0,pipe_symbol_came=0;
	long int val;
	char value=0;
	app_id=3;
	fun_id=4;
	for(i=0,j=0;i<strlen(string_process_data_buf);i++)
	{
		if(!frame_err_flag)
		{
			if(string_process_data_buf[i]!='|')
			temp_string[j++]= string_process_data_buf[i];
			else
			{
				if(strcmp(temp_string,"RESUME")!=0)
				pipe_symbol_came++;
				if(pipe_symbol_came==1)			
				{
					if((app_id==0x03)AND(fun_id==0x02))
					{
						if(strcmp(temp_string,"10")==0)		//
						process_data_buf[byte]=2;
						else if(strcmp(temp_string,"11")==0)   	//
						process_data_buf[byte]=1;
						else if(strcmp(temp_string,"12")==0)	//
						process_data_buf[byte]=5;
						else if(strcmp(temp_string,"13")==0)	//
						process_data_buf[byte]=1;
						else if(strcmp(temp_string,"14")==0)	//
						process_data_buf[byte]=3;
						
						if(strcmp(temp_string,"1")==0)		//
						process_data_buf[byte]=1;
						else if(strcmp(temp_string,"2")==0)   	//
						process_data_buf[byte]=2;
						else if(strcmp(temp_string,"3")==0)	//
						process_data_buf[byte]=3;
						else if(strcmp(temp_string,"4")==0)	//
						process_data_buf[byte]=4;
						else
						frame_err_flag=SET;
						
					}
					else if((app_id==0x02)AND((fun_id==0x02)OR(fun_id==0X0C)OR(fun_id==0X07)))
					{
						if(strcmp(temp_string,"1")==0)		//FWD
						direction=FWD;
						else if(strcmp(temp_string,"2")==0)   	//REV
						direction=REV;  
						else
						frame_err_flag=SET;
					}
					else if((app_id==0x03)AND(fun_id==0x04))
					{
						if(strcmp(temp_string,"ON")==0)
						water_flow_flag=1;
						else if(strcmp(temp_string,"OFF")==0)
						water_flow_flag=0;				
						else
						frame_err_flag=SET;
					}
				}				 
				if(pipe_symbol_came==2)
				{
					if((temp_string[0]=='-')AND(fun_id==0x07))
					{
						low_time_minus_data_flag=SET;
					  	low_speed_timing=(int)strtol(temp_string+1, NULL, 10);
					}
					else if((app_id==0x03)AND(fun_id==0x04))
					water_flow[0]=atoi(temp_string);
					
					else
					low_speed_timing=atoi(temp_string);     	// LOW TIME
				}
				if(pipe_symbol_came==3)
				{
					if((temp_string[0]=='-')AND(fun_id==0x07))
					{
						high_time_minus_data_flag=SET;
					  	high_speed_timing=(int)strtol(temp_string+1, NULL, 10);
					}
					else if((app_id==0x03)AND(fun_id==0x04))
					water_flow[1]=atoi(temp_string);
					
					else
					high_speed_timing=atoi(temp_string);		// RESUME  HIGH TIME data
				}
				if(pipe_symbol_came==4)
				{
					if(fun_id==0x0C)
					{
						if(strcmp(temp_string,"L")==0)
						value=1;
						else if(strcmp(temp_string,"H")==0)
						value=2;
						else
						frame_err_flag=SET;
					}
					else if((app_id==0x03)AND(fun_id==0x04))
					water_flow[2]=atoi(temp_string);
				}
				else if(pipe_symbol_came==5)
				{
					if((app_id==0x03)AND(fun_id==0x04))
					water_flow[3]=atoi(temp_string);
				}
				else if(pipe_symbol_came==6)
				{
					if((app_id==0x03)AND(fun_id==0x04))
					water_flow[4]=atoi(temp_string);
				}
				byte++;
				j=0;
				memset(temp_string,0,sizeof(temp_string));				
			}
		}
	}
	if(!frame_err_flag)
	{
		if(temp_string[0]!='B')	//BOARD_ER Data
		{
			if(temp_string[0]=='O')
			{
				if(strcmp(temp_string,"ON")==0)
				process_data_buf[byte]=1;
				else if(strcmp(temp_string,"OFF")==0)
				process_data_buf[byte]=0;				
				else
				frame_err_flag=SET;
			}
			else if(((app_id==0X03)AND(fun_id==0x02))AND((temp_string[0]=='1')OR(temp_string[0]=='2')))
			{
				if(strcmp(temp_string,"1")==0)
				process_data_buf[byte]=1;
				else if(strcmp(temp_string,"2")==0)
				process_data_buf[byte]=2;
				else
				frame_err_flag=SET;
			}
			else if((app_id==0x02)AND((fun_id==0x02)OR(fun_id==0X07)))
			{
				if((temp_string[0]=='-')AND(fun_id==0x07))
				{
					high_time_minus_data_flag=SET;
				  	high_speed_timing= (int)strtol(temp_string+1, NULL, 10);
				}
				else
				high_speed_timing=atoi(temp_string);		//  HIGH TIME
			}
			else if((app_id==0x02)AND(fun_id==0x0C))
			{					
				if(value==1)
				{
					low_speed_timing=atoi(temp_string);
				}
				else if(value==2)
				{
					high_speed_timing=atoi(temp_string);
					low_speed_timing=0;
				}
				else
				frame_err_flag=SET;
			}
			else if((app_id==0x03)AND(fun_id==0x04))
			{
				if(pipe_symbol_came==2)
				water_flow[1]=atoi(temp_string);
				else if(pipe_symbol_came==3)
				water_flow[2]=atoi(temp_string);
				else if(pipe_symbol_came==4)
				water_flow[3]=atoi(temp_string);
				else if(pipe_symbol_came==5)
				water_flow[4]=atoi(temp_string);
				else if(pipe_symbol_came==6)
				water_flow[5]=atoi(temp_string);			
			}
		}
		else
		frame_err_flag=SET;
	}
	memset(string_process_data_buf,0,sizeof(string_process_data_buf));
}