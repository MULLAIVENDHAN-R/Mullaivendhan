#include "sfr_r825.h"                    
#include "cstartdef.h"
#include "macro.h"
#include "xvariables.h"  
void function_load();
void write_data(unsigned char value);
void block_erase();
void function_load()
{
	/*function_flag=CLEAR;
	if(function_id==HEATER_TIME)
	{
    	asm("FCLR I"); //Disable all the Interrupts	
		heat_time=data_browse_ptr;	
		write_addr = eeprom_heat_time;
  	   	temperary=heat_time;
	    write_data(temperary);
    	asm("FSET I"); //Enable all the Interrupts
	}
	else if(function_id==STER_TIME)
	{
		asm("FCLR I"); //Disable all the Interrupts		
		ster_time=data_browse_ptr;
		temperary=ster_time;
		write_addr = eeprom_ster_time;		
		write_data(temperary);
	   asm("FSET I"); //Enable all the Interrupts
	}*/
	
		/*asm("FCLR I"); //Disable all the Interrupts		
		ster_time=data_browse_ptr;
		temperary=ster_time;
		write_addr = eeprom_ster_time;		
		write_data(temperary);
	   	asm("FSET I"); //Enable all the Interrupts*/
}



void write_data(unsigned char value)
{
      /*block_erase();
      fmr0=0x01;
	  asm(" ");
	  fmr0=0x03;
	  fmr1=0x00;
	  asm(" ");
	  fmr1=0x02;
	  
	*write_addr=0x40;
	*write_addr = value;
		while( fmr00 != 1 );
   	fmr0 = 0x01;      // reset the flash control register*/

	
}

void block_erase()
{

	//ers_addr =write_addr;
	
		/* Flash memory control registers set */
	//asm("FCLR I");									/* Interrupt disabled */
	//fmr01 = 0;										/* Write 0 before to set 1 */
	//asm(" ");										/* Description for preventing the abbreviation from optimization */
	//fmr01 = 1;										/* CPU rewrite mode enabled */
	//fmr11 = 0;										/* Write 0 before to set 1 */
	//asm(" ");										/* Description for preventing the abbreviation from optimization */
	//fmr11 = 1;										/* EW1 mode selected */

	//fmr40 = 0;										/* Write 0 before to set 1 */
	//asm(" ");										/* Description for preventing the abbreviation from optimization */
	//fmr40 = 1;										/* Enable suspend function */

	//fmr47 = 0;										/* Low-consumption-current read mode disabled */

	/* Block erase command written */
	//*ers_addr = 0x20;								/* Block erase command written in the first bus cycle */
	//asm("FSET I");									/* Interrupt enabled */
	//*ers_addr = 0xD0;								/* Block erase command written in the second bus cycle */

	//while(1) 
	//{
	//	fmr41 = 0;									/* Erase suspend request */
	//	if ( fmr00 == 1 ) {							/* Wait for status ready */
	//		break;
	//	}
	//}
	//fmr40 = 0;										/* Disable suspend function */

	//fmr01 = 0;	
}
