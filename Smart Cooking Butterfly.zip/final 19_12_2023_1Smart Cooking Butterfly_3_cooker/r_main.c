/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_main.c
* Version      : CodeGenerator for RL78/G13 V2.05.06.02 [08 Nov 2021]
* Device(s)    : R5F100PL
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 29-06-2023
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_cgc.h"
#include "r_cg_port.h"
#include "r_cg_intc.h"
#include "r_cg_serial.h"
#include "r_cg_adc.h"
#include "r_cg_timer.h"
/* Start user code for include. Do not edit comment generated here */
#include <string.h>
#include "Macros.h"
#include"GUI_Macros.h"
#include "Variables.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
extern void R_TAU0_Channel0_Start();
extern void R_UART0_Start();
extern void R_INTC2_Start();
extern void R_INTC4_Start();
extern void R_ADC_Create(void);
extern void R_ADC_Start(void);
extern void handshake_approve();
extern void receipe_prep_process();
extern void gui_uart_send();
extern void all_outputs_off_fun();
extern void is_initial_position_ok();
extern void sensor_open_close_conform();
extern void grammage_test();
extern void water_level_filling();
extern void water_heater_control();
extern void short_circuit_test();
extern void cookers_home_position();
extern void is_this_pending_restart();
extern void store_output_status();
extern void preparation_stop();
extern void eeprom_write(unsigned int, unsigned char);
extern unsigned char eeprom_read(unsigned char);
extern void process_buf_splitup();
extern void allTime_check_fun();
extern void kadai_home_position(); 
extern void init_lid_home_position();
extern void check_idle_condition();
extern void form_send_buf(char,char);
extern void preparation_not_ok();
//extern void dishes_complete();
/* End user code. Do not edit comment generated here */
void R_MAIN_UserInit(void);

/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
    R_MAIN_UserInit();
    /* Start user code. Do not edit comment generated here */  
    
    
    	//1851 pulses/litre water in metal flow meter	
	
	/*HEATER_A_ON;
	HEATER_A_OFF;
	HEATER_B_ON;
	HEATER_B_OFF;
	HEATER_C_ON;
	HEATER_C_OFF;
	HEATER_D_ON;
	HEATER_D_OFF;
	WATER_PUMP_ON;
	WATER_PUMP_OFF;
	COOKER_MOTOR_FWD_ON;
	COOKER_MOTOR_OFF;
	COOKER_MOTOR_REV_ON;
	COOKER_MOTOR_OFF;*/
	/*LID_DWN_ON;
	LID_UP_DWN_STOP;
	LID_UP_ON;
	LID_UP_DWN_STOP;
	LID_FWD_ON;	
	LID_FWD_REV_STOP;
	LID_REV_ON;
	LID_FWD_REV_STOP;*/
	/*KADAI_FWD_ON;
	KADAI_FWD_REV_STOP;
	KADAI_REV_ON;
	KADAI_FWD_REV_STOP;
	KADAI_CC_ON;
	KADAI_CC_CCW_STOP;
	KADAI_CCW_ON;
	KADAI_CC_CCW_STOP;*/
	/*while(1)
	{
		if(flag==1)
		{
			ERROR_APPID_FUNID_WO_OP_OFF;
			form_send_buf(COMMAND_RES,C2_VT2_FAILURE);
			flag=0;
		}
		if(flag==2)
		{
			ERROR_APPID_FUNID_WO_OP_OFF;
			form_send_buf(COMMAND_RES,C3_VT3_FAILURE);
			flag=0;
		}
		if(flag==3)
		{
			ERROR_APPID_FUNID_WO_OP_OFF;
			form_send_buf(COMMAND_RES,KADAI_CCW_FAILURE);	
			flag=0;
		}
		if(flag==4)
		{
			ERROR_APPID_FUNID;
			form_send_buf(COMMAND_RES,KADAI_REV_SENSOR_FAILURE);	
			flag=0;
		}
		if(flag==5)
		{
			ERROR_APPID_FUNID_WO_OP_OFF;
			form_send_buf(COMMAND_RES,KADAI_REV_FAILURE);	
			flag=0;
		}
	}*/
	
	/*while(1)
	{
		sensor_open_close_conform();
		if(flag==1)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				//KADAI_FWD_ON;
				KADAI_CC_ON;
				//KADAI_CCW_ON;
				testing_delay=1200; //3500
			}
			else if((kadai_cw_switch_close_flag)AND(testing_flag))
			{
				//KADAI_FWD_REV_STOP;
				KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		if(flag==2)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				//KADAI_FWD_ON;
				//KADAI_CC_ON;
				KADAI_CCW_ON;
				testing_delay=1000; //3500
			}
			else if((testing_delay<=0)AND(testing_flag))
			{
				//KADAI_FWD_REV_STOP;
				KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		if(flag==3)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				KADAI_FWD_ON;
				//KADAI_CC_ON;
				//KADAI_CCW_ON;
				testing_delay=2800; //3500
			}
			else if((testing_delay<=0)AND(testing_flag))
			{
				KADAI_FWD_REV_STOP;
				//KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		if(flag==4)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				KADAI_REV_ON;
				//KADAI_CC_ON;
				//KADAI_CCW_ON;
				//testing_delay=00; //3500
			}
			else if((kadai_rev_switch_close_flag)AND(testing_flag))
			{
				KADAI_FWD_REV_STOP;
				//KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
	}*/
	/*while(1)
	{
		sensor_open_close_conform();
		if(flag==1)
		{
			HEATER_D_ON;
			flag=0;
		}
		if(flag==2)
		{
			HEATER_D_OFF;
			flag=0;
		}
		if(flag==3)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				//KADAI_FWD_ON;
				//KADAI_CC_ON;
				KADAI_CCW_ON;
				testing_delay=1200; //3500
			}
			else if((testing_delay<=0)AND(testing_flag))
			{
				//KADAI_FWD_REV_STOP;
				KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		if(flag==4)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				//KADAI_FWD_ON;
				KADAI_CC_ON;
				//KADAI_CCW_ON;
				testing_delay=1200; //3500
			}
			else if((kadai_cw_switch_close_flag)AND(testing_flag))
			{
				//KADAI_FWD_REV_STOP;
				KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		if(flag==5)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				KADAI_FWD_ON;
				//KADAI_CC_ON;
				//KADAI_CCW_ON;
				testing_delay=2800; //3500
			}
			else if((testing_delay<=0)AND(testing_flag))
			{
				KADAI_FWD_REV_STOP;
				//KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		if(flag==6)
		{
			if(!testing_flag)
			{
				testing_flag=SET;
				KADAI_REV_ON;
				//KADAI_CC_ON;
				//KADAI_CCW_ON;
				testing_delay=2900; //3500
			}
			else if((testing_delay<=0)AND(testing_flag))
			{
				KADAI_FWD_REV_STOP;
				//KADAI_CC_CCW_STOP;
				testing_flag=0;
				testing_delay=0;
				flag=0;
			}
		}
		
	}*/
	
    grammage_test();
    
    delay=40;				//This delay used for reading the all sensor's(Limit switches) status
    while(delay)
    sensor_open_close_conform();
    
    if(SHORT_CIRCUIT_TEST)
    short_circuit_test();
    //is_model_1=0;
   // eeprom_write(eeprom_cooker_model,is_model_1);
    is_model_1=eeprom_read(eeprom_cooker_model);	// Need to identify the model before handshake process   
      				
    //kadai_home_position(); 				// kadai home position
    //kadai_home_position_ok_flag=CLEAR;
	
   // init_lid_home_position();  
    //lid_position_flag=CLEAR;
    
    handshake_approve();				//used for handshake with the Android driver PCB 
    
    is_this_pending_restart();
    
    is_initial_position_ok();				//Initial Process(Veg Tray Home Position,Lid Home Position)
    
    
//    init_filling_flag=SET;
//    while(init_filling_flag)
//    {
//	sensor_open_close_conform();
//    	water_level_filling();				//used for the water filling by using the float sensor
//    }
    
    
    /*
    
    init_heating_flag=SET;
    while(init_heating_flag)
    {
    	water_heater_control();				//used for the heating the water heater by using the 20K sensor  //future use
    }
    
    */
    
    
    while (1U)
    {	
//	water_heater_control();	
		
	
	all_outputs_off_fun();
	
	allTime_check_fun();
	
	store_output_status();	
	
	preparation_stop();
	
	preparation_not_ok();
	
	
	//dishes_complete();
	
	//if((frame_formed_flag)OR(uart_send_flag))
	//gui_uart_send();
	/****************Idle time(with out food processing) need to check the float sensor based on that fill the water in the Tank**********/
	/*if(!dish1_preparation_start_flag)	
	{
		sensor_open_close_conform();			//For future use only
    		water_level_filling();
	}
	else
	{
		if(water_pump_on_flag)
		{
			water_pump_on_flag=CLEAR;
			WATER_PUMP_OFF;
		}
	}*/
	/****************Idle time(with out food processing) need to check the float sensor based on that fill the water in the Tank**********/
	
	
    }
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: R_MAIN_UserInit
* Description  : This function adds user code before implementing main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_UserInit(void)
{
    /* Start user code. Do not edit comment generated here */
    EI();
    R_TAU0_Channel0_Start();
    R_UART0_Start();
    //R_UART1_Start();
    R_INTC2_Start();
    R_INTC4_Start();
    R_ADC_Create();
    R_ADC_Start();
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
