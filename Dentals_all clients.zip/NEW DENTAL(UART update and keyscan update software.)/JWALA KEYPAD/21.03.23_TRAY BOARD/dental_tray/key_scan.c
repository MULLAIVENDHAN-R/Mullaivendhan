#include "sfr_r825.h"
#include "cstartdef.h" 
#include "xvariables.h"
#include "macro.h"
void touch_key_scan();
void key_led_control();
void err_update();
void key_scan();
void keychange();

void touch_key_scan()
{
	if(!key_status_changed_flag)
	{
		if((serial_received_data != (0x01FFEF63)))
		{
		
				key_status_changed_flag= SET;
				second_time_flag=CLEAR;
				touch_key_flag = SET;
		}
		else
		{
			touch_key_flag = CLEAR;	
			serial_received_data  = 0x01ffef63;
			fwd_rev_key_pressed_flag=CLEAR;
			hand_foot_key_pressed_flag = CLEAR;		
			pgm1_sw_flag=CLEAR;
			pgm2_sw_flag=CLEAR;
			pgm3_sw_flag=CLEAR;
			zero_sw_flag=CLEAR;													
			if(!second_time_flag)
			{
				send_uart_data_flag=SET;
				second_time_flag=SET;
//				act_fwd_flag=CLEAR;
//				act_rev_flag=CLEAR;
//				act_up_flag=CLEAR;
//				act_dwn_flag=CLEAR;
				tumbler_sw_flag=CLEAR;
				spit_sw_flag=CLEAR;	
				lamp_sw_flag=CLEAR;	
				lamp_sw_pressed_flag=CLEAR;	
				gaugle_sw_flag=CLEAR;
				shark_sw_flag=CLEAR;
				lamp_key_pressed_flag=CLEAR;				
				xray_key_pressed_flag=CLEAR;
				on_off_key_pressed_flag=CLEAR;
				on_off_sw_flag=CLEAR;
				hand_foot_key_pressed_flag=CLEAR;
				fwd_rev_sw_flag=CLEAR;
				hand_foot_sw_flag=CLEAR;
				aeroter_sw_flag=CLEAR;
				aeroter_key_pressed_flag=CLEAR;	
				speed_dec_delay_flag=CLEAR;
				speed_inc_delay_flag=CLEAR;	
						
			}
			if(increment_uart_send_flag)
			{
				increment_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffd));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
			if(decrement_uart_send_flag)
			{
				decrement_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffb));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
		}	
	}	
}

void key_scan()
{
	if(!key_status_changed_flag)
	{
		//temp_serial_received_data=key_data[3];
		temp_serial_received_data=key_data[2];
		temp_serial_received_data=((temp_serial_received_data<<8)|key_data[1]);
		temp_serial_received_data=((temp_serial_received_data<<8)|key_data[0]);
		//temp_serial_received_data=((temp_serial_received_data<<8)|key_data[0]);
		temp_serial_received_data=(temp_serial_received_data&KEYPAD_DATA);
		//if((temp_serial_received_data != (0x01ffef63)))	//pan
		if((temp_serial_received_data != (KEYPAD_DATA)))
		{
		//key_pad_data_flag=SET; 				 MULLAI
			if(!temp_key_delay_flag)
			{
				if(!key_delay_flag)
				{				
					key_press_time=3;			
					max_key_data=temp_serial_received_data;
					key_delay_flag=SET;						
				}
				else
				{
					if(key_press_time==0)
					{
						if(temp_serial_received_data == max_key_data)	//pan
						{
							serial_received_data = temp_serial_received_data;
							key_status_changed_flag= SET;
							temp_key_delay_flag = SET;
							first_time_flag=CLEAR;
							key_delay_flag=CLEAR;							
							p1_6 = 1;						
						}
						else
						{
							key_status_changed_flag= CLEAR;
							temp_key_delay_flag = CLEAR;
							first_time_flag=CLEAR;
						//	temp_serial_received_data=0x01ffef63;		//pan
							temp_serial_received_data=KEYPAD_DATA;
							key_delay_flag=CLEAR;
						}
					}					
				}
			}
			else
			{
				key_status_changed_flag=CLEAR;
				key_delay_flag=CLEAR;
			//	temp_serial_received_data = 0x01ffef63;		//pan
				temp_serial_received_data=KEYPAD_DATA;
				//sense_key_data=0XFF;				
			}
		}
		else
		{
			key_status_changed_flag=CLEAR;				//MULLAI
			touch_key_flag = CLEAR;
			temp_key_delay_flag = CLEAR;
			key_delay_flag=CLEAR;
		//	serial_received_data  = 0x01ffef63;			//pan
			serial_received_data=KEYPAD_DATA;
		//	send_uart_data_flag=SET;
			max_key_data=KEYPAD_DATA;
			key_pad_data_flag=CLEAR;
			fwd_rev_key_pressed_flag=CLEAR;
			hand_foot_key_pressed_flag = CLEAR;		
			pgm1_sw_flag=CLEAR;
			pgm2_sw_flag=CLEAR;
			pgm3_sw_flag=CLEAR;
			zero_sw_flag=CLEAR;
			inc_sw_key_flag=CLEAR;
			dec_sw_key_flag=CLEAR;													
			if(!first_time_flag)
			{
				send_uart_data_flag=SET;
				p1_6 = 0;
				first_time_flag=SET;
	//			act_fwd_flag=CLEAR;
	//			act_rev_flag=CLEAR;
	//			act_up_flag=CLEAR;
	//			act_dwn_flag=CLEAR;
				tumbler_sw_flag=CLEAR;
				spit_sw_flag=CLEAR;	
				lamp_sw_flag=CLEAR;	
				lamp_sw_pressed_flag=CLEAR;	
				gaugle_sw_flag=CLEAR;
				shark_sw_flag=CLEAR;
				lamp_key_pressed_flag=CLEAR;				
				xray_key_pressed_flag=CLEAR;
				speed_dec_delay_flag=CLEAR;
				speed_inc_delay_flag=CLEAR;
				on_off_key_pressed_flag=CLEAR;
				on_off_sw_flag=CLEAR;
				hand_foot_key_pressed_flag=CLEAR;			
				fwd_rev_sw_flag=CLEAR;
				hand_foot_sw_flag=CLEAR;
				aeroter_sw_flag=CLEAR;
				aeroter_key_pressed_flag=CLEAR;				
			}
			if(increment_uart_send_flag)
			{
				increment_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffd));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
			if(decrement_uart_send_flag)
			{
				decrement_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffb));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}			
		}
	}
	else
	{
		if((temp_serial_received_data==KEYPAD_DATA)AND(temp_serial_received_data==0X00000000))	//		MULLAI
		key_status_changed_flag=CLEAR;
	}	
}

void key_led_control()
{
	if(led_key_count==2)
	{				
		COM_LED2_ON;					
		LED_KEY_COTROL_PORT=0xFC;
		LED_OUTPUT;						
	}
	if((led_key_count>=3)AND(led_key_count<=5))	
	{
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");		
		COM_LED2_OFF;	
		COM_KEY1_OFF;
		COM_KEY2_OFF;
		COM_KEY3_OFF;	
		LED_KEY_COTROL_PORT=(led_data[1]&0xFC);		
	}	

	if((led_key_count>=6)AND(led_key_count<=8))
	{
		prc2=1; 
		KEY_SENSE_INIT;
		p0=0x00;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		KEY_SENSE;
		COM_LED2_ON;		
	}
	if((led_key_count>=9)AND(led_key_count<=11))
	{
		COM_LED2_ON;			
		COM_KEY2_OFF;
		COM_KEY3_OFF;
		COM_KEY1_ON;
		key_data[0]=(LED_KEY_COTROL_PORT&0xFC);		
	}
	if((led_key_count>=12)AND(led_key_count<=14))
	{
		COM_LED2_ON;				
		COM_KEY1_OFF;		
		COM_KEY3_OFF;
		COM_KEY2_ON;
		key_data[1]=(LED_KEY_COTROL_PORT&0xFC);		
	}
	if((led_key_count>=15)AND(led_key_count<=17))
	{
		COM_LED2_ON;				
		COM_KEY1_OFF;
		COM_KEY2_OFF;
		COM_KEY3_ON;
		key_data[2]=(LED_KEY_COTROL_PORT&0xFC);	
	}
	if(led_key_count>18)
	{
		led_key_count=0;
		COM_KEY3_OFF;
		prc2=1; 		
		LED_OUTPUT_INIT;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		LED_OUTPUT;
		key_scan_flag=SET;		
	}	
}

void keychange()
{
	if(serial_received_data==0x00fcdcfc)	//TUMBLER KEY
	serial_received_data=0XF87494BC;
	if(serial_received_data==0x00fcf8fc)	//LAMP KEY
	serial_received_data=0X78F494BC;
	if(serial_received_data==0x00fcf4fc)	//SPITOON KEY
	serial_received_data=0XF8F490B8;
	if(serial_received_data==0x00fcecfc)	//ZERO KEY
	serial_received_data=0XF8F490B8;
	if(serial_received_data==0x00fcfcf8)	//ACT DOWN KEY
	serial_received_data=0XF8D494BC;
	if(serial_received_data==0x00fcfcf4)	//FWD REV KEY
	serial_received_data=0XF8E494BC;
	if(serial_received_data==0x00fcfcbc)	//MOTOR SPEED DEC KEY
	serial_received_data=0XF8F414BC;
	if(serial_received_data==0x00fcfcdc)	//MOTOR SPEED INC KEY
	serial_received_data=0XF8F090BC;
	if(serial_received_data==0x00fcfcec)	//ACT REV KEY
	serial_received_data=0XE8F494BC;
	if(serial_received_data==0x00f8fcfc)	//ACT FWD KEY
	serial_received_data=0XF8F4949C;
	if(serial_received_data==0x00bcfcfc)	//MOTOR ON KEY
	serial_received_data=0XF8F484BC;
	if(serial_received_data==0x00f4fcfc)	//HAND/FOOT KEY
	serial_received_data=0XF8F4143C;
	if(serial_received_data==0x00dcfcfc)	//ACT UP KEY
	serial_received_data=0XD8F494BC;	
}