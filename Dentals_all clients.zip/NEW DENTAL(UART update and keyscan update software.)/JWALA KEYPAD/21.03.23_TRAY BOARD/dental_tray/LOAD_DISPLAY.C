#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"
void load_display();
void load_display1();

void load_display()
{
	if(display_flag)
 	{
	//	display_flag=CLEAR;
		if(error_id==0)
		{
			if((act_up_flag)OR(foot_act_up_flag))
			{
				err_id = ACT_MOV_UP;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==1)
		{
			if((act_dwn_flag)OR(foot_act_dwn_flag))
			{
				err_id = ACT_MOV_DOWN;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==2)
		{
			if((act_fwd_flag)OR(foot_act_fwd_flag))
			{
				err_id = ACT_MOV_FORWARD;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==3)
		{
			if((act_rev_flag)OR(foot_act_rev_flag))
			{
				err_id = ACT_MOV_REVERSE;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==4)
		{
		//	if(tumbler_sw_flag)
		//	{
				if(tumbler_on_flag)
				{
					err_id=TMBLR_ON;
					err_msg_update_flag = SET;
				}
				else 
				{
					if(tumbler_prgm_on_flag)
					{
						err_id=TUMBLER_SAVED;
						err_msg_update_flag = SET;
					}
				}
		//	}
			error_id==error_id++;
		}
		else if(error_id==5)
		{
		//	if(spit_sw_flag)
		//	{
				if(spit_on_flag)
				{
					err_id = SPIT_ON;
					err_msg_update_flag = SET;
				}
			
				else 
				{
					if(spitoon_prgm_on_flag)
					{
						err_id =SPITOON_SAVED;
						err_msg_update_flag = SET;	
					}
				}
		//	}
			error_id==error_id++;
		}
		else if(error_id==6)
		{
			if(xray_on_flag)
			{
				err_id = X_RAY_ON;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==7)
		{
			if(lamp_second_time_flag) 
			{
				err_id = LAMP_ON;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==8)
		{
			if(up_dn_pulse_error_flag)
			{
				err_id = ACT1_PULSE_ERROR;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==9)
		{
			if(fwd_rev_pulse_error_flag)
			{
				err_id = ACT2_PULSE_ERROR;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
	}
}
void load_display1()
{
		if(error_id==10)
		{	
			if(on_off_flag)
			{
				if(foot_sw_flag)
				{
					err_id = FOOT_MODE;
					err_msg_update_flag = SET;
				}
			}
			error_id==error_id++;
		}
		else if(error_id==11)
		{
			if(on_off_flag)
			{
				if(hand_sw_flag)
				{
					err_id = HAND_MODE;
					err_msg_update_flag = SET;
				}
			}			
			error_id==error_id++;
		}
		else if(error_id==12)
		{
			if(fwd_sw_flag)
			{
				err_id = MTR_FW_MODE;
				err_msg_update_flag = SET;
			}	
			error_id==error_id++;
		}
		else if(error_id==13)
		{
			if(rvs_sw_flag)
			{
				err_id = MTR_REV_MODE;
				err_msg_update_flag = SET;
			}	
			error_id==error_id++;
		}
		else if(error_id==14)
		{
			if(aeroter_on_flag)
			{
			err_id = AEROTOR_ON;
			err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}		
		else if(error_id==15)
		{
	
			if(gaugle_on_flag)
			{
				err_id = GAUGLE_RUNNING;
				err_msg_update_flag = SET;
			}
			
			else 
			{
				if(gaugle_prgm_on_flag)
				{
					err_id =GAUGLE_SAVED;
					err_msg_update_flag = SET;	
				}
	
			}
			error_id==error_id++;
		}
		else if(error_id==16)
		{
	
			if(shark_on_flag)
			{
				err_id = SHARK_RUNNING;
				err_msg_update_flag = SET;
			}
			
			else 
			{
				if(shark_prgm_on_flag)
				{
					err_id =SHARK_SAVED;
					err_msg_update_flag = SET;	
				}
	
			}
			error_id==error_id++;
		}
		else if(error_id==17)
		{
	
			if(pgm1_on_flag)
			{
				err_id = PROGRAM1_RUNNING;
				err_msg_update_flag = SET;
			}
			
			else 
			{
				if(pgm1_prgm_on_flag)
				{
					err_id =PROG1_SAVED;
					err_msg_update_flag = SET;	
				}
	
			}
			error_id==error_id++;
		}
		else if(error_id==18)
		{
	
			if(pgm2_on_flag)
			{
				err_id = PROGRAM2_RUNNING;
				err_msg_update_flag = SET;
			}
			
			else 
			{
				if(pgm2_prgm_on_flag)
				{
					err_id =PROG2_SAVED;
					err_msg_update_flag = SET;	
				}
	
			}
			error_id==error_id++;
		}
		else if(error_id==19)
		{
	
			if(pgm3_on_flag)
			{
				err_id = PROGRAM3_RUNNING;
				err_msg_update_flag = SET;
			}
			
			else 
			{
				if(pgm3_prgm_on_flag)
				{
					err_id =PROG3_SAVED;
					err_msg_update_flag = SET;	
				}
	
			}
			error_id==error_id++;
		}
		else if(error_id==20)
		{
	
			if(zero_on_flag)
			{
				err_id = ZERO_PGM_RUNNING;
				err_msg_update_flag = SET;
			}
			error_id==error_id++;
		}
		else if(error_id==21)
		{
			disp_id=DENTAL_PROJECT;
			err_msg_update_flag = CLEAR;
			msg_update_flag = SET;
			error_id=0X00;
			
		}
}
