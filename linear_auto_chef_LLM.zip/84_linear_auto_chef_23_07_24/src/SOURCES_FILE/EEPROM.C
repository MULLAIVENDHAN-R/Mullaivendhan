/*
 * EEPROM.C
 *
 *  Created on: Dec 9, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/EXTERN_FUN.H"
#include "HEADER_FILE/EEPROM_HEADER.H"



void waiting1(void);
unsigned char eeprom_read(unsigned int);
void eeprom_write(unsigned int, unsigned char);
void eeprom_write_int(unsigned int,unsigned int);
unsigned int eeprom_read_int(unsigned int);
unsigned long int eeprom_read_long_int(unsigned int);
void eeprom_write_long_int(unsigned int, unsigned long int);
extern unsigned char eeprom_read_iic(unsigned char device_addr, unsigned char no_bytes);
extern bool read_iic(unsigned int , unsigned char );
extern unsigned char eeprom_write_iic(unsigned int , unsigned char );
unsigned int b,eeprom_write_time_out;
bool eeprom_write_ok,eeprom_reed_ok;

void eeprom_write(unsigned int address, unsigned char datas)
{
    unsigned int v;
    eeprom_write_time_out=10;
    do
    {
        tmp_var = datas;    //value to write in eeprom
        ram_addr = &tmp_var;
        disp_addr = address;    //write at 0th address
        /****************************************************/
        if(disp_addr<255)
        {
            eeprom_write_ok=eeprom_write_iic(EEPROM_WRITE,1);
        }
        else
        {
            disp_addr = address-255;
            eeprom_write_ok=eeprom_write_iic(EEPROM_WRITE_ADR,1);
        }

        /****************************************************/
        for(v=0;v<1000;v++);
        eeprom_write_time_out--;
      //  if(eeprom_write_ok)
        //    eeprom_write_start_flag=CLR;
    }
    while((!eeprom_write_ok)AND(eeprom_write_time_out));
}

unsigned char eeprom_read(unsigned int address)
{
    for(b = 0; b < 20 ; b++)
    {
        tmp_var = 0;    //clear that variable
        ram_addr = &tmp_var;
        disp_addr = address;    //read at 0th address
        //eeprom_reed_ok=read_iic(EEPROM_READ,1);
        /**********************************************/
        if(disp_addr<255)
        {
            eeprom_reed_ok=eeprom_read_iic(EEPROM_READ,1);
        }
        else
        {
            disp_addr = address-255;
            eeprom_reed_ok=eeprom_read_iic(EEPROM_READ_ADR,1);
        }
        /**********************************************/
        if(eeprom_reed_ok)
        break;
    }
    return(tmp_var);
}

void eeprom_write_int(unsigned int adress,unsigned int value)
{
    unsigned char temp_count;
    temp_count = value;
    eeprom_write(adress,temp_count);
    temp_count = value>>8;
    adress++;
    eeprom_write(adress,temp_count);
}

unsigned int eeprom_read_int(unsigned int adress)
{
    unsigned char temp_char;
    unsigned int temp_int;
    temp_char=eeprom_read(adress);
    adress++;
    temp_int=eeprom_read(adress);
    temp_int <<=8;
    temp_int |= temp_char;
    return(temp_int);
}

void waiting1()
{
    while(eprom_dly);
}

void eeprom_write_long_int(unsigned int address, unsigned long int datas)
{
    unsigned char temp_count;
    temp_count = datas >> 16;  //MSB
    eeprom_write(address,temp_count);
    temp_count = datas >> 8;  //MSB
    address ++;
    eeprom_write(address,temp_count);
    temp_count = datas;   //LSB
    address ++;
    eeprom_write(address,temp_count);
}

unsigned long int eeprom_read_long_int(unsigned int address)
{
    unsigned char temp_char;
    unsigned long int temp_long_int1, temp_long_int2;
    temp_long_int1 = eeprom_read(address);
    temp_long_int1 <<= 16;
    temp_long_int2 = eeprom_read(address+1);
    temp_long_int2 <<= 8;
    temp_char = eeprom_read(address+2);
    temp_long_int1 |= (temp_long_int2 | temp_char);
    return(temp_long_int1);
}

