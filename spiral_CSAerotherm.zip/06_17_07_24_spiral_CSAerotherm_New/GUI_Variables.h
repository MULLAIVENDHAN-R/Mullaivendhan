char
temp_string[10],
string_process_data_buf[MAX_SIZE_RX_BUF];

unsigned char 
test_buf[MAX_SIZE_RX_BUF],
uart_main_buf[MAX_SIZE_RX_BUF],
uart_backup_buf[MAX_SIZE_RX_BUF],
process_data_buf[MAX_SIZE_RX_BUF],
//string_process_data_buf[MAX_SIZE_RX_BUF],
send_buf[MAX_SIZE_RX_BUF],
total_length,
total_data_bytes,
data;

__boolean
chk_sum_err_flag,
frame_err_flag,
dlc_err_flag,
appid_err_flag,
funid_err_flag;


unsigned char
uart_error_clear_count,
received_app_id,
received_fun_id,
app_id,
fun_id;



/*********************************UART DATA PROCESS *****************************/
__boolean
low_time_minus_data_flag,
high_time_minus_data_flag,
handshake_ok_flag,
ack_ok_flag;


/************************************UART SEND***************************/
__boolean
waiting_for_ack_flag,
uart_driver_reset_flag,
resend_flag,
uart_send_flag;

unsigned char
resend_cnt,
trasmit_dly,
send_backup_buf[MAX_SIZE_RX_BUF],
backup_total_bytes,
tx_total_send_bytes;

