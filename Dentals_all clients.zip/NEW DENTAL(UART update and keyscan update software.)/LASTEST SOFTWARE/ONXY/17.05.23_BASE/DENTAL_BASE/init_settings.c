#include "sfr_r825.h"                    /* Definition of R8C/2K SFR */  
#include "macro.h"
#include "xvariables.h"  

void init_settings();
extern void write_data(unsigned char value);
void init_settings()
{	  
	/*asm("FCLR I");  	
	read_addr=eeprom_heat_time;
   	heat_time=0x00;
   	heat_time=*read_addr;
	asm("FSET I"); //Enable all the Interrupts
	
	if(heat_time>100)
	{
    	asm("FCLR I"); //Disable all the Interrupts	
		heat_time=0x00;	
		write_addr = eeprom_heat_time;
  	   	temperary=heat_time;
	    write_data(temperary);
    	asm("FSET I"); //Enable all the Interrupts

		asm("FCLR I"); //Disable all the Interrupts		
		ster_time=0x00;
		temperary=ster_time;
		write_addr = eeprom_ster_time;		
		write_data(temperary);
	  	asm("FSET I"); //Enable all the Interrupts

	}
	asm("FCLR I");  
	
	read_addr=eeprom_heat_time;
   	heat_time=0x00;
   	heat_time=*read_addr;	
	
	
	//read_data(eeprom_ster_time);
	read_addr=eeprom_ster_time;
   	ster_time=0x00;
   	ster_time=*read_addr;
	
	asm("FSET I");
	
/*	//read_data(eeprom_heat_on_off_time);
	read_addr=eeprom_heat_on_off_time;
   	heat_on_off_time=0x00;
   	heat_on_off_time=*read_addr;	
	
	
	//read_data(eeprom_sole_time);
	read_addr=eeprom_sole_time;
   	sole_time=0x00;
   	sole_time=*read_addr;
	
	
	//read_data(eeprom_dry_time);
	read_addr=eeprom_dry_time;
   	dry_time=0x00;
   	dry_time=*read_addr;	*/

}