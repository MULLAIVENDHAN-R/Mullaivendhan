#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"


void detect_key_pressed();
extern void on_off_function();
extern void fwd_rev_function();
extern void hand_foot_fuction();
extern void xray_function();

void detect_key_pressed()
{
	if(key_status_changed_flag)
	{
		key_status_changed_flag=CLEAR;
		send_uart_data_flag=SET;
		if((serial_received_data&ON_OFF_KEY)==0x00000000)
		{
			if(!micro_error_flag)
			on_off_sw_flag=SET;					//ON_OFF-KEY
		//	xray_function();
		}
		else if((serial_received_data&INC_SW_KEY)==0x00000000)
		{
			if(on_off_flag)
			{			
//				speed_inc_delay_flag=SET;
				inc_sw_key_flag=SET;		
			//	inc_function();					//INC_SW_KEY
					
			}			
		}
		else if((serial_received_data&DEC_SW_KEY)==0x00000000)
		{
			if(on_off_flag)
			{
				dec_sw_key_flag=SET;
			//	dec_function();					//DEC_SW_KEY;
			}					
		}
		else if((serial_received_data&FWD_REV_KEY)==0x00000000)
		{
			if(on_off_flag)	
			{	
				fwd_rev_key_pressed_flag=SET;			
				fwd_rev_function();				//FWD_REV_KEY
			}									
										
		}
		/*else if((serial_received_data&XRAY_SW_KEY)==0x00000000)
		{	
			xray_function();					//XRAY_SW_KEY		
		}
		else if((serial_received_data&AERO_SW_KEY)==0x00000000)
		{
			aeroter_sw_flag=SET;				//AERO_SW_KEY
		}*/
		else if((serial_received_data&HAND_FOOR_KEY)==0x00000000)
		{
			if(on_off_flag)
			{
				hand_foot_key_pressed_flag=SET;
				hand_foot_fuction();		//HAND_FOOT_KEY
			}			   
		}
	}		
}