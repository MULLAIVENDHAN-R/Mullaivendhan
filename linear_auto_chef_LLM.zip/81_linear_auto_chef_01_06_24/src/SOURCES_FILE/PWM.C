/*
 * PWM.C
 *
 *  Created on: Dec 28, 2023
 *      Author: kl
 */

#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/IO.H"
#include "HEADER_FILE/EXTERN_FUN.H"


unsigned int
            pulse_counter_1,
            pulse_counter_2,
            pulse_counter_3,

            rod_pulse_counter,

            ROD_ON_TIME,
            ROD_OFF_TIME,

            ON_TIME_1,
            OFF_TIME_1,

            ON_TIME_2,
            OFF_TIME_2,

            ON_TIME_3,
            OFF_TIME_3;

 bool
     pulse_1_on_flag,
     pulse_2_on_flag,
     pulse_3_on_flag,

     rod_pulse_on_flag,

     str_mtr1_on_flag,
     str_mtr2_on_flag,
     str_mtr3_on_flag;

void stro_mtr_speed_ctrl();
void load_pulse_period(unsigned char,unsigned char);
void Rod_gen_pulse();

void stro_mtr_speed_ctrl()
{
    if(str_mtr1_on_flag)
    {
        if((ON_TIME_1)AND(OFF_TIME_1))
        {
        pulse_counter_1++;
        if(pulse_counter_1 <= ON_TIME_1)
        {
            if(!pulse_1_on_flag)
            {
                pulse_1_on_flag = SET;
                STIRRER_1_MOTOR_PWM_HIGH;
            }
        }
        else
        {
            if(pulse_counter_1<ON_TIME_1+OFF_TIME_1)
            {
                if(pulse_1_on_flag)
                {
                    pulse_1_on_flag = CLR;
                     STIRRER_1_MOTOR_PWM_LOW;
                }
            }
            else
            pulse_counter_1 = 0;
        }
        }else
            STIRRER_1_MOTOR_PWM_HIGH;
    }
    if(str_mtr2_on_flag)
    {
        pulse_counter_2++;
        if(pulse_counter_2 <= ON_TIME_2)
        {
            if(!pulse_2_on_flag)
            {
                pulse_2_on_flag = SET;
                STIRRER_2_MOTOR_PWM_HIGH;
            }
        }
        else
        {
            if(pulse_counter_2<ON_TIME_2+OFF_TIME_2)
            {
                if(pulse_2_on_flag)
                {
                    pulse_2_on_flag = CLR;
                    STIRRER_2_MOTOR_PWM_LOW;
                }
            }
            else
            pulse_counter_2 = 0;
        }
    }
    if(str_mtr3_on_flag)
    {
        pulse_counter_3++;
        if(pulse_counter_3 <= ON_TIME_3)
        {
            if(!pulse_3_on_flag)
            {
                pulse_3_on_flag = SET;
                STIRRER_3_MOTOR_PWM_HIGH;
            }
        }
        else
        {
            if(pulse_counter_3<ON_TIME_3+OFF_TIME_3)
            {
                if(pulse_3_on_flag)
                {
                    pulse_3_on_flag = CLR;
                    STIRRER_3_MOTOR_PWM_LOW;
                }
            }
            else
            pulse_counter_3 = 0;
        }
    }
}
void Rod_gen_pulse()
{
    rod_pulse_counter++;
    if(rod_pulse_counter <= ROD_ON_TIME)
    {
        if(!rod_pulse_on_flag)
        {
            rod_pulse_on_flag = SET;
            ROD_PWM_HIGH;
        }
    }
    else if(rod_pulse_counter<ROD_ON_TIME+ROD_OFF_TIME)
    {
        if(rod_pulse_on_flag)
        {
            rod_pulse_on_flag = 0;
            ROD_PWM_LOW;
        }
    }
    else
    {
      rod_pulse_counter = 0;
      rod_pulse_on_flag=0;
      ROD_ON_TIME=13;
      ROD_OFF_TIME=12;
    }
}

void load_pulse_period(unsigned char level,unsigned char cooker)
{

    switch(level)
    {
        case STRL:
                    if(cooker==COOKER1)
                    {
                        ON_TIME_1=25;
                        OFF_TIME_1=100;
                    }
                    if(cooker==COOKER2)
                    {
                        ON_TIME_2=25;
                        OFF_TIME_2=100;
                    }
                    if(cooker==COOKER3)
                    {
                        ON_TIME_3=25;
                        OFF_TIME_3=100;
                    }
            break;

        case STRM:
                    if(cooker==COOKER1)
                    {
                        ON_TIME_1=50;
                        OFF_TIME_1=50;
                    }
                    if(cooker==COOKER2)
                    {
                        ON_TIME_2=50;
                        OFF_TIME_2=50;
                    }
                    if(cooker==COOKER3)
                    {
                        ON_TIME_3=50;
                        OFF_TIME_3=50;
                    }

              break;

        case STRH:
                    if(cooker==COOKER1)
                    {
                        ON_TIME_1=100;
                        OFF_TIME_1=25;
                    }
                    if(cooker==COOKER2)
                    {
                        ON_TIME_2=100;
                        OFF_TIME_2=25;
                    }
                    if(cooker==COOKER3)
                    {
                        ON_TIME_3=100;
                        OFF_TIME_3=25;
                    }
              break;

    }

}

