#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"


void uart_send_data_function();			//THIS FUNCTION IS CONCENTRATE TO LED ON-OFF & LCD DISPLAY UPDATE FORM UART DATA send to lcd screen.


void uart_send_data_function()
{
	
//	te_u0c1=1;
	for(l=0;l<7;l++)
	{			
	//	receive_send_uart_data1=(temp_uart_serial_received_data1>>(8*l));
		while(ti_u0c1 == 0);
		u0tb = send_buff[l];	//Wait until buffer becomes empty
	//	while(ti_u0c1 == 0);
	}
//	te_u0c1=0;
}