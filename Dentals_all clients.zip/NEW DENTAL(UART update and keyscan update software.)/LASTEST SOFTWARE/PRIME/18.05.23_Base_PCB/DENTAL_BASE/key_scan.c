#include "sfr_r825.h"
#include "cstartdef.h" 
#include "xvariables.h"
#include "macro.h"

void uart_key_scan();
void food_key_scan();

void uart_key_scan()
{
	if(!key_status_changed_flag)
	{
		if(temp_serial_received_data != KEYPAD_DATA)
		{				
			key_status_changed_flag= SET;					
			first_time_flag=CLEAR;
			INDICATOR_OFF;
		/*	if(!fst_lamp_flag)
			{
				fst_lamp_flag = SET;
				lamp_sw_flag=CLEAR;
				lamp_low_sw_flag = CLEAR;
				lamp_high_sw_flag = CLEAR;
			}	*/																	
		}
		else
		{			
			conti_lamp_flag = CLEAR;
			if(temp_serial_received_data==KEYPAD_DATA)
			{
				key_status_changed_flag=CLEAR;
				INDICATOR_ON;
				first_time_flag=SET;
				tumbler_sw_flag=CLEAR;
				lamp_sw_flag =CLEAR;
				spit_sw_flag =CLEAR;
				pgm2_sw_flag=CLEAR;
				act_up_flag=CLEAR;
				zero_sw_flag=CLEAR;
				act_dwn_flag=CLEAR;
				pgm3_sw_flag=CLEAR;
				gaugle_sw_flag=CLEAR;
				act_rev_flag=CLEAR;
				shark_sw_flag=CLEAR;
				pgm1_sw_flag=CLEAR;
				act_fwd_flag =CLEAR;
				up_act_display_send_flag=CLEAR;
				dwn_act_display_send_flag=CLEAR;
				fwd_act_display_send_flag=CLEAR;
				rev_act_display_send_flag=CLEAR;
				BUZZER_OFF;
				if((fwd_act_off_flag)AND(foot_key_data==0x1E))
				FWD_ACTUATOR_OFF;
				if((rev_act_off_flag)AND(foot_key_data==0x1E))
				REV_ACTUATOR_OFF;
				if((dwn_act_off_flag)AND(foot_key_data==0x1E))
				DWN_ACTUATOR_OFF;
				if((up_act_off_flag)AND(foot_key_data==0x1E))
				UP_ACTUATOR_OFF;
				if(fwd_rev_pulse_error_flag)
				fwd_rev_pulse_error_flag=CLEAR;
				if(up_dn_pulse_error_flag)
				up_dn_pulse_error_flag=CLEAR;
				
			}		
		}
	}	
}
void food_key_scan()
{
	if(!foot_key_status_changed_flag)
	{
		foot_key_data= FOOT_PORT;
		foot_key_data=foot_key_data&0x3E;
		if(foot_key_data!=0x3E)
		{
			if(!foot_key_delay_flag)
			{
				foot_key_press_time=5;//20;
				temp_foot_key_data= foot_key_data;
				foot_key_delay_flag=SET;;
			}
			else
			{
				if(foot_key_press_time<=0)
				{
					if(foot_key_data==temp_foot_key_data)
					{
						foot_key_status_changed_flag= SET;
						foot_key_delay_flag=CLEAR;					
					}
					else
					{
						foot_key_status_changed_flag= CLEAR;
						temp_foot_key_data=0;
						foot_key_delay_flag=CLEAR;
					}
				}
				
			}
			
		}
		else
		{
			foot_key_status_changed_flag = CLEAR;
			foot_key_delay_flag = CLEAR;
			foot_rev_sw_flag = CLEAR;
			foot_fwd_sw_flag = CLEAR;
			foot_dwn_sw_flag = CLEAR;
			foot_up_sw_flag = CLEAR;
			foot_zero_sw_flag = CLEAR;
			if((temp_serial_received_data == KEYPAD_DATA)AND(foot_key_data==0x3E))
			{
				if(fwd_rev_pulse_error_flag)
				fwd_rev_pulse_error_flag=CLEAR;
				if(up_dn_pulse_error_flag)
				up_dn_pulse_error_flag=CLEAR;
				up_act_display_send_flag=CLEAR;
				dwn_act_display_send_flag=CLEAR;
				fwd_act_display_send_flag=CLEAR;
				rev_act_display_send_flag=CLEAR;
			}
			BUZZER_OFF;	
		}
	}
}

void assistance_key_scan()
{
	if(!assistance_key_status_changed_flag)
	{
//		zero_assistance_key_data=(p0&0x40);
//		zero_assistance_key_data=(zero_assistance_key_data>>6);
		assistance_key_data= ASSISTANCE_PORT;
		assistance_key_data = (assistance_key_data&0xB8);
		//assistance_key_data=(assistance_key_data);
		//assistance_key_data=(assistance_key_data&0xb9);
		if((assistance_key_data!=0xb8)AND(assistance_key_data!=0x00))
		{
			if(!assistance_key_delay_flag)
			{
				assistance_key_press_time=4;
				temp_assistance_key_data= assistance_key_data;
				assistance_key_delay_flag=SET;
			}
			else
			{
				if(assistance_key_press_time<=0)
				{
					if(assistance_key_data==temp_assistance_key_data)
					{
						assistance_key_status_changed_flag= SET;
						assistance_one_time_press_flag=SET;
						assistance_key_delay_flag=CLEAR;	
						INDICATOR_OFF;				
					}
					else
					{
						assistance_key_status_changed_flag= CLEAR;
						temp_assistance_key_data=0;
						assistance_key_delay_flag=CLEAR;
					}
				}				
			}			
		}
		else
		{			
			if(((temp_serial_received_data==KEYPAD_DATA)OR(temp_serial_received_data==0x00000000)OR(assistance_one_time_press_flag))AND(foot_key_data==0x3E)AND((assistance_key_data==0xb8)OR(assistance_key_data==0x00)))
			{
				conti_lamp_flag = CLEAR;
				assistance_key_status_changed_flag = CLEAR;
				assistance_key_delay_flag = CLEAR;
				//zero_sw_flag = CLEAR;	
				zero_sw_flag=CLEAR;	
				tumbler_sw_flag=CLEAR;
			//	tumbler_on_flag=CLEAR;
				spit_sw_flag =CLEAR;
				//gaugle_sw_flag=CLEAR;	
				tumb_sudden_enter_stop_flag = CLEAR;
				spit_sudden_enter_stop_flag = CLEAR;
				asst_act_up_flag=CLEAR;	
				aast_act_dwn_flag=CLEAR;
				asst_act_fwd_flag=CLEAR;
				asst_act_rev_flag=CLEAR;
				assistance_one_time_press_flag=CLEAR;
			//	assistance_zero_sw_flag = CLEAR;			
				BUZZER_OFF;
				INDICATOR_ON;
				temp_assistance_key_data=0x00;
			}	
		}
	}
	else
	{
	//	assistance_key_status_changed_flag=CLEAR;
	}
}



