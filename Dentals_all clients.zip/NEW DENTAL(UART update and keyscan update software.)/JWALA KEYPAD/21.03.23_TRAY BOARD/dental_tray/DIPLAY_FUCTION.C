#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"
#include "lcd_code.h"

extern void delay1(unsigned char);
extern void delay(unsigned char);
extern void lcd_write(unsigned char,unsigned char);
void rotate_display(void);
void err_update(void);
void update_message();
void display_message(unsigned char,unsigned char);

void rotate_display()
{
	rotating_flag = CLEAR;
	start_index = rotate_index;
	for(tmp_var1 = 16;tmp_var1<=32;tmp_var1++)
	{
		delay(0x0F);
		display_message(tmp_var1,rotate_mesg[0][start_index]);
		start_index++;
		if(start_index>=28)         
		{
			start_index = 0;
		//	rotating_flag = CLEAR;
		}
				
	}
	if(++rotate_index>=28)
	{			
		rotate_index = 0;		
	}
}

void err_update(void)
{
	err_msg_update_flag = CLEAR;
	for(tmp_var1 = 0;tmp_var1 <= 15;tmp_var1++)
	{
		delay(0x1);
	    display_message(tmp_var1,err_mesg[err_id-1][tmp_var1]);
	}
}

void update_message()
{
	msg_update_flag = CLEAR;
	for(tmp_var1 = 0;tmp_var1 <= 15;tmp_var1++)
	{
		
		delay(0x1);
		display_message(tmp_var1,lcdcode[disp_id-1][tmp_var1]);
	}
}

void display_message(unsigned char count, unsigned char data1)
{
	if(count == 0)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_2);	//Select address for second line
		delay1(0xFF);
	}
	if(count == 8)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_1);	//Select address for first line
		delay1(0xFF);
	}
	if(count == 16)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_4);	
		delay1(0xFF);
	}
	if(count == 24)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_3);	
		delay1(0xFF);
	}
	lcd_write(RAM,data1);			//Write the data in DDRAM
	delay1(0xFF);
}
