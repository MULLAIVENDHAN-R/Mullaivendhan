#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h" 
#include "GUI_XVariables.h" 

static unsigned char process_data=0;
static unsigned char lids_trays_data_count=0;
void adj_pos_data_get_fun();
void cookers_home_position();
extern void form_send_buf(char,char);
extern void all_outputs_on_off_fun(char,unsigned char);
extern void all_outputs_off_fun();
extern void gui_uart_send();
extern void sensor_open_close_conform();
extern void process_buf_splitup();
extern void allTime_check_fun();
void kadai_home_position(); 
void init_lid_home_position(); 
void init_veg_tray_home_position();
extern void str_to_process_buf_conversion();
void is_initial_position_ok()
{
	while(!initial_position_ok_flag)
    	{
		if((vegtray_set_flag)AND(lid_set_flag))
		{
			initial_position_ok_flag=SET;
		}
	    	all_outputs_off_fun();
	    	allTime_check_fun();
    	}
}
void veg_tray_home_position()
{
	if(tray_pos_adj_data_flag)
	{
		init_veg_tray_home_position();
		veg_tray_position_ok_flag=CLEAR;
		//adj_pos_data_get_fun();
	}	
	if((tray_pos_rqt_acpt_flag)AND(!tray_pos_adj_data_flag))
	{
		if(is_model_1)
		{
			temp_send_buf[tx_data++]=(VEG_TRAY1_SWITCH)+0X30;
			temp_send_buf[tx_data++]='|';
			temp_send_buf[tx_data++]='1';			//consider as closed
			temp_send_buf[tx_data++]='|';
			temp_send_buf[tx_data++]='1';			//consider as closed
		}
		else
		{
			temp_send_buf[tx_data++]=(1)+0X30;  		 //VEG_TRAY1_SWITCH  //consider as closed
			temp_send_buf[tx_data++]='|';
			temp_send_buf[tx_data++]=(1)+0X30;		 //VEG_TRAY2_SWITCH  //consider as closed
			temp_send_buf[tx_data++]='|';
			temp_send_buf[tx_data++]=(1)+0X30;// //consider as closed //consider as closed
		}
		TRAY_POS_RES_APPID_FUNID;
		form_send_buf(DATA_RES,tx_data);
		tx_data=0;	
	}
	
	if((vegtray1_switch_close_flag)AND(vegtray2_switch_close_flag)AND(vegtray3_switch_close_flag))
	vegtray_set_flag=SET;
	if((vegtray1_switch_close_flag)AND(is_model_1))
	vegtray_set_flag=SET;	
}
void lid_home_position()
{
	if(lid_pos_adj_data_flag)
	{
		init_lid_home_position();
		lid_position_flag=CLEAR;
		//adj_pos_data_get_fun();
	}
	if((lid_pos_rqt_acpt_flag)AND(!lid_pos_adj_data_flag))
	{
		if(is_model_1)
		{
			temp_send_buf[tx_data++]=(LID_UP_SWITCH)+0X30;
			temp_send_buf[tx_data++]='|';
			temp_send_buf[tx_data++]=(LID_REV_SWITCH)+0X30;
		}
		else
		{
			temp_send_buf[tx_data++]=1+0X30;//((LID_UP_SWITCH)AND(LID1_UP_SWITCH)AND(LID2_UP_SWITCH))+0X30;
			temp_send_buf[tx_data++]='|';
			temp_send_buf[tx_data++]=1+0X30;//((LID_REV_SWITCH)AND(LID1_REV_SWITCH)AND(LID2_REV_SWITCH))+0X30;
		}
		LID_POS_RES_APPID_FUNID;
		form_send_buf(DATA_RES,tx_data);
		tx_data=0;
	}
	
	if((lid_up_switch_close_flag)AND(lid_rev_switch_close_flag)AND(lid1_up_switch_close_flag)AND(lid1_rev_switch_close_flag)AND(lid2_up_switch_close_flag)AND(lid2_rev_switch_close_flag))
	lid_set_flag=SET;
	if((lid_up_switch_close_flag)AND(lid_rev_switch_close_flag)AND(is_model_1))
	lid_set_flag=SET;
}
void adj_pos_data_get_fun()
{
	motor_code=cooker1_buf[process_data];
	direction=cooker1_buf[++process_data];
	action_based=cooker1_buf[++process_data];
	time_unit=cooker1_buf[++process_data];
	if(time_unit==1)
	multiply_with=1;
	else if(time_unit==2)
	multiply_with=MILLI_SECONDS;
	else if(time_unit==3)
	multiply_with=SECONDS*MILLI_SECONDS;
	else
	multiply_with=0;
	output_on_time=cooker1_buf[++process_data];
	output_on_time=((output_on_time<<8)|cooker1_buf[++process_data]);
	output_on_time=((output_on_time<<8)|cooker1_buf[++process_data]);			
	output_on_time=multiply_with*output_on_time;
	process_data=0;	
	
	if(lid_pos_adj_data_flag)
	{
		if((!lid_up_switch_close_flag)OR(!lid1_up_switch_close_flag)OR(!lid2_up_switch_close_flag))
		{
			if(!lid_up_switch_close_flag)
			motor_code=LDM1;
			else if(!lid1_up_switch_close_flag)
			motor_code=LDM3;
			else if(!lid2_up_switch_close_flag)
			motor_code=LDM5;
			
		}
		else
		{
			if(!lid_rev_switch_close_flag)
			motor_code=LDM2;
			else if(!lid1_rev_switch_close_flag)
			motor_code=LDM4;
			else if(!lid2_rev_switch_close_flag)
			motor_code=LDM6;
		}
	}
	
	all_outputs_on_off_fun(OP_GETS_ON,motor_code);
}
void cookers_home_position()
{
	if(!cooker1_switch_close_flag)
	COOKER_MOTOR_REV_ON;
	while(!cooker1_switch_close_flag)
	{
		allTime_check_fun();
		if((cooker_switch_failure_counter>15)AND(!COOKER_MOTOR_REV))
		{
			COOKER_MOTOR_OFF;
			ERROR_APPID_FUNID;
			BUZZER_ON;
			form_send_buf(COMMAND_RES,COOKER_PROXI_SENSOR_FAILURE);
		}
	}
	if((cooker1_switch_close_flag)AND(cooker2_switch_close_flag))
	{
		COOKER_MOTOR_OFF;
		return;
	}
	else
	{
		COOKER_MOTOR_REV_ON;
		delay=260;
		while(delay)
		{
			allTime_check_fun();
			if((cooker1_switch_close_flag)AND(cooker2_switch_close_flag))
			{
				COOKER_MOTOR_OFF;
				return;
			}
			
		}
		COOKER_MOTOR_OFF;
		delay=20;
		while(delay);
		COOKER_MOTOR_FWD_ON;
		cooker_switch_failure_counter=0;
		while((!cooker1_switch_close_flag)OR(!cooker2_switch_close_flag))
		{
			allTime_check_fun();
			if((cooker_switch_failure_counter>34)AND(!COOKER_MOTOR_FWD))
			{
				COOKER_MOTOR_OFF;
				ERROR_APPID_FUNID;
				BUZZER_ON;
				form_send_buf(COMMAND_RES,COOKER_HOME_SWITCH_FAILURE);
			}
		}
		cooker_switch_failure_counter=0;
		COOKER_MOTOR_OFF;
	}
	return;
}
void heartBeat()
{
	if(heart_beat_send_flag)
    	{
	        heart_beat_send_flag=CLEAR;
	        HEART_BEAT_APPID_FUNID;
	        form_send_buf(COMMAND_RES,HEART_BEAT_DATA);
    	}
}

void dataRcvd_success()
{
	if(process_data_rcvd_success_flag)
	{
		process_buf_splitup();
		if(general_data_rcvd_flag)
		{
			general_data_rcvd_flag=CLEAR;
			memset(process_data_buf1,0,sizeof(process_data_buf1));
		}
		memset(process_data_buf,0,sizeof(process_data_buf));
		process_data_rcvd_success_flag=CLEAR;
	}
}
void dataRcvd_to_process_buf_conversion()
{
	if(data_received_ok_flag)
	{		
		if((string_process_data_backup__buf3_set_flag)AND(!string_process_data_backup__buf2_set_flag)AND(!string_process_data_backup__buf1_set_flag))
		{	
			memcpy(string_process_data_buf,string_process_data_backup_buf2,sizeof(string_process_data_backup_buf2));
			memset(temp_string,0,sizeof(temp_string));		
			str_to_process_buf_conversion();
			string_process_data_backup__buf3_set_flag=CLEAR;			
		} 
		else if((string_process_data_backup__buf2_set_flag)AND(!string_process_data_backup__buf3_set_flag)AND(!string_process_data_backup__buf1_set_flag))		
		{			
			memcpy(string_process_data_buf,string_process_data_backup_buf1,sizeof(string_process_data_backup_buf1));
			memset(temp_string,0,sizeof(temp_string));		
			str_to_process_buf_conversion();
			string_process_data_backup__buf2_set_flag=CLEAR;			
		}		
		else 
		{
			if((string_process_data_backup__buf1_set_flag)AND(!string_process_data_backup__buf3_set_flag)AND(!string_process_data_backup__buf2_set_flag))
			{
				memset(temp_string,0,sizeof(temp_string));		
				str_to_process_buf_conversion();
				string_process_data_backup__buf1_set_flag=CLEAR;
			}
		}
		data_received_ok_flag=CLEAR;
		memset(uart_backup_buf,0,sizeof(uart_backup_buf));
		if(string_process_data_flag)
		{
			process_data_rcvd_success_flag=SET;
			string_process_data_flag=CLEAR;
		}
		if(frame_err_flag)
		{
			process_data_rcvd_success_flag=CLEAR;
			waiting_for_ack_flag=SET,resend_cnt=10;
			frame_err_flag=CLEAR;
		}
	}
	else if(general_data_rcvd_flag)	
		process_data_rcvd_success_flag=SET;
		
	
		
	
		
	
}
void kadai_home_position()
{	
	unsigned char kadai_motor;
	while(!kadai_home_position_ok_flag)
	{
		switch(kadai_motor)
		{
			case(1):
				if((!kadai_cw_switch_close_flag)AND(!kadai_cw_on_flag))
				{
					KADAI_CC_ON;
					kadai_cw_on_flag=SET;
					kadai_cc_ccw_time=MILLI_SECONDS*10;										
				}
				else if(kadai_cw_switch_close_flag)
				{
					KADAI_CC_CCW_STOP;
					kadai_motor=2;
					kadai_cc_ccw_time=0;
					kadai_cw_on_flag=CLEAR;
				}
				break;
			case(2):
				if((!kadai_rev_switch_close_flag)AND(!kadai_rev_on_flag)AND(kadai_cw_switch_close_flag))
				{
					KADAI_REV_ON;					
					kadai_rev_on_flag=SET;
					kadai_fwd_rev_time=MILLI_SECONDS*20;
				}
				else if((kadai_rev_switch_close_flag)AND(kadai_cw_switch_close_flag))
				{
					KADAI_FWD_REV_STOP;
					kadai_motor=0;
					kadai_fwd_rev_time=0;
					kadai_rev_on_flag=CLEAR;
				}
				break;			
			default:
				if((kadai_cw_switch_close_flag)AND(kadai_rev_switch_close_flag)AND(kadai_motor==0))
				kadai_home_position_ok_flag=SET;
				else 
				kadai_motor=1;
				break;			
		}
		sensor_open_close_conform();
		all_outputs_off_fun();	
		gui_uart_send();
		if((kadai_cw_switch_close_flag)AND(kadai_rev_switch_close_flag)AND(kadai_motor==0))
		kadai_home_position_ok_flag=SET;		
	}
	
	
	
}
void init_lid_home_position()
{	
	unsigned char lid_motor;
	while(!lid_position_flag)
	{	
		
		switch(lid_motor)
		{
			case(1): 
				if((!lid_rev_switch_close_flag)AND(!lid1_rev_flag))
				{
					LID_REV_ON;
					lid1_rev_flag=SET;
					lid_fwd_rev_time=MILLI_SECONDS*7;
				}
				else if(lid_rev_switch_close_flag)
				{
					LID_FWD_REV_OFF;
					lid_fwd_rev_time=0;
					lid_motor=2;					
				}
				break;
			case(2):
				if((!lid_up_switch_close_flag)AND(!lid1_up_flag))
				{
					LID_UP_ON;
					lid1_up_flag=SET;
					lid_up_dwn_time=MILLI_SECONDS*7;
				}
				else if(lid_up_switch_close_flag)
				{
					LID_UP_DWN_OFF;
					lid_motor=3;
					lid_up_dwn_time=0;
				}
				break;
			case(3): 
				if((!lid1_rev_switch_close_flag)AND(!lid2_rev_flag))
				{
					LID1_REV_ON;
					lid2_rev_flag=SET;
					lid1_fwd_rev_time=MILLI_SECONDS*7;
				}
				else if(lid1_rev_switch_close_flag)
				{
					LID1_FWD_REV_OFF;
					lid_motor=4;
					lid1_fwd_rev_time=0;
				}	
				break;
			case(4): 
				if((!lid1_up_switch_close_flag)AND(!lid2_up_flag))
				{
					LID1_UP_ON;
					lid2_up_flag=SET;
					lid1_up_dwn_time=MILLI_SECONDS*7;
				}
				else if(lid1_up_switch_close_flag)
				{
					LID1_UP_DWN_OFF;
					lid1_up_dwn_time=0;
					lid_motor=5;					
				}
				break;
			case(5): 
				if((!lid2_rev_switch_close_flag)AND(!lid3_rev_flag))
				{
					LID2_REV_ON;
					lid3_rev_flag=SET;
					lid2_fwd_rev_time=MILLI_SECONDS*7;
				}
				else if(lid2_rev_switch_close_flag)
				{
					LID2_FWD_REV_OFF;
					lid2_fwd_rev_time=0;
					lid_motor=6;					
				}
				break;
			case(6): 
				if((!lid2_up_switch_close_flag)AND(!lid3_up_flag))
				{
					LID2_UP_ON;
					lid3_up_flag=SET;
					lid2_up_dwn_time=MILLI_SECONDS*7;
				}
				else if(lid2_up_switch_close_flag)
				{
					LID2_UP_DWN_OFF;
					lid2_up_dwn_time=0;
					lid_motor=0;					
				}
				break;
			default: 
			if((lid_rev_switch_close_flag)AND(lid_up_switch_close_flag)AND(lid1_rev_switch_close_flag)AND(lid1_up_switch_close_flag)AND(lid2_rev_switch_close_flag)AND(lid2_up_switch_close_flag)AND(lid_motor==0))
			lid_position_flag=SET;
			else
			lid_motor=1;
			break;
		}
		sensor_open_close_conform();
		all_outputs_off_fun();
		gui_uart_send();
		if((lid_rev_switch_close_flag)AND(lid_up_switch_close_flag)AND(lid1_rev_switch_close_flag)AND(lid1_up_switch_close_flag)AND(lid2_rev_switch_close_flag)AND(lid2_up_switch_close_flag)AND(lid_motor==0))
		lid_position_flag=SET;
	}
}	
void init_veg_tray_home_position()
{
	unsigned char Tray_no;
	while(!veg_tray_position_ok_flag)
	{
		switch(Tray_no)
		{
			case(1):
				if((!vegtray1_switch_close_flag)AND(!veg_tray1_flag))
				{
					veg_tray1_flag=SET;
					VEG_TRAY1_REV_ON;
					vegtray1_time=MILLI_SECONDS*10;
				}
				else if(vegtray1_switch_close_flag)
				{
					VEG_TRAY1_OFF;
					Tray_no=2;
					vegtray1_time=0;
				}				
			break;
			case(2):
				if((!vegtray2_switch_close_flag)AND(!veg_tray2_flag))
				{
					veg_tray2_flag=SET;
					VEG_TRAY2_REV_ON;
					vegtray2_time=MILLI_SECONDS*10;
				}
				else if(vegtray2_switch_close_flag)
				{
					VEG_TRAY2_OFF;
					Tray_no=3;
					vegtray2_time=0;
				}
			break;
			
			case(3):
				if((!vegtray3_switch_close_flag)AND(!veg_tray3_flag))
				{
					veg_tray3_flag=SET;
					VEG_TRAY3_REV_ON;
					vegtray3_time=MILLI_SECONDS*10;
				}
				else if(vegtray3_switch_close_flag)
				{
					VEG_TRAY3_OFF;
					Tray_no=0;
					vegtray3_time=0;
				}
			break;			
			default:
				if((vegtray1_switch_close_flag)AND(vegtray2_switch_close_flag)AND(vegtray3_switch_close_flag)AND(Tray_no==0))
				veg_tray_position_ok_flag=SET;
				else
				Tray_no=1;
			break;
		}		
		sensor_open_close_conform();
		all_outputs_off_fun();
		gui_uart_send();
		if((vegtray1_switch_close_flag)AND(vegtray2_switch_close_flag)AND(vegtray3_switch_close_flag)AND(Tray_no==0))
		veg_tray_position_ok_flag=SET;
		
	}	
}
		 

