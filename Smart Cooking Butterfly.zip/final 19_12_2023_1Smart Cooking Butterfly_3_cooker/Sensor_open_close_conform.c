#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"



void sensor_open_close_conform()
{
	if(!VEG_TRAY1_SWITCH)
	{
		if(vegtray1_switch_open_conform_time>20)
		{
			vegtray1_switch_close_flag=CLEAR;
			vegtray1_switch_close_conform_time=0;
		}
	}
	else
	{
		if(vegtray1_switch_close_conform_time>20)
		{
			vegtray1_switch_close_flag=SET;
			vegtray1_switch_open_conform_time=0;
		}
	}
	if(!VEG_TRAY2_SWITCH)	
	{
		if(vegtray2_switch_open_conform_time>40)
		{
			vegtray2_switch_close_flag=CLEAR;
			vegtray2_switch_close_conform_time=0;
		}
	}
	else
	{
		if(vegtray2_switch_close_conform_time>40)
		{
			vegtray2_switch_close_flag=SET;
			vegtray2_switch_open_conform_time=0;
		}
	}
	if(!VEG_TRAY3_SWITCH)
	{
		if(vegtray3_switch_open_conform_time>20)
		{
			vegtray3_switch_close_flag=CLEAR;
			vegtray3_switch_close_conform_time=0;
		}
	}
	else
	{
		if(vegtray3_switch_close_conform_time>20)
		{
			vegtray3_switch_close_flag=SET;
			vegtray3_switch_open_conform_time=0;
		}
	}
 	if(!LID_UP_SWITCH)
	{
		if(lid_up_switch_open_conform_time>5)
		{
			lid_up_switch_close_flag=CLEAR;
			lid_up_switch_close_conform_time=0;
		}
	}
	else
	{
		if(lid_up_switch_close_conform_time>5)
		{
			lid_up_switch_close_flag=SET;
			lid_up_switch_open_conform_time=0;
		}
	}
	if(!LID_DWN_SWITCH)
	{
		if(lid_dwn_switch_open_conform_time>5)
		{
			lid_dwn_switch_close_flag=CLEAR;
			lid_dwn_switch_close_conform_time=0;
		}
			
	}
	else
	{
		if(lid_dwn_switch_close_conform_time>5)
		{
			lid_dwn_switch_close_flag=SET;
			lid_dwn_switch_open_conform_time=0;
		}
	}
	if(!LID_FWD_SWITCH)
	{
		if(lid_fwd_switch_open_conform_time>5)
		{
			lid_fwd_switch_close_flag=CLEAR;
			lid_fwd_switch_close_conform_time=0;
		}
			
	}
	else
	{
		if(lid_fwd_switch_close_conform_time>5)
		{
			lid_fwd_switch_close_flag=SET;
			lid_fwd_switch_open_conform_time=0;
		}
	}
	if(!LID_REV_SWITCH)
	{
		if(lid_rev_switch_open_conform_time>5)
		{
			lid_rev_switch_close_flag=CLEAR;
			lid_rev_switch_close_conform_time=0;
		}
	}
	else
	{
		if(lid_rev_switch_close_conform_time>5)
		{
			lid_rev_switch_close_flag=SET;
			lid_rev_switch_open_conform_time=0;
		}
	}
	
	
	
	
	if(!LID1_UP_SWITCH)
	{
		if(lid1_up_switch_open_conform_time>5)
		{
			lid1_up_switch_close_flag=CLEAR;
			lid1_up_switch_close_conform_time=0;
		}
	}
	else
	{
		if(lid1_up_switch_close_conform_time>5)
		{
			lid1_up_switch_close_flag=SET;
			lid1_up_switch_open_conform_time=0;
		}
	}
	if(!LID1_DWN_SWITCH)
	{
		if(lid1_dwn_switch_open_conform_time>5)
		{
			lid1_dwn_switch_close_flag=CLEAR;
			lid1_dwn_switch_close_conform_time=0;
		}
			
	}
	else
	{
		if(lid1_dwn_switch_close_conform_time>5)
		{
			lid1_dwn_switch_close_flag=SET;
			lid1_dwn_switch_open_conform_time=0;
		}
	}
	if(!LID1_FWD_SWITCH)
	{
		if(lid1_fwd_switch_open_conform_time>5)
		{
			lid1_fwd_switch_close_flag=CLEAR;
			lid1_fwd_switch_close_conform_time=0;
		}
			
	}
	else
	{
	if(lid1_fwd_switch_close_conform_time>5)
		{
			lid1_fwd_switch_close_flag=SET;
			lid1_fwd_switch_open_conform_time=0;
		}
	}
	if(!LID1_REV_SWITCH)
	{
		if(lid1_rev_switch_open_conform_time>5)
		{
			lid1_rev_switch_close_flag=CLEAR;
			lid1_rev_switch_close_conform_time=0;
		}
	}
	else
	{
		if(lid1_rev_switch_close_conform_time>5)
		{
			lid1_rev_switch_close_flag=SET;
			lid1_rev_switch_open_conform_time=0;
		}
	}
	
	
	if(!LID2_UP_SWITCH)
	{
		if(lid2_up_switch_open_conform_time>5)
		{
			lid2_up_switch_close_flag=CLEAR;
			lid2_up_switch_close_conform_time=0;
		}
	}
	else
	{
		if(lid2_up_switch_close_conform_time>5)
		{
			lid2_up_switch_close_flag=SET;
			lid2_up_switch_open_conform_time=0;
		}
	}
	if(!LID2_DWN_SWITCH)
	{
		if(lid2_dwn_switch_open_conform_time>5)
		{
			lid2_dwn_switch_close_flag=CLEAR;
			lid2_dwn_switch_close_conform_time=0;
		}
			
	}
	else
	{
		if(lid2_dwn_switch_close_conform_time>5)
		{
			lid2_dwn_switch_close_flag=SET;
			lid2_dwn_switch_open_conform_time=0;
		}
	}
	if(!LID2_FWD_SWITCH)
	{
		if(lid2_fwd_switch_open_conform_time>5)
		{
			lid2_fwd_switch_close_flag=CLEAR;
			lid2_fwd_switch_close_conform_time=0;
		}
			
	}
	else
	{
		if(lid2_fwd_switch_close_conform_time>5)
		{
			lid2_fwd_switch_close_flag=SET;
			lid2_fwd_switch_open_conform_time=0;
		}
	}
	if(!LID2_REV_SWITCH)
	{
		if(lid2_rev_switch_open_conform_time>5)
		{
			lid2_rev_switch_close_flag=CLEAR;
			lid2_rev_switch_close_conform_time=0;
		}
	}
	else
	{
		if(lid2_rev_switch_close_conform_time>5)
		{
			lid2_rev_switch_close_flag=SET;
			lid2_rev_switch_open_conform_time=0;
		}
	}
	
	
	if(!COOKER1_SWITCH)
	{
		if(cooker1_switch_open_conform_time>150)
		{
			cooker1_switch_close_flag=CLEAR;
			cooker1_switch_close_conform_time=0;
		}
	}
	else
	{
		if(cooker1_switch_close_conform_time>150)
		{
			cooker1_switch_close_flag=SET;
			cooker1_switch_open_conform_time=0;
		}
	}	
	if(!COOKER2_SWITCH)
	{
		if(cooker2_switch_open_conform_time>20)
		{
			cooker2_switch_close_flag=CLEAR;
			cooker2_switch_close_conform_time=0;
		}
	}
	else
	{
		if(cooker2_switch_close_conform_time>20)
		{
			cooker2_switch_close_flag=SET;
			cooker2_switch_open_conform_time=0;
		}
	}
//	if(COOKER3_SWITCH)		//now it used as the float sensor for the water tank
//	{ 
//		if(cooker3_switch_open_conform_time>20)
//		{
//			cooker3_switch_close_flag=CLEAR;
//			cooker3_switch_close_conform_time=0;
//		}
//	}
//	else
//	{
//		if(cooker3_switch_close_conform_time>20)
//		{
//			cooker3_switch_close_flag=SET;
//			cooker3_switch_open_conform_time=0;
//		}
//	}
	if(!KADAI_REV_SWITCH)
	{
		if(kadai_rev_switch_open_conform_time>5)
		{
			kadai_rev_switch_close_flag=CLEAR;
			kadai_rev_switch_close_conform_time=0;
		}			
	}
	else
	{
		if(kadai_rev_switch_close_conform_time>5)
		{
			kadai_rev_switch_close_flag=SET;
			kadai_rev_switch_open_conform_time=0;
		}
	}
	
	/*if(!KADAI_CCW_SWITCH)
	{
		if(kadai_ccw_switch_open_conform_time>5)
		{
			kadai_ccw_switch_close_flag=CLEAR;
			kadai_ccw_switch_close_conform_time=0;
		}
	}
	else
	{
		if(kadai_ccw_switch_close_conform_time>5)
		{
			kadai_ccw_switch_close_flag=SET;
			kadai_ccw_switch_open_conform_time=0;
		}
	}*/
	if(!KADAI_CW_SWITCH)
	{
		if(kadai_cw_switch_close_conform_time>5)
		{
			kadai_cw_switch_close_flag=CLEAR;
			kadai_cw_switch_close_conform_time=0;
		}			
	}
	else
	{
		if(kadai_cw_switch_close_conform_time>5)
		{
			kadai_cw_switch_close_flag=SET;
			kadai_cw_switch_close_conform_time=0;
		}
	}
}