/*
 * STRNG_DATA_TO_PROCESS_HEX_DATA.c

 *
 *  Created on: Dec 9, 2023
 *      Author: kl
 */
//#include <HEADER_FILE/UART_SEND_HEADER.H>
#include "Main_thread.h"
#include "bsp_api.h"
#include "../HEADER_FILE/Macros.H"
#include "string.h"
#include <stdio.h>
#include "stdlib.h"
#include "HEADER_FILE/EXTERN_FUN.H"



void str_to_process_buf_conversion();
unsigned char hex_code_conversion(char [],unsigned char ,char );

char *string_to_char[]={

            "    ",
            "IGM1",     /* 1 */
            "IGM2",     /* 2 */
            "IGM3",     /* 3 */
            "IGM4",     /* 4 */
            "IGM5",     /* 5 */
            "IGM6",     /* 6 */
            "IGM7",     /* 7 */
            "IGM8",     /* 8 */
            "IGM9",     /* 9 */
            "IGM10",    /* 10 */
            "IGM11",    /* 11 */
            "IGM12",    /* 12 */
            "IGM13",    /* 13 */
            "IGM14",    /* 14 */
            "IGM15",    /* 15 */
            "IGM16",    /* 16 */
            "IGM17",    /* 17 */
            "IGM18",    /* 18 */
            "IGM19",    /* 19 */
            "IGM20",    /* 20 */
            "IGM21",    /* 21 */
            "IGM22",    /* 22 */
            "IGM23",    /* 23 */

            "STRL",     /* 24 */
            "STRM",     /* 25 */
            "STRH",     /* 26 */

            "VTM",     /* 27*/

            "OPM",      /* 28*/

            "WPB",      /* 29 */

            "IDLE",     /* 30 */
            "CTIM",     /* 31 */
            "LOCK",     /* 32 */
            "KTM",      /* 33 */

            "LID1",     /* 34 */
            "LID2",     /* 35 */
            "LID3",     /* 36 */

            "VEG1",     /* 37 */
            "VEG2",     /* 38 */
            "VEG3",     /* 39 */

            "CKM1",     /* 40 */
            "CKM2",     /* 41 */
            "CKM3",     /* 42 */

            "K1FR",     /* 43 */
            "K2FR",     /* 44 */
            "K1CA",     /* 45 */
            "K2CA",     /* 46 */

            "CTFR",     /* 47 */
            "CTCA",     /* 48 */
            "TWPB",     /* 49 */

            };

void str_to_process_buf_conversion()
{
    char i,j,byte=0,pipe_symbol_came=0;
    long int val;
    unsigned char temp_string[10];


    memset(temp_string,0,sizeof(temp_string));
    memset(process_data_buf,0,sizeof(process_data_buf));
    for(i=0,j=0;i<strlen(string_process_data_buf);i++)
    {
        if(!frame_err_flag)
        {
            if(string_process_data_buf[i]!='|')
                temp_string[j++]= string_process_data_buf[i];
            else if(app_id==0x03)
            {
                pipe_symbol_came++;
                if(pipe_symbol_came==1)
                    init_step_count=atoi(temp_string);
                else if(pipe_symbol_came==2)
                {
                    if((temp_string[0]=='L')AND(temp_string[2]=='D'))
                        process_data_buf[byte]=hex_code_conversion(temp_string,LID1,LID3);
                    else if((temp_string[0]=='V')AND(temp_string[2]=='G'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,VEG1,VEG3);
                    else if((temp_string[0]=='C')AND(temp_string[2]=='M'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,CKM1,CKM3);
                    else if((temp_string[0]=='C')AND(temp_string[1]=='T'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,CTFR,CTCA);
                    else if((temp_string[0]=='K')AND(temp_string[2]=='F'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,K1FR,K2FR);

                    byte++;

                }
                j=0;
                memset(temp_string,0,sizeof(temp_string));

            }
            else if(app_id==0x09)
            {
                pipe_symbol_came++;
                if(pipe_symbol_came==1)
                    MIM_BOILER_TEMP=atoi(temp_string);

                else if(pipe_symbol_came==2)
                    MAX_BOILER_TEMP=atoi(temp_string);

                else if(pipe_symbol_came==3)
                    MIM_KADAI_1_TEMP=atoi(temp_string);

                else if(pipe_symbol_came==4)
                    MAX_KADAI_1_TEMP=atoi(temp_string);

                else if(pipe_symbol_came==5)
                    MIM_KADAI_2_TEMP=atoi(temp_string);


                j=0;
                memset(temp_string,0,sizeof(temp_string));

            }
            else if((app_id==0x04)OR(app_id==0X05))
            {
                if((app_id==0X04)AND(i<=5))
                {
                    pipe_symbol_came++;
                    pipe_symbol_came++;
                }
                pipe_symbol_came++;
                if(pipe_symbol_came==1)         //cooker no
                {
                    if(strcmp(temp_string,"C1")==0)
                    process_data_buf[byte]=1;
                    else if(strcmp(temp_string,"C2")==0)
                    process_data_buf[byte]=2;
                    else if(strcmp(temp_string,"C3")==0)
                    process_data_buf[byte]=3;

                    else
                    frame_err_flag=SET;
                }
                if(pipe_symbol_came==2)         //step count
                {
                    if((process_data_buf[0]==1)AND(!dish1_data_flag))
                    c1_step_count=atoi(temp_string);
                    if((process_data_buf[0]==2)AND(!dish2_data_flag))
                    c2_step_count=atoi(temp_string);
                    if((process_data_buf[0]==3)AND(!dish3_data_flag))
                    c3_step_count=atoi(temp_string);
                    byte--;
                }
                if(pipe_symbol_came==3)         //motor code
                {
                    if((temp_string[0]=='I')AND(temp_string[1]=='D'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,IDLE,IDLE);

                    else if((temp_string[0]=='L')AND(temp_string[1]=='O'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,LOCK,LOCK);

                    else if((temp_string[0]=='I')AND(temp_string[1]=='G')AND((temp_string[4]!='S')AND(temp_string[5]!='S')))
                    process_data_buf[byte]=hex_code_conversion(temp_string,IGM1,IGM23);

                    else if((temp_string[0]=='V')AND(temp_string[2]=='M'))
                    process_data_buf[byte]=hex_code_conversion(temp_string,VTM,VTM);

                    else if((temp_string[0]=='S')AND(temp_string[2]=='R'))
                    {
                        if(temp_string[3]=='L')
                            process_data_buf[byte]=hex_code_conversion(temp_string,STRL,STRL);

                        else if(temp_string[3]=='M')
                            process_data_buf[byte]=hex_code_conversion(temp_string,STRM,STRM);

                        else if(temp_string[3]=='H')
                            process_data_buf[byte]=hex_code_conversion(temp_string,STRH,STRH);

                        else
                            frame_err_flag=SET;

                    }
                    else if(temp_string[0]=='K')
                             process_data_buf[byte]=hex_code_conversion(temp_string,KTM,KTM);
                    else if(temp_string[0]=='C')
                        process_data_buf[byte]=hex_code_conversion(temp_string,CTIM,CTIM);

                    else if(temp_string[0]=='W')
                        process_data_buf[byte]=hex_code_conversion(temp_string,WPB,WPB);
                    else if(temp_string[0]=='O')
                       process_data_buf[byte]=hex_code_conversion(temp_string,OPM,OPM);
                    else if(temp_string[0]=='T')
                              process_data_buf[byte]=hex_code_conversion(temp_string,TWPB,TWPB);
                    else
                    frame_err_flag=SET;
                }
                if(pipe_symbol_came==4)         //direction
                {
                    if(strcmp(temp_string,"FWD")==0)
                        process_data_buf[byte]=1;

                    else if(strcmp(temp_string,"REV")==0)
                        process_data_buf[byte]=2;

                    else if(strcmp(temp_string,"NO")==0)    //no direction
                    process_data_buf[byte]=0;

                    else
                    frame_err_flag=SET;

                }
                if(pipe_symbol_came==5)                     //Time Unit
                {
                    if(strcmp(temp_string,"MS")==0)         //milli sec
                    process_data_buf[byte]=1;

                    else if(strcmp(temp_string,"P")==0)     //pulse
                    process_data_buf[byte]=1;

                    else if(strcmp(temp_string,"G")==0)     //grams
                    process_data_buf[byte]=1;

                    else if(strcmp(temp_string,"S")==0)     //secs
                    process_data_buf[byte]=2;

                    else if(strcmp(temp_string,"M")==0)     //mins
                        process_data_buf[byte]=3;

                    else if(strcmp(temp_string,"NO")==0)    //no time unit
                    process_data_buf[byte]=0;

                    else
                    frame_err_flag=SET;
                }
                byte++;
                j=0;
                memset(temp_string,0,sizeof(temp_string));
            }
        }
    }
    if(!frame_err_flag)
    {
        if(temp_string[0]!='B') //BOARD_ER Data
        {
            if(((temp_string[0]=='F')OR(temp_string[0]=='R')OR(temp_string[0]=='P'))AND(app_id==0x03))
            {
                if(strcmp(temp_string,"FWD")==0)
                    process_data_buf[byte++]=1;
                else if(strcmp(temp_string,"REV")==0)
                    process_data_buf[byte++]=2;
                else if(strcmp(temp_string,"POS1")==0)
                   process_data_buf[byte]=1;

                else if(strcmp(temp_string,"POS2")==0)
                    process_data_buf[byte]=2;

            }
            else if(temp_string[0]=='O')
            {
                if(strcmp(temp_string,"ON")==0)
                process_data_buf[byte]=1;
                else if(strcmp(temp_string,"OFF")==0)
                process_data_buf[byte]=0;
                else
                frame_err_flag=SET;
            }
            else if(app_id==0x09)
            {
                if(pipe_symbol_came==5)
                MAX_KADAI_2_TEMP=atoi(temp_string);
            }
            else
            {
                val=atol(temp_string);
                process_data_buf[byte++]=val>>16;
                process_data_buf[byte++]=val>>8;
                process_data_buf[byte]=val;
            }
        }
        else
        frame_err_flag=SET;
    }
    if(MIM_BOILER_TEMP==MAX_BOILER_TEMP)
    {
        MAX_BOILER_TEMP=30;
        MIM_BOILER_TEMP=28;
    }
    string_process_data_flag=SET;
}
unsigned char hex_code_conversion(char string_buf[],unsigned char index,char check_upto)     // MOTORCODE
{
        unsigned char byte;
        char *ptr,string_matched_flag;
        for(;index<check_upto+1;index++)
        {
            ptr=string_to_char[index];
            string_matched_flag=SET;
            for(byte=0;byte<strlen(string_buf);byte++)
            {
                if((*ptr++)!=string_buf[byte])
                {
                    string_matched_flag=CLR;
                    break;
                }
            }
            if(string_matched_flag)
                break;
        }
        if(!string_matched_flag)
        frame_err_flag=SET;
        return index;
}
