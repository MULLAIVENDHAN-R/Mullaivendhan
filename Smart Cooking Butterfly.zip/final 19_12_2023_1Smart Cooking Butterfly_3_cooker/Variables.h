 #include "GUI_Macros.h"

/******************************Water_Level & Heater********************/
__boolean
init_filling_flag,
init_heating_flag,
heater_on_off_flag,
water_pump_on_flag;
unsigned char
water_level_sensor_close_ctr,
water_level_sensor_open_ctr;
/******************************Water_Level & Heater********************/

/******************************ADC********************/
__boolean
adc_read_flag;
unsigned char
ctemp,
m,
t;
unsigned int

crnt_temp[5],
acc_temp[5],
ad_result;
/******************************ADC********************/

/******************************EEPROM********************************/
__boolean
sda_status_flag,
clock_low_flag,
ack_received_flag;
unsigned char
settings[5],
dflt_value,
tmp_var,
received_data,
receive_bit_counter,
*ram_addr,
temp_pr[3];
unsigned int
temp_delay,
disp_addr,
acc;
/******************************EEPROM********************************/

/*******************************************RTC**********************************************/
__boolean
time_update_flag;

char
receiveRTC[10],
read_rtc_buf[30],
write_rtc_buf[30];

/*******************************************RTC END**********************************************/


/******************************TIMER VAR********************/
__boolean
heart_beat_send_flag;

unsigned char
heart_beat_delay_cntr,
one_min_counter,
heart_beat_counter,
hundred_usec_sec_counter,
five_sec_counter;

unsigned int 
err_flow_pulse,
one_sec_counter,
one_milli_sec_counter,
fifty_milli_sec_counter;
/******************************TIMER VAR********************/


/**********************PROCESS DATA VARIABLES*****************/
__boolean

c1_lock_flag,
c2_lock_flag,
c3_lock_flag,

vegtray1_not_move_flag,
vegtray2_not_move_flag,
vegtray3_not_move_flag,
cooker_not_move_flag,

water_pump_used_flag,
cooker_set_flag,
ing_motor_used_flag,
lid1_vegtray1_used_flag,
lid2_vegtray2_used_flag,
lid3_vegtray3_used_flag,
restart_cooker_move_flag,
htr1_on_flag,
htr2_on_flag,
htr3_on_flag,
htr4_on_flag,
wtr_htr_on_flag,
dc_fan_on_flag,
eeprom_store_flag,
prep_pending_restart_flag,
independent_out_on_flag,
water_sol_on_flag,
lid_set_flag,
vegtray_set_flag,
c1_idle_flag,
c2_idle_flag,
c3_idle_flag,

c1_lock_release_flag,
c2_lock_release_flag,
c3_lock_release_flag,

veg_tray_position_ok_flag,
veg_tray1_flag,
veg_tray2_flag,
veg_tray3_flag,

lid_position_flag,
lid1_rev_flag,
lid1_up_flag,
lid2_rev_flag,
lid2_up_flag,
lid3_rev_flag,
lid3_up_flag,


kadai_home_position_ok_flag,
kadai_rev_on_flag,
kadai_cw_on_flag,

c1_free_flag,
c2_free_flag,
c3_free_flag,
c1_in_idle_condition_flag,
c2_in_idle_condition_flag,
c3_in_idle_condition_flag,
dish1_data_flag,
dish2_data_flag,
dish3_data_flag,
dish1_hold_flag,
dish2_hold_flag,
dish3_hold_flag,
dish1_step_complete_flag,
dish2_step_complete_flag,
dish3_step_complete_flag,
tray_pos_adj_data_flag,
tray_pos_rqt_acpt_flag,
lid_pos_rqt_acpt_flag,
lid_pos_adj_data_flag,
load_test_start_flag,
load_test_stop_flag,
initial_position_ok_flag,
flow_pulse_flag,
flow_meter_failure_flag,
process1_stop_flag,
process2_stop_flag,
process3_stop_flag,

c1_preparation_not_ok_flag,
c2_preparation_not_ok_flag,
c3_preparation_not_ok_flag,

vegtray1_switch_close_flag,
vegtray2_switch_close_flag,
vegtray3_switch_close_flag,
lid_up_switch_close_flag,
lid_dwn_switch_close_flag,
lid_fwd_switch_close_flag,
lid_rev_switch_close_flag,

lid1_up_switch_close_flag,
lid1_dwn_switch_close_flag,
lid1_fwd_switch_close_flag,
lid1_rev_switch_close_flag,

lid2_up_switch_close_flag,
lid2_dwn_switch_close_flag,
lid2_fwd_switch_close_flag,
lid2_rev_switch_close_flag,



cooker1_switch_close_flag,
cooker2_switch_close_flag,
cooker3_switch_close_flag,
dish1_preparation_start_flag,
dish2_preparation_start_flag,
dish3_preparation_start_flag,



kadai_fwd_switch_close_flag,
kadai_rev_switch_close_flag,
kadai_cw_switch_close_flag,
kadai_ccw_switch_close_flag;

unsigned char
cooker1_start_delay,
cooker2_start_delay,
cooker3_start_delay,
gram_test_motor_id,
cooker_switch_failure_counter,
cooker_no,
stop_motor_id,
motor_id,
motor_code,
motor_code1,
motor_code2,
motor_code3,
ing_motor_code,
dish1_outputs_on,
dish2_outputs_on,
dish3_outputs_on,
direction,
time_unit,
action_based,
load_test_buf[FIXED_DATA_LENGTH],
cooker1_buf[FIXED_DATA_LENGTH],
cooker2_buf[FIXED_DATA_LENGTH],
cooker3_buf[FIXED_DATA_LENGTH],
cooker1_holding_backbuf[FIXED_DATA_LENGTH],
cooker2_holding_backbuf[FIXED_DATA_LENGTH],
cooker3_holding_backbuf[FIXED_DATA_LENGTH],
vegtray1_switch_open_conform_time,
vegtray1_switch_close_conform_time,
vegtray2_switch_open_conform_time,
vegtray2_switch_close_conform_time,
vegtray3_switch_open_conform_time,
vegtray3_switch_close_conform_time,
lid_up_switch_open_conform_time,
lid_up_switch_close_conform_time,
lid_dwn_switch_open_conform_time,
lid_dwn_switch_close_conform_time,
lid_fwd_switch_open_conform_time,
lid_fwd_switch_close_conform_time,
lid_rev_switch_open_conform_time,
lid_rev_switch_close_conform_time,


lid1_up_switch_open_conform_time,
lid1_up_switch_close_conform_time,
lid1_dwn_switch_open_conform_time,
lid1_dwn_switch_close_conform_time,
lid1_fwd_switch_open_conform_time,
lid1_fwd_switch_close_conform_time,
lid1_rev_switch_open_conform_time,
lid1_rev_switch_close_conform_time,


lid2_up_switch_open_conform_time,
lid2_up_switch_close_conform_time,
lid2_dwn_switch_open_conform_time,
lid2_dwn_switch_close_conform_time,
lid2_fwd_switch_open_conform_time,
lid2_fwd_switch_close_conform_time,
lid2_rev_switch_open_conform_time,
lid2_rev_switch_close_conform_time,







cooker1_switch_open_conform_time,
cooker1_switch_close_conform_time,
cooker2_switch_open_conform_time,
cooker2_switch_close_conform_time,
cooker3_switch_open_conform_time,
cooker3_switch_close_conform_time,


kadai_fwd_switch_open_conform_time,
kadai_fwd_switch_close_conform_time,
kadai_rev_switch_open_conform_time,
kadai_rev_switch_close_conform_time,
kadai_ccw_switch_open_conform_time,
kadai_ccw_switch_close_conform_time,
kadai_cw_switch_close_conform_time,
kadai_cw_switch_open_conform_time;



unsigned int 
c1_step_count,
c2_step_count,
c3_step_count,
current_send_step_count,
multiply_with,
temp_water_pump_time,
flow_err_time;


unsigned long int 
motor_on_off_delay,
allLid_initSetTime,
output_on_time,
ing_motor_time,
cooker_mtr_time,
str1_mtr_time,
str2_mtr_time,
str3_mtr_time,
vegtray1_time,
vegtray2_time,
vegtray3_time,
lid_fwd_rev_time,
lid_up_dwn_time,
lid1_fwd_rev_time,
lid1_up_dwn_time,
lid2_fwd_rev_time,
lid2_up_dwn_time,
temp_oil_pump_time,
temp_htr1_time,
temp_htr2_time,
temp_htr3_time,
temp_htr4_time,
c1_idle_time,
c2_idle_time,
c3_idle_time,
idle_lock_time,
temp_wat_htr_time,
temp_fan_time,
kadai_fwd_rev_time,
kadai_cc_ccw_time,
kadai_fwd_on_time;


/****************EEPROM STORE VARIABLES******************/

__boolean
htr1_eeprom_store_flag,
htr2_eeprom_store_flag,
htr3_eeprom_store_flag,
htr4_eeprom_store_flag,
water_htr_eeprom_store_flag,
dc_fan_eeprom_store_flag,
c1_idle_eeprom_store_flag,
c2_idle_eeprom_store_flag,
c3_idle_eeprom_store_flag,
cooker_model_eeprom_store_flag;

/****************EEPROM STORE VARIABLES******************/

/*********************SEND UART***************************/
unsigned char
tx_data,
temp_send_buf[MAX_SIZE_RX_BUF];

unsigned int
delay;

__boolean
ktm2_ccw_not_move_flag,
ktm1_fwd_not_move_flag,
lid_position_flag,
testing_flag,
kadai_used_flag,
c1_lock_eeprom_store_flag,
c2_lock_eeprom_store_flag,
c3_lock_eeprom_store_flag,
buzzer_flag;
/*********************BUZZER***************************/

unsigned int	
testing_delay,
buzzer_delay;
unsigned char
flag,
first_in_first_complete[3],
outputs;
