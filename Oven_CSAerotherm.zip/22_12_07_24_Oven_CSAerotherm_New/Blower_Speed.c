#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "string.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

void blower_motor_pwm_period(char);

void blower_speed_variation()
{
	blower_pulse_counter++;
	if(blower_motor_speed>0)
	{		
		if(blower_pulse_counter <= BLOWER_ON_TIME)
		{
			if(!blower_pulse_on_flag)
			{
				blower_pulse_on_flag = SET;
				//BLOWER_OP_PWM=1;
				
			}
		}
		else
		{
			if(blower_pulse_counter<BLOWER_ON_TIME+BLOWER_OFF_TIME)
			{
				if(blower_pulse_on_flag)
				{
					blower_pulse_on_flag = CLEAR;					
					//BLOWER_OP_PWM=0;
					
				}
			}
			else
			blower_pulse_counter = 0;
		}
	}
	else
	{
		blower_pulse_counter = 0;
		blower_pulse_on_flag=CLEAR;
		//BLOWER_OP_PWM=0;		
	}	
	blower_motor_pwm_period(blower_motor_speed);
}
void blower_motor_pwm_period(char blower_motor_speed)		//10khz PWM
{
	if(blower_motor_speed)
	{
		switch(blower_motor_speed)
		{
			case(1):
					BLOWER_ON_TIME = 2;
					BLOWER_OFF_TIME = 18;					
					break;
			case(2):
					BLOWER_ON_TIME = 4;
					BLOWER_OFF_TIME = 16;
					break;
			case(3):
					BLOWER_ON_TIME = 6;
					BLOWER_OFF_TIME = 14;						
					break;
			case(4):
					BLOWER_ON_TIME = 8;
					BLOWER_OFF_TIME = 12;						
					break;
			case(5):
					BLOWER_ON_TIME = 10;
					BLOWER_OFF_TIME = 10;						
					break;
			case(6):
					BLOWER_ON_TIME = 12;
					BLOWER_OFF_TIME = 8;						
					break;
			case(7):
					BLOWER_ON_TIME = 14;
					BLOWER_OFF_TIME = 6;						
					break;
			case(8):
					BLOWER_ON_TIME = 16;
					BLOWER_OFF_TIME = 4;					
					break;
			case(9):
					BLOWER_ON_TIME = 18;
					BLOWER_OFF_TIME = 2;						
					break;
			case(10):
					BLOWER_ON_TIME = 20;
					BLOWER_OFF_TIME =0;						
					break;	
			default:
					break;															
					
		}
	}	
}