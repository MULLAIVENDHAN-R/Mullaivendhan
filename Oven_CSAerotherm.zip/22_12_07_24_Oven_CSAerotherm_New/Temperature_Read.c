#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "string.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include "math.h"
#include <stdio.h>

extern void form_send_buf(char,char);
extern void err_occured();
 //int sample,acc_temp[4],temp_average,temp_ctemp;
float fuelLevel,module;
void temp_sense()
{

	static int sample,acc_temp[4],temp_average,temp_ctemp;				
	acc_temp[sample] = adc_result;	
	sample++;
	if(sample>3)
	{
		sample=0;	
		temp_average = ((acc_temp[0]+acc_temp[1]+acc_temp[2]+acc_temp[3])/4);
		temp_ctemp=(temp_average/2); //1.967
		if(ctemp!=temp_ctemp)
		{
			//temp_ctemp=ctemp;
			ctemp=temp_ctemp;//=42;
			//ctemp=ctemp-30;
			temp_changed_flag=SET;
		}			
	}
}
void temp_update_to_display()
{
	unsigned char ctemp_buf[20],j, fuel_buf[20];
	char str1[20];
	send_every_one_sec_flag=CLEAR;
	sprintf(ctemp_buf,"%d",ctemp);
	for(j=0;j<strlen(ctemp_buf);tx_data++,j++)
	temp_send_buf[tx_data]=ctemp_buf[j];
	temp_send_buf[tx_data++]='|';
	sprintf(fuel_buf,"%d",fuel_tank_capacity);
	for(j=0;j<strlen(fuel_buf);tx_data++,j++)
	temp_send_buf[tx_data]=fuel_buf[j];
	if(bake_start_flag)
	TEMP_SEND_APPID_FUNID;
	form_send_buf(DATA_RES,tx_data);
	tx_data=0;
	
	
//	sprintf(ctemp_buf,"%d",ctemp);
//	for(j=0;j<strlen(ctemp_buf);tx_data++,j++)
//	temp_send_buf[tx_data]=ctemp_buf[j];
//	if(bake_start_flag)
//	TEMP_SEND_APPID_FUNID;
//	form_send_buf(DATA_RES,tx_data);
//	tx_data=0;
	
}
void fuel_tank()
{
	static int sample_1,fuel_temp[4],fuel_average,temp_fuel;	

	fuel_temp[sample_1] = fuel_adc_result;	
	sample_1++;
	if(sample_1>3)
	{
		sample_1=0;	
		if(module<=5.0)
		fuel_average=(unsigned int)fuel_average;
		else
		fuel_average=(unsigned int)fuel_average+1;
		fuel_average = ((fuel_temp[0]+fuel_temp[1]+fuel_temp[2]+fuel_temp[3])/4);
		module= fmod(fuel_average,11.377); /// 5.688  180 L  ///11.377

		fuelLevel=(float)(fuel_average/11.377);// 11.377  10.37	
		temp_fuel=(unsigned int)fuelLevel;
		if(fuel_tank_capacity!=temp_fuel)
		{
			fuel_tank_capacity=temp_fuel+8;
			fuel_changed_flag=SET;
		}
	}
}
