#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include "string.h"
#include "X_variables.h"


extern void frame_send_data(char ,char ,char ,char);
extern void Input_output_status();
extern void check_door_status();
extern void get_process_steps_values(unsigned char );
extern void output_status();
extern void Input_status();
extern void output_testmode();

extern unsigned int live_status_counter;

void uart_process_data(  char data[],unsigned char received_app_id, unsigned char received_fun_id)
{
		switch(received_app_id)
		{
			 case HANDSHAKE_APP_ID:
			 			switch(received_fun_id)
						{
							case HANDSHAKE_ACK_FUN_ID:
										if(strcmp(data,"HANDSHAKE")==0)
										{
											
											frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);	
											handshake_ok_flag=SET;
											frame_send_data(COMMAND_RES,H_S_VERSION,HANDSHAKE_APP_ID,VERSION_ACK_FUN_ID); 
										}
							break;							
							case VERSION_ACK_FUN_ID:
										if(strcmp( data,"ACK")==0)
										{
											resend_flag=CLEAR;
											resend_count=0;								
											machine_ready_delay=5; 		// after 5 sec  send machine ready data
                                                                                }										
							break;		 			
						}
						break;
			 
			 case MACHINE_READY_APP_ID:
		 				if(received_fun_id==MACHINE_ACK_FUN_ID)
						{
							if(strcmp( data,"ACK")==0)
							{								
								machine_ready_ok_flag=SET;
								resend_count=0;
								resend_flag=CLEAR;
							}								
						}			 
					 	break;
			 
			 case HEART_BEAT_APP_ID:
			 			if(received_fun_id==HEART_BEAT_ACK_FUN_ID)
						{
							if(strcmp( data,"ACK")==0)
							{
								resend_count=0;
								resend_flag=CLEAR;
							}
						}			 
						break;			 
			 case ST_ENTER_EXIT_APP_ID:
			 			if(received_fun_id==ST_ENTER_ACK_FUN_ID)
						{
							if(strcmp(data,"ENTER")==0)
							frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
						}
						else if(received_fun_id==ST_EXIT_ACK_FUN_ID)
						{
							if(strcmp(data,"EXIT")==0)
							frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
						}			 
			 			break;			 
			 case SETTING_APP_ID:  
			 			if(received_fun_id==FACTOR_SETTING_ACK_FUN_ID)
						{
							frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
						}			 
			 			break;						
			 case OUTPUT_APP_ID:	
						if(received_fun_id==OUTPUT_IO_STATUS_ACK_FUN_ID)
						{	
							if(strcmp(data,"IO_STATUS")==0)	
							{
								output_status_flag=SET;
								output_status();
							}
						}			 			
						else if(received_fun_id==OUTPUT_ON_OFF_ACK_FUN_ID)							
						{	
							frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
							output_testmode();							
						}												
			 			break;
			 
			 case INPUT_APP_ID:
			 
					switch(received_fun_id)
					{ 
						 case  INPUT_ENTER_ACK_FUN_ID :									 						
							if(strcmp(data,"ENTER")==0)
							{
							 	frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
								input_status_flag=SET;
								input_status_count=4;
								Input_status();
							}
						 break;						 
						 case  INPUT_DATA_ACK_FUN_ID :						 
							if(strcmp( data,"ACK")==0)
							{
								resend_count=0;
								resend_flag=CLEAR;
							}					 
						 break;
						 
						 case  INPUT_EXIT_ACK_FUN_ID :
							if(strcmp( data,"EXIT")==0)
							{
								input_status_flag=CLEAR;
								input_status_count=0;
								frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
							}
						 break;						 
					}			 
			 		break;
			 
			 case LIVE_APP_ID:
					switch(received_fun_id)
					{ 
						 case  LIVE_ENTER_ACK_FUN_ID :
									if(strcmp(data,"ENTER")==0)
									{
							 			frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);	
										live_enter_ok_flag=SET;
									}									
									break;
						 
						 case  LIVE_OUT_DATA_FUN_ID :
						 			if(strcmp( data,"ACK")==0)
									{
										resend_count=0;
										resend_flag=CLEAR;
									}
						 			break;
						 
						 case  LIVE_IN_DATA_FUN_ID :
									if(strcmp( data,"ACK")==0)
									{
										resend_count=0;
										resend_flag=CLEAR;
									}
									break;
						 
						 case  LIVE_EXIT_ACK_FUN_ID :
						 			if(strcmp( data,"EXIT")==0)
									{
										 frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
										 live_enter_ok_flag=CLEAR;
										 output_status_flag=CLEAR;
										 input_status_flag=CLEAR;
										 live_status_counter=CLEAR;
									}						
						 			break;						 
					}			 
			 		break;
			 
			 case ERROR_APP_ID:
			 			if(received_fun_id==WARNING_DATA_ACK_FUN_ID)
						{
							if(strcmp( data,"ACK")==0)
							{								
								resend_count=0;
								resend_flag=CLEAR;
							}
														
						}
						else if(received_fun_id==ERROR_DATA_ACK_FUN_ID)
						{
							if(strcmp( data,"ACK")==0)
							{								
								resend_count=0;
								resend_flag=CLEAR;
							}
						}
				 		break;
			 
			 case PROCESS_DATA_APP_ID:
			 			switch(received_fun_id)						
						{
							case PROCESS_INIT_FUN_ID:
										if(strcmp( data,"INIT")==0)
										{
											frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);						
											Door_status_flag=SET;
											check_door_status();
										}
										break;							
							case DOOR_ACK_FUN_ID:
										if(strcmp( data,"ACK")==0)
										{
											resend_flag=CLEAR;
											resend_count=0;
										}										
										break;
							
							case START_ACK_FUN_ID:
										if(strcmp( data,"ACK")==0)
										{																						
											resend_flag=CLEAR;
											resend_count=0;
											get_process_steps_values(0);
											process_start_flag=SET;
										}
										break;
							
							case DATA_ACK_FUN_ID:
										{
											frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
											first_time_load_flag=CLEAR;										
											frame_send_data(COMMAND_RES,START,PROCESS_DATA_APP_ID,START_ACK_FUN_ID);											
										}
										break;
							
							case STOP_ACK_FUN_ID:
										if(strcmp( data,"STOP")==0)
										{
											STOP_PROCESS;													
											frame_send_data(COMMAND_RES,COMPLETE,PROCESS_DATA_APP_ID,COMPLETE_ACK_FUN_ID);
										}
										break;
							
							case PAUSE_ACK_FUN_ID:
										if(strcmp( data,"PAUSE")==0)
										{											
											PAUSE_PROCESS;
											frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
										}
										break;
							
							case RESUME_ACK_FUN_ID:
										if(strcmp( data,"RESUME")==0)
										{											
											RESUME_PROCESS;
											frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
										}
										break;
							
							case RESET_ACK_FUN_ID:
										if(strcmp( data,"RESET")==0)
										{
											RESET_PROCESS;
											frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
										}
										break;
							
							case COMPLETE_ACK_FUN_ID:							
										if(strcmp( data,"COMPLETE")==0)
										frame_send_data(COMMAND_RES,ACK_DATA,received_app_id,received_fun_id);
										break;
							case STEP_NO_ACK_FUN_ID:
										if(strcmp( data,"ACK")==0)
										{
											resend_flag=CLEAR;
											resend_count=0;
										}
										break;
							case STEP_COMPLETE_FUN_ID:
										if(strcmp( data,"ACK")==0)
										{
											resend_flag=CLEAR;
											resend_count=0;
										}
										break;			
							
							case TEMPERATURE_ACK_FUN_ID:
											if(strcmp( data,"ACK")==0)
											{
												resend_flag=CLEAR;
												resend_count=0;
											}										
											break;							
						}			 
			 			break;
			 
			 case INFROMATION_APP_ID:
			 			if(received_fun_id==IN_ENTER_ACK_FUN_ID)
						{
							if(strcmp( data,"ACK")==0)																					
							resend_flag=CLEAR;

							else										
							resend_flag=SET;
						}
						else if(received_fun_id==IN_REMOVE_ACK_FUN_ID)
						{
							if(strcmp( data,"ACK")==0)																					
							resend_flag=CLEAR;

							else										
							resend_flag=SET;							
						}
						break;
		}
		memset (data ,0, sizeof(data));
		
}