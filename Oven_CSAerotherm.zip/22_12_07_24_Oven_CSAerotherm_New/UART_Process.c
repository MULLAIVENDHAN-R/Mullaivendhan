#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"



extern __boolean is_valid_data(unsigned char received_buf[],char);
extern void form_send_buf(char,char);
extern void err_resend_fun();
extern void gui_uart_send();
extern void io_status_fun();
extern void temp_update_to_display();
extern void manual_operate_ops();
extern void io_on_off_check();
void rtc_data_splitup();
static unsigned int current_baking_time,remaining_time; 

void process_buf_splitup()
{
	received_app_id=app_id;
	received_fun_id=fun_id;
	if((!resend_flag)AND(!frame_err_flag))
	{
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==HANDSHAKE_RES_FUN_ID))
		{
			frame_err_flag=(process_data_buf[DATA]=='D')?is_valid_data(process_data_buf,DISPLAY_READY_DATA):1;
			if(!frame_err_flag)
			{
				handshake_ok_flag=SET;
				form_send_buf(COMMAND_RES,HANDSHAKE_DATA);
				time_update_flag=SET;
			}
		}
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==HEART_BEAT_FUN_ID))
		{
			frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
			if(!frame_err_flag)
			{
				ack_ok_flag=SET;
				waiting_for_ack_flag=CLEAR;
				uart_driver_reset_flag=CLEAR,resend_cnt=0;
			}			
		}
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==RTC_SEND_ACK_FUNID))
		{
			frame_err_flag=is_valid_data(process_data_buf,ACK_DATA);
			if(!frame_err_flag)
			{
				waiting_for_ack_flag=CLEAR;
				resend_cnt=0;
				ack_ok_flag=SET;
				uart_driver_reset_flag=CLEAR;
			}
		}
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==RTC_RECEIVE_FUNID))
		{
			rtc_data_splitup();
			form_send_buf(COMMAND_RES,ACK_DATA);	
		}
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==RTC_ONE_HOUR_ACK_FUNID))
		{
			frame_err_flag=is_valid_data(process_data_buf,ACK_DATA);
			if(!frame_err_flag)
			{
				waiting_for_ack_flag=CLEAR;
				resend_cnt=0;
				ack_ok_flag=SET;
				uart_driver_reset_flag=CLEAR;
			}
		}
	}
	if((!resend_flag)AND(handshake_ok_flag)AND(!frame_err_flag))
	{
		switch(received_app_id)
		{
			case BAKING_TIME_APP_ID:
							switch(received_fun_id)
							{
								case PROCESS_START_FUN_ID:
											if(process_data_buf[DATA]=='S')
											{
												frame_err_flag=(process_data_buf[DATA]=='S')?is_valid_data(process_data_buf,START_DATA):1;
												if(!frame_err_flag)
												{	
													DOOR_STATUS_APPID_FUNID;
													if(!door_switch_close_flag)
													form_send_buf(COMMAND_RES,CLOSE_DATA);
													else
													form_send_buf(COMMAND_RES,OPEN_DATA);											
													err_occured_flag=CLEAR;
												}
											}
											else if(process_data_buf[DATA]=='A')
											{
												frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
												if(!frame_err_flag)
												{
													ack_ok_flag=SET;
													waiting_for_ack_flag=CLEAR;
													uart_driver_reset_flag=CLEAR,resend_cnt=0;
												}
											}
											else
											frame_err_flag=SET;
											break;
								case PROCESS_DATA_FUN_ID:
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(step_no==0)
											{
												if(!bake_start_flag)
												{
													bake_start_flag=SET;
													step_no=TURN_TABLE_ON;
													current_baking_time=baking_time;
													temp_baking_time=(unsigned long)(baking_time)*1000;												
													temp_steam_time=(unsigned long)(steam_time)*1000;
												}
											}
											else
											{
												bake_start_flag=SET;
												current_baking_time=baking_time;
												temp_baking_time=(unsigned long)(baking_time)*1000;
											}
											break;
								case DATA_ACK_FUN_ID	:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;								
								case PROCESS_STOP_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='S')?is_valid_data(process_data_buf,STOP_DATA):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);												
												temp_baking_time=temp_steam_time=0;
												bake_stop_flag=SET;
											}
											break;
								case TEMP_REQ_FUN_ID	:
											frame_err_flag=(process_data_buf[DATA]=='T')?is_valid_data(process_data_buf,TEMP_DATA):1;
											if(!frame_err_flag)
											temp_update_to_display();
											break;
								case DONE_ACK_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
								case UPDATE_DATA_FUN_ID:
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(!door_switch_close_flag)
											{
												if(!bake_start_flag)
												{
													err_occured_flag=CLEAR;
													DOOR_STATUS_APPID_FUNID;
													form_send_buf(COMMAND_RES,CLOSE_DATA);													
													bake_start_flag=SET;													
													current_baking_time=baking_time;
													temp_baking_time=(unsigned long)(baking_time)*1000;
													step_no=TURN_TABLE_ON; // NEW
												}
												else
												{
													if(temp_baking_time>0)
													{
														if(baking_time!=current_baking_time)
														{														
															if(baking_time>current_baking_time)
															{
																remaining_time=baking_time-current_baking_time;
																temp_baking_time+=(unsigned long)(remaining_time)*1000;
															}												
															else
															{
																remaining_time=current_baking_time-baking_time;
																temp_baking_time-=(unsigned long)(remaining_time)*1000;													
															}
														}
													}
													else
													temp_baking_time+=(unsigned long)(baking_time)*1000;												
													current_baking_time=baking_time;
												}
											}
											else
											{
												DOOR_STATUS_APPID_FUNID;
												form_send_buf(COMMAND_RES,OPEN_DATA);												
											}
											break;
								case PROCESS_COMPLETE_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='C')?is_valid_data(process_data_buf,COMPLETE_DATA):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);												
												BUZZER_OP_OFF;
												BUZZER_OFF;
												
											}
											break;
								case ERR_AT_PROCESS_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
								case POPUP_CLOSED_ACK_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;			
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
												err_popup_closed_flag=SET;
											}
											break;
								case POPUP_CLOSED_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='E')?is_valid_data(process_data_buf,ERR_CLOSED_DATA):1;
											if(!frame_err_flag)
											{
												BUZZER_OFF;
												BUZZER_OP_OFF;											
												form_send_buf(COMMAND_RES,ACK_DATA);
												err_popup_closed_flag=SET;
											}
											break;
								case RESUME_PROCESS_FUN_ID:
											step_no=TEMP_MAINTAINING;
											EXHAUST_FAN_OP_OFF;
											IND_LIGHT_OP_ON;
											bake_start_flag=SET;
											current_baking_time=baking_time;
											temp_baking_time=(unsigned long)(temp_baking_time)*1000;
											
											form_send_buf(COMMAND_RES,ACK_DATA);		//ack for new resume data after power came
											received_app_id=0X02;
											received_fun_id=0X02;
											form_send_buf(COMMAND_RES,ACK_DATA);		//ack for old process data before power off
											break;
							}
							break;
			case SETTINGS_APP_ID	:
							switch(received_fun_id)
							{
								case IO_STATUS_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='I')?is_valid_data(process_data_buf,IO_STATUS_DATA):1;
											if(!frame_err_flag)
											io_status_fun();
											break;
								case IO_CHECK_FUN_ID:	
											form_send_buf(COMMAND_RES,ACK_DATA);
											outputs=process_data_buf[DATA];
											status=process_data_buf[DATA+1];
											io_manual_check_flag=SET;											
											break;
							}
							break;
			case ERROR_APP_ID:
							switch(received_fun_id)
							{
								case ERR_AT_IDLE_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
							}
							break;
			case MESSAGE_POPUP_APP_ID:
							switch(received_fun_id)
							{
								 case EMER_POPUP_ACK_FUN_ID:
								 			frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
								 case ALERT_POPUP_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ALERT_POPUP_MSG):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);												
												BUZZER_OP_ON;
												BUZZER_ON;												
											}
											break;
							}
							break;
			case IOT_SEND_DATA_APP_ID:
							if(IOT_SEND_DATA_FUN_ID==received_fun_id)
							{
								frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
								if(!frame_err_flag)
								{
									ack_ok_flag=SET;
									waiting_for_ack_flag=CLEAR;
									uart_driver_reset_flag=CLEAR,resend_cnt=0;
								}
							}
							break;
			case SCREEN_FRZ_DATA_APP_ID:
						frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
						if(!frame_err_flag)
						{
							ack_ok_flag=SET;
							waiting_for_ack_flag=CLEAR;
							uart_driver_reset_flag=CLEAR,resend_cnt=0;
						}		
		break;
		}
	}	
	if(frame_err_flag)
	{
		resend_flag=SET;
		waiting_for_ack_flag=SET,resend_cnt=0;
		frame_err_flag=CLEAR;
	}
	app_id=fun_id=0;
	ack_ok_flag=CLEAR;
}
void rtc_data_splitup()
{
	char index,i,j;
	memset(temp_string,0,sizeof(temp_string));
	for(index=0,i=0,j=0;index<strlen(process_data_buf);index++)
	{
		if(process_data_buf[index]=='|')
		{
			receiveRTC[++j]=strtol(temp_string,NULL,16);			
			if(j==3)
			{
				year = strtol(temp_string,NULL,16) >> 8;
				eeprom_store_flag=SET;
			}
			memset(temp_string,0,sizeof(temp_string));
			i=0;
		}
		else
		{
			temp_string[i++]=process_data_buf[index];
		}
	}
	receiveRTC[++j]=strtol(temp_string,NULL,16);
	receiveRTC[0] =	0;
	timeDate_save_flag=SET;
	time_update_flag=SET;
}