/*
 * Receipe_preparation.c
 *
 *  Created on: Dec 9, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/PROCESS_HEADER.H"
#include "HEADER_FILE/IO.H"
#include "stdlib.h"
#include "HEADER_FILE/EXTERN_FUN.H"

void dish1_prep_process();
void dish2_prep_process();
void dish3_prep_process();
void stop_preparation();
void all_outputs_on_off_fun(char,unsigned char,unsigned char);
void is_step_complete(char );
void dishes_complete();
void sensor_gets_failure(char code);
void check_idle_condition();
void all_outputs_off_fun();

void cooker_A__outputs(unsigned char);
void cooker_B__outputs(unsigned char);
void cooker_C__outputs(unsigned char);

void restart_process();

void All_ing_motors(char op_ON_OFF,unsigned code);
_Bool C1_kadai_1_already_used_flag,C2_kadai_1_already_used_flag,restart_ok_flag;
unsigned char restart_step,stop_1_step,stop_2_step,stop_3_step,str1_delay,str2_delay,str3_delay,ing_temp_delay;
static unsigned char process_data_1=0,process_data_2=0,process_data_3=0;
extern _Bool vibration_fwd_flag,vibration_rev_flag, kadai_1_tilting_flag, kadai_2_tilting_flag, load_test_start_flag,load_test_stop_flag;
extern  unsigned char cooker_A_steps,cooker_B_steps,cooker_C_steps,vibration_count;


void dish1_prep_process()
{
    if((restart_ok_flag)AND(!dish1_preparation_start_flag))
    {
        dish1_preparation_start_flag=SET;
        if(cooker_1_kadai_using_flag)
            HEATER_4_ON;
        cooker1_cooking_process_start_flag=SET;
    }
    if((dish1_data_flag)AND(!process1_stop_flag)AND(dish1_preparation_start_flag))
    {
        process_data_1=0;
        motor_code1=cooker1_buf[process_data_1+1];
        if((COOKER_1_OK)AND(!C2_kadai_1_already_used_flag))
        {
            cooker_no=cooker1_buf[process_data_1];
            dish1_outputs_on=motor_code1=cooker1_buf[++process_data_1];
            C1_direction=cooker1_buf[++process_data_1];
            time_unit=cooker1_buf[++process_data_1];
            if(time_unit==1)
            multiply_with=1;
            else if(time_unit==2)
            multiply_with=MILLI_SECONDS;
            else if(time_unit==3)
            multiply_with=SECONDS*MILLI_SECONDS;
            else
            multiply_with=0;
            output_on_time=cooker1_buf[++process_data_1];
            output_on_time=((output_on_time<<8)|cooker1_buf[++process_data_1]);
            output_on_time=((output_on_time<<8)|cooker1_buf[++process_data_1]);
            output_on_time=multiply_with*output_on_time;
            process_data_1=0;
            HEATER_1_ON;
            if(dish1_hold_flag)
            {
               // if((!cooker_1_kadai_using_flag)AND(!cooker_2_kadai_using_flag))
                {
                    first_in_first_complete[0]=first_in_first_complete[1];
                    first_in_first_complete[1]=first_in_first_complete[2];
                }
                outputs--;
                dish1_hold_flag=CLR;
            }
            if((cooker_1_kadai_using_flag)AND(((motor_code1>=IGM1)AND(motor_code1<=IGM22))OR(motor_code1==VTM)OR(motor_code1==OPM)))
            {
                    if(motor_code1==OPM)
                        oil_pump_1_on_time=output_on_time;

                    else if((motor_code1>=IGM1)AND(motor_code1<=IGM22))
                    {
                        ing_motor_used_flag=SET;
                        cooker_1_ing_motor_used_flag=SET;
                        dish1_outputs_on=ing_motor_code=ALL_ING_MOTORS;
                        ing_motor_time=output_on_time;
                    }
                    kadai_1_process_flag=SET;
            }
            else if((motor_code1>=IGM1)AND(motor_code1<=IGM22)AND(!cooker_1_kadai_using_flag))
            {
                ing_motor_used_flag=SET;
                cooker_1_ing_motor_used_flag=SET;
                dish1_outputs_on=ing_motor_code=ALL_ING_MOTORS;
                ing_motor_time=output_on_time;
                collecting_tray_set_position(motor_code1);
            }
            else
            cooker_A__outputs(motor_code1);
            output_on_time=0;
        }
        else if((!dish1_hold_flag)AND(!c1_lock_flag))
        {
            if((motor_code1==KTM)AND(cooker_2_kadai_using_flag))
            {
                C2_kadai_1_already_used_flag=SET;
                HEATER_1_OFF;
                memcpy(cooker1_holding_backbuf,cooker1_buf,sizeof(cooker1_buf));  // new update
            }
            else
            {
                dish1_hold_flag=SET;
                HEATER_1_OFF;
                first_in_first_complete[outputs++]=cooker1_buf[process_data_1];
                memcpy(cooker1_holding_backbuf,cooker1_buf,sizeof(cooker1_buf));  // new update
            }
        }
    }
}
void dish2_prep_process()
{
    if((restart_ok_flag)AND(!dish2_preparation_start_flag))
    {
        dish2_preparation_start_flag=SET;
        if(cooker_2_kadai_using_flag)
            HEATER_4_ON;
        cooker2_cooking_process_start_flag=SET;
    }
    if((dish2_data_flag)AND(!process2_stop_flag)AND(dish2_preparation_start_flag))
    {
        process_data_2=0;
        motor_code2=cooker2_buf[process_data_2+1];
        if((COOKER_2_OK)AND(!C1_kadai_1_already_used_flag))
        {
            cooker_no=cooker2_buf[process_data_2];
            dish2_outputs_on=motor_code2=cooker2_buf[++process_data_2];
            C2_direction=cooker2_buf[++process_data_2];
            time_unit=cooker2_buf[++process_data_2];
            if(time_unit==1)
            multiply_with=1;
            else if(time_unit==2)
            multiply_with=MILLI_SECONDS;
            else if(time_unit==3)
            multiply_with=SECONDS*MILLI_SECONDS;
            else
            multiply_with=0;
            output_on_time=cooker2_buf[++process_data_2];
            output_on_time=((output_on_time<<8)|cooker2_buf[++process_data_2]);
            output_on_time=((output_on_time<<8)|cooker2_buf[++process_data_2]);
            output_on_time=multiply_with*output_on_time;
            process_data_2=0;
            HEATER_2_ON;
            if(dish2_hold_flag)
            {
                first_in_first_complete[0]=first_in_first_complete[1];
                first_in_first_complete[1]=first_in_first_complete[2];
                outputs--;
                dish2_hold_flag=CLR;
            }
            if((cooker_2_kadai_using_flag)AND(((motor_code2>=IGM1)AND(motor_code2<=IGM22))OR(motor_code2==VTM)OR(motor_code2==OPM)))
            {
                    if(motor_code2==OPM)
                    oil_pump_2_on_time=output_on_time;

                   else if((motor_code2>=IGM1)AND(motor_code2<=IGM22))
                   {
                       ing_motor_used_flag=SET;
                       cooker_2_ing_motor_used_flag=SET;
                       dish2_outputs_on=ing_motor_code=ALL_ING_MOTORS;
                       ing_motor_time=output_on_time;
                   }
                   kadai_1_process_flag=SET;
            }
            else if((motor_code2>=IGM1)AND(motor_code2<=IGM22))
            {
                ing_motor_used_flag=SET;
                cooker_2_ing_motor_used_flag=SET;
                dish2_outputs_on=ing_motor_code=ALL_ING_MOTORS;
                ing_motor_time=output_on_time;
                collecting_tray_set_position(motor_code2);
            }
            else
            cooker_B__outputs(motor_code2);
            output_on_time=0;

        }
        else if((!dish2_hold_flag)AND(!c2_lock_flag))
        {
            if((motor_code2==KTM)AND(cooker_1_kadai_using_flag))
            {
                C1_kadai_1_already_used_flag=SET;
                HEATER_2_OFF;
                memcpy(cooker2_holding_backbuf,cooker2_buf,sizeof(cooker2_buf));  // new update
            }
            else
            {
                dish2_hold_flag=SET;
                HEATER_2_OFF;
                first_in_first_complete[outputs++]=cooker2_buf[process_data_2];
                memcpy(cooker2_holding_backbuf,cooker2_buf,sizeof(cooker2_buf));  // new update
            }
        }

    }
}
void dish3_prep_process()
{
    if((restart_ok_flag)AND(!dish3_preparation_start_flag))
    {
        dish3_preparation_start_flag=SET;
        if(cooker_3_kadai_using_flag)
            HEATER_5_ON;
        cooker3_cooking_process_start_flag=SET;
    }
    if((dish3_data_flag)AND(!process3_stop_flag)AND(dish3_preparation_start_flag))
    {
        process_data_3=0;
        motor_code3=cooker3_buf[process_data_3+1];
        if(COOKER_3_OK)
        {
          cooker_no=cooker3_buf[process_data_3];
          dish3_outputs_on=motor_code3=cooker3_buf[++process_data_3];
          C3_direction=cooker3_buf[++process_data_3];
          time_unit=cooker3_buf[++process_data_3];
          if(time_unit==1)
          multiply_with=1;
          else if(time_unit==2)
          multiply_with=MILLI_SECONDS;
          else if(time_unit==3)
          multiply_with=SECONDS*MILLI_SECONDS;
          else
          multiply_with=0;
          output_on_time=cooker3_buf[++process_data_3];
          output_on_time=((output_on_time<<8)|cooker3_buf[++process_data_3]);
          output_on_time=((output_on_time<<8)|cooker3_buf[++process_data_3]);
          output_on_time=multiply_with*output_on_time;
          process_data_3=0;
          HEATER_3_ON;
          if(dish3_hold_flag)
          {
              first_in_first_complete[0]=first_in_first_complete[1];
              first_in_first_complete[1]=first_in_first_complete[2];
              outputs--;
              dish3_hold_flag=CLR;
          }
          if((cooker_3_kadai_using_flag)AND(((motor_code3>=IGM1)AND(motor_code3<=IGM22))OR(motor_code3==VTM)OR(motor_code3==OPM)))
          {
                if(motor_code3==OPM)
                    oil_pump_3_on_time=output_on_time;

                 else if((motor_code3>=IGM1)AND(motor_code3<=IGM22))
                 {
                     ing_motor_used_flag=SET;
                     cooker_3_ing_motor_used_flag=SET;
                     dish3_outputs_on=ing_motor_code=ALL_ING_MOTORS;
                     ing_motor_time=output_on_time;
                 }
                 kadai_2_process_flag=SET;
          }
          else if((motor_code3>=IGM1)AND(motor_code3<=IGM22))
          {
              ing_motor_used_flag=SET;
              dish3_outputs_on=ing_motor_code=ALL_ING_MOTORS;
              ing_motor_time=output_on_time;
              cooker_3_ing_motor_used_flag=SET;
              collecting_tray_set_position(motor_code3);
          }
          else
          cooker_C__outputs(motor_code3);
          output_on_time=0;
        }
        else if((!dish3_hold_flag)AND(!c3_lock_flag))
        {
           {
               dish3_hold_flag=SET;
               HEATER_3_OFF;
               first_in_first_complete[outputs++]=cooker3_buf[process_data_3];
               memcpy(cooker3_holding_backbuf,cooker3_buf,sizeof(cooker3_buf));  // new update
           }
        }
    }
}
void All_ing_motors(char op_ON_OFF,unsigned code)
{
    switch(code)
    {
        case IGM1:                  //Ingredient only on
                if(op_ON_OFF)
                ING1_MTR_ON;
                else
                ING1_MTR_OFF;
                break;
        case IGM2:
                if(op_ON_OFF)
                ING2_MTR_ON;
                else
                ING2_MTR_OFF;
                break;
        case IGM3:
                if(op_ON_OFF)
                ING3_MTR_ON;
                else
                ING3_MTR_OFF;
                break;
        case IGM4:
                if(op_ON_OFF)
                ING4_MTR_ON;
                else
                ING4_MTR_OFF;
                break;
        case IGM5:
                if(op_ON_OFF)
                ING5_MTR_ON;
                else
                ING5_MTR_OFF;
                break;
        case IGM6:
                if(op_ON_OFF)
                ING6_MTR_ON;
                else
                ING6_MTR_OFF;
                break;
        case IGM7:
                if(op_ON_OFF)
                ING7_MTR_ON;
                else
                ING7_MTR_OFF;
                break;
        case IGM8:
                if(op_ON_OFF)
                ING8_MTR_ON;
                else
                ING8_MTR_OFF;
                break;
        case IGM9:
                if(op_ON_OFF)
                ING9_MTR_ON;
                else
                ING9_MTR_OFF;
                break;
        case IGM10:
                if(op_ON_OFF)
                ING10_MTR_ON;
                else
                ING10_MTR_OFF;
                break;
        case IGM11:
                if(op_ON_OFF)
                ING11_MTR_ON;
                else
                ING11_MTR_OFF;
                break;
        case IGM12:
                if(op_ON_OFF)
                ING12_MTR_ON;
                else
                ING12_MTR_OFF;
                break;
        case IGM13:
                if(op_ON_OFF)
                ING13_MTR_ON;
                else
                ING13_MTR_OFF;
                break;
        case IGM14:
                if(op_ON_OFF)
                ING14_MTR_ON;
                else
                ING14_MTR_OFF;
                break;
        case IGM15:
                if(op_ON_OFF)
                ING15_MTR_ON;
                else
                ING15_MTR_OFF;
                break;
        case IGM16:
                if(op_ON_OFF)
                ING16_MTR_ON;
                else
                ING16_MTR_OFF;
                break;
        case IGM17:
                if(op_ON_OFF)
                ING17_MTR_ON;
                else
                ING17_MTR_OFF;
                break;
        case IGM18:
                if(op_ON_OFF)
                ING18_MTR_ON;
                else
                ING18_MTR_OFF;
                break;
        case IGM19:
                if(op_ON_OFF)
                ING19_MTR_ON;
                else
                ING19_MTR_OFF;
                break;
        case IGM20:
                if(op_ON_OFF)
                ING20_MTR_ON;
                else
                ING20_MTR_OFF;
                break;
        case IGM21:
                if(op_ON_OFF)
                ING21_MTR_ON;
                else
                ING21_MTR_OFF;
                break;
        case IGM22:
                if(op_ON_OFF)
                ING22_MTR_ON;
                else
                ING22_MTR_OFF;
                break;
        case WPB:
                if(op_ON_OFF)
                {
                    VALVE_4_ON;;
                    VALVE_1_ON;
                   // solenoid_1_valve_flag=SET;
                }
                else
                {
                    VALVE_4_OFF;
                    VALVE_1_OFF;
                  //  solenoid_1_valve_flag=CLR;
                }
                break;
        case TWPB:
            if(op_ON_OFF)
                VALVE_5_ON;

            else
                VALVE_5_OFF;

            break;

    }
    if(!load_test_start_flag)
    ing_motor_on_flag=SET;
}
void cooker_A__outputs(unsigned char C1)
{
    switch(C1)
    {
        case VTM:
                if(C1_direction==FWD)
                {
                    if(veg_tray_1_position<3)
                    {
                        veg_tray_1_fwd_rev_pulse=57;
                        VEG_TRAY_1_FWD;
                        veg_tray_1_fwd_rev_flag=SET;
                        veg_tray_1_position++;
                    }
                }
                else if(C1_direction==REV)
                {
                    veg1_tray_rev_ok_flag=SET;
                }
            break;
        case STRL:
        case STRH:
        case STRM:
                    load_pulse_period(motor_code1,COOKER1);
                    if(C1_direction==FWD)
                    {
                        str1_mtr_time=output_on_time;
                        STIRRER_1_MOTOR_FORWARD;
                        str_mtr1_on_flag=SET;
                    }
                    else if(C1_direction==REV)
                    {
                        str1_mtr_time=output_on_time;
                        STIRRER_1_MOTOR_REVERSE;
                        str_mtr1_on_flag=SET;
                    }
        break;
        case OPM:
                OIL_PUMP_1_ON;
                if(!cooker_1_kadai_using_flag)
                oil_pump_1_on_time=output_on_time;
                oil_pump_1_on_flag=SET;
        break;
        case WPB:
                VALVE_4_ON;
                VALVE_1_ON;
                solenoid_1_valve_flag=SET;
                water_pump_time=FLOW_METER_CAL;
                water_flag=SET;
        break;
        case TWPB:
                cooker_1_kadai_using_flag=SET;
                c1_kadai_epprom_store_flag=SET;
                turmerind_water_collecting_flag=SET;
                turmerind_water_on_time=(output_on_time/5);  //50/5=10000 MILI SEC (50ML)
        break;
        case IDLE:
                c1_idle_time=output_on_time;
                c1_idle_flag=SET;
        break;
        case LOCK:
                if(!c1_lock_flag)
                {
                    c1_lock_flag=SET;
                    is_step_complete(LOCK);
                    dishes_complete();
                }
                else
                {
                    c1_lock_flag=CLR;
                    is_step_complete(LOCK);
                    dishes_complete();
                }
        break;
        case CTIM:
                    if(!cooking_time_1_flag)
                    {
                        cooking_time_1_flag=SET;
                        cooker1_cooking_time_on_flag=SET;
                        c1_idle_time=output_on_time;
                        c1_idle_flag=SET;
                    }
        break;
        case KTM:
                if(!cooker_1_kadai_using_flag)
                {
                   HEATER_4_ON;
                    cooker_1_kadai_using_flag=SET;
                    dish1_step_complete_flag=SET;
                    c1_kadai_epprom_store_flag=SET;
                    dishes_complete();
                }
                else if(cooker_1_kadai_using_flag)
                {
                    HEATER_4_OFF;
                    kadai_1_tilting_flag=SET;
                }

        break;

    }
}
void cooker_B__outputs(unsigned char C2)
{
    switch(C2)
    {
        case VTM:
                if(C2_direction==FWD)
                {
                    if(veg_tray_2_position<3)
                    {
                        veg_tray_2_fwd_rev_pulse=57;
                        VEG_TRAY_2_FWD;
                        veg_tray_2_fwd_rev_flag=SET;
                        veg_tray_2_position++;
                    }
                }
                else if(C2_direction==REV)
                {
                    veg2_tray_rev_ok_flag=SET;
                }
            break;
        case STRL:
        case STRH:
        case STRM:
                    load_pulse_period(motor_code2,COOKER2);
                    if(C2_direction==FWD)
                    {
                        str2_mtr_time=output_on_time;
                        STIRRER_2_MOTOR_FORWARD;
                        str_mtr2_on_flag=SET;
                    }
                    else if(C2_direction==REV)
                    {
                        str2_mtr_time=output_on_time;
                        STIRRER_2_MOTOR_REVERSE;
                        str_mtr2_on_flag=SET;
                    }
        break;
        case OPM:
                OIL_PUMP_2_ON;
                if(!cooker_2_kadai_using_flag)
                oil_pump_2_on_time=output_on_time;
                oil_pump_2_on_flag=SET;
        break;
        case WPB:
                VALVE_4_ON;
                VALVE_2_ON;
                solenoid_2_valve_flag=SET;
                water_pump_time=FLOW_METER_CAL;
                water_flag=SET;
        break;
        case TWPB:
                VALVE_5_ON;
                turmerind_water_on_time=(output_on_time/5);
                turmerind_water_on_flag=SET;
        break;
        case IDLE:
                c2_idle_time=output_on_time;
                c2_idle_flag=SET;
        break;
        case LOCK:
                if(!c2_lock_flag)
                {
                    c2_lock_flag=SET;
                    is_step_complete(LOCK);
                    dishes_complete();
                }
                else
                {
                    c2_lock_flag=CLR;
                    is_step_complete(LOCK);
                    dishes_complete();
                }
        break;
        case CTIM:
                    if(!cooking_time_2_flag)
                    {
                        cooking_time_2_flag=SET;
                        cooker2_cooking_time_on_flag=SET;
                        c2_idle_time=output_on_time;
                        c2_idle_flag=SET;
                    }
        break;
        case KTM:
                if(!cooker_2_kadai_using_flag)
                {
                   HEATER_4_ON;
                    cooker_2_kadai_using_flag=SET;
                    dish2_step_complete_flag=SET;
                    c2_kadai_epprom_store_flag=SET;
                    dishes_complete();
                }
                else if(cooker_2_kadai_using_flag)
                {
                   HEATER_4_OFF;
                   //c2_kadai_epprom_store_flag=SET;
                   kadai_1_tilting_flag=SET;
                }
        break;

    }
}
void cooker_C__outputs(unsigned char C3)
{
    switch(C3)
    {
        case VTM:
                if(C3_direction==FWD)
                {
                    if(veg_tray_3_position<3)
                    {
                        veg_tray_3_fwd_rev_pulse=57;
                        VEG_TRAY_3_FWD;
                        veg_tray_3_fwd_rev_flag=SET;
                        veg_tray_3_position++;
                    }
                }
                else if(C3_direction==REV)
                {
                    veg3_tray_rev_ok_flag=SET;
                }
            break;
        case STRL:
        case STRH:
        case STRM:
                    load_pulse_period(motor_code3,COOKER3);
                    if(C3_direction==FWD)
                    {
                        str3_mtr_time=output_on_time;
                        STIRRER_3_MOTOR_FORWARD;
                        str_mtr3_on_flag=SET;
                    }
                    else if(C3_direction==REV)
                    {
                        str3_mtr_time=output_on_time;
                       STIRRER_3_MOTOR_REVERSE;
                        str_mtr3_on_flag=SET;
                    }
        break;
        case OPM:
                OIL_PUMP_3_ON;
                if(!cooker_3_kadai_using_flag)
                oil_pump_3_on_time=output_on_time;
                oil_pump_3_on_flag=SET;
        break;
        case WPB:
                VALVE_4_ON;
                VALVE_3_ON;
                solenoid_3_valve_flag=SET;
                water_pump_time=FLOW_METER_CAL;
                water_flag=SET;
        break;
        case TWPB:
                    turmerind_water_collecting_flag=SET;
                    c3_kadai_epprom_store_flag=SET;
                    cooker_3_kadai_using_flag=SET;
                    turmerind_water_on_time=(output_on_time/5);
        break;
        case IDLE:
                c3_idle_time=output_on_time;
                c3_idle_flag=SET;
        break;
        case LOCK:
                if(!c3_lock_flag)
                {
                    c3_lock_flag=SET;
                    is_step_complete(LOCK);
                    dishes_complete();
                }
                else
                {
                    c3_lock_flag=CLR;
                    is_step_complete(LOCK);
                    dishes_complete();
                }
        break;
        case CTIM:
                    if(!cooking_time_3_flag)
                    {
                        cooking_time_3_flag=SET;
                        cooker3_cooking_time_on_flag=SET;
                        c3_idle_time=output_on_time;
                        c3_idle_flag=SET;
                    }
        break;
        case KTM:
                if(!cooker_3_kadai_using_flag)
                {
                   HEATER_5_ON;
                   cooker_3_kadai_using_flag=SET;
                   dish3_step_complete_flag=SET;
                   c3_kadai_epprom_store_flag=SET;
                   dishes_complete();
                }
                else if(cooker_3_kadai_using_flag)
                {
                  HEATER_5_OFF;
                //  c3_kadai_epprom_store_flag=SET;
                kadai_2_tilting_flag=SET;
                }
        break;
    }
}
void all_outputs_off_fun()
{
    //if(((dish1_data_flag)OR(dish2_data_flag)OR(dish3_data_flag))OR(load_test_stop_flag)OR(!initial_position_ok_flag))
    {
/****************************  client command outputs *******************************/

        if(((water_flag)AND(water_pump_time<=0))OR(stop_motor_id==WPB))//OR(flow_meter_failure_flag))
        {
            VALVE_4_OFF;
            water_flag=CLR;
            water_pump_time=0;
            if(solenoid_1_valve_flag)
            {
                VALVE_1_OFF;
                solenoid_1_valve_flag=CLR;
            }
            else if(solenoid_2_valve_flag)
            {
                VALVE_2_OFF;
                solenoid_2_valve_flag=CLR;
            }
            else if(solenoid_3_valve_flag)
            {
                VALVE_3_OFF;
                solenoid_3_valve_flag=CLR;
            }
            if(flow_meter_failure_flag)
            {
                flow_meter_failure_flag=CLR;
                //form_send_buf(ERR_APP_ID_FUN_ID,COMMAND_RES,FLOW_METER_FAILURE);
                sensor_gets_failure(WPB);
            }
            is_step_complete(WPB);
            dishes_complete();
        }
        if(((turmerind_water_on_flag)AND(turmerind_water_on_time<=0))OR(stop_motor_id==TWPB))
        {
            VALVE_5_OFF;
            turmerind_water_on_flag=CLR;
            if(!turmerind_water_collecting_flag)
            {
                is_step_complete(TWPB);
                dishes_complete();
            }
        }
        if(((oil_pump_1_on_time<=0)AND(oil_pump_1_on_flag))OR((stop_motor_id==OPM)AND(process1_stop_flag)))
        {
            OIL_PUMP_1_OFF;
            oil_pump_1_on_flag=CLR;
            if(!cooker_1_kadai_using_flag)
            {
                dish1_step_complete_flag=SET;
                dishes_complete();
            }
        }
        if(((oil_pump_2_on_time<=0)AND(oil_pump_2_on_flag))OR((stop_motor_id==OPM)AND(process2_stop_flag)))
        {
            OIL_PUMP_2_OFF;
            oil_pump_2_on_flag=CLR;
            if(!cooker_2_kadai_using_flag)
            {
                dish2_step_complete_flag=SET;
                dishes_complete();
            }
        }
        if(((oil_pump_3_on_time<=0)AND(oil_pump_3_on_flag))OR((stop_motor_id==OPM)AND(process3_stop_flag)))
        {
            OIL_PUMP_3_OFF;
            oil_pump_3_on_flag=CLR;
            if(!cooker_3_kadai_using_flag)
            {
                dish3_step_complete_flag=SET;
                dishes_complete();
            }
        }
        if(((ing_motor_time<=0)AND(ing_motor_on_flag))OR(load_test_stop_flag))
        {
           ing_motor_on_flag=CLR;
           load_test_stop_flag=CLR;
           ALL_ING_MOTORS_OFF;

          extra_ing_motor_delay_time=2;         //  DELAY TIME   ING MOTOR TO COOKER POS
          extra_ing_motor_delay_flag=SET;
        }
        if((extra_ing_motor_delay_flag)AND(extra_ing_motor_delay_time<=0))
        {
            extra_ing_motor_delay_flag=CLR;
            extra_ing_motor_delay_time=0;

           if(cooker_1_ing_motor_used_flag)
               Go_cooker_pos(COOKER1);                      // STEP 3 DONE
           else if(cooker_2_ing_motor_used_flag)
               Go_cooker_pos(COOKER2);
           else if(cooker_3_ing_motor_used_flag)
               Go_cooker_pos(COOKER3);
        }
        if(((str1_mtr_time<=0)AND(str_mtr1_on_flag))OR((stop_motor_id>=STRL)AND(stop_motor_id<=STRH)AND(process1_stop_flag)))
        {
            STIRRER_1_MOTOR_STOP;
            str_mtr1_on_flag=CLR;
            str1_delay=2;
            dish1_step_complete_flag=SET;
            dishes_complete();
        }
        if(((str2_mtr_time<=0)AND(str_mtr2_on_flag))OR((stop_motor_id>=STRL)AND(stop_motor_id<=STRH)AND(process2_stop_flag)))
        {
            STIRRER_2_MOTOR_STOP;
            str_mtr2_on_flag=CLR;
            str2_delay=2;
            dish2_step_complete_flag=SET;
            dishes_complete();
        }
        if(((str3_mtr_time<=0)AND(str_mtr3_on_flag))OR((stop_motor_id>=STRL)AND(stop_motor_id<=STRH)AND(process3_stop_flag)))
        {
            STIRRER_3_MOTOR_STOP;
            str_mtr3_on_flag=CLR;
            str3_delay=2;
            dish3_step_complete_flag=SET;
            dishes_complete();
        }
        if(((c1_idle_time<=0)AND(c1_idle_flag))OR((stop_motor_id==IDLE)AND(process1_stop_flag)))
        {
           c1_idle_flag=CLR;
           c1_idle_time=0;
           if(cooking_time_1_flag)
           {
               cooker1_cooking_time_off_flag=SET;
           }
           else
           {
               dish1_step_complete_flag=SET;
               dishes_complete();
           }
        }
        if(((c2_idle_time<=0)AND(c2_idle_flag))OR((stop_motor_id==IDLE)AND(process2_stop_flag)))
        {
            c2_idle_flag=CLR;
            c2_idle_time=0;
            if(cooking_time_2_flag)
            {
                cooker2_cooking_time_off_flag=SET;
            }
            else
            {
                dish2_step_complete_flag=SET;
                dishes_complete();
            }
        }
        if(((c3_idle_time<=0)AND(c3_idle_flag))OR((stop_motor_id==IDLE)AND(process3_stop_flag)))
        {
            c3_idle_flag=CLR;
            c3_idle_time=0;
            if(cooking_time_3_flag)
            {
                cooker3_cooking_time_off_flag=SET;
            }
            else
            {
                dish3_step_complete_flag=SET;
                dishes_complete();
            }
        }
        if(((veg_tray_1_fwd_rev_flag)AND((veg_tray_1_fwd_rev_pulse<=0)OR(VEG_1_SWITCH)))OR((stop_motor_id==VTM)AND(process1_stop_flag)))
        {
           veg_tray_1_fwd_rev_flag=CLR;
           veg_tray_1_fwd_rev_pulse=0;
           VEG_TRAY_1_STOP;
           if(initial_position_ok_flag)
           {
               if(!cooker_1_kadai_using_flag)
               {
                   dish1_step_complete_flag=SET;
                   dishes_complete();
               }
           }
           else
               form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
        }
        if(((veg_tray_2_fwd_rev_flag)AND((veg_tray_2_fwd_rev_pulse<=0)OR(VEG_2_SWITCH)))OR((stop_motor_id==VTM)AND(process2_stop_flag)))
        {
           veg_tray_2_fwd_rev_flag=CLR;
           veg_tray_2_fwd_rev_pulse=0;
           VEG_TRAY_2_STOP;
           if(initial_position_ok_flag)
           {
               if(!cooker_2_kadai_using_flag)
               {
                   dish2_step_complete_flag=SET;
                   dishes_complete();
               }
           }
           else
              form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
        }
        if(((veg_tray_3_fwd_rev_flag)AND((veg_tray_3_fwd_rev_pulse<=0)OR(VEG_3_SWITCH)))OR((stop_motor_id==VTM)AND(process3_stop_flag)))
        {
           veg_tray_3_fwd_rev_flag=CLR;
           veg_tray_3_fwd_rev_pulse=0;
           VEG_TRAY_3_STOP;
           if(initial_position_ok_flag)
           {
               if(!cooker_3_kadai_using_flag)
               {
                   dish3_step_complete_flag=SET;
                   dishes_complete();
               }
           }
           else
              form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
        }
/****************************  client command outputs *******************************/
        if((collecting_tray_ok_flag)AND((collecting_tray_fwd_rev_pulse<=0)OR(COLLECTING_1_SWITCH)OR(COLLECTING_2_SWITCH)))   // COLLECTING FWD_REV_MOTOR
        {
            //temp_tray_position=temp_tray_position;
            MC_FWD_REV_STOP;
            collecting_tray_ok_flag=CLR;
            collecting_tray_fwd_rev_pulse=0;

            if(collecting_tray_A_switch_flag)
                collecting_tray_A_switch_flag=CLR;
            else if(collecting_tray_B_switch_flag)
                collecting_tray_B_switch_flag=CLR;

            if(initial_position_ok_flag)
            {
                if(go_dispensing_correspond_cooker_flag)   // STEP 4 DONE
                {
                    go_dispensing_correspond_cooker_flag=CLR;
                    if(cooker_1_ing_motor_used_flag)
                        tilt_correspondig_direction(COOKER1);
                    else if(cooker_2_ing_motor_used_flag)
                        tilt_correspondig_direction(COOKER2);
                    else if(cooker_3_ing_motor_used_flag)
                        tilt_correspondig_direction(COOKER3);
                }
                else if(go_corresponding_ingredient_motor_flag)      // STEP 2 DONE
                {
                    go_corresponding_ingredient_motor_flag=CLR;
                    if(cooker_1_ing_motor_used_flag)
                        All_ing_motors(OP_GETS_ON,motor_code1);
                    else if(cooker_2_ing_motor_used_flag)
                        All_ing_motors(OP_GETS_ON,motor_code2);
                    else if(cooker_3_ing_motor_used_flag)
                        All_ing_motors(OP_GETS_ON,motor_code3);
                }
            }
            else
            {
                    form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
        if((vibrator_delay<=0)AND(collecting_tray_tilt_ok_flag)AND((collecting_tray_clk_anticlk_pulse<=0)OR(COLLECTING_BIN_SWITCH)))// COLLECTING CW_ACW_MOTOR
        {
            MC_CW_ACW_STOP;
            collecting_tray_tilt_ok_flag=CLR;
            collecting_tray_clk_anticlk_pulse=0;

            if(collecting_bin_switch_flag)
                collecting_bin_switch_flag=CLR;
            if(initial_position_ok_flag)
            {
                if(select_collecting_bin)                       // STEP 1 DONE
                {
                    select_collecting_bin=CLR;
                    if(cooker_1_ing_motor_used_flag)
                        collecting_tray_step_load_fun(motor_code1);
                    else if(cooker_2_ing_motor_used_flag)
                        collecting_tray_step_load_fun(motor_code2);
                    else if(cooker_3_ing_motor_used_flag)
                        collecting_tray_step_load_fun(motor_code3);
                }
                else if(ingredient_dispensed_ok_flag)           // STEP 5 DONE
                {
                    ingredient_dispensed_ok_flag=CLR;
                    tilt_motor_process_ok=1;
                    tilt_dispending_vibration_on_flag=SET;
                }
                else if((tilt_motor_process_ok)AND(!tilt_dispending_vibration_on_flag))
                {

                    tilt_motor_process_ok=CLR;                  // STEP 6 DONE
                    if(cooker_1_ing_motor_used_flag)
                        tilt_motor_home_position(COOKER1,using_bin_no);
                   else if(cooker_2_ing_motor_used_flag)
                       tilt_motor_home_position(COOKER2,using_bin_no);
                   else if(cooker_3_ing_motor_used_flag)
                       tilt_motor_home_position(COOKER3,using_bin_no);
                }
                else if(ingredient_motor_process_ok_flag)
                {                                               // STEP 7 DONE
                    ingredient_motor_process_ok_flag=CLR;
                    if(cooker_1_ing_motor_used_flag)
                    {
                        cooker_1_ing_motor_used_flag=CLR;
                        if(!cooker_1_kadai_using_flag)
                        {
                            dish1_step_complete_flag=SET;
                            dishes_complete();
                        }
                    }
                    else if(cooker_2_ing_motor_used_flag)
                    {
                        cooker_2_ing_motor_used_flag=CLR;
                        if(!cooker_2_kadai_using_flag)
                        {
                            dish2_step_complete_flag=SET;
                            dishes_complete();
                        }
                    }
                    else if(cooker_3_ing_motor_used_flag)
                    {
                        cooker_3_ing_motor_used_flag=CLR;
                        if(!cooker_3_kadai_using_flag)
                        {
                            dish3_step_complete_flag=SET;
                            dishes_complete();
                        }
                    }
                    ing_temp_delay=3;
                    ing_motor_used_flag=CLR;
                }
            }
            else
            {
                    form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
        if((lid_1_up_down_flag)AND((lid_1_up_down_on_pluse<=0)OR(LID_1_SWITCH)))
        {
           lid_1_up_down_flag=CLR;
           LID_1_STOP;
           lid_1_up_down_on_pluse=0;
           if(!initial_position_ok_flag)
           {
               form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
           }
        }
        if((lid_2_up_down_flag)AND((lid_2_up_down_on_pluse<=0)OR(LID_2_SWITCH)))
        {
            lid_2_up_down_flag=CLR;
            lid_2_up_down_on_pluse=0;
            LID_2_STOP;
           if(!initial_position_ok_flag)
           {
                form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
           }
        }
        if((lid_3_up_down_flag)AND((lid_3_up_down_on_pluse<=0)OR(LID_3_SWITCH)))
        {
           lid_3_up_down_flag=CLR;
           lid_3_up_down_on_pluse=0;
           LID_3_STOP;
           if(!initial_position_ok_flag)
           {
               form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
           }
        }
        if((kadai_1_fwd_rev_flag)AND((kadai_1_fwd_rev_pulse<=0)OR(KADAI_HOMING)OR(KADAI_1_FWD_REV_SWITCH)))
        {
            kadai_1_fwd_rev_flag=CLR;
            kadai_1_fwd_rev_pulse=0;
            PUMP_1_BREAK;
            K1_FWD_REV_STOP;

            if(kadai_homing_switch_flag)
                kadai_homing_switch_flag=CLR;

            if(kadai_1_switch_flag)
                kadai_1_switch_flag=CLR;

            if(!initial_position_ok_flag)
            {
                if(!kadai_1_homing_flag)
                {
                    form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
                }
            }
        }
        if((kadai_1_clk_anti_flag)AND((kadai_1_clk_anti_pulse<=0)OR(KADAI_1_CW_SWITCH)))
        {
            kadai_1_clk_anti_flag=CLR;
            K1_CW_ACW_STOP;
            kadai_1_clk_anti_pulse=0;
            if(kadai_1_cw_acw_switch_flag)
            kadai_1_cw_acw_switch_flag=CLR;

            if(!initial_position_ok_flag)
            {
                form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
        if((kadai_2_fwd_rev_flag)AND((kadai_2_fwd_rev_pulse<=0)OR(KADAI_HOMING)OR(KADAI_2_FWD_REV_SWITCH)))
        {
            kadai_2_fwd_rev_flag=CLR;
            PUMP_2_BREAK;
            K2_FWD_REV_STOP;
            kadai_2_fwd_rev_pulse=0;

            if(kadai_homing_switch_flag)
                kadai_homing_switch_flag=CLR;

            if(kadai_2_switch_flag)
                kadai_2_switch_flag=CLR;

            if(!initial_position_ok_flag)
            {
                if(!kadai_2_homing_flag)
                {
                    form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
                }
            }
        }
        if((kadai_2_clk_anti_flag)AND((kadai_2_clk_anti_pulse<=0)OR(KADAI_2_CW_SWITCH)))
        {
            kadai_2_clk_anti_flag=CLR;
            K2_CW_ACW_STOP;
            kadai_2_clk_anti_pulse=0;

            if(kadai_2_cw_acw_switch_flag)
                kadai_2_cw_acw_switch_flag=CLR;

            if(!initial_position_ok_flag)
            {
                form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
        if((cooker_1_fwd_rev_flag)AND((cooker_1_fwd_rev_pulse<=0)OR(COOKER_1_SWITCH)))
        {
            COOKER_1_STOP;
            cooker_1_fwd_rev_flag=0;
            cooker_1_fwd_rev_pulse=0;
            if(!initial_position_ok_flag)
            {
               form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
        if((cooker_2_fwd_rev_flag)AND((cooker_2_fwd_rev_pulse<=0)OR(COOKER_2_SWITCH)))
        {
            COOKER_2_STOP;
            cooker_2_fwd_rev_flag=0;
            cooker_2_fwd_rev_pulse=0;
            if(!initial_position_ok_flag)
            {
               form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
        if((cooker_3_fwd_rev_flag)AND((cooker_3_fwd_rev_pulse<=0)OR(COOKER_3_SWITCH)))
        {
            COOKER_3_STOP;
            cooker_3_fwd_rev_flag=0;
            cooker_3_fwd_rev_pulse=0;
            if(!initial_position_ok_flag)
            {
               form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
            }
        }
    }
}
void sensor_gets_failure(char code)
{
    if(dish1_outputs_on==code)
    {
        dish1_data_flag=CLR;
        dish1_outputs_on=0;
        dish1_preparation_start_flag=CLR;
        HEATER_1_OFF;
    }
    if(dish2_outputs_on==code)
    {
        dish2_data_flag=CLR;
        dish2_outputs_on=0;
        dish2_preparation_start_flag=CLR;
        HEATER_2_OFF;
    }
    if(dish3_outputs_on==code)
    {
        dish3_data_flag=CLR;
        dish3_outputs_on=0;
        dish3_preparation_start_flag=CLR;
        HEATER_3_OFF;
    }
}
void is_step_complete(char id)
{
    if((dish1_data_flag)AND(dish1_outputs_on==id)AND(!process1_stop_flag))
    dish1_step_complete_flag=SET;
    if((dish2_data_flag)AND(dish2_outputs_on==id)AND(!process2_stop_flag))
    dish2_step_complete_flag=SET;
    if((dish3_data_flag)AND(dish3_outputs_on==id)AND(!process3_stop_flag))
    dish3_step_complete_flag=SET;
}
void dishes_complete()
{
    if(initial_position_ok_flag)
    {
        if((dish1_data_flag)AND(!dish1_hold_flag)AND(dish1_step_complete_flag))
        {
            dish1_outputs_on=0;
            dish1_data_flag=CLR;
            dish1_step_complete_flag=CLR;
            current_send_step_count=c1_step_count;
           form_send_buf(RECEIPE_PREP_APP_ID,DONE_ACK_FUN_ID,COMMAND_RES,COOKER1_DONE_DATA);
        }
        if((dish2_data_flag)AND(!dish2_hold_flag)AND(dish2_step_complete_flag))
        {
            dish2_outputs_on=0;
            dish2_data_flag=CLR;
            dish2_step_complete_flag=CLR;
            current_send_step_count=c2_step_count;
            form_send_buf(RECEIPE_PREP_APP_ID,DONE_ACK_FUN_ID,COMMAND_RES,COOKER2_DONE_DATA);
        }
        if((dish3_data_flag)AND(!dish3_hold_flag)AND(dish3_step_complete_flag))
        {
            dish3_outputs_on=0;
            dish3_data_flag=CLR;
            dish3_step_complete_flag=CLR;
            current_send_step_count=c3_step_count;
            form_send_buf(RECEIPE_PREP_APP_ID,DONE_ACK_FUN_ID,COMMAND_RES,COOKER3_DONE_DATA);
        }
    }

}
void check_idle_condition()
{
    switch(first_in_first_complete[0])
       {
           case COOKER1:
                   if((dish1_hold_flag)AND(COOKER_1_OK))
                   {
                       memcpy(cooker1_buf,cooker1_holding_backbuf,sizeof(cooker1_holding_backbuf));
                       dish1_prep_process();
                   }
                   break;
           case COOKER2:
                   if((dish2_hold_flag)AND(COOKER_2_OK))
                   {
                       memcpy(cooker2_buf,cooker2_holding_backbuf,sizeof(cooker2_holding_backbuf));
                       dish2_prep_process();
                   }
                   break;
           case COOKER3:
                   if((dish3_hold_flag)AND(COOKER_3_OK))
                   {
                       memcpy(cooker3_buf,cooker3_holding_backbuf,sizeof(cooker3_holding_backbuf));
                       dish3_prep_process();
                   }
                   break;
       }
       if((!dish1_hold_flag)AND(!dish2_hold_flag)AND(!dish3_hold_flag))
       first_in_first_complete[0]=first_in_first_complete[1]=first_in_first_complete[2]=outputs=0;

       if((motor_code1==KTM)AND(!cooker_2_kadai_using_flag)AND(C2_kadai_1_already_used_flag)AND(!turmerind_water_collecting_flag))
       {
           memcpy(cooker1_buf,cooker1_holding_backbuf,sizeof(cooker1_holding_backbuf));
           C2_kadai_1_already_used_flag=CLR;
           dish1_prep_process();
       }
       else if((motor_code2==KTM)AND(!cooker_1_kadai_using_flag)AND(C1_kadai_1_already_used_flag)AND(!turmerind_water_collecting_flag))
       {
           memcpy(cooker2_buf,cooker2_holding_backbuf,sizeof(cooker2_holding_backbuf));
           C1_kadai_1_already_used_flag=CLR;
           dish2_prep_process();
       }
}
void stop_preparation()
{
    if(process1_stop_flag)
    {
        if(!stop_1_step)
        {
            HEATER_1_OFF;

            COOKER_1_STOP;
            cooker_1_fwd_rev_flag=0;
            cooker_1_fwd_rev_pulse=0;

            lid_1_up_down_flag=CLR;
            LID_1_STOP;
            lid_1_up_down_on_pluse=0;

            if((cooker_1_ing_motor_used_flag)AND(ing_motor_used_flag))
            {
                MC_FWD_REV_STOP;
                collecting_tray_ok_flag=CLR;
                collecting_tray_fwd_rev_pulse=0;

                MC_CW_ACW_STOP;
                collecting_tray_tilt_ok_flag=CLR;
                collecting_tray_clk_anticlk_pulse=0;

                ALL_ING_MOTORS_OFF;

                STIRRER_1_MOTOR_STOP;

                select_collecting_bin=CLR;
                go_corresponding_ingredient_motor_flag=CLR;
                ing_motor_on_flag=CLR;

                extra_ing_motor_delay_time=0;
                extra_ing_motor_delay_flag=CLR;

                go_dispensing_correspond_cooker_flag=CLR;
                ingredient_dispensed_ok_flag=CLR;
                tilt_dispending_vibration_on_flag=CLR;

                vibration_fwd_flag=CLR;
                vibration_rev_flag=CLR;
                vibration_count=0;

                tilt_motor_process_ok=CLR;
                ingredient_motor_process_ok_flag=CLR;

            }
            if((cooker1_cooking_process_start_flag)OR(cooker1_cooking_time_on_flag)OR(cooker1_cooking_time_off_flag)OR(cooker1_cooking_process_complete_flag))
            {
                cooker1_cooking_process_start_flag=CLR;
                cooker1_cooking_time_on_flag=CLR;
                cooker1_cooking_time_off_flag=CLR;
                cooker1_cooking_process_complete_flag=CLR;
                cooker_A_steps=0;
            }
            if(cooker_1_kadai_using_flag)
            {
                HEATER_4_OFF;

                kadai_1_clk_anti_flag=CLR;
                K1_CW_ACW_STOP;
                kadai_1_clk_anti_pulse=0;

                kadai_1_fwd_rev_flag=CLR;
                kadai_1_fwd_rev_pulse=0;
                K1_FWD_REV_STOP;

                if(kadai_homing_switch_flag)
                    kadai_homing_switch_flag=CLR;
                if(kadai_1_switch_flag)
                    kadai_1_switch_flag=CLR;

                kadai_1_process_flag=CLR;
                kadai_1_tilting_flag=CLR;
                cooker_A_steps=0;
            }
            if(cooking_time_1_flag)
            {
                cooking_time_1_flag=CLR;
                c1_idle_flag=CLR;
                c1_idle_time=0;
            }
            stop_motor_id=dish1_outputs_on;
            all_outputs_off_fun();
            stop_1_step++;
        }
        if((cooker_1_fwd_rev_pulse<=0)AND(lid_1_up_down_on_pluse<=0)AND(collecting_tray_fwd_rev_pulse<=0)AND(collecting_tray_clk_anticlk_pulse<=0)AND(kadai_1_fwd_rev_pulse<=0))
        {
            switch(stop_1_step)
            {
                    case 1:
                            veg1_tray_rev_ok_flag=SET;

                            COOKER_1_FWD;
                            cooker_1_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                            cooker_1_fwd_rev_flag=SET;


                            LID_1_FWD;
                            lid_1_up_down_on_pluse=LID_FWD_PULSE;
                            lid_1_up_down_flag=SET;


                            if(temp_tray_position>=16)
                                temp_tray_position=15;

                            test_flag=SET;
                            collecting_tray_A_switch_flag=SET;
                            collecting_tray_step_load_fun(2);
                            test_flag=CLR;

                            stop_1_step++;
                    break;
                    case 2:
                            MC_CW;
                            collecting_tray_tilt_ok_flag=SET;
                            collecting_tray_clk_anticlk_pulse=200;
                            collecting_bin_switch_flag=SET;
                            stop_1_step++;
                    break;
                    case 3:
                        if((cooker_1_kadai_using_flag)AND(!kadai_1_left_right_switch_close_flag))
                        {
                           kadai_1_homing_flag=SET;
                        }
                        stop_1_step++;
                    break;
                    case 4:
                        if(dish1_hold_flag)
                        {
                            dish1_hold_flag=CLR;
                            if(first_in_first_complete[0]==1)
                            {
                                first_in_first_complete[0]=first_in_first_complete[1];
                                first_in_first_complete[1]=first_in_first_complete[2];
                                first_in_first_complete[2]=first_in_first_complete[3];
                            }
                            else if(first_in_first_complete[1]==1)
                            {
                                first_in_first_complete[1]=first_in_first_complete[2];
                                first_in_first_complete[2]=first_in_first_complete[3];
                            }
                            else if(first_in_first_complete[2]==1)
                            {
                                first_in_first_complete[2]=first_in_first_complete[3];
                                first_in_first_complete[3]=0;
                            }
                            else if(first_in_first_complete[3]==1)
                            {
                                first_in_first_complete[3]=0;
                            }
                        }
                        cooker_1_ing_motor_used_flag=CLR;
                        cooker_1_kadai_using_flag=CLR;
                        c1_kadai_epprom_store_flag=SET;
                        ing_motor_used_flag=CLR;
                        dish1_outputs_on=0,stop_motor_id=0,motor_code1=0;
                        dish1_data_flag=CLR;
                        process1_stop_flag=CLR;
                        stop_1_step=0;
                break;
            }
        }
    }
    else if(process2_stop_flag)
    {
        if(!stop_2_step)
        {
            HEATER_2_OFF;

            COOKER_2_STOP;
            cooker_2_fwd_rev_flag=0;
            cooker_2_fwd_rev_pulse=0;

            lid_2_up_down_flag=CLR;
            LID_2_STOP;
            lid_2_up_down_on_pluse=0;

            if((cooker_2_ing_motor_used_flag)AND(ing_motor_used_flag))
            {
                MC_FWD_REV_STOP;
                collecting_tray_ok_flag=CLR;
                collecting_tray_fwd_rev_pulse=0;

                MC_CW_ACW_STOP;
                collecting_tray_tilt_ok_flag=CLR;
                collecting_tray_clk_anticlk_pulse=0;

                ALL_ING_MOTORS_OFF;

                STIRRER_2_MOTOR_STOP;

                select_collecting_bin=CLR;
                go_corresponding_ingredient_motor_flag=CLR;
                ing_motor_on_flag=CLR;

                extra_ing_motor_delay_time=0;
                extra_ing_motor_delay_flag=CLR;

                go_dispensing_correspond_cooker_flag=CLR;
                ingredient_dispensed_ok_flag=CLR;
                tilt_dispending_vibration_on_flag=CLR;

                vibration_fwd_flag=CLR;
                vibration_rev_flag=CLR;
                vibration_count=0;

                tilt_motor_process_ok=CLR;
                ingredient_motor_process_ok_flag=CLR;

            }
            if((cooker2_cooking_process_start_flag)OR(cooker2_cooking_time_on_flag)OR(cooker2_cooking_time_off_flag)OR(cooker2_cooking_process_complete_flag))
            {
                cooker2_cooking_process_start_flag=CLR;
                cooker2_cooking_time_on_flag=CLR;
                cooker2_cooking_time_off_flag=CLR;
                cooker2_cooking_process_complete_flag=CLR;
                cooker_B_steps=0;
            }
            if(cooker_2_kadai_using_flag)
            {
                HEATER_4_OFF;

                kadai_1_clk_anti_flag=CLR;
                K1_CW_ACW_STOP;
                kadai_1_clk_anti_pulse=0;

                kadai_1_fwd_rev_flag=CLR;
                kadai_1_fwd_rev_pulse=0;
                K1_FWD_REV_STOP;

                if(kadai_homing_switch_flag)
                    kadai_homing_switch_flag=CLR;
                if(kadai_1_switch_flag)
                    kadai_1_switch_flag=CLR;

                kadai_1_process_flag=CLR;
                kadai_1_tilting_flag=CLR;
                cooker_B_steps=0;
            }
            if(cooking_time_2_flag)
            {
                cooking_time_2_flag=CLR;
                c2_idle_flag=CLR;
                c2_idle_time=0;
            }
            stop_motor_id=dish2_outputs_on;
            all_outputs_off_fun();
            stop_2_step++;
        }
        if((cooker_2_fwd_rev_pulse<=0)AND(lid_2_up_down_on_pluse<=0)AND(collecting_tray_fwd_rev_pulse<=0)AND(collecting_tray_clk_anticlk_pulse<=0)AND(kadai_1_fwd_rev_pulse<=0))
        {
            switch(stop_2_step)
            {

                    case 1:
                            veg2_tray_rev_ok_flag=SET;

                            COOKER_2_FWD;
                            cooker_2_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                            cooker_2_fwd_rev_flag=SET;


                            LID_2_FWD;
                            lid_2_up_down_on_pluse=LID_FWD_PULSE;
                            lid_2_up_down_flag=SET;

                            if(temp_tray_position>=16)
                                temp_tray_position=15;

                            test_flag=SET;
                            collecting_tray_A_switch_flag=SET;
                            collecting_tray_step_load_fun(2);
                            test_flag=CLR;

                            stop_2_step++;
                    break;
                    case 2:
                            MC_CW;
                            collecting_tray_tilt_ok_flag=SET;
                            collecting_tray_clk_anticlk_pulse=200;
                            collecting_bin_switch_flag=SET;
                            stop_2_step++;
                    break;
                    case 3:
                        if((cooker_2_kadai_using_flag)AND(!kadai_1_left_right_switch_close_flag))
                        {
                           kadai_1_homing_flag=SET;
                        }
                        stop_2_step++;
                    break;
                    case 4:
                        if(dish2_hold_flag)
                        {
                            dish2_hold_flag=CLR;
                            if(first_in_first_complete[0]==2)
                            {
                                first_in_first_complete[0]=first_in_first_complete[1];
                                first_in_first_complete[1]=first_in_first_complete[2];
                                first_in_first_complete[2]=first_in_first_complete[3];
                            }
                            else if(first_in_first_complete[1]==2)
                            {
                                first_in_first_complete[1]=first_in_first_complete[2];
                                first_in_first_complete[2]=first_in_first_complete[3];
                            }
                            else if(first_in_first_complete[2]==2)
                            {
                                first_in_first_complete[2]=first_in_first_complete[3];
                                first_in_first_complete[3]=0;
                            }
                            else if(first_in_first_complete[3]==2)
                            {
                                first_in_first_complete[3]=0;
                            }
                        }
                        cooker_2_ing_motor_used_flag=CLR;
                        cooker_2_kadai_using_flag=CLR;
                        c2_kadai_epprom_store_flag=SET;
                        ing_motor_used_flag=CLR;
                        dish2_outputs_on=0,stop_motor_id=0,motor_code2=0;
                        dish2_data_flag=CLR;
                        process2_stop_flag=CLR;
                        stop_2_step=0;
                break;
            }
        }
    }
    else if(process3_stop_flag)
    {
        if(!stop_3_step)
        {
            HEATER_3_OFF;

            COOKER_3_STOP;
            cooker_3_fwd_rev_flag=0;
            cooker_3_fwd_rev_pulse=0;

            lid_3_up_down_flag=CLR;
            LID_3_STOP;
            lid_3_up_down_on_pluse=0;

            if((cooker_3_ing_motor_used_flag)AND(ing_motor_used_flag))
            {
                MC_FWD_REV_STOP;
                collecting_tray_ok_flag=CLR;
                collecting_tray_fwd_rev_pulse=0;

                MC_CW_ACW_STOP;
                collecting_tray_tilt_ok_flag=CLR;
                collecting_tray_clk_anticlk_pulse=0;

                ALL_ING_MOTORS_OFF;

                STIRRER_3_MOTOR_STOP;

                select_collecting_bin=CLR;
                go_corresponding_ingredient_motor_flag=CLR;
                ing_motor_on_flag=CLR;

                extra_ing_motor_delay_time=0;
                extra_ing_motor_delay_flag=CLR;

                go_dispensing_correspond_cooker_flag=CLR;
                ingredient_dispensed_ok_flag=CLR;
                tilt_dispending_vibration_on_flag=CLR;

                vibration_fwd_flag=CLR;
                vibration_rev_flag=CLR;
                vibration_count=0;

                tilt_motor_process_ok=CLR;
                ingredient_motor_process_ok_flag=CLR;

            }
            if((cooker3_cooking_process_start_flag)OR(cooker3_cooking_time_on_flag)OR(cooker3_cooking_time_off_flag)OR(cooker3_cooking_process_complete_flag))
            {
                cooker3_cooking_process_start_flag=CLR;
                cooker3_cooking_time_on_flag=CLR;
                cooker3_cooking_time_off_flag=CLR;
                cooker3_cooking_process_complete_flag=CLR;
                cooker_C_steps=0;
            }
            if(cooker_3_kadai_using_flag)
            {
                HEATER_5_OFF;

                kadai_2_clk_anti_flag=CLR;
                K2_CW_ACW_STOP;
                kadai_2_clk_anti_pulse=0;

                kadai_2_fwd_rev_flag=CLR;
                kadai_2_fwd_rev_pulse=0;
                K2_FWD_REV_STOP;

                if(kadai_homing_switch_flag)
                    kadai_homing_switch_flag=CLR;
                if(kadai_2_switch_flag)
                    kadai_2_switch_flag=CLR;

                kadai_2_process_flag=CLR;
                kadai_2_tilting_flag=CLR;
                cooker_C_steps=0;
            }
            if(cooking_time_3_flag)
            {
                cooking_time_3_flag=CLR;
                c3_idle_flag=CLR;
                c3_idle_time=0;
            }
            stop_motor_id=dish3_outputs_on;
            all_outputs_off_fun();
            stop_3_step++;
        }
        if((cooker_3_fwd_rev_pulse<=0)AND(lid_3_up_down_on_pluse<=0)AND(collecting_tray_fwd_rev_pulse<=0)AND(collecting_tray_clk_anticlk_pulse<=0)AND(kadai_2_fwd_rev_pulse<=0))
        {
            switch(stop_3_step)
            {
                    case 1:
                            veg3_tray_rev_ok_flag=SET;

                            COOKER_3_FWD;
                            cooker_3_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                            cooker_3_fwd_rev_flag=SET;


                            LID_3_FWD;
                            lid_3_up_down_on_pluse=LID_FWD_PULSE;
                            lid_3_up_down_flag=SET;

                            if(temp_tray_position>=16)
                                temp_tray_position=15;

                            test_flag=SET;
                            collecting_tray_A_switch_flag=SET;
                            collecting_tray_step_load_fun(2);
                            test_flag=CLR;

                            stop_3_step++;
                    break;
                    case 2:
                            MC_CW;
                            collecting_tray_tilt_ok_flag=SET;
                            collecting_tray_clk_anticlk_pulse=200;
                            collecting_bin_switch_flag=SET;
                            stop_3_step++;
                    break;
                    case 3:
                        if((cooker_3_kadai_using_flag)AND(!kadai_2_left_right_switch_close_flag))
                        {
                           kadai_2_homing_flag=SET;
                        }
                        stop_3_step++;
                    break;
                    case 4:
                        if(dish3_hold_flag)
                        {
                            dish3_hold_flag=CLR;
                            if(first_in_first_complete[0]==3)
                            {
                                first_in_first_complete[0]=first_in_first_complete[1];
                                first_in_first_complete[1]=first_in_first_complete[2];
                                first_in_first_complete[2]=first_in_first_complete[3];
                            }
                            else if(first_in_first_complete[1]==3)
                            {
                                first_in_first_complete[1]=first_in_first_complete[2];
                                first_in_first_complete[2]=first_in_first_complete[3];
                            }
                            else if(first_in_first_complete[2]==3)
                            {
                                first_in_first_complete[2]=first_in_first_complete[3];
                                first_in_first_complete[3]=0;
                            }
                            else if(first_in_first_complete[3]==3)
                            {
                                first_in_first_complete[3]=0;
                            }
                        }
                        cooker_3_ing_motor_used_flag=CLR;
                        cooker_3_kadai_using_flag=CLR;
                        c3_kadai_epprom_store_flag=SET;
                        ing_motor_used_flag=CLR;
                        dish3_outputs_on=0,stop_motor_id=0,motor_code3=0;
                        dish3_data_flag=CLR;
                        process3_stop_flag=CLR;
                        stop_3_step=0;
                break;
            }
        }
    }
}
void restart_process()
{
    if((restart_cooker_move_flag)AND(collecting_tray_clk_anticlk_pulse<=0)AND(!kadai_2_homing_flag)AND(kadai_2_fwd_rev_pulse<=0)AND(!kadai_1_homing_flag)AND(kadai_1_fwd_rev_pulse<=0)AND(collecting_tray_fwd_rev_pulse<=0)AND(cooker_1_fwd_rev_pulse<=0)AND(cooker_2_fwd_rev_pulse<=0)AND(cooker_3_fwd_rev_pulse<=0)AND(lid_1_up_down_on_pluse<=0)AND(lid_2_up_down_on_pluse<=0)AND(lid_3_up_down_on_pluse<=0))
    {
        if(!restart_step)
            restart_step++;

        switch(restart_step)
        {
            case 1:
                    if(!lid_1_switch_close_flag)
                    {
                       LID_1_FWD;
                       lid_1_up_down_flag=SET;
                       lid_1_up_down_on_pluse=LID_FWD_PULSE;
                    }
                    if(!lid_2_switch_close_flag)
                    {
                      LID_2_FWD;
                      lid_2_up_down_flag=SET;
                      lid_2_up_down_on_pluse=LID_FWD_PULSE;
                    }
                    if(!lid_3_switch_close_flag)
                    {
                      LID_3_FWD;
                      lid_3_up_down_flag=SET;
                      lid_3_up_down_on_pluse=LID_FWD_PULSE;
                    }
                    restart_step++;
                break;
            case 2:
                    if(!cooker1_switch_close_flag)
                    {
                        COOKER_1_FWD;
                        cooker_1_fwd_rev_flag=SET;
                        cooker_1_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                    }
                    if(!cooker2_switch_close_flag)
                    {
                        COOKER_2_FWD;
                        cooker_2_fwd_rev_flag=SET;
                        cooker_2_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                    }
                    if(!cooker3_switch_close_flag)
                    {
                        COOKER_3_FWD;
                        cooker_3_fwd_rev_flag=SET;
                        cooker_3_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                    }
                    restart_step++;
            break;
            case 3:
                    if(!collecting_1_switch_close_flag)
                    {
                        temp_tray_position=15;
                        test_flag=SET;
                        collecting_tray_step_load_fun(2);
                        test_flag=CLR;
                        collecting_tray_A_switch_flag=SET;
                    }
                    restart_step++;
            break;
            case 4:
                    if(!kadai_1_left_right_switch_close_flag)
                    {
                        kadai_1_homing_flag=SET;
                    }
                    restart_step++;
            break;
            case 5:
                    if(!kadai_2_left_right_switch_close_flag)
                    {
                        kadai_2_homing_flag=SET;
                    }
                    restart_step++;
            break;
            case 6:
                MC_ACW;
                collecting_tray_tilt_ok_flag=SET;
                collecting_tray_clk_anticlk_pulse=185*4;;
                collecting_bin_switch_flag=SET;
                    restart_step++;
            break;
            case 7:
                    restart_step=0;
                    restart_cooker_move_flag=CLR;
                    initial_position_ok_flag=SET;
                     machine_ready_ok_flag=SET;
                    restart_ok_flag=SET;
                    pending_restart();
                    if(dish1_data_flag)
                        dish1_prep_process();
                    if(dish2_data_flag)
                        dish2_prep_process();
                    if(dish3_data_flag)
                        dish3_prep_process();

            break;
            default:
                break;
        }
    }
}
