#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "string.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

void sensor_open_close_conform();

void sensor_open_close_conform()
{
	if(!DOOR_SWITCH)
	{
		if(door_switch_open_conform_time>20)
		{
			if(door_switch_close_flag)
			iot_compenent_name[6]=HIGH;
			door_switch_close_flag=CLEAR;
			door_switch_close_conform_time=0;
		}
	}
	else
	{
		if(door_switch_close_conform_time>20)
		{
			if(!door_switch_close_flag)
			iot_compenent_name[6]=HIGH;
			door_switch_close_flag=SET;
			door_switch_open_conform_time=0;
		}
	}
	
	if(!SPIRAL_TRIP_SWITCH)
	{
		if(sprial_trip_switch_open_conform_time>20)
		{
			if(spiral_trip_switch_close_flag)
			iot_compenent_name[7]=HIGH;
			spiral_trip_switch_close_flag=CLEAR;
			spiral_trip_switch_close_conform_time=0;
		}
	}
	else
	{
		if(spiral_trip_switch_close_conform_time>20)
		{
			if(!spiral_trip_switch_close_flag)
			iot_compenent_name[7]=HIGH;
			spiral_trip_switch_close_flag=SET;
			sprial_trip_switch_open_conform_time=0;
		}
	}
	if(!BOWL_TRIP_SWITCH)
	{
		if(bowl_trip_switch_open_conform_time>20)
		{
			if(bowl_trip_switch_close_flag)
			iot_compenent_name[4]=HIGH;
			bowl_trip_switch_close_flag=CLEAR;
			bowl_trip_switch_close_conform_time=0;
		}
	}
	else
	{
		if(bowl_trip_switch_close_conform_time>20)
		{
			if(!bowl_trip_switch_close_flag)
			iot_compenent_name[4]=HIGH;
			bowl_trip_switch_close_flag=SET;
			bowl_trip_switch_open_conform_time=0;
		}
	}	
	if(!EMERGENCY_SWITCH)
	{
		if(emergency_switch_open_conform_time>20)
		{
			if(emergency_switch_close_flag)
			iot_compenent_name[5]=HIGH;
			emergency_switch_close_flag=CLEAR;
			emergency_switch_close_conform_time=0;
		}
	}
	else
	{
		if(emergency_switch_close_conform_time>20)
		{
			if(!emergency_switch_close_flag)
			iot_compenent_name[5]=HIGH;
			emergency_switch_close_flag=SET;
			emergency_switch_open_conform_time=0;
		}
	}

}