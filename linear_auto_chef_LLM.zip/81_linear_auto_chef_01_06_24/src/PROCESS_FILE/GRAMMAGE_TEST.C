/*
 * GRAMMAGE_TEST.C
 *
 *  Created on: Dec 27, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/EXTERN_FUN.H"

void load_test_fun();

bool load_test_start_flag,load_test_stop_flag;
static unsigned char process_data=0;
unsigned char grammage_motor_code;

void load_test_fun(unsigned char load_test_buf[])
{
    if((!load_test_start_flag)AND(!dish1_data_flag)AND(!dish2_data_flag)AND(!dish3_data_flag))
    {
        grammage_motor_code=load_test_buf[process_data];
        load_test_start_flag=load_test_buf[++process_data];
        load_test_stop_flag=CLR;
      //  output_on_time=0;
        process_data=0;
        All_ing_motors(OP_GETS_ON,grammage_motor_code);

    }
    else
    {
      //  load_test_stop_flag=SET;
        load_test_start_flag=CLR;
        All_ing_motors(OP_GETS_OFF,grammage_motor_code);
       // all_outputs_off_fun();
    }
}
