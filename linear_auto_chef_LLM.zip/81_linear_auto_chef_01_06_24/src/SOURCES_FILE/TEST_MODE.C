/*
 * TEST_MODE.C
 *
 *  Created on: Dec 11, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "../HEADER_FILE/Macros.H"
#include "../HEADER_FILE/IO.H"

void test_mode();

int mode,i,test_mode_on_off_time;
bool toggle_flag;
extern bool str_mtr1_on_flag,str_mtr2_on_flag,str_mtr3_on_flag;
extern int
        ON_TIME_1,
        OFF_TIME_1,

        ON_TIME_2,
        OFF_TIME_2,

        ON_TIME_3,
        OFF_TIME_3;
void test_mode()
{
    if((TEST_MODE)AND(test_mode_on_off_time<=0))
    {

       if((i%2)==0)
       {
           mode++;
           test_mode_on_off_time=100;
       }
       else
       {

           test_mode_on_off_time=40;
       }
       i++;
       if(MOTOR_DRIVER)
       {
           switch(mode)
           {
               case 1:
                   if(!toggle_flag)
                   {
                       toggle_flag=SET;
                       STIRRER_1_MOTOR_FORWARD;
                       str_mtr1_on_flag=SET;
                    //   ON_TIME_1=10;
                      // OFF_TIME_1=50;
                   }
                   else
                   {
                       STIRRER_1_MOTOR_STOP;
                       str_mtr1_on_flag=CLR;
                       toggle_flag=CLR;
                   }
                   break;
               case 2:
                      if(!toggle_flag)
                      {
                          toggle_flag=SET;
                          STIRRER_1_MOTOR_FORWARD;
                          str_mtr1_on_flag=SET;
                          ON_TIME_1=70;
                          OFF_TIME_1=50;
                      }
                      else
                      {
                          STIRRER_1_MOTOR_STOP;
                          str_mtr1_on_flag=CLR;
                          toggle_flag=CLR;
                      }
                      break;
               case 3:
                   if(!toggle_flag)
                   {
                       toggle_flag=SET;
                       STIRRER_1_MOTOR_FORWARD;
                       str_mtr1_on_flag=SET;
                       ON_TIME_1=1;
                       OFF_TIME_1=0;
                   }
                   else
                   {
                       STIRRER_1_MOTOR_STOP;
                       str_mtr1_on_flag=CLR;
                       toggle_flag=CLR;
                   }
                   break;
               case 4:
                     if(!toggle_flag)
                     {
                         toggle_flag=SET;
                         STIRRER_1_MOTOR_REVERSE;
                         str_mtr1_on_flag=SET;
                         ON_TIME_1=10;
                         OFF_TIME_1=50;
                     }
                     else
                     {
                         STIRRER_1_MOTOR_STOP;
                         str_mtr1_on_flag=CLR;
                         toggle_flag=CLR;
                     }
                     break;
                 case 5:
                        if(!toggle_flag)
                        {
                            toggle_flag=SET;
                            STIRRER_1_MOTOR_REVERSE;
                            str_mtr1_on_flag=SET;
                            ON_TIME_1=30;
                            OFF_TIME_1=20;
                        }
                        else
                        {
                            STIRRER_1_MOTOR_STOP;
                            str_mtr1_on_flag=CLR;
                            toggle_flag=CLR;
                        }
                        break;
                 case 6:
                     if(!toggle_flag)
                     {
                         toggle_flag=SET;
                         STIRRER_1_MOTOR_REVERSE;
                         str_mtr1_on_flag=SET;
                         ON_TIME_1=1;
                         OFF_TIME_1=1;
                     }
                     else
                     {
                         STIRRER_1_MOTOR_STOP;
                         str_mtr1_on_flag=CLR;
                         toggle_flag=CLR;
                     }
                     break;
                 case 7:
                    if(!toggle_flag)
                    {
                        toggle_flag=SET;
                        STIRRER_2_MOTOR_FORWARD;
                        str_mtr2_on_flag=SET;
                        ON_TIME_2=10;
                        OFF_TIME_2=50;
                    }
                    else
                    {
                        STIRRER_2_MOTOR_STOP;
                        str_mtr2_on_flag=CLR;
                        toggle_flag=CLR;
                    }
                    break;
                case 8:
                       if(!toggle_flag)
                       {
                           toggle_flag=SET;
                           STIRRER_2_MOTOR_FORWARD;
                           str_mtr2_on_flag=SET;
                           ON_TIME_2=30;
                           OFF_TIME_2=20;
                       }
                       else
                       {
                           STIRRER_2_MOTOR_STOP;
                           str_mtr2_on_flag=CLR;
                           toggle_flag=CLR;
                       }
                       break;
                case 9:
                    if(!toggle_flag)
                    {
                        toggle_flag=SET;
                        STIRRER_2_MOTOR_FORWARD;
                        str_mtr2_on_flag=SET;
                        ON_TIME_2=1;
                        OFF_TIME_2=1;
                    }
                    else
                    {
                        STIRRER_2_MOTOR_STOP;
                        str_mtr2_on_flag=CLR;
                        toggle_flag=CLR;
                    }
                    break;
                case 10:
                      if(!toggle_flag)
                      {
                          toggle_flag=SET;
                          STIRRER_2_MOTOR_REVERSE;
                          str_mtr2_on_flag=SET;
                          ON_TIME_2=10;
                          OFF_TIME_2=50;
                      }
                      else
                      {
                          STIRRER_2_MOTOR_STOP;
                          str_mtr2_on_flag=CLR;
                          toggle_flag=CLR;
                      }
                      break;
                  case 11:
                         if(!toggle_flag)
                         {
                             toggle_flag=SET;
                             STIRRER_2_MOTOR_REVERSE;
                             str_mtr2_on_flag=SET;
                             ON_TIME_2=30;
                             OFF_TIME_2=20;
                         }
                         else
                         {
                             STIRRER_2_MOTOR_STOP;
                             str_mtr2_on_flag=CLR;
                             toggle_flag=CLR;
                         }
                         break;
                  case 12:
                      if(!toggle_flag)
                      {
                          toggle_flag=SET;
                          STIRRER_2_MOTOR_REVERSE;
                          str_mtr2_on_flag=SET;
                          ON_TIME_2=1;
                          OFF_TIME_2=1;
                      }
                      else
                      {
                          STIRRER_2_MOTOR_STOP;
                          str_mtr2_on_flag=CLR;
                          toggle_flag=CLR;
                      }
                      break;
                  case 13:
                      if(!toggle_flag)
                      {
                          toggle_flag=SET;
                          STIRRER_3_MOTOR_FORWARD;
                          str_mtr3_on_flag=SET;
                          ON_TIME_3=10;
                          OFF_TIME_3=50;
                      }
                      else
                      {
                          STIRRER_3_MOTOR_STOP;
                          str_mtr3_on_flag=CLR;
                          toggle_flag=CLR;
                      }
                      break;
                  case 14:
                         if(!toggle_flag)
                         {
                             toggle_flag=SET;
                             STIRRER_3_MOTOR_FORWARD;
                             str_mtr3_on_flag=SET;
                             ON_TIME_3=30;
                             OFF_TIME_3=20;
                         }
                         else
                         {
                             STIRRER_3_MOTOR_STOP;
                             str_mtr3_on_flag=CLR;
                             toggle_flag=CLR;
                         }
                         break;
                  case 15:
                      if(!toggle_flag)
                      {
                          toggle_flag=SET;
                          STIRRER_3_MOTOR_FORWARD;
                          str_mtr3_on_flag=SET;
                          ON_TIME_3=1;
                          OFF_TIME_3=1;
                      }
                      else
                      {
                          STIRRER_3_MOTOR_STOP;
                          str_mtr3_on_flag=CLR;
                          toggle_flag=CLR;
                      }
                      break;
                  case 16:
                        if(!toggle_flag)
                        {
                            toggle_flag=SET;
                            STIRRER_3_MOTOR_REVERSE;
                            str_mtr3_on_flag=SET;
                            ON_TIME_3=10;
                            OFF_TIME_3=50;
                        }
                        else
                        {
                            STIRRER_3_MOTOR_STOP;
                            str_mtr3_on_flag=CLR;
                            toggle_flag=CLR;
                        }
                        break;
                    case 17:
                           if(!toggle_flag)
                           {
                               toggle_flag=SET;
                               STIRRER_3_MOTOR_REVERSE;
                               str_mtr3_on_flag=SET;
                               ON_TIME_3=30;
                               OFF_TIME_3=20;
                           }
                           else
                           {
                               STIRRER_3_MOTOR_STOP;
                               str_mtr3_on_flag=CLR;
                               toggle_flag=CLR;
                           }
                           break;
                    case 18:
                        if(!toggle_flag)
                        {
                            toggle_flag=SET;
                            STIRRER_3_MOTOR_REVERSE;
                            str_mtr3_on_flag=SET;
                            ON_TIME_3=1;
                            OFF_TIME_3=1;
                        }
                        else
                        {
                            STIRRER_3_MOTOR_STOP;
                            str_mtr3_on_flag=CLR;
                            toggle_flag=CLR;
                        }
                        break;
           }
       }
       if(MOSFET)
       {
        switch(mode)
        {
            case 1:
                if(!toggle_flag)
                {
                    toggle_flag=SET;
                   HEATER_1_ON;
                }
                else
                {
                    HEATER_1_OFF;
                    toggle_flag=CLR;
                }
                break;
            case 2:
                if(!toggle_flag)
                {
                    HEATER_2_ON;
                    toggle_flag=SET;
                }
                else
                {
                    HEATER_2_OFF;
                    toggle_flag=CLR;
                }
                break;
            case 3:
                if(!toggle_flag)
                {
                    toggle_flag=SET;
                   HEATER_3_ON;
                }
                else
                {
                    HEATER_3_OFF;
                    toggle_flag=CLR;
                }
                break;
            case 4:
                if(!toggle_flag)
                {
                    toggle_flag=SET;
                   HEATER_4_ON;
                }
                else
                {
                    HEATER_4_OFF;
                    toggle_flag=CLR;
                }
                break;
            case 5:
               if(!toggle_flag)
               {
                   toggle_flag=SET;
                  HEATER_5_ON;
               }
               else
               {
                   HEATER_5_OFF;
                   toggle_flag=CLR;
               }
               break;
            case 6:
               if(!toggle_flag)
               {
                   toggle_flag=SET;
                  HEATER_6_ON;
               }
               else
               {
                   HEATER_6_OFF;
                   toggle_flag=CLR;
               }
               break;

            case 7:
                if(!toggle_flag)
                {
                    toggle_flag=SET;
                    VALVE_1_ON;
                }
                else
                {
                    VALVE_1_OFF;
                    toggle_flag=CLR;
                }
                break;
            case 8:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   VALVE_2_ON;
               }
               else
               {
                   VALVE_2_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 9:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   VALVE_3_ON;
               }
               else
               {
                   VALVE_3_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 10:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   VALVE_4_ON;
               }
               else
               {
                   VALVE_4_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 11:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   VALVE_5_ON;
               }
               else
               {
                   VALVE_5_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 12:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   VALVE_6_ON;
               }
               else
               {
                   VALVE_6_OFF;
                   toggle_flag=CLR;
               }
                break;

            case 13:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   WATER_PUMP_ON;
               }
               else
               {
                   WATER_PUMP_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 14:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   OIL_PUMP_1_ON;
               }
               else
               {
                   OIL_PUMP_1_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 15:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   OIL_PUMP_2_ON;
               }
               else
               {
                   OIL_PUMP_2_OFF;
                   toggle_flag=CLR;
               }
                break;
            case 16:
                if(!toggle_flag)
               {
                   toggle_flag=SET;
                   FAN_ON;
               }
               else
               {
                   FAN_OFF;
                   toggle_flag=CLR;
               }
                break;
        }
       }


    //    HEARTER_A_ON;
    //    HEARTER_A_OFF;

    //    HEARTER_B_ON;
    //    HEARTER_B_OFF;

    //    HEARTER_C_ON;
    //    HEARTER_C_OFF;

    //    KADAI_HEARTER_1_ON;
    //    KADAI_HEARTER_1_OFF;

    //    KADAI_HEARTER_2_ON;
    //    KADAI_HEARTER_2_OFF;

    //    WATER_HEATER_ON;
    //    WATER_HEATER_OFF;

    //    WATER_PUMP_ON;
    //    WATER_PUMP_OFF;

    //    DC_FAN_ON;
    //    DC_FAN_OFF;

    //    OIL_PUMP_1_ON;
    //    OIL_PUMP_1_OFF;

    //    OIL_PUMP_2_ON;
    //    OIL_PUMP_2_OFF;

    //    DC_VALVE_1_ON;
    //    DC_VALVE_1_OFF;

    //    DC_VALVE_2_ON;
    //    DC_VALVE_2_OFF;

    //    DC_VALVE_3_ON;
    //    DC_VALVE_3_OFF;

    //    DC_VALVE_4_ON;
    //    DC_VALVE_4_OFF;

    //    DC_VALVE_5_ON;
    //    DC_VALVE_5_OFF;

    //    DC_VALVE_6_ON;
    //    DC_VALVE_6_OFF;



        //MOVING_TRAY_FWD_ON;
        //MOVING_TRAY_FWD_OFF;

        //MOVING_TRAY_REV_ON;
        //MOVING_TRAY_REV_OFF;

        //MOVING_TRAY_CW_ON;
        //MOVING_TRAY_CW_OFF;

        //MOVING_TRAY_ACW_ON;
        //MOVING_TRAY_ACW_OFF;

        //COOKER_A_FWD_ON;
        //COOKER_A_FWD_OFF;

        //COOKER_A_REV_ON;
        //COOKER_A_REV_OFF;

        //COOKER_B_FWD_ON;
        //COOKER_B_FWD_OFF;

        //COOKER_B_REV_ON;
        //COOKER_B_REV_OFF;

        //COOKER_C_FWD_ON;
        //COOKER_C_FWD_OFF;

        //COOKER_C_REV_ON;
        //COOKER_C_REV_OFF;

        //VEG_TRAY1_FWD_ON;
        //VEG_TRAY1_OFF;

        //VEG_TRAY1_REV_ON;
        //VEG_TRAY1_OFF;

        //VEG_TRAY2_FWD_ON;
        //VEG_TRAY2_OFF;

        //VEG_TRAY2_REV_ON;
        //VEG_TRAY2_OFF;

        //VEG_TRAY3_FWD_ON;
        //VEG_TRAY3_OFF;

        //VEG_TRAY3_REV_ON;
        //VEG_TRAY3_OFF;

        //VEG_TRAY4_FWD_ON;
        //VEG_TRAY4_OFF;

        //VEG_TRAY4_REV_ON;
        //VEG_TRAY4_OFF;

        //VEG_TRAY5_FWD_ON;
        //VEG_TRAY5_OFF;

        //VEG_TRAY5_REV_ON;
        //VEG_TRAY5_OFF;

        //VEG_TRAY6_FWD_ON;
        //VEG_TRAY6_OFF;

        //VEG_TRAY6_REV_ON;
        //VEG_TRAY6_OFF;

    //    LID1_UP_ON;
    //    LID1_UP_DWN_OFF;
    //    LID1_DWN_ON;
    //    LID1_UP_DWN_OFF;
    //    LID1_FWD_ON;
    //    LID1_FWD_REV_OFF;
    //    LID1_REV_ON;
    //    LID1_FWD_REV_OFF;

    //    LID2_UP_ON;
    //    LID2_UP_DWN_OFF;
    //    LID2_DWN_ON;
    //    LID2_UP_DWN_OFF;
    //    LID2_FWD_ON;
    //    LID2_FWD_REV_OFF;
    //    LID2_REV_ON;
    //    LID2_FWD_REV_OFF;


    //    LID3_UP_ON;
    //    LID3_UP_DWN_OFF;
    //    LID3_DWN_ON;
    //    LID3_UP_DWN_OFF;
    //    LID3_FWD_ON;
    //    LID3_FWD_REV_OFF;
    //    LID3_REV_ON;
    //    LID3_FWD_REV_OFF;

    //    KADAI_1_FWD_ON;
    //    KADAI_1_FWD_REV_STOP;
    //    KADAI_1_REV_ON;
    //    KADAI_1_FWD_REV_STOP;
    //    KADAI_1_CW_ON;
    //    KADAI_1_CW_ACW_STOP;
    //    KADAI_1_ACW_ON;
    //    KADAI_1_CW_ACW_STOP;

    //    KADAI_2_FWD_ON;
    //    KADAI_2_FWD_REV_STOP;
    //    KADAI_2_REV_ON;
    //    KADAI_2_FWD_REV_STOP;
    //    KADAI_2_CW_ON;
    //    KADAI_2_CW_ACW_STOP;
    //    KADAI_2_ACW_ON;
    //    KADAI_2_CW_ACW_STOP;

        //STIRRER1_FWD_ON;
        //STIRRER1_OFF;
        //STIRRER1_REV_ON;
        //STIRRER1_OFF;

        //STIRRER2_FWD_ON;
        //STIRRER2_OFF;
        //STIRRER2_REV_ON;
        //STIRRER2_OFF;

        //STIRRER3_FWD_ON;
        //STIRRER3_OFF;
        //STIRRER3_REV_ON;
        //STIRRER3_OFF;


//       if(eprom_dly<=0)
//       {
//           if(flag==0)
//           {
//               ING1_MTR_ON;
//           }
//           else if(flag==1)
//           {
//               ING1_MTR_OFF;
//               ING2_MTR_ON;
//           }
//           else if(flag==2)
//           {
//               ING2_MTR_OFF;
//               ING3_MTR_ON;
//           }
//           else if(flag==3)
//           {
//               ING3_MTR_OFF;
//               ING4_MTR_ON;
//           }
//           else if(flag==4)
//           {
//               ING4_MTR_OFF;
//               ING5_MTR_ON;
//           }
//           else if(flag==5)
//           {
//               ING5_MTR_OFF;
//               ING6_MTR_ON;
//           }
//           else if(flag==6)
//           {
//               ING6_MTR_OFF;
//               ING7_MTR_ON;
//           }
//           else if(flag==7)
//           {
//               ING7_MTR_OFF;
//               ING8_MTR_ON;
//           }
//           else if(flag==8)
//           {
//               ING8_MTR_OFF;
//               ING9_MTR_ON;
//           }
//           else if(flag==9)
//           {
//               ING9_MTR_OFF;
//               ING10_MTR_ON;
//           }
//           else if(flag==10)
//           {
//               ING10_MTR_OFF;
//               ING11_MTR_ON;
//           }
//           else if(flag==11)
//           {
//               ING11_MTR_OFF;
//               ING12_MTR_ON;
//           }
//           else if(flag==12)
//          {
//              ING12_MTR_OFF;
//              ING13_MTR_ON;
//          }
//          else if(flag==13)
//          {
//              ING13_MTR_OFF;
//              ING14_MTR_ON;
//          }
//          else if(flag==14)
//          {
//              ING14_MTR_OFF;
//              ING15_MTR_ON;
//          }
//          else if(flag==15)
//          {
//              ING15_MTR_OFF;
//              ING16_MTR_ON;
//          }
//          else if(flag==16)
//          {
//              ING16_MTR_OFF;
//              ING17_MTR_ON;
//          }
//          else if(flag==17)
//          {
//              ING17_MTR_OFF;
//              ING18_MTR_ON;
//
//          }
//          else if(flag==18)
//          {
//              ING18_MTR_OFF;
//              ING19_MTR_ON;
//          }
//          else if(flag==19)
//          {
//              ING19_MTR_OFF;
//              ING20_MTR_ON;
//          }
//          else if(flag==20)
//          {
//              ING20_MTR_OFF;
//              ING21_MTR_ON;
//          }
//          else if(flag==21)
//          {
//              ING21_MTR_OFF;
//              ING22_MTR_ON;
//          }
//          else if(flag==22)
//          {
//              ING22_MTR_OFF;
//              ING23_MTR_ON;
//          }
//           flag++;
//           eprom_dly=60;
//
//       }

       //   Rod_sensor.p_api->read(Rod_sensor.p_ctrl,ADC_REG_CHANNEL_0,&J);
       //        boiler_temp.p_api->read(boiler_temp.p_ctrl,ADC_REG_CHANNEL_0,&I);
       //        boiler_temp.p_api->read(boiler_temp.p_ctrl,ADC_REG_CHANNEL_1,&L);
       //        boiler_temp.p_api->read(boiler_temp.p_ctrl,ADC_REG_CHANNEL_2,&M);



//       if(eprom_dly<=0)
//       {
//           if(flag==0)
//           {
//               HEATER_1_ON;
//           }
//           else if(flag==1)
//           {
//            //   HEATER_1_OFF;
//               HEATER_2_ON;
//           }
//           else if(flag==2)
//           {
//              // HEATER_2_OFF;
//               HEATER_3_ON;
//           }
//           else if(flag==3)
//           {
//               //HEATER_3_OFF;
//               HEATER_4_ON;
//           }
//           else if(flag==4)
//           {
//               //HEATER_4_OFF;
//               HEATER_5_ON;
//           }
//           else if(flag==5)
//           {
//               //HEATER_5_OFF;
//               HEATER_6_ON;
//           }
//           else if(flag==6)
//           {
//               //HEATER_6_OFF;
//               WATER_PUMP_ON;
//           }
//           else if(flag==7)
//           {
//               WATER_PUMP_OFF;
//
//           }
    }

}
