#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

static unsigned char process_data=0;
extern void form_send_buf(char,char);
extern void all_outputs_on_off_fun(char,unsigned char);
extern void all_outputs_off_fun();

void load_test_fun()
{
	if((!load_test_start_flag)AND(!dish1_data_flag)AND(!dish2_data_flag)AND(!dish3_data_flag))
	{
		motor_code=load_test_buf[process_data];
		load_test_start_flag=load_test_buf[++process_data];
		load_test_stop_flag=CLEAR;
		output_on_time=0,process_data=0;
		all_outputs_on_off_fun(OP_GETS_ON,motor_code);		
	}	
	else
	{
		load_test_stop_flag=SET;
		load_test_start_flag=CLEAR;
		all_outputs_off_fun();
	}
}	