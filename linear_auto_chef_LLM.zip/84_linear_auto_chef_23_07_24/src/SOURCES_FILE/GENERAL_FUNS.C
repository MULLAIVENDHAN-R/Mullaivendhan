/*
 * GENERAL_FUNS.C
 *
 *  Created on: Dec 12, 2023
 *      Author: kl
 */

#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/IO.H"
#include "HEADER_FILE/EXTERN_FUN.H"

void handshake_ok_fun();
void check_all_functions();
void machine_initilization();
void pending_restart();
void store_current_io_status();
extern bool test_flag,
dish1_preparation_start_flag,
dish2_preparation_start_flag,
dish3_preparation_start_flag;
bool heart_beat_send_flag;
void heartBeat()
{
    if(heart_beat_send_flag)
    {
        form_send_buf(HEARTBEAT_APP_ID,HEART_BEAT_FUN_ID,COMMAND_RES,HEART_BEAT_DATA);
        heart_beat_send_flag=CLR;
    }
}
void machine_initilization()
{
    unsigned code=0,direction=0;
    code=process_data_buf[0];
    direction=process_data_buf[1];
    switch(code)
    {
        case LID1 :
                    if(direction==FWD)
                    {
                        if(!lid_1_switch_close_flag)
                        {
                            LID_1_FWD;
                            lid_1_up_down_flag=SET;
                            lid_1_up_down_on_pluse=LID_FWD_PULSE;
                        }
                        else
                        {
                            lid_1_up_down_flag=SET;
                            lid_1_up_down_on_pluse=LID_FWD_PULSE;
                            //form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
                        }
                    }
                    else if(direction==REV)
                    {
                        LID_1_REV;
                        lid_1_up_down_flag=SET;
                        lid_1_up_down_on_pluse=LID_REV_PULSE;
                    }
        break;

        case LID2 :
                    if(direction==FWD)
                    {
                        if(!lid_2_switch_close_flag)
                        {
                            LID_2_FWD;
                            lid_2_up_down_flag=SET;
                            lid_2_up_down_on_pluse=LID_FWD_PULSE;
                        }
                        else
                        {
                            lid_2_up_down_flag=SET;
                            lid_2_up_down_on_pluse=LID_FWD_PULSE;
                            //form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
                        }
                    }
                    else if(direction==REV)
                    {
                        LID_2_REV;
                        lid_2_up_down_flag=SET;
                        lid_2_up_down_on_pluse=LID_REV_PULSE;
                    }
        break;

        case LID3 :
                   if(direction==FWD)
                    {
                        if(!lid_3_switch_close_flag)
                        {
                            LID_3_FWD;
                            lid_3_up_down_flag=SET;
                            lid_3_up_down_on_pluse=LID_FWD_PULSE;
                        }
                        else
                        {
                            lid_3_up_down_flag=SET;
                            lid_3_up_down_on_pluse=LID_FWD_PULSE;
                            //form_send_buf(INIT_APP_ID,INIT_STEP_DONE_FUN_ID,COMMAND_RES,DONE_DATA);
                        }
                    }
                    else if(direction==REV)
                    {
                        LID_3_REV;
                        lid_3_up_down_flag=SET;
                        lid_3_up_down_on_pluse=LID_REV_PULSE;
                    }
        break;
        case VEG1 :
                    if(direction==FWD)
                    {
                        VEG_TRAY_1_FWD;
                        veg_tray_1_fwd_rev_flag=SET;
                        veg_tray_1_fwd_rev_pulse=810;
                    }
                    else if(direction==REV)
                    {
                        if(!veg_1_switch_close_flag)
                        {
                            VEG_TRAY_1_REV;
                            veg_tray_1_fwd_rev_flag=SET;
                            veg_tray_1_fwd_rev_pulse=810;
                            veg_1_switch_flag=SET;
                        }
                        else
                        {
                            veg_tray_1_fwd_rev_flag=SET;
                            veg_tray_1_fwd_rev_pulse=810;
                            veg_1_switch_flag=SET;
                        }
                    }
        break;
        case VEG2 :

                    if(direction==FWD)
                    {
                        VEG_TRAY_2_FWD;
                        veg_tray_2_fwd_rev_flag=SET;
                        veg_tray_2_fwd_rev_pulse=810;
                    }
                    else if(direction==REV)
                    {
                        if(!veg_2_switch_close_flag)
                        {
                            VEG_TRAY_2_REV;
                            veg_tray_2_fwd_rev_flag=SET;
                            veg_tray_2_fwd_rev_pulse=810;
                            veg_2_switch_flag=SET;
                        }
                        else
                        {
                            veg_tray_2_fwd_rev_flag=SET;
                            veg_tray_2_fwd_rev_pulse=810;
                            veg_2_switch_flag=SET;
                        }
                    }
        break;
        case VEG3 :

                    if(direction==FWD)
                    {
                        VEG_TRAY_3_FWD;
                        veg_tray_3_fwd_rev_flag=SET;
                        veg_tray_3_fwd_rev_pulse=810;
                    }
                    else if(direction==REV)
                    {
                        if(!veg_3_switch_close_flag)
                        {
                            VEG_TRAY_3_REV;
                            veg_tray_3_fwd_rev_flag=SET;
                            veg_tray_3_fwd_rev_pulse=810;
                            veg_3_switch_flag=SET;
                        }
                        else
                        {
                            veg_tray_3_fwd_rev_flag=SET;
                            veg_tray_3_fwd_rev_pulse=810;
                            veg_3_switch_flag=SET;
                        }
                    }
        break;
        case K1FR :
                    if(!kadai_1_left_right_switch_close_flag)
                    {
                        kadai_1_homing_flag=SET;
                    }
                    else
                    {
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_fwd_rev_pulse=10;
                    }
        break;
        case K2FR :
                    if(!kadai_2_left_right_switch_close_flag)
                    {
                        kadai_2_homing_flag=SET;
                    }
                    else
                    {
                        kadai_2_fwd_rev_flag=SET;
                        kadai_2_fwd_rev_pulse=10;
                    }
                    break;
        case K1CA :
                    if(direction==FWD)
                    {
                        K1_CW;
                        kadai_1_clk_anti_flag=SET;
                        kadai_1_clk_anti_pulse=10;
                    }
                    else if(direction==REV)
                    {
                        K1_ACW;
                        kadai_1_clk_anti_flag=SET;
                        kadai_1_clk_anti_pulse=10;

                    }
       break;
        case K2CA :
                    if(direction==FWD)
                    {
                        K2_CW;
                        kadai_2_clk_anti_flag=SET;
                        kadai_2_clk_anti_pulse=10;

                    }
                    else if(direction==REV)
                    {
                        K2_ACW;
                        kadai_2_clk_anti_flag=SET;
                        kadai_2_clk_anti_pulse=10;
                    }
                    break;
        case CKM1 :
                    if(direction==FWD)
                    {
                        if(!cooker1_switch_close_flag)
                        {
                            COOKER_1_FWD;
                            cooker_1_fwd_rev_flag=SET;
                            cooker_1_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                        }
                        else
                        {
                            cooker_1_fwd_rev_flag=SET;
                            cooker_1_fwd_rev_pulse=10; // dummy
                       }
                    }
                    else if(direction==REV)
                    {
                        COOKER_1_REV;
                        cooker_1_fwd_rev_flag=SET;
                        cooker_1_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                    }
        break;
        case CKM2 :
                    if(direction==FWD)
                    {
                        if(!cooker2_switch_close_flag)
                        {
                            COOKER_2_FWD;
                            cooker_2_fwd_rev_flag=SET;
                            cooker_2_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                        }
                        else
                        {
                            cooker_2_fwd_rev_flag=SET;
                            cooker_2_fwd_rev_pulse=10; // dummy
                        }
                    }
                    else if(direction==REV)
                    {
                        COOKER_2_REV;
                        cooker_2_fwd_rev_flag=SET;
                        cooker_2_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                    }
                    break;
        case CKM3 :
                    if(direction==FWD)
                    {
                        if(!cooker3_switch_close_flag)
                        {
                            COOKER_3_FWD;
                            cooker_3_fwd_rev_flag=SET;
                            cooker_3_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                        }
                        else
                        {
                            cooker_3_fwd_rev_flag=SET;
                            cooker_3_fwd_rev_pulse=10;
                        }
                    }
                    else if(direction==REV)
                    {
                        COOKER_3_REV;
                        cooker_3_fwd_rev_flag=SET;
                        cooker_3_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                    }
                    break;
        case CTFR :
                    if(direction==FWD)
                    {
                       if(!collecting_2_switch_close_flag)
                        {
                            test_flag=SET;
                            collecting_tray_step_load_fun(14);
                            test_flag=CLR;
                            collecting_tray_B_switch_flag=SET;
                        }
                       else
                       {
                           collecting_tray_fwd_rev_pulse=20;
                           collecting_tray_ok_flag=1;
                       }
                    }
                    else if(direction==REV)
                    {
                        if(!collecting_1_switch_close_flag)
                        {
                            temp_tray_position=15;
                            test_flag=SET;
                            collecting_tray_step_load_fun(2);
                            test_flag=CLR;
                            collecting_tray_A_switch_flag=SET;
                        }
                        else
                        {
                            collecting_tray_fwd_rev_pulse=20;
                            collecting_tray_ok_flag=1;
                            temp_tray_position=2;
                        }
                    }
                    break;
        case CTCA :
                    if(direction==FWD)
                    {
                        MC_ACW;
                        collecting_tray_tilt_ok_flag=SET;
                        collecting_tray_clk_anticlk_pulse=185*4;
                        collecting_bin_switch_flag=SET;
                    }
                    else if(direction==REV)
                    {
                        MC_ACW;
                        collecting_tray_tilt_ok_flag=SET;
                        collecting_tray_clk_anticlk_pulse=185*4;;
                        collecting_bin_switch_flag=SET;
                    }
                    break;
    }
    memset(process_data_buf,0,sizeof(process_data_buf));
}
void check_all_functions()
{
        gui_uart_send();
        stop_preparation();
        all_outputs_off_fun();
        dataRcvd_to_process_buf_conversion();
        dataRcvd_success();
        heartBeat();
        temperature_read();
        water_filling_and_water_level_and_heater_control();
        check_idle_condition();
        restart_process();
//        if((!dish1_preparation_start_flag)AND(dish2_preparation_start_flag)AND(!dish3_preparation_start_flag)AND(!collecting_tray_tilt_ok_flag)AND(output_data[120]==HIGH))
//            MC_CW_ACW_EN_LOW;
}
void pending_restart()
{
    cooker_1_kadai_using_flag=eeprom_read(c1_kadai_epprom_store_status);
    cooker_2_kadai_using_flag=eeprom_read(c2_kadai_epprom_store_status);
    cooker_3_kadai_using_flag=eeprom_read(c3_kadai_epprom_store_status);
}
void store_current_io_status()
{
    if(!eeprom_write_start_flag)
    {
        if(c1_kadai_epprom_store_flag)
        {
            eeprom_write_start_flag=SET;
            c1_kadai_epprom_store_flag=CLR;
            eeprom_write(c1_kadai_epprom_store_status,cooker_1_kadai_using_flag);
            eeprom_write_start_flag=CLR;
        }
        else if(c2_kadai_epprom_store_flag)
        {
            eeprom_write_start_flag=SET;
            c2_kadai_epprom_store_flag=CLR;
            eeprom_write(c2_kadai_epprom_store_status,cooker_2_kadai_using_flag);
            eeprom_write_start_flag=CLR;
        }
        else if(c3_kadai_epprom_store_flag)
        {
            eeprom_write_start_flag=SET;
            c3_kadai_epprom_store_flag=CLR;
            eeprom_write(c3_kadai_epprom_store_status,cooker_3_kadai_using_flag);
            eeprom_write_start_flag=CLR;

        }
    }
}
