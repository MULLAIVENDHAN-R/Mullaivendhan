#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"
void dec_function();
void inc_function();

 
void total_ctrl_process()
{
/********         ON/OFF SWITCH         *******/
	if(on_off_sw_flag)
	{
		if(!on_off_key_pressed_flag)
		{
			if(AEROTER==0)
			{
				if(!on_off_flag)
				{
					ON_OFF_LED_ON;//ON_OFF_LED_ON;
					HAND_LED_ON;
				//	speed=0;
					MTR_FWD_LED_ON;
					MTR_FWD_ON;
					PWM = OFF;
					hand_sw_flag = SET;
					fwd_sw_flag = SET;
					on_off_flag = SET;
				//	if(aeroter_on_flag)
				//	airoter_onetime_uart_flag = SET;
					on_off_key_pressed_flag = SET;
					direct_uart_send_data = ((direct_uart_send_data)|(0x00000008));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
					uart_receive_input_flag=SET;				//FOR TRAY TO TOUCH SEND FLAG
				}
				else
				{
					ON_OFF_LED_OFF;
					HAND_LED_OFF;
					MTR_FWD_LED_OFF;
					MTR_REV_LED_OFF;
					MTR_ENABLE_OFF;
//					FOOT_LED_OFF;
					MTR_FWD_OFF;
					MTR_REV_OFF;
					BAR_LED_ALL_OFF;
				//	prev_value=PREV_VALUE;
					prev_value=led_op_variable&(0x000000EF);
					foot_sw_flag = CLEAR;
					first_foot_signal_flag = CLEAR;
					on_off_flag = CLEAR;
					on_off_key_pressed_flag = SET;
					fwd_sw_flag = CLEAR; 
					rvs_sw_flag = CLEAR;
//					fst_fwd_rev_stop_flag = SET;//change
				//	speed=0;
					direct_uart_send_data = ((direct_uart_send_data)&(0xffffffd0));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
					uart_receive_input_flag=SET;			//FOR TRAY TO TOUCH SEND FLAG
				}
			}
		}
	}	
	/*else
	{
		if(!on_off_flag)
		{
			if(!on_off_toggle_flag)
			{
				if(on_off_blink_delay==0)
				{
					ON_OFF_LED_ON;	
					on_off_toggle_flag = SET;
					on_off_blink_delay = FIVE_HUN_MS;
				}
			}
			else
			{
				if(on_off_blink_delay==0)
				{
					ON_OFF_LED_OFF;
					on_off_toggle_flag = CLEAR;
					on_off_blink_delay = FIVE_HUN_MS;
				}
			}
		}
	}*/
/*****  FOOT SIGNAL CONTROL	***********/
	if(foot_sw_flag)
	{
		if(foot_signal_flag)
		{
			if(!first_foot_signal_flag)	
			{
				//if(!FOOT_LED)
//				FOOT_LED_ON;	//foot_led_on = SET;
				ON_OFF_LED_ON;
				toggle_flag = CLEAR;
				if(!sw_change_flag)
				{
					if(first_hand_foot_changed_flag)
					{
						first_hand_foot_changed_flag = CLEAR;
						led_op_variable = ((led_op_variable&0xffffff10)|prev_value);
					}
					first_foot_signal_flag = SET;
					speed_changed_flag = SET;
				//	inc_dec_flag = SET;
					MTR_ENABLE_ON;
					if(rvs_sw_flag)
					MTR_REV_ON;
					if(fwd_sw_flag) 
					MTR_FWD_ON;	
				}	
			}
		}
		else
		{
			first_foot_signal_flag = CLEAR;
			if(!first_hand_foot_changed_flag)
			{
				prev_value=(led_op_variable&(0x000000EF));				
				BAR_LED_ALL_OFF;
				MTR_ENABLE_OFF;
				MTR_FWD_OFF;
				MTR_REV_OFF;
				first_hand_foot_changed_flag = SET;
			}
			if(!toggle_flag)
			{
				if(blink_delay==0)
				{
//					FOOT_LED_ON;
					ON_OFF_LED_ON;		
					toggle_flag = SET;
					blink_delay = FIVE_HUN_MS;
				}
			}
			else if(blink_delay==0)
			{
//				FOOT_LED_OFF;
				ON_OFF_LED_OFF;
				toggle_flag = CLEAR;
				blink_delay = FIVE_HUN_MS;
			}
			
		}
	}
	if(aeroter_sw_flag)
	{		
		if(!aeroter_key_pressed_flag)
		{
			if(!aeroter_on_flag)
			{
				AEROTER_LED_ON;
				aeroter_on_flag = SET;
				aeroter_key_pressed_flag = SET;	
				direct_uart_send_data = ((direct_uart_send_data)|(0x00000080));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
				airoter_onetime_uart_flag=SET;			
							
			}
			else
			{
				AEROTER_OFF;
				AEROTER_LED_OFF;
				aeroter_on_flag = CLEAR;
				aeroter_key_pressed_flag = SET;
				direct_uart_send_data = ((direct_uart_send_data)&(0xffffff7F));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
		}
	}	
	else
	{
		if(aeroter_on_flag)
		{
			if(foot_signal_flag)
			{
				ON_OFF_LED_OFF;
				AEROTER_ON;	
				AEROTER_LED_ON;	
				HAND_LED_OFF;
				MTR_REV_LED_OFF;
				MTR_FWD_LED_OFF;
				MTR_ENABLE_OFF;
//				FOOT_LED_OFF;
				MTR_FWD_OFF;
				MTR_REV_OFF;
				BAR_LED_ALL_OFF;
		//		prev_value=led_op_variable&(0x000000EF);
				foot_sw_flag = CLEAR;	
				first_foot_signal_flag = CLEAR;
				on_off_flag = CLEAR;
				on_off_key_pressed_flag = CLEAR;
				fwd_sw_flag = CLEAR;   
				rvs_sw_flag = CLEAR;
			//	first_hand_foot_changed_flag = CLEAR;
				if(airoter_onetime_uart_flag)
				{
					direct_uart_send_data = ((direct_uart_send_data)&(0xffffffd0));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
					uart_receive_input_flag=SET;
					airoter_onetime_uart_flag=CLEAR;
				}
			}
			else
			{
				AEROTER_OFF;
				if(!aeroter_toggle_flag)
				{
					if(aeroter_blink_delay==0)
					{
						AEROTER_LED_ON;		
						aeroter_toggle_flag = SET;
						aeroter_blink_delay = FIVE_HUN_MS;
					}
				}
				else if(aeroter_blink_delay==0)
				{
					AEROTER_LED_OFF;
					aeroter_toggle_flag = CLEAR;
					aeroter_blink_delay = FIVE_HUN_MS;
				}
			}
		}
	}
	if(inc_sw_key_flag)
	{
		inc_function();
	}
	if(dec_sw_key_flag)
	{
		dec_function();
	}
}
void xray_function()
{
	if(!xray_key_pressed_flag)
	{
		if(!xray_on_flag)
		{
			if(XRAY==0)
			XRAY_ON;
			XRAY_LED_ON;			
			xray_on_flag = SET;
			xray_key_pressed_flag = SET;
			direct_uart_send_data = ((direct_uart_send_data)|(0x00000040));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
			uart_receive_input_flag=SET;
			error_id=6;			//FOR TRAY TO TOUCH SEND FLAG	
		}
		else
		{
			if(XRAY==1)
				XRAY_OFF;
			XRAY_LED_OFF;
			xray_on_flag = CLEAR;
			xray_key_pressed_flag = SET;
			direct_uart_send_data = ((direct_uart_send_data)&(0xffffffbf));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
			uart_receive_input_flag=SET;				//FOR TRAY TO TOUCH SEND FLAG
		}
	}
}
void dec_function()
{	
	if(!speed_dec_delay_flag)
	{
		if(speed>0)
		{
			speed--;
			dec_key_sw_flag = SET;
			speed_changed_flag = SET;
			speed_dec_delay_flag = SET;
			speed_dec_time = 10;
			decrement_uart_send_flag=SET;
			direct_uart_send_data = ((direct_uart_send_data)|(0x00000004));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
			uart_receive_input_flag=SET;			
		}
	}
}
void inc_function()
{
	if(!speed_inc_delay_flag)
	{
		if(speed<19)
		{
			speed++;
			inc_key_sw_flag = SET;
			speed_changed_flag = SET;
			speed_inc_delay_flag = SET;
			speed_inc_time = 10;
			increment_uart_send_flag=SET;
			direct_uart_send_data = ((direct_uart_send_data)|(0x00000002));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
			uart_receive_input_flag=SET;
		}
	}
}
void fwd_rev_function()
{
	if(on_off_flag)
	{
		if(!fwd_rev_sw_flag)
		{
			if(fwd_rev_key_pressed_flag)
			{
				if(fwd_sw_flag)
				{
					rvs_sw_flag = SET;
					fwd_sw_flag = CLEAR;
					MTR_REV_LED_ON;
					MTR_FWD_LED_OFF;
					MTR_FWD_OFF;
					MTR_REV_OFF;
					char_led=led_op_variable;
					if((!sw_change_flag)AND(char_led!=0xEF))
					prev_value=led_op_variable&(0x000000EF);		//PREV_VALUES OF LED'S	
					BAR_LED_ALL_OFF;
					MTR_ENABLE_OFF;
					sw_change_flag = SET;
					//if(fst_fwd_rev_stop_flag)
					//sw_delay = 10;
				//	else
					sw_delay = 60;		//THREE_SECONDS_DELAY;
				//	hand_sw_flag = CLEAR;
					fwd_rev_sw_flag=SET;
					direct_uart_send_data = ((direct_uart_send_data)|(0x00000020));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
					uart_receive_input_flag=SET;
									
				}
				else
				{
					rvs_sw_flag = CLEAR;
					fwd_sw_flag = SET;
					MTR_REV_LED_OFF;
					MTR_FWD_LED_ON;
					MTR_REV_OFF;
					MTR_FWD_OFF;
					char_led=led_op_variable;
					if((!sw_change_flag)AND(char_led!=0xEF))
					prev_value=led_op_variable&(0x000000EF);		//PREV_VALUES OF LED'S	
					BAR_LED_ALL_OFF;			
					MTR_ENABLE_OFF;
					sw_change_flag = SET;
					sw_delay = 60;			//THREE_SECONDS_DELAY;				
				//	hand_sw_flag = CLEAR;
					fwd_rev_sw_flag=SET;
					direct_uart_send_data = ((direct_uart_send_data)&(0xffffffdf));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
					uart_receive_input_flag=SET; 					
				}
			}
		}
	}
}
void hand_foot_fuction()
{
	if(!hand_foot_sw_flag)	
	{
		if(hand_foot_key_pressed_flag)
		{
			if(hand_sw_flag)
			{
				HAND_LED_OFF;
				foot_sw_flag = SET;
				hand_sw_flag = CLEAR;
				hand_foot_sw_flag=SET;
				hand_foot_key_pressed_flag = CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)|(0x00000001));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;										//FOR TRAY TO TOUCH SEND FLAG
				//id = 14; 			//	FOOT_MODE 
			}
			else
			{
				HAND_LED_ON;
				ON_OFF_LED_ON;
//				FOOT_LED_OFF;
				hand_sw_flag = SET;
				foot_sw_flag = CLEAR;
				hand_foot_sw_flag=SET;
				if(rvs_sw_flag)
				MTR_REV_ON;
				if(fwd_sw_flag) 
				MTR_FWD_ON;	
				first_foot_signal_flag = CLEAR;
				hand_foot_key_pressed_flag = CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffe));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;										//FOR TRAY TO TOUCH SEND FLAG
				if(first_hand_foot_changed_flag)	
				{
					speed_changed_flag = SET;
					MTR_ENABLE_ON;
	//				inc_dec_flag = SET;
					led_op_variable = ((led_op_variable & 0xffffff10)|prev_value);
					first_hand_foot_changed_flag = CLEAR;
				}
			}										
		}
	}			
}