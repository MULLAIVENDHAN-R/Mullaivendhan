#include "sfr_r825.h"
#include "cstartdef.h" 
#include "xvariables.h"
#include "macro.h"
void touch_key_scan();
void key_led_control();
void err_update();
void key_scan();

void touch_key_scan()
{
	if(!key_status_changed_flag)
	{
		if((serial_received_data != (0x01FFEF63)))
		{
		
				key_status_changed_flag= SET;
				second_time_flag=CLEAR;
				touch_key_flag = SET;
		}
		else
		{
			touch_key_flag = CLEAR;	
			serial_received_data  = 0x01ffef63;
			fwd_rev_key_pressed_flag=CLEAR;
			hand_foot_key_pressed_flag = CLEAR;		
			pgm1_sw_flag=CLEAR;
			pgm2_sw_flag=CLEAR;
			pgm3_sw_flag=CLEAR;
			zero_sw_flag=CLEAR;													
			if(!second_time_flag)
			{
				send_uart_data_flag=SET;
				second_time_flag=SET;
//				act_fwd_flag=CLEAR;
//				act_rev_flag=CLEAR;
//				act_up_flag=CLEAR;
//				act_dwn_flag=CLEAR;
				tumbler_sw_flag=CLEAR;
				spit_sw_flag=CLEAR;	
				lamp_sw_flag=CLEAR;	
				lamp_sw_pressed_flag=CLEAR;	
				gaugle_sw_flag=CLEAR;
				shark_sw_flag=CLEAR;
				lamp_key_pressed_flag=CLEAR;				
				xray_key_pressed_flag=CLEAR;
				on_off_key_pressed_flag=CLEAR;
				on_off_sw_flag=CLEAR;
				hand_foot_key_pressed_flag=CLEAR;
				fwd_rev_sw_flag=CLEAR;
				hand_foot_sw_flag=CLEAR;
				aeroter_sw_flag=CLEAR;
				aeroter_key_pressed_flag=CLEAR;	
				speed_dec_delay_flag=CLEAR;
				speed_inc_delay_flag=CLEAR;	
						
			}
			if(increment_uart_send_flag)
			{
				increment_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffd));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
			if(decrement_uart_send_flag)
			{
				decrement_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffb));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
		}	
	}	
}

void key_scan()
{
	if(!key_status_changed_flag)
	{
		//temp_serial_received_data=key_data[3];
		temp_serial_received_data=key_data[2];
		temp_serial_received_data=((temp_serial_received_data<<8)|key_data[1]);
		//temp_serial_received_data=((temp_serial_received_data<<8)|key_data[1]);
		temp_serial_received_data=((temp_serial_received_data<<8)|key_data[0]);
		temp_serial_received_data=(temp_serial_received_data&KEYPAD_DATA);
		//if((temp_serial_received_data != (0x01ffef63)))	//pan
		if((temp_serial_received_data != (KEYPAD_DATA)))
		{
			key_pad_data_flag=SET;
			if(!temp_key_delay_flag)
			{
				if(!key_delay_flag)
				{
				//	if(!touch_uart_receive_input_flag)
					key_press_time=3;
				//	else
				//	key_press_time=0;
					//serial_received_data = temp_serial_received_data;		//pan
					max_key_data=temp_serial_received_data;
					key_delay_flag=SET;
				}
				else
				{
					if(key_press_time==0)
					{
						if(temp_serial_received_data == max_key_data)	//pan
						{
							serial_received_data = temp_serial_received_data;
							key_status_changed_flag= SET;
							temp_key_delay_flag = SET;
							first_time_flag=CLEAR;
							key_delay_flag=CLEAR;
							//max_key_data = serial_received_data;
							p1_6 = 1;						
						}
						else
						{
							key_status_changed_flag= CLEAR;
							temp_key_delay_flag = CLEAR;
							first_time_flag=CLEAR;
						//	temp_serial_received_data=0x01ffef63;		//pan
							temp_serial_received_data=KEYPAD_DATA;
							key_delay_flag=CLEAR;
						}
					}				
				}
			}
			else
			{
				key_status_changed_flag=CLEAR;
				key_delay_flag=CLEAR;
			//	temp_serial_received_data = 0x01ffef63;		//pan
				temp_serial_received_data=KEYPAD_DATA;
				//sense_key_data=0XFF;				
			}
		}
		else
		{
			touch_key_flag = CLEAR;
			temp_key_delay_flag = CLEAR;
			key_delay_flag=CLEAR;
		//	serial_received_data  = 0x01ffef63;			//pan
			serial_received_data=KEYPAD_DATA;
		//	send_uart_data_flag=SET;
			max_key_data=KEYPAD_DATA;
			key_pad_data_flag=CLEAR;
			fwd_rev_key_pressed_flag=CLEAR;
			hand_foot_key_pressed_flag = CLEAR;		
			pgm1_sw_flag=CLEAR;
			pgm2_sw_flag=CLEAR;
			pgm3_sw_flag=CLEAR;
			zero_sw_flag=CLEAR;
			inc_sw_key_flag=CLEAR;
			dec_sw_key_flag=CLEAR;													
			if(!first_time_flag)
			{
				send_uart_data_flag=SET;
				p1_6 = 0;
				first_time_flag=SET;
	//			act_fwd_flag=CLEAR;
	//			act_rev_flag=CLEAR;
	//			act_up_flag=CLEAR;
	//			act_dwn_flag=CLEAR;
				tumbler_sw_flag=CLEAR;
				spit_sw_flag=CLEAR;	
				lamp_sw_flag=CLEAR;	
				lamp_sw_pressed_flag=CLEAR;	
				gaugle_sw_flag=CLEAR;
				shark_sw_flag=CLEAR;
				lamp_key_pressed_flag=CLEAR;				
				xray_key_pressed_flag=CLEAR;
				speed_dec_delay_flag=CLEAR;
				speed_inc_delay_flag=CLEAR;
				on_off_key_pressed_flag=CLEAR;
				on_off_sw_flag=CLEAR;
				hand_foot_key_pressed_flag=CLEAR;			
				fwd_rev_sw_flag=CLEAR;
				hand_foot_sw_flag=CLEAR;
				aeroter_sw_flag=CLEAR;
				aeroter_key_pressed_flag=CLEAR;				
			}
			if(increment_uart_send_flag)
			{
				increment_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffd));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}
			if(decrement_uart_send_flag)
			{
				decrement_uart_send_flag=CLEAR;
				direct_uart_send_data = ((direct_uart_send_data)&(0xfffffffb));	//FOR TRAY TOUCH DIRECT SEND DATA WITH ASSIGNING
				uart_receive_input_flag=SET;
			}			
		}
	}	
}

void key_led_control()
{
	if(led_key_count==2)
	{				
		COM_LED1_ON;
		COM_LED3_ON;			
	//	LED_KEY_COTROL_PORT=0xfe;
		LED_OUTPUT;						
	}
	if(led_key_count==3)	
	{
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");		
		COM_LED1_OFF;
		COM_LED3_ON;			
		COM_KEY1_OFF;
		COM_KEY2_OFF;
		COM_KEY3_OFF;	
		LED_KEY_COTROL_PORT=(led_data[1]&0x7F);			
	}	
	if(led_key_count==6)
	{				
		COM_LED1_ON;
		COM_LED3_OFF;	
		COM_KEY1_OFF;
		COM_KEY2_OFF;
		COM_KEY3_OFF;		
		LED_KEY_COTROL_PORT=(led_data[0]&0x9F);			
		/*prc2=1; 
		KEY_SENSE_INIT;
		p0=0x00;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		KEY_SENSE;*/
	}
	if(led_key_count==9)
	{
		prc2=1; 
		KEY_SENSE_INIT;
		p0=0x00;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		KEY_SENSE;
		/*COM_LED2_ON;
		COM_LED3_ON;		
		COM_LED1_ON;		
		COM_KEY1_OFF;
		COM_KEY2_OFF;
		COM_KEY3_OFF;
		key_data[3]=(LED_KEY_COTROL_PORT&0xfc);*/
	}
	if((led_key_count>=10)AND(led_key_count<=11))
	{
		COM_LED1_ON;
		COM_LED3_ON;				
		COM_KEY2_OFF;
		COM_KEY3_OFF;
		COM_KEY1_ON;
		key_data[0]=(LED_KEY_COTROL_PORT&0XFF);
		com_key1_flag=SET;
		com_key2_flag=CLEAR;
		com_key3_flag=CLEAR;
	}
	if((led_key_count>=12)AND(led_key_count<=13))
	{
		COM_LED1_ON;
		COM_LED3_ON;				
		COM_KEY1_OFF;		
		COM_KEY3_OFF;
		COM_KEY2_ON;
		key_data[1]=(LED_KEY_COTROL_PORT&0XFF);
		com_key1_flag=CLEAR;
		com_key2_flag=SET;
		com_key3_flag=CLEAR;
	}
	if((led_key_count>=14)AND(led_key_count<=15))
	{
		COM_LED1_ON;
		COM_LED3_ON;					
		COM_KEY1_OFF;
		COM_KEY2_OFF;
		COM_KEY3_ON;
		key_data[2]=(LED_KEY_COTROL_PORT&0X0F);	
		com_key1_flag=CLEAR;
		com_key2_flag=CLEAR;
		com_key3_flag=SET;
	}
	if(led_key_count>16)
	{
		led_key_count=0;
		COM_KEY3_OFF;
		prc2=1; 		
		LED_OUTPUT_INIT;
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		LED_OUTPUT;
		key_scan_flag=SET;		
	}
}