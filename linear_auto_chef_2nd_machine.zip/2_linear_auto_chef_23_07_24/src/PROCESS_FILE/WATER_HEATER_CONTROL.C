/*
 * WATER_HEATER_CONTROL.C
 *
 *  Created on: Dec 9, 2023
 *      Author: kl
 */

#include "Main_thread.h"
#include "bsp_api.h"
#include "../HEADER_FILE/Macros.H"
#include "../HEADER_FILE/IO.H"
#include "HEADER_FILE/Macros.H"
bool
    refiiling_and_heatingflag,
    temperature_read_flag,
    boiler_heater_flag,
    heater_on_flag,
    water_level_sensing_flag;

extern bool water_flag;
#define PER_DEG_COUNTS        14.5
unsigned char water_level_close_counter,water_level_open_counter, tmpr,tmpr_1,adc_temp[10],crnt_temp[10], water_level_sensing_open_ctr,water_level_sensing_close_ctr;
unsigned int  MIM_BOILER_TEMP,MAX_BOILER_TEMP,MIM_KADAI_1_TEMP,MAX_KADAI_1_TEMP,MIM_KADAI_2_TEMP,MAX_KADAI_2_TEMP,currrent_temp,adc_rod_level,adc_boiler_temp,set_boiler_temp;

void temperature_read();
void water_filling_and_water_level_and_heater_control();

void temperature_read()
{
    boiler_temp.p_api->read(boiler_temp.p_ctrl,ADC_REG_CHANNEL_0,&adc_boiler_temp);
    if(temperature_read_flag)
    {
        temperature_read_flag=CLR;
            adc_temp[tmpr] =(unsigned int)((1024-adc_boiler_temp)/PER_DEG_COUNTS);    // to change count as temperature
            tmpr++;

            if(tmpr>4)
            {
                tmpr=0x00;
                crnt_temp[tmpr_1] =((adc_temp[0]+adc_temp[1]+adc_temp[2]+adc_temp[3]+adc_temp[4])/5);
                tmpr_1++;
                if(tmpr_1>1)
                {
                    tmpr_1=0;
                    if(crnt_temp[0]==crnt_temp[1])
                    {
                        currrent_temp  =(unsigned char)(crnt_temp[0]);

                    }
                }
            }
    }
}
void water_filling_and_water_level_and_heater_control()
{
    if(refiiling_and_heatingflag)
    {
       refiiling_and_heatingflag=CLR;
       Rod_sensor.p_api->read(Rod_sensor.p_ctrl,ADC_REG_CHANNEL_0,&adc_rod_level);

       if((initial_position_ok_flag)AND(!water_flag))
       {
        if(((adc_rod_level>=WATER_ABSENT)OR(adc_rod_level>=WATER_PRESENT+20))AND(water_level_close_counter>20)AND(adc_rod_level>=15))
        {
            water_level_close_counter=0;
            water_level_open_counter=0;
            if(!water_on_flag)
            {
                WATER_PUMP_ON;
                water_on_flag=SET;
                if(heater_on_flag)
                {
                    heater_on_flag=CLR;
                    HEATER_6_OFF;
                }
            }
        }
        else if((adc_rod_level<=WATER_PRESENT)AND(water_level_open_counter>20)AND(adc_rod_level>=15))
        {
            water_level_open_counter=0;
            water_level_close_counter=0;
            if(water_on_flag)
            {
                WATER_PUMP_OFF;
                water_on_flag=CLR;
            }
            else
            {

                 if((!machine_ready_ok_flag)AND(!heater_on_flag)AND(currrent_temp<MAX_BOILER_TEMP)) //MAX
                 {
                    heater_on_flag=SET;
                    HEATER_6_ON;
                 }
                 else if((!heater_on_flag)AND(currrent_temp<MIM_BOILER_TEMP)) // min set temperature 53`c
                 {
                       heater_on_flag=SET;
                       HEATER_6_ON;
                 }
                else if(currrent_temp>=MAX_BOILER_TEMP)//  max set temperature 55`c
                {
                    if(heater_on_flag)
                    {
                        HEATER_6_OFF;
                        heater_on_flag=CLR;
                    }
                }

            }
        }
        if((!machine_ready_ok_flag)AND(!heater_on_flag)AND(!water_on_flag)AND(currrent_temp>=MAX_BOILER_TEMP))
        {
            machine_ready_ok_flag=SET;
            form_send_buf(0X03,0x04,COMMAND_RES,ACK_DATA);
        }
       }
    }

}
