/*
 * UART_DATA_PROCESS.c
 *
 *  Created on: Dec 9, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "stdlib.h"
#include "HEADER_FILE/IO.H"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/EXTERN_FUN.H"


void process_buf_splitup();


extern unsigned char
stop_1_step,stop_2_step,stop_3_step,
                process_data_buf1[MAX_SIZE_RX_BUF],
                process_data_buf[MAX_SIZE_RX_BUF],
                c1_resend_cnt,c2_resend_cnt,c3_resend_cnt,retry_send_cnt;
extern _Bool

            int_step_ok_flag,

            load_test_start_flag,
            restart_cooker_move_flag,

            veg1_tray_rev_ok_flag,
            veg2_tray_rev_ok_flag,
            veg3_tray_rev_ok_flag,

            dish1_preparation_start_flag,
            dish2_preparation_start_flag,
            dish3_preparation_start_flag,

            dish1_data_flag,
            dish2_data_flag,
            dish3_data_flag,

            c1_in_idle_condition_flag,
            c2_in_idle_condition_flag,
            c3_in_idle_condition_flag,

            process1_stop_flag,
            process2_stop_flag,
            process3_stop_flag,

            prep_pending_restart_flag,
            frame_err_flag,handshake_ok_flag,
            c1_resend_ok_flag, c2_resend_ok_flag,c3_resend_ok_flag,retry_buffer_flag,
            c1_one_time_resend_flag,c2_one_time_resend_flag,c3_one_time_resend_flag;

extern unsigned int
            current_send_step_count,
            c1_step_count,
            c2_step_count,
            c3_step_count;


void process_buf_splitup()
{
    if(!frame_err_flag)
    {
        received_app_id=app_id;
        received_fun_id=fun_id;
        if((received_app_id==HANDSHAKE_APP_ID)AND(received_fun_id==DISPLAY_ST_FUN_ID))
        {
            if((process_data_buf1[DATA]=='D')?is_valid_data(process_data_buf1,DISPLAY_READY_DATA):1)
            {
                frame_err_flag=SET;
            }
            else
            {
                if(!handshake_ok_flag)
                {
                    form_send_buf(received_app_id,received_fun_id,COMMAND_RES,HANDSHAKE_DATA);
                    handshake_ok_flag=SET;
                }
            }
        }
        if((received_app_id==HANDSHAKE_APP_ID)AND(received_fun_id==PENDING_RESTART_FUN_ID))
        {
            if((process_data_buf1[DATA]=='R')?is_valid_data(process_data_buf1,PREP_PENDING_RESTART):1)
            {
                frame_err_flag=SET;
            }
            else
            {
                handshake_ok_flag=SET;
             //   prep_pending_restart_flag=SET;
                restart_cooker_move_flag=SET;
                form_send_buf(HANDSHAKE_APP_ID,PENDING_RESTART_FUN_ID,COMMAND_RES,ACK_DATA);
            }
        }
        if((handshake_ok_flag)AND(!frame_err_flag))
        {
            switch(received_app_id)
            {

                case HEARTBEAT_APP_ID:  //0x02
                                        if(is_valid_data(process_data_buf1,ACK_DATA))
                                        {
                                            frame_err_flag=SET;
                                            break;
                                        }
                                        retry_send_cnt=0;
                                        retry_buffer_flag=CLR;
                break;
                case LOAD_TEST_APP_ID   ://0X04
                                    switch(received_fun_id)
                                    {
                                        case TEST_DATA_FUN_ID:
                                                                form_send_buf(received_app_id,received_fun_id,COMMAND_RES,ACK_DATA);
                                                                if(!load_test_start_flag)
                                                                {
                                                                    load_test_fun(process_data_buf);
                                                                }
                                        break;
                                        case TEST_STOP_FUN_ID:
                                                                form_send_buf(received_app_id,received_fun_id,COMMAND_RES,ACK_DATA);
                                                                if(load_test_start_flag)
                                                                {
                                                                    load_test_fun(process_data_buf);
                                                                }
                                        break;
                                    }
            break;
            case RECEIPE_PREP_APP_ID:     //OXO5
                switch(received_fun_id)
                {
                    case STEP_DATA_FUN_ID:
                                        switch(process_data_buf[DATA])
                                        {
                                            case COOKER1:
                                                                    current_send_step_count=c1_step_count;
                                                                    form_send_buf(RECEIPE_PREP_APP_ID,STEP_DATA_FUN_ID,COMMAND_RES,COOKER1_ACK_DATA);
                                                                    if(!dish1_data_flag)
                                                                    {
                                                                       dish1_data_flag=SET;
                                                                       memcpy(cooker1_buf,process_data_buf,sizeof(process_data_buf));
                                                                       dish1_prep_process();
                                                                    }
                                            break;

                                            case COOKER2:
                                                                    current_send_step_count=c2_step_count;
                                                                    form_send_buf(RECEIPE_PREP_APP_ID,STEP_DATA_FUN_ID,COMMAND_RES,COOKER2_ACK_DATA);
                                                                    if(!dish2_data_flag)
                                                                    {
                                                                        dish2_data_flag=SET;
                                                                        memcpy(cooker2_buf,process_data_buf,sizeof(process_data_buf));
                                                                        dish2_prep_process();
                                                                    }
                                            break;

                                            case COOKER3:
                                                                    current_send_step_count=c3_step_count;
                                                                    form_send_buf(RECEIPE_PREP_APP_ID,STEP_DATA_FUN_ID,COMMAND_RES,COOKER3_ACK_DATA);
                                                                    if(!dish3_data_flag)
                                                                    {
                                                                        dish3_data_flag=SET;
                                                                        memcpy(cooker3_buf,process_data_buf,sizeof(process_data_buf));
                                                                        dish3_prep_process();
                                                                    }
                                            break;
                                            default:
                                                        frame_err_flag=SET;
                                                        break;
                                        }
                        break;

                case DONE_ACK_FUN_ID:
                                    switch(process_data_buf1[DATA+1])       //here compare 1/2/3 in ascii format
                                    {
                                        case CKR1_STR:
                                                    if(is_valid_data(process_data_buf1,COOKER1_ACK_DATA))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    c1_resend_cnt=0;
                                                    c1_resend_ok_flag=CLR;
                                                    c1_one_time_resend_flag=CLR;
                                        break;
                                        case CKR2_STR:
                                                    if(is_valid_data(process_data_buf1,COOKER2_ACK_DATA))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    c2_resend_cnt=0;
                                                    c2_resend_ok_flag=CLR;
                                                    c2_one_time_resend_flag=CLR;

                                        break;
                                        case CKR3_STR:
                                                    if(is_valid_data(process_data_buf1,COOKER3_ACK_DATA))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    c3_resend_cnt=0;
                                                    c3_resend_ok_flag=CLR;
                                                    c3_one_time_resend_flag=CLR;
                                        break;
                                        default:
                                            frame_err_flag=SET;
                                        break;
                                    }
                break;

                case PREP_STOP_FUN_ID:

                                    switch(process_data_buf1[DATA+1])       //here compare 1/2/3 in ascii format
                                    {
                                        case CKR1_STR:
                                                    if(is_valid_data(process_data_buf1,COOKER1_STOP_DATA))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    form_send_buf(RECEIPE_PREP_APP_ID,PREP_STOP_FUN_ID,COMMAND_RES,COOKER1_ACK_DATA);
                                                    if(!process1_stop_flag)
                                                    {
                                                        stop_1_step=0;
                                                        process1_stop_flag=SET;
                                                        dish1_preparation_start_flag=CLR;
                                                        stop_preparation();
                                                    }
                                        break;

                                        case CKR2_STR:
                                                    if(is_valid_data(process_data_buf1,COOKER2_STOP_DATA))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    form_send_buf(RECEIPE_PREP_APP_ID,PREP_STOP_FUN_ID,COMMAND_RES,COOKER2_ACK_DATA);
                                                    if(!process2_stop_flag)
                                                    {
                                                        stop_2_step=0;
                                                        process2_stop_flag=SET;
                                                        dish2_preparation_start_flag=CLR;
                                                        stop_preparation();
                                                    }
                                        break;
                                        case CKR3_STR:
                                                   if(is_valid_data(process_data_buf1,COOKER3_STOP_DATA))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    form_send_buf(RECEIPE_PREP_APP_ID,PREP_STOP_FUN_ID,COMMAND_RES,COOKER3_ACK_DATA);
                                                    if(!process3_stop_flag)
                                                    {
                                                        stop_3_step=0;
                                                        process3_stop_flag=SET;
                                                        dish3_preparation_start_flag=CLR;
                                                        stop_preparation();
                                                    }
                                        break;
                                    default:
                                        frame_err_flag=SET;
                                    break;
                                    }
                break;

                case ALL_STEPS_DONE:
                                    switch(process_data_buf1[DATA+1])       //here compare 1/2/3 in ascii format
                                    {
                                        case CKR1_STR:
                                                        if(is_valid_data(process_data_buf1,COOKER1_COMPLETE_DATA))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }

                                                        if(dish1_preparation_start_flag)
                                                        {
                                                            dish1_preparation_start_flag=CLR;
                                                            cooker1_cooking_process_complete_flag=SET;
                                                            HEATER_1_OFF;
                                                            if(!c1_in_idle_condition_flag)
                                                            {
                                                                c1_in_idle_condition_flag=SET;
                                                            }
                                                            veg1_tray_rev_ok_flag=SET;
                                                            //veg_tray_home_position();
                                                        }
                                        break;
                                        case CKR2_STR:
                                                        if(is_valid_data(process_data_buf1,COOKER2_COMPLETE_DATA))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }
//                                                        form_send_buf(RECEIPE_PREP_APP_ID,ALL_STEPS_DONE,COMMAND_RES,COOKER2_ACK_DATA);
                                                        if(dish2_preparation_start_flag)
                                                        {
                                                            dish2_preparation_start_flag=CLR;
                                                            cooker2_cooking_process_complete_flag=SET;
                                                            HEATER_2_OFF;
                                                            if(!c2_in_idle_condition_flag)
                                                            {
                                                                c2_in_idle_condition_flag=SET;
                                                            }
                                                            veg2_tray_rev_ok_flag=SET;
                                                          //  veg_tray_home_position();
                                                        }
                                        break;
                                        case CKR3_STR:
                                                        if(is_valid_data(process_data_buf1,COOKER3_COMPLETE_DATA))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }
                                                     //   form_send_buf(RECEIPE_PREP_APP_ID,received_fun_id,COMMAND_RES,COOKER3_ACK_DATA);
                                                        if(dish3_preparation_start_flag)
                                                        {
                                                            dish3_preparation_start_flag=CLR;
                                                            cooker3_cooking_process_complete_flag=SET;
                                                            HEATER_3_OFF;
                                                            if(!c3_in_idle_condition_flag)
                                                            {
                                                                c3_in_idle_condition_flag=SET;
                                                            }
                                                            veg3_tray_rev_ok_flag=SET;
                                                           // veg_tray_home_position();
                                                        }
                                        break;
                                        default:
                                            frame_err_flag=SET;
                                        break;
                                        }
                    break;

                    case STEPS_START:
                                        switch(process_data_buf1[DATA+1])       //here compare 1/2/3 in ascii format
                                        {
                                            case CKR1_STR:
                                                        {
                                                            dish1_preparation_start_flag=SET;
                                                            cooker1_cooking_process_start_flag=SET;
                                                            //restart_cooker_move_flag=CLR;
                                                            form_send_buf(RECEIPE_PREP_APP_ID,STEPS_START,COMMAND_RES,COOKER1_ACK_DATA);
                                                        }
                                            break;
                                            case CKR2_STR:
                                                    {
                                                        dish2_preparation_start_flag=SET;
                                                        cooker2_cooking_process_start_flag=SET;
                                                        restart_cooker_move_flag=CLR;
                                                        form_send_buf(RECEIPE_PREP_APP_ID,STEPS_START,COMMAND_RES,COOKER2_ACK_DATA);
                                                    }
                                            break;
                                            case CKR3_STR:
                                                      {
                                                        dish3_preparation_start_flag=SET;
                                                        cooker3_cooking_process_start_flag=SET;
                                                        restart_cooker_move_flag=CLR;
                                                        form_send_buf(RECEIPE_PREP_APP_ID,STEPS_START,COMMAND_RES,COOKER3_ACK_DATA);
                                                      }
                                            break;
                                            default:
                                                frame_err_flag=SET;
                                            break;
                                        }
                break;

                case STEP_TIMER_ACK:
                                    switch(process_data_buf1[DATA+1])       //here compare 1/2/3 in ascii format
                                    {
                                        case CKR1_STR:
                                                        if(is_valid_data(process_data_buf1,COOKER1_ACK_DATA))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }
                                                        c1_resend_cnt=0;
                                                        c1_resend_ok_flag=CLR;
                                                        c1_one_time_resend_flag=CLR;
                                    break;
                                        case CKR2_STR:
                                                        if(is_valid_data(process_data_buf1,COOKER2_ACK_DATA))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }
                                                        c2_resend_cnt=0;
                                                        c2_resend_ok_flag=CLR;
                                                        c2_one_time_resend_flag=CLR;
                                        break;
                                        case CKR3_STR:
                                                        if(is_valid_data(process_data_buf1,COOKER3_ACK_DATA))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }
                                                        c3_resend_cnt=0;
                                                        c3_resend_ok_flag=CLR;
                                                        c3_one_time_resend_flag=CLR;
                                        break;
                                        default:
                                            frame_err_flag=SET;
                                        break;
                                    }
                    break;
                    case RECIPE_START_ACK:
                                        if(is_valid_data(process_data_buf1,START_DATA))
                                        {
                                            frame_err_flag=SET;
                                            break;
                                        }
                                        else
                                        {
                                            form_send_buf(RECEIPE_PREP_APP_ID,RECIPE_START_ACK,COMMAND_RES,ACK_DATA);

                                            if(((!heater_on_flag)AND(!water_on_flag))OR((dish1_preparation_start_flag)AND(dish2_preparation_start_flag)AND(dish3_preparation_start_flag)))
                                            {
                                                form_send_buf(RECEIPE_PREP_APP_ID,RECIPE_READY_DATA,COMMAND_RES,READY_DATA);
                                            }
                                            else
                                            {
                                                if(!dish1_preparation_start_flag)
                                                {
                                                    if(water_on_flag)
                                                    {
                                                        form_send_buf(ERR_APP_ID,WARNING_FUN_ID,COMMAND_RES,C1_REFILLING_PROGESS_POP);
                                                    }
                                                    else if(heater_on_flag)
                                                    {
                                                        form_send_buf(ERR_APP_ID,WARNING_FUN_ID,COMMAND_RES,C1_HEATING_PROGESS_POP);
                                                    }
                                                }
                                                else if(!dish2_preparation_start_flag)
                                                {
                                                    if(water_on_flag)
                                                    {
                                                        form_send_buf(ERR_APP_ID,WARNING_FUN_ID,COMMAND_RES,C2_REFILLING_PROGESS_POP);
                                                    }
                                                    else if(heater_on_flag)
                                                    {
                                                        form_send_buf(ERR_APP_ID,WARNING_FUN_ID,COMMAND_RES,C2_HEATING_PROGESS_POP);
                                                    }
                                                }
                                                else if(!dish3_preparation_start_flag)
                                                {
                                                    if(water_on_flag)
                                                    {
                                                        form_send_buf(ERR_APP_ID,WARNING_FUN_ID,COMMAND_RES,C3_REFILLING_PROGESS_POP);
                                                    }
                                                    else if(heater_on_flag)
                                                    {
                                                        form_send_buf(ERR_APP_ID,WARNING_FUN_ID,COMMAND_RES,C3_HEATING_PROGESS_POP);
                                                    }
                                                }
                                            }
                                        }
                    break;
                }
            break;
            case ERR_APP_ID:
                           switch(received_fun_id)
                           {
                               case WARNING_FUN_ID:
                                                   if(is_valid_data(process_data_buf1,ACK_DATA))
                                                   {
                                                       frame_err_flag=SET;
                                                       break;
                                                   }
                                                   retry_send_cnt=0;
                                                   retry_buffer_flag=CLR;
                               break;
                               case TEMPERATURE_DATA:
                                   form_send_buf(ERR_APP_ID,TEMPERATURE_DATA,COMMAND_RES,ACK_DATA);
                               break;
                               default:
                                      frame_err_flag=SET;
                              break;
                           }
            break;
            case INIT_APP_ID:

                switch(received_fun_id)
                {
                    case INIT_START_DATA_FUN_ID:
                                                {
                                                    retry_send_cnt=0;
                                                    retry_buffer_flag=CLR;// handshake resend clear
                                                    if(is_valid_data(process_data_buf1,INIT))
                                                    {
                                                        frame_err_flag=SET;
                                                        break;
                                                    }
                                                    else
                                                    form_send_buf(INIT_APP_ID,INIT_START_DATA_FUN_ID,COMMAND_RES,ACK_DATA);
                                                }
                    break;
                    case INIT_STEP_DATA_FUN_ID:
                                                retry_send_cnt=0;
                                                retry_buffer_flag=CLR;
                                                form_send_buf(INIT_APP_ID,INIT_STEP_DATA_FUN_ID,COMMAND_RES,ACK_DATA);
                                                if(!int_step_ok_flag)
                                                {
                                                    int_step_ok_flag=SET;
                                                    machine_initilization(process_data_buf[0],process_data_buf[1]);
                                                }
                    break;
                    case INIT_STEP_DONE_FUN_ID:
                                                if(is_valid_data(process_data_buf1,ACK_DATA))
                                                {
                                                    frame_err_flag=SET;
                                                    break;
                                                }
                                                retry_send_cnt=0;
                                                retry_buffer_flag=CLR;
                    break;
                    case INIT_STEP_COMPLETE_FUN_ID:
                                                        if(is_valid_data(process_data_buf1,INIT_COMPLETE))
                                                        {
                                                            frame_err_flag=SET;
                                                            break;
                                                        }
                                                        retry_send_cnt=0;
                                                        retry_buffer_flag=CLR;
                                                       initial_position_ok_flag=SET;
                    break;
                }
                break;
            }
        }
    }
}












