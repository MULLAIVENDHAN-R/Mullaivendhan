
#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/UART_RECV_HEADER.H"
#include "HEADER_FILE/EXTERN_FUN.H"
#include "string.h"
#include <stdio.h>
#include <stdlib.h>

void uart_callback(uart_callback_args_t *p_args)
{
    switch (p_args->event)
    {
        case UART_EVENT_RX_COMPLETE:

            Uart.p_api->read (Uart.p_ctrl, uart_rx_buff, 1);
            uart_main_buf[data] = uart_rx_buff[0];
            uart_error_clear_count = 20;
            buf_length =((uart_main_buf[0]==START_BYTE)AND(data<MAX_SIZE_RX_BUF))?((uart_main_buf[data]==END_BYTE)?(receive_complete_flag=SET, data+1):++data):(data = 0);
            if (receive_complete_flag)
            {
                receive_complete_flag = CLR;
                total_length = remove_stuff_byte (buf_length,uart_main_buf);
                if (total_data_bytes > FIXED_DATA_LENGTH)
                    fd_err_flag = SET;
                if (!fd_err_flag)
                {
                    chk_sum_err_flag=received_check_sum(total_length,uart_backup_buf);
                    check_app_fun_id(uart_backup_buf);
                    if((!chk_sum_err_flag)AND(!appid_err_flag)AND(!funid_err_flag)AND(!fd_err_flag)AND(uart_backup_buf[6]!='B'))
                    received_fine_buf(total_length);

                }
            }
        break;
        case UART_EVENT_TX_COMPLETE:
        break;

        case UART_EVENT_ERR_PARITY:
        case UART_EVENT_ERR_FRAMING:
        case UART_EVENT_BREAK_DETECT:
        case UART_EVENT_ERR_OVERFLOW:
        case UART_EVENT_ERR_RXBUF_OVERFLOW:
        case UART_EVENT_RX_CHAR:
                                break;

        default:
        break;
    }
}
int remove_stuff_byte(char len,unsigned char stuff_data_buf[])
{
    unsigned char i = 0, j = 0;

    memset (uart_backup_buf, 0, sizeof(uart_backup_buf));

    for (i = 0, j = 0; i < len; i++, j++)
    {
        if (stuff_data_buf[i] == STUFF_BYTE)
            uart_backup_buf[j] = (~stuff_data_buf[++i]);
        else
        {
            uart_backup_buf[j] = stuff_data_buf[i];
            if (stuff_data_buf[i] == END_BYTE)
                break;
        }
    }
    total_data_bytes = stuff_data_buf[3];
    memset (uart_main_buf, 0, sizeof(uart_main_buf));
    return j + 1;                    //ADD END BYTE ALSO
}
int received_check_sum(unsigned char total_len,unsigned char check_sum_buf[])
{
    unsigned char temp_check_sum = 0, count, byte;
    for (byte = START_FROM, count = 0; byte < total_len - 2; byte++, count++)
    temp_check_sum = (temp_check_sum + (count ^ (check_sum_buf[byte])));
    temp_check_sum = ~(temp_check_sum + check_sum_buf[HEADER_BYTE]);
    if (temp_check_sum==check_sum_buf[total_len-2])
        return 0;
    else
        return 1;
}

void check_app_fun_id(unsigned char app_fun_id_buf[])
{
    unsigned char i,j,app_fun_id[TOTAL_APP_ID][MAX_FUN_ID+1]={
                                                                        {0X01,0X01,0X02},   //here this has all appid and fun id
                                                                        {0X02,0X01},
                                                                        {0X03,0X01,0X02,0X03,0X04},
                                                                        {0X04,0X01,0X02},
                                                                        {0X05,0X01,0X02,0X03,0X04,0X05,0X06,0x07,0X08},
                                                                        {0X09,0X01,0X02},

                                                              };

    if(((app_id=app_fun_id_buf[4])>0)AND((fun_id=app_fun_id_buf[5])>0))
    {
        appid_err_flag=funid_err_flag=1;
        for(i=0;i<TOTAL_APP_ID;i++)
        {
            if(app_fun_id[i][0]==app_id)
            {
                    appid_err_flag=0;
                    for(j=0;j<(MAX_FUN_ID+1);j++)
                    {
                        if((j>0)AND(app_fun_id[i][j]==fun_id))
                    {
                            funid_err_flag=0;
                        break;
                    }
                    }
                break;
            }
        }
    }
    else
    {
        if(app_id==0)
        appid_err_flag=1;
        if(fun_id==0)
        funid_err_flag=1;
    }
}
void received_fine_buf(char total_len)
{
    unsigned char i,j,k,l,byte,byte1,byte2,byte3;

        if((RCV_PRS_APP_FUN_ID)OR(INIT_APP_FUN_ID)OR(TEMP_APP_FUN_ID))
        {
            if(!string_process_data_backup__buf1_set_flag)
            {
                string_process_data_backup__buf1_set_flag=SET;
                memset(string_process_data_buf,0,sizeof(string_process_data_buf));
                for(byte1=DATA_START,i=0;byte1<total_len-2;byte1++,i++)
                string_process_data_buf[i]=uart_backup_buf[byte1];
            }
            else if(!string_process_data_backup__buf2_set_flag)
            {
                string_process_data_backup__buf2_set_flag=SET;
                memset(string_process_data_backup_buf1,0,sizeof(string_process_data_backup_buf1));
                for(byte2=DATA_START,j=0;byte2<total_len-2;byte2++,j++)
                string_process_data_backup_buf1[j]=uart_backup_buf[byte2];
            }
            else if(!string_process_data_backup__buf3_set_flag)
            {
                string_process_data_backup__buf3_set_flag=SET;
                memset(string_process_data_backup_buf2,0,sizeof(string_process_data_backup_buf2));
                for(byte3=DATA_START,k=0;byte3<total_len-2;byte3++,k++)
                string_process_data_backup_buf2[k]=uart_backup_buf[byte3];
            }
            if((string_process_data_backup__buf1_set_flag)OR(string_process_data_backup__buf2_set_flag)OR(string_process_data_backup__buf3_set_flag))
            data_received_ok_flag=SET;
        }
        else
        {
            for(byte=DATA_START,l=0;byte<total_len-2;byte++,l++)
            process_data_buf1[l]=uart_backup_buf[byte];
            general_data_rcvd_flag=SET;
        }
}
void dataRcvd_to_process_buf_conversion()
{
    if(data_received_ok_flag)
    {
        if((string_process_data_backup__buf3_set_flag)AND(!string_process_data_backup__buf2_set_flag)AND(!string_process_data_backup__buf1_set_flag))
        {
            memcpy(string_process_data_buf,string_process_data_backup_buf2,sizeof(string_process_data_backup_buf2));
            str_to_process_buf_conversion();
            string_process_data_backup__buf3_set_flag=CLR;
        }
        else if((string_process_data_backup__buf2_set_flag)AND(!string_process_data_backup__buf3_set_flag)AND(!string_process_data_backup__buf1_set_flag))
        {
            memcpy(string_process_data_buf,string_process_data_backup_buf1,sizeof(string_process_data_backup_buf1));
            str_to_process_buf_conversion();
            string_process_data_backup__buf2_set_flag=CLR;
        }
        else
        {
            if((string_process_data_backup__buf1_set_flag)AND(!string_process_data_backup__buf3_set_flag)AND(!string_process_data_backup__buf2_set_flag))
            {
               str_to_process_buf_conversion();
                string_process_data_backup__buf1_set_flag=CLR;
            }
        }
        data_received_ok_flag=CLR;
        memset(uart_backup_buf,0,sizeof(uart_backup_buf));
        if(string_process_data_flag)
        {
            process_data_rcvd_success_flag=SET;
            string_process_data_flag=CLR;
        }
    }
    else if(general_data_rcvd_flag)
        process_data_rcvd_success_flag=SET;
}
void dataRcvd_success()
{
    if(process_data_rcvd_success_flag)
    {
        process_buf_splitup();
        if(general_data_rcvd_flag)
        {
            general_data_rcvd_flag=CLR;
            memset(process_data_buf1,0,sizeof(process_data_buf1));
        }
        memset(process_data_buf,0,sizeof(process_data_buf));
        process_data_rcvd_success_flag=CLR;
    }
}
