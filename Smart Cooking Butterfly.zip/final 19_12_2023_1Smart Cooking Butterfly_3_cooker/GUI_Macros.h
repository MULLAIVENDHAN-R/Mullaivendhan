#ifndef GUI_MACROS_H
#define GUI_MACROS_H

#define START_BYTE	0X2A
#define END_BYTE	0X23
#define STUFF_BYTE	0X1C
#define HEADER_BYTE	1
#define START_FROM	2
#define DATA_START	6
#define MAX_SIZE_RX_BUF	57


#define TOTAL_APP_ID		7
#define MAX_FUN_ID		6
#define FIXED_DATA_LENGTH	57


#define APP_ID_BYTE		4
#define FUN_ID_BYTE		5


/***************** FORMULA CALCULATION***********/

#define DATA_SIZE_FORMULA	(data_len | ((data_len&0X03)<<6))

/**********************SEND UART*****************/
#define DATA 			0





#define ACK_DATA		0
#define HANDSHAKE_DATA		1
#define DISPLAY_READY_DATA	2
#define REQUEST_DATA		3
#define START_DATA		4
#define DONE_DATA		5
#define STOP_DATA		6
#define COOKER1_DONE_DATA	7
#define COOKER2_DONE_DATA	8
#define COOKER3_DONE_DATA	9
#define COOKER1_STOP_DATA	10
#define COOKER2_STOP_DATA	11
#define COOKER3_STOP_DATA	12
#define COOKER1_START_DATA	13
#define COOKER2_START_DATA	14
#define COOKER3_START_DATA	15
#define COOKER1_ACK_DATA	16
#define COOKER2_ACK_DATA	17
#define COOKER3_ACK_DATA	18


#define CHKSUM_ERR_DATA		19
#define FUNID_ERR_DATA		20
#define APPID_ERR_DATA		21
#define FRAME_ERR_DATA		22
#define DLC_ERR_DATA		23
#define COOKER1_SENSOR_FAILURE	24
#define COOKER2_SENSOR_FAILURE	25
#define COOKER3_SENSOR_FAILURE	26
#define LID_UP_SENSOR_FAILURE	27
#define LID_DWN_SENSOR_FAILURE	28
#define LID_FWD_SENSOR_FAILURE	29
#define LID_REV_SENSOR_FAILURE	30
#define VEGTRAY1_SENSOR_FAILURE	31
#define VEGTRAY2_SENSOR_FAILURE	32
#define VEGTRAY3_SENSOR_FAILURE	33
#define FLOW_METER_FAILURE	34

#define COOKER1_COMPLETE_DATA	35
#define COOKER2_COMPLETE_DATA	36
#define COOKER3_COMPLETE_DATA	37

#define C1_VT1_FAILURE		38
#define C2_VT2_FAILURE		39
#define C3_VT3_FAILURE		40

#define PREP_PENDING_RESTART	41

#define COOKER_PROXI_SENSOR_FAILURE	42
#define COOKER_HOME_SWITCH_FAILURE	43

#define C1_STEP_TIMER		44
#define C2_STEP_TIMER		45
#define C3_STEP_TIMER		46

#define HEART_BEAT_DATA		47


#define LID1_UP_SENSOR_FAILURE	48
#define LID1_DWN_SENSOR_FAILURE	49
#define LID1_FWD_SENSOR_FAILURE	50
#define LID1_REV_SENSOR_FAILURE	51

#define LID2_UP_SENSOR_FAILURE	52
#define LID2_DWN_SENSOR_FAILURE	53
#define LID2_FWD_SENSOR_FAILURE	54
#define LID2_REV_SENSOR_FAILURE	55


#define C1_LID_UP_FAILURE	56
#define C1_LID_DWN_FAILURE	57
#define C1_LID_FWD_FAILURE	58
#define C1_LID_REV_FAILURE	59

#define C2_LID1_UP_FAILURE	60
#define C2_LID1_DWN_FAILURE	61
#define C2_LID1_FWD_FAILURE	62
#define C2_LID1_REV_FAILURE	63

#define C3_LID2_UP_FAILURE	64
#define C3_LID2_DWN_FAILURE	65
#define C3_LID2_FWD_FAILURE	66
#define C3_LID2_REV_FAILURE	67

#define COOKER_MTR_NOT_WORK	68
#define VEGTRAY1_NOT_WORK	69
#define VEGTRAY2_NOT_WORK	70
#define VEGTRAY3_NOT_WORK	71



#define KADAI_CW_SENSOR_FAILURE		72   // initial error
#define KADAI_REV_SENSOR_FAILURE	73
#define KADAI_CCW_SENSOR_FAILURE	74   // initial error
#define KADAI_FWD_SENSOR_FAILURE	75


#define C1_KADAI_CW_FAILURE	76  // prepartion error
#define C1_KADAI_REV_FAILURE	77
#define C1_KADAI_CCW_FAILURE	78  // prepartion error
#define C1_KADAI_FWD_FAILURE	79

#define C2_KADAI_CW_FAILURE	80  // prepartion error
#define C2_KADAI_REV_FAILURE	81
#define C2_KADAI_CCW_FAILURE	82  // prepartion error
#define C2_KADAI_FWD_FAILURE	83

#define C3_KADAI_CW_FAILURE	84  // prepartion error
#define C3_KADAI_REV_FAILURE	85
#define C3_KADAI_CCW_FAILURE	86  // prepartion error
#define C3_KADAI_FWD_FAILURE	87


/***************************UART SEND FUNID APPID*******************/
#define LOAD_TEST_STOP_APPID_FUNID			received_app_id=0X04,received_fun_id=0X02
#define ERROR_APPID_FUNID				received_app_id=0X09,received_fun_id=0X01,ALL_OUTPUTS_OFF,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0,ack_ok_flag=CLEAR
#define ERROR_APPID_FUNID_WO_OP_OFF			received_app_id=0X09,received_fun_id=0X01,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0,ack_ok_flag=CLEAR,check_idle_condition(),check_idle_condition()
#define TRAY_POS_RES_APPID_FUNID			received_app_id=0X02,received_fun_id=0X01,waiting_for_ack_flag=SET,resend_cnt=0
#define LID_POS_RES_APPID_FUNID				received_app_id=0X03,received_fun_id=0X01,waiting_for_ack_flag=SET,resend_cnt=0
#define	PREP_STEP_DONE_APPID_FUNID			received_app_id=0X05,received_fun_id=0X02,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0,ack_ok_flag=CLEAR
#define STEP_TIMER_APPID_FUNID				received_app_id=0X05,received_fun_id=0X06,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0,ack_ok_flag=CLEAR
#define HEART_BEAT_APPID_FUNID				received_app_id=0X06,received_fun_id=0X01,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0,ack_ok_flag=CLEAR
#define RTC_SEND_APPID_FUNID				received_app_id=0X06,received_fun_id=0X02,waiting_for_ack_flag=SET,uart_driver_reset_flag=SET,resend_cnt=0,ack_ok_flag=CLEAR			
/**********************RESPOND DATA *****************/

#define DATA_RES	0
#define COMMAND_RES	1

/**********************RESPOND DATA *****************/


#endif