#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include "X_variables.h"
#include "string.h"
#include <stdlib.h>

extern void send_uart();
void heart_beat();
void all_check_functions();
void dryer_process();
extern void get_process_steps_values();
extern void reload_process_cycle_values();
void heating_process();
void cooling_process();
void  spin_motor_direction();
void dataRcvd_to_process_buf_conversion();
void output_testmode();

extern void step_complete();
extern void frame_send_data(char respond_format,char index,char received_app_id,char received_fun_id );
extern void send_current_temperature();
extern void  check_door_status();
extern void sensors_read();
extern void humidity_sensor();
extern void Input_output_status();
unsigned int pause_delay;
extern unsigned char test_dataaaaaa;

extern unsigned char
step_count_buf[10];

void all_check_functions()
{
	send_uart();
	dataRcvd_to_process_buf_conversion();
	heart_beat();
	dryer_process();
	send_current_temperature();
	sensors_read();		
	humidity_sensor();
	Input_output_status();	
}
void dryer_process()
{	
	if(process_start_flag)
	{		
		if((total_no_of_steps>0)AND(!door_open_flag))
		{
			if(steps_timing<=0)
			{				
				RELOAD_CLEAR_PROCESS_VALUES_AND_FLAGS;
				step_complete();
				total_no_of_steps--;
				if(total_no_of_steps<=0)
				{
					STOP_PROCESS;
					frame_send_data(COMMAND_RES,COMPLETE,PROCESS_DATA_APP_ID,COMPLETE_ACK_FUN_ID);
				}
				else
				get_process_steps_values(cycle);					
			}			
		 	else if(steps_timing>0)
			{
				heating_process();
				cooling_process();
				spin_motor_direction();	
			}			
		}
		else if(door_open_flag)
		{
			check_door_status();
			PAUSE_PROCESS;		
		}
	}
	else if((total_no_of_steps>0)AND(door_open_flag))
	{
		check_door_status();
		RESUME_PROCESS;
	}
}
void heating_process()
{
	static __boolean heater_on_flag;
	if(set_splits==HEATING)
	{		
			if(current_temperature >= set_temperature)//-High_temperature_tolerance)		// add temp tolarance
			{
				if(heater_on_flag)
				{
					if(ELECTRIC)
					ELECTRIC_HEATER_OFF;
					else if(GAS)
					GAS_BURNER_OFF;
					else if(STEAM)	
					STEAM_VALVE_OFF;
					heater_on_flag = CLEAR;
				}
			}
			else if(current_temperature <= set_temperature)//-High_temperature_tolerance)
			{
				if(!heater_on_flag)
				{
					if(ELECTRIC)
					ELECTRIC_HEATER_ON;
					else if(GAS)
					GAS_BURNER_ON;
					else if(STEAM)	
					STEAM_VALVE_ON;
					heater_on_flag = SET;
				}
			}
	}
	else
	{		
		if(heater_on_flag)
		{
			if(ELECTRIC)
			ELECTRIC_HEATER_OFF;
			else if(GAS)
			GAS_BURNER_OFF;
			else if(STEAM)	
			STEAM_VALVE_OFF;			
			heater_on_flag = CLEAR;
		}
		
	}
}
void cooling_process()
{ 
	if(set_splits==COOLING)
	{
		if(!cooling_fan_on_flag)
		{
			COOLING_FAN_ON;
			cooling_fan_on_flag = SET;
		}	
	}
	else
	{
		if(cooling_fan_on_flag)
		{			
			COOLING_FAN_OFF;
			cooling_fan_on_flag = CLEAR;
		}
	}
	
}
void  spin_motor_direction()
{
	if(set_direction==BI_D)
	{
		if((motor_fwd_on_time>0)AND(!fwd_on_time_flag))
		{
			fwd_on_time_flag=SET;			
			MOTOR_FWD_ON;
		}
		else if((motor_fwd_pause_time>0)AND(fwd_on_time_flag)AND(motor_fwd_on_time<=0)AND(!fwd_pause_flag_flag))
		{
			MOTOR_FWD_OFF;
			fwd_pause_flag_flag=SET;
			fwd_on_time_flag=CLEAR;				
			pause_delay=motor_fwd_pause_time;
		}				
		else if((motor_rev_on_time>0)AND(motor_fwd_pause_time<=0)AND(fwd_pause_flag_flag)AND(!rev_on_time_flag))
		{
			rev_on_time_flag=SET;
			fwd_pause_flag_flag=CLEAR;
			MOTOR_REV_ON;
			motor_rev_pause_time=pause_delay;
		}
		else if((motor_rev_pause_time>0)AND(motor_rev_on_time<=0)AND(rev_on_time_flag)AND(!rev_pause_flag_flag))
		{
			rev_on_time_flag=CLEAR;
			rev_pause_flag_flag=SET;
			MOTOR_REV_OFF;					
		}
		else if((motor_rev_pause_time<=0)AND(rev_pause_flag_flag))
		{		
			pause_delay=0;
			rev_pause_flag_flag=CLEAR;
			if(steps_timing>0)
			{
				RELOAD_CLEAR_PROCESS_VALUES_AND_FLAGS;
				reload_process_cycle_values();
			}
		}
	}
	else if(set_direction==UNI_D)
	{
		if((motor_fwd_on_time>0)AND(!fwd_on_time_flag))
		{
			fwd_on_time_flag=SET;
			MOTOR_FWD_ON;
			fwd_pause_flag_flag=CLEAR;
		}		
	}
}
void output_testmode()
{
	if(test_mode_ssid_condition==ON)
	{
		if(test_mode_ssid_no==1)
		ELECTRIC_HEATER_ON;
		else if(test_mode_ssid_no==2)
		GAS_BURNER_ON;
		else if(test_mode_ssid_no==3)
		STEAM_VALVE_ON;
		else if(test_mode_ssid_no==4)
		MOTOR_FWD_ON;
		else if(test_mode_ssid_no==5)
		MOTOR_REV_ON;
		else if(test_mode_ssid_no==6)
		ALARM_ON;
		else if(test_mode_ssid_no==7)
		SUPPRESSION_VALVE_ON;
		else if(test_mode_ssid_no==8)
		BLOWER_ON;
		else if(test_mode_ssid_no==9)
		COOLING_FAN_ON;
	}
	else if(test_mode_ssid_condition==OFF)
	{
		if(test_mode_ssid_no==1)
		ELECTRIC_HEATER_OFF;
		else if(test_mode_ssid_no==2)
		GAS_BURNER_OFF;
		else if(test_mode_ssid_no==3)
		STEAM_VALVE_OFF;
		else if(test_mode_ssid_no==4)
		MOTOR_FWD_OFF;
		else if(test_mode_ssid_no==5)
		MOTOR_REV_OFF;
		else if(test_mode_ssid_no==6)
		ALARM_OFF;
		else if(test_mode_ssid_no==7)
		SUPPRESSION_VALVE_OFF;
		else if(test_mode_ssid_no==8)
		BLOWER_OFF;
		else if(test_mode_ssid_no==9)
		COOLING_FAN_OFF;
	}
}
void beeper()
{
	
}