const unsigned char err_mesg[][16] = 
{
     /// 0123456789ABCDEF
	 " ACT1 MOVING UP ",			/* 01 */
	 " ACT1 MOVING DN ",			/* 02 */
	 " ACT2 MOVING FWD",			/* 03 */
	 "ACT2 MOVING REVS",			/* 04 */
	 "   TUMBLER ON   ",			/* 05 */
	 "   SPITOON ON   ",            /* 06 */
	 "    X-RAY ON    ",           	/* 07 */
	 "    LAMP ON     ",            /* 08 */
	 " PROGRAM1 SAVED ",			/* 09 */
	 " PROGRAM2 SAVED ",			/* 0A */
	 "   ZERO SAVED   ",			/* 0B */
	 "  GAUGLE SAVED  ",			/* 0C */
	 " TUMBLER SAVED  ",			/* 0D */
	 " SPITOON SAVED  ",			/* 0E */
	 "   FOOT MODE    ",			/* 0F */
	 "   HAND MODE    ",			/* 10 */
	 "  MTR FWD MODE  ",			/* 11 */ 
	 "  MTR REV MODE  ",         	/* 12 */
	 "  ZERO WORKING  ",            /* 13 */
	 "PROGRAM1 WORKING",			/* 14 */
	 "PROGRAM2 WORKING",			/* 15 */
	 " GAUGLE WORKING ",			/* 16 */
	 "ACT1 PULSE ERROR",			/* 17 */
	 "ACT2 PULSE ERROR",			/* 18 */
	 "   AEROTOR ON   ",			/* 19 */
	 "   SHARK SAVED  ",			/* 1A */
	 "  SHARK WORKING ",			/* 1B */
	 " PROGRAM3 SAVED ",			/* 1C */
     "PROGRAM3 WORKING",			/* 1D */
};

const unsigned char lcdcode[][16] = 
{
//	  0123456789ABCDEF
	"  CHESA CARBON  ",			/* 01 */
};

const unsigned char rotate_mesg[][36] = 
{ 
// 	123456789ABCDEFHIJKLMNOPQRSTUVWXYZ
   "     WELCOME TO CHESA DENTAL     " 
};