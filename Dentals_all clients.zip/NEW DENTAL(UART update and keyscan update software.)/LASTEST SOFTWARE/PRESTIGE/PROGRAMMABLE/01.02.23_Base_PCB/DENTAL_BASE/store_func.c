#include "sfr_r825.h"
#include "cstartdef.h" 
#include "xvariables.h"
#include "macro.h"

void eeprom_waiting();
void store_function();
void eeprom_write(unsigned char,unsigned char);  
void delay(unsigned char dly);
unsigned char eeprom_read(unsigned char address);
_Bool read_iic(unsigned char, unsigned char);
_Bool write_iic(unsigned char, unsigned char);

_Bool eeprom_write_ok,eeprom_reed_ok;
unsigned int b,ep,eeprom_write_time_out;

void store_function()
{
	if(eeram_tumbler_save_flag)
	{
		temp_eeram_tumbler_prgm_on_delay=eeram_tumbler_prgm_on_delay;
		delay(0x02);
		eeprom_write(eeprom_tumbler_adrs_one,temp_eeram_tumbler_prgm_on_delay);
		temp_eeram_tumbler_prgm_on_delay=temp_eeram_tumbler_prgm_on_delay>>8;
		delay(0x02);
		eeprom_write(eeprom_tumbler_adrs_two,temp_eeram_tumbler_prgm_on_delay);
		eeram_tumbler_save_flag=CLEAR;
	}
	if(eeram_gaugle_save_flag)
	{
		temp_eeram_gaugle_prgm_on_delay=eeram_gaugle_fwd_rev_counter;
		delay(0x02);
		eeprom_write(eeprom_gaugle_dis_adrs_one,temp_eeram_gaugle_prgm_on_delay);
		temp_eeram_gaugle_prgm_on_delay=temp_eeram_gaugle_prgm_on_delay>>8;
		delay(0x02);
		eeprom_write(eeprom_gaugle_dis_adrs_two,temp_eeram_gaugle_prgm_on_delay);
		eeram_gaugle_save_flag=CLEAR;
	}
	if(eeram_spit_save_flag)
	{
		temp_eeram_spit_prgm_on_delay=eeram_spit_prgm_on_delay;
		delay(0x02);
		eeprom_write(eeprom_spit_adrs_one,temp_eeram_spit_prgm_on_delay);
		temp_eeram_spit_prgm_on_delay=temp_eeram_spit_prgm_on_delay>>8;
		delay(0x02);
		eeprom_write(eeprom_spit_adrs_two,temp_eeram_spit_prgm_on_delay);
		eeram_spit_save_flag=CLEAR;
	}
	if(eeram_pgm1_save_flag)
	{
		temp_eeram_pgm1_fwd_rev_counter=eeram_pgm1_fwd_rev_counter;		
		eeprom_write(eeprom_prog1_fwd_bak_adrs_one,temp_eeram_pgm1_fwd_rev_counter);
		delay(0x02);
		temp_eeram_pgm1_fwd_rev_counter=temp_eeram_pgm1_fwd_rev_counter>>8;		
		eeprom_write(eeprom_prog1_fwd_bak_adrs_two,temp_eeram_pgm1_fwd_rev_counter);
		delay(0x02);
		temp_eeram_pgm1_up_down_counter1=eeram_pgm1_up_down_counter1;
		eeprom_write(eeprom_prog1_up_dn_adrs_one,temp_eeram_pgm1_up_down_counter1);		
		delay(0x02);
		temp_eeram_pgm1_up_down_counter1=temp_eeram_pgm1_up_down_counter1>>8;
		eeprom_write(eeprom_prog1_up_dn_adrs_two,temp_eeram_pgm1_up_down_counter1);
		eeram_pgm1_save_flag=CLEAR;
	}
	if(eeram_pgm2_save_flag)
	{
		temp_eeram_pgm2_fwd_rev_counter=eeram_pgm2_fwd_rev_counter;		
		eeprom_write(eeprom_prog2_fwd_bak_adrs_one,temp_eeram_pgm2_fwd_rev_counter);
		temp_eeram_pgm2_fwd_rev_counter=temp_eeram_pgm2_fwd_rev_counter>>8;
		delay(0x02);
		eeprom_write(eeprom_prog2_fwd_bak_adrs_two,temp_eeram_pgm2_fwd_rev_counter);
		delay(0x02);
		temp_eeram_pgm2_up_down_counter1=eeram_pgm2_up_down_counter1;
		eeprom_write(eeprom_prog2_up_dn_adrs_one,temp_eeram_pgm2_up_down_counter1);		
		delay(0x02);
		temp_eeram_pgm2_up_down_counter1=temp_eeram_pgm2_up_down_counter1>>8;
		eeprom_write(eeprom_prog2_up_dn_adrs_two,temp_eeram_pgm2_up_down_counter1);
		eeram_pgm2_save_flag=CLEAR;
	}
	if(eeram_pgm3_save_flag)
	{
		temp_eeram_pgm3_fwd_rev_counter=eeram_pgm3_fwd_rev_counter;		
		eeprom_write(eeprom_prog3_fwd_bak_adrs_one,temp_eeram_pgm3_fwd_rev_counter);
		delay(0x02);
		temp_eeram_pgm3_fwd_rev_counter=temp_eeram_pgm3_fwd_rev_counter>>8;		
		eeprom_write(eeprom_prog3_fwd_bak_adrs_two,temp_eeram_pgm3_fwd_rev_counter);
		delay(0x02);
		temp_eeram_pgm3_up_down_counter1=eeram_pgm3_up_down_counter1;
		eeprom_write(eeprom_prog3_up_dn_adrs_one,temp_eeram_pgm3_up_down_counter1);
		delay(0x02);
		temp_eeram_pgm3_up_down_counter1=temp_eeram_pgm3_up_down_counter1>>8;		
		eeprom_write(eeprom_prog3_up_dn_adrs_two,temp_eeram_pgm3_up_down_counter1);
		eeram_pgm3_save_flag=CLEAR;
	}
/*	if(eeram_zero_save_flag)
	{
		temp_eeram_zero_fwd_rev_counter=eeram_zero_fwd_rev_counter;
		delay(0x02);
		eeprom_write(eeprom_zero_fwd_bak_adrs_one,temp_eeram_zero_fwd_rev_counter);
		temp_eeram_zero_fwd_rev_counter=temp_eeram_zero_fwd_rev_counter>>8;
		delay(0x02);
		eeprom_write(eeprom_zero_fwd_bak_adrs_two,temp_eeram_zero_fwd_rev_counter);
		delay(0x02);
		temp_eeram_zero_up_down_counter1=eeram_zero_up_down_counter1;
		eeprom_write(eeprom_zero_up_dn_adrs_one,temp_eeram_zero_up_down_counter1);
		delay(0x02);
		temp_eeram_zero_up_down_counter1=temp_eeram_zero_up_down_counter1>>8;		
		eeprom_write(eeprom_zero_up_dn_adrs_two,temp_eeram_zero_up_down_counter1);
		eeram_zero_save_flag=CLEAR;
	}
	if(eeram_shark_save_flag)
	{
		temp_eeram_shark_fwd_rev_counter=eeram_shark_fwd_rev_counter;
		delay(0x02);
		eeprom_write(eeprom_shark_fwd_bak_adrs_one,temp_eeram_shark_fwd_rev_counter);
		temp_eeram_shark_fwd_rev_counter=temp_eeram_shark_fwd_rev_counter>>8;
		delay(0x02);
		eeprom_write(eeprom_shark_fwd_bak_adrs_two,temp_eeram_shark_fwd_rev_counter);
		delay(0x02);
		temp_eeram_shark_up_down_counter1=eeram_shark_up_down_counter1;
		eeprom_write(eeprom_shark_up_dn_adrs_one,temp_eeram_shark_up_down_counter1);
		delay(0x02);
		temp_eeram_shark_up_down_counter1=temp_eeram_shark_up_down_counter1>>8;		
		eeprom_write(eeprom_shark_up_dn_adrs_two,temp_eeram_shark_up_down_counter1);
		eeram_shark_save_flag=CLEAR;
	}*/
}
void eeprom_write(unsigned char address, unsigned char datas)
{
	/*tmp_var = datas;	//value to write in eeprom
	ram_addr = &tmp_var;
	disp_addr = address;	//write at 0th address
	write_iic(EEPROM_WRITE,1);*/
	for(ep=0;ep<=20;ep++)
	{
		eeprom_write_time_out=20;
		do
		{
			tmp_var = datas;	//value to write in eeprom
			ram_addr = &tmp_var;
			disp_addr = address;	//write at 0th address
			eeprom_write_ok=write_iic(EEPROM_WRITE,1);
			/*if(disp_addr<=255)
			{
				eeprom_write_ok=write_iic(EEPROM_WRITE,1);
			}
			else
			{
				disp_addr = address-255;
				eeprom_write_ok=write_iic(EEPROM_WRITE_ADR_p0,1);
			}	*/		
			eeprom_delay = 100;//500;//1000;	//100usec isr
			eeprom_waiting();
			eeprom_write_time_out--;	
		}
		while((!eeprom_write_ok)AND(eeprom_write_time_out));	
		tmp_var=0;
		for(b = 0; b < 30 ; b++)
		{
			tmp_var = 0;	//clear that variable
			ram_addr = &tmp_var;
			disp_addr = address;	//read at 0th address
			eeprom_reed_ok=read_iic(EEPROM_READ,1);
			/*if(disp_addr<=255)
			{
				eeprom_reed_ok=read_iic(EEPROM_READ,1);
			}
			else
			{
				disp_addr = address-255;
				eeprom_reed_ok=read_iic(EEPROM_READ_ADR_p0,1);
			}*/
			eeprom_delay = 50;//250;//500;	//100usec isr
			eeprom_waiting();			
			if(eeprom_reed_ok)
			break;	
		}	
		if(tmp_var==datas)
		{
			ep=100;
			break;
		}
	}			
}
unsigned char eeprom_read(unsigned char address)
{
	/*tmp_var = 0;	//clear that variable
	ram_addr = &tmp_var;
	disp_addr = address;	//read at 0th address
	read_iic(EEPROM_READ,1);		
	return(tmp_var);*/
	for(b = 0; b < 30 ; b++)
	{
		tmp_var = 0;	//clear that variable
		ram_addr = &tmp_var;
		disp_addr = address;	//read at 0th address
		eeprom_reed_ok=read_iic(EEPROM_READ,1);
		/*if(disp_addr<=255)
		{
			eeprom_reed_ok=read_iic(EEPROM_READ,1);
		}
		else
		{
			disp_addr = address-255;
			eeprom_reed_ok=read_iic(EEPROM_READ_ADR_p0,1);
		}*/
		eeprom_delay = 100;//600;//500;	//100usec isr
		eeprom_waiting();			
		if(eeprom_reed_ok)
		break;	
	}				
	return(tmp_var);
	
}

void eeprom_waiting()
{
	while(eeprom_delay > 0)
	{
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");	
	}
}
void delay(unsigned char dly)
{
	wait_delay=dly;	
	while(wait_delay);	
}
