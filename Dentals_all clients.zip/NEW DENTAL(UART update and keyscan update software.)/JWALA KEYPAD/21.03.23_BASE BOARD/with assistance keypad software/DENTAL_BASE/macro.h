
#define NOP  asm("nop")


/*********DEFINITION***********/
#define SET	1
#define CLEAR	0
#define HIGH	1
#define LOW	0
#define ON 	1
#define OFF 	0
#define AND 	&&
#define OR 	||
#define EQUAL_TO ==
#define NOT_EQUAL_TO !=



/*****     TIME DELAY     *******/
#define FIVE_HUN_MS		     20		//	10
#define FIVE_SECONDS		 100
#define THREE_SECONDS_DELAY	 3000


#define FOOT_INPUT    		p0_1//p0_0
#define FOOT_PORT   		p0
#define ASSISTANCE_PORT     p3
#define UP_ACTUATOR 		p2_6//p2_7
#define DWN_ACTUATOR 		p2_7//p2_6
#define FWD_ACTUATOR 		p2_5//p2_5//p2_4
#define REV_ACTUATOR 		p2_4//p2_4//p2_5

#define UP_ACTUATOR_OFF		UP_ACTUATOR=OFF
#define UP_ACTUATOR_ON		UP_ACTUATOR=ON

#define DWN_ACTUATOR_ON		DWN_ACTUATOR=ON
#define DWN_ACTUATOR_OFF 	DWN_ACTUATOR=OFF

#define FWD_ACTUATOR_ON		FWD_ACTUATOR=ON
#define FWD_ACTUATOR_OFF 	FWD_ACTUATOR=OFF

#define REV_ACTUATOR_ON 	REV_ACTUATOR=ON
#define REV_ACTUATOR_OFF	REV_ACTUATOR=OFF

#define LAMP_LOW			p2_0
#define LAMP_LOW_ON			LAMP_LOW=1
#define LAMP_LOW_OFF		LAMP_LOW=0

#define LAMP_HIGH			p2_1
#define LAMP_HIGH_ON		LAMP_HIGH=1
#define LAMP_HIGH_OFF		LAMP_HIGH=0

#define TUMBLER				p2_2
#define TMBLR_ON			TUMBLER=1
#define TMBLR_OFF			TUMBLER=0

#define SPITOON				p2_3
#define SPITOON_ON			SPITOON=1
#define SPITOON_OFF			SPITOON=0

#define READ_PULSE1			p1_7
#define READ_PULSE2			p4_5

#define TE_RE_EN			p6_3
#define TE_RE_EN_LOW		TE_RE_EN=0
#define TE_RE_EN_HIGH		TE_RE_EN=1

#define BUZZER				p1_0
#define BUZZER_ON			BUZZER=ON
#define BUZZER_OFF			BUZZER=OFF

#define INDICATOR			p6_2
#define INDICATOR_ON		INDICATOR=ON
#define INDICATOR_OFF		INDICATOR=OFF

#define LAMP_SENSOR 		p0_7


/*************************EEPROM ADDRESS***********************/
#define EEPROM_WRITE   		0xa6
#define EEPROM_READ    		0Xa7
/***************************i2c********************************/
#define SCL					p6_5	
#define SDA					p6_4


//***********eeprom address PROG 1****************//
#define eeprom_prog1_fwd_bak_adrs_one		0X00
#define eeprom_prog1_fwd_bak_adrs_two		0X01
		
#define eeprom_prog1_up_dn_adrs_one			0X03
#define eeprom_prog1_up_dn_adrs_two			0X04

//***********eeprom address PROG 2****************//
#define eeprom_prog2_fwd_bak_adrs_one		0X05
#define eeprom_prog2_fwd_bak_adrs_two		0X06
		
#define eeprom_prog2_up_dn_adrs_one			0X07
#define eeprom_prog2_up_dn_adrs_two			0X08

//***********eeprom address ZERO****************//

#define eeprom_zero_fwd_bak_adrs_one		0X09
#define eeprom_zero_fwd_bak_adrs_two		0X0A

#define eeprom_zero_up_dn_adrs_one			0X0B
#define eeprom_zero_up_dn_adrs_two			0X0C

//***********TUMBLER****************//
#define eeprom_tumbler_adrs_one				0X0D
#define eeprom_tumbler_adrs_two				0X0E

//***********SPITOON****************//
#define eeprom_spit_adrs_one				0X0F
#define eeprom_spit_adrs_two				0X10

//***********GAUGLE****************//
#define eeprom_gaugle_dis_adrs_one			0X11
#define eeprom_gaugle_dis_adrs_two			0X12

//***********FORWARD BACKWARD****************//
#define eeprom_fwd_rev_dis_adrs_one			0X13
#define eeprom_fwd_rev_dis_adrs_two			0X14

//***********UP DOWN****************//
#define eeprom_up_dn_dis_adrs_one			0X15
#define eeprom_up_dn_dis_adrs_two			0X16

//***********eeprom address SHARK****************//
#define eeprom_shark_up_dn_adrs_one			0X17
#define eeprom_shark_up_dn_adrs_two			0X18

#define eeprom_shark_fwd_bak_adrs_one		0X19
#define eeprom_shark_fwd_bak_adrs_two		0X1A

//***********eeprom address PROG 3****************//
#define eeprom_prog3_fwd_bak_adrs_one		0X1B
#define eeprom_prog3_fwd_bak_adrs_two		0X1C
		
#define eeprom_prog3_up_dn_adrs_one			0X1D
#define eeprom_prog3_up_dn_adrs_two			0X1E

//***************position of actuators ***************//

#define eeprom_fwd_rev_actuator_position_one	0X1F
#define eeprom_fwd_rev_actuator_position_two	0X20

#define eeprom_up_dwn_actuator_position_one1	0x21
#define eeprom_up_dwn_actuator_position_two		0x23

/*****************************************************/

/****  KEY_STAUS_DATA crowndend***/

/*#define TUMB_SW_KEY				0x00100000
#define SPIT_SW_KEY				0x00040000
#define ZERO_SW_KEY				0x00004000
#define GARGLE_SW_KEY			0x00000400
#define SHARK_SW_KEY			0x00000100
#define PGM1_SW_KEY				0x01ffef23
#define PGM2_SW_KEY				0x00010000
#define PGM3_SW_KEY				0x00000800
#define LAMP_SW_KEY				0x00000020
#define ACT_FWD_KEY				0x00000002
#define ACT_REV_KEY				0x00000200
#define ACT_UP_KEY				0x01ff6f63
#define ACT_DWN_KEY				0x00002000*/

/****  KEY_STAUS_DATA Chesa JWALA keypad***/

#define TUMB_SW_KEY				0x00002000	//0x00800000
#define SPIT_SW_KEY				0x00000800	//0x00000004
#define ZERO_SW_KEY				0x00001000	//0x00000008
#define GARGLE_SW_KEY			0x00400000	//NOT USING for the JWALA KEYPAD
//#define SHARK_SW_KEY			0x00000000	//NOT USING for the JWALA KEYPAD
#define PGM1_SW_KEY				0x00000010	//NOT USING for the JWALA KEYPAD
#define PGM2_SW_KEY				0x00040000	//NOT USING for the JWALA KEYPAD
//#define PGM3_SW_KEY			0x00000040	//NOT USING for the JWALA KEYPAD
#define LAMP_SW_KEY				0x00000400	//0x80000000
#define ACT_FWD_KEY				0x00040000	//0x00000020
#define ACT_REV_KEY				0x00000010	//0x10000000
#define ACT_UP_KEY				0x00200000	//0x20000000
#define ACT_DWN_KEY				4			//0x00200000

/**********************ASSISTANT_KEYDATA***************/
#define ASST_TUMBLER_KEY		0x88
#define ASST_SPITOON_KEY		0x18
#define ASST_ZERO_KEY			0x90
#define ASST_ACTUP_KEY			0x08
#define ASST_ACTDWN_KEY			0x20
#define ASST_ACTFWD_KEY			0x80
#define ASST_ACTREV_KEY			0x10

#define KEYPAD_DATA 			0xFCFCFC	//0xF8F494BC				