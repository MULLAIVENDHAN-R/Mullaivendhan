#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include "X_variables.h"


void heart_beat();

void heart_beat();