#include "sfr_r825.h"
#include "macro.h"
#include "xvariables.h"

void delay1(unsigned char);
void lcd_write(unsigned char,unsigned char);
void four_bit_init(unsigned char);
void display_data(unsigned char, unsigned char);
void delay(unsigned char dly);

void init_lcd()
{
	delay(0xff);
	delay(0xff);
	four_bit_init(0x03);//function set(46 page)
	delay(0xff);
	four_bit_init(0x03);//function set(")
	delay(0x04);		// 4
	four_bit_init(0x02);	//set interface to 4 bit
	delay(0x04);		// 4
	lcd_write(INST,0x28);//function set 28 page
	delay(0x04);		// 4
	lcd_write(INST,0x08);//disp on see 28 page;
	delay(0x04);		// 4
	lcd_write(INST,0x01);//clear disp 28 page
	delay(0x04);		// 4
	lcd_write(INST,0x06);//entry mode 28 page
	delay(0x04);		// 4
	lcd_write(INST,0x0f);//display curser (dt)
	delay(0x04);		// 4 4

}

void lcd_write(unsigned char x, unsigned char y)
{
	unsigned char temp1,temp2;
	if(x==1)
	{
		RS = 1;//instruction reg for write&data reg for read;
	}
	else
	{
		RS = 0;//data reg for read and write;
	}
	temp3 = 0;
	temp3 = (y)|0x0f;
	temp1 = temp3&0xf0;
	temp2 = LCD_PORT;
	temp2 = temp2&0x0f;
	LCD_PORT = (temp1|temp2);
	ENABLE = HIGH;
	

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	
	ENABLE = LOW;
	temp3 = 0;
	temp3 = (y&0x0f)|0xf0;
	//lcd_change();
	temp1 = temp3&0x0f;
	temp1 = temp1<<4;
	temp2 = LCD_PORT;
	temp2 = temp2&0x0f;
	LCD_PORT = (temp1|temp2);
	ENABLE = HIGH;						
	

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	ENABLE = LOW;
}

void delay1(unsigned char dly)
{
	unsigned char A;
	while(dly)
	{		
		A = 0x01;		// 01
		while(A)
		{			
			A--;
		}
		dly--;
	}
}


void four_bit_init(unsigned char temp)
{
	unsigned char temp1,temp2;

	RS = 0;
	temp3 = 0;
	temp3 = temp;            //chg1
	temp1 = temp3&0x0f;	// chg2
	temp1 = (temp1<<4);	

	temp2 = LCD_PORT;
	temp2 = temp2&0x0f;
	LCD_PORT = temp1|temp2;
	ENABLE = HIGH;	
	

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	asm ("NOP");
	asm ("NOP");
	asm ("NOP");

	ENABLE = LOW;
}


void delay(unsigned char dly)
{
	unsigned char A;
	while(dly)
	{		
		A = 0xff;
		while(A)
		{
			A--;
		}
		dly--;
		
	}
}