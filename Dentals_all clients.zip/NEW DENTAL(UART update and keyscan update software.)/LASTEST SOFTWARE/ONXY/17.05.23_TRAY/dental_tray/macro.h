
#define NOP  asm("nop")


/*********DEFINITION***********/
#define SET	1
#define CLEAR	0
#define HIGH	1
#define LOW	0
#define ON 	1
#define OFF 	0
#define AND 	&&
#define OR 	||
#define EQUAL_TO ==
#define NOT_EQUAL_TO !=

#define TEST_MODE		0

# define VERIFY			1
# define CALCULATE		0
/*****     TIME DELAY     *******/
#define FIVE_HUN_MS		     10		//	10
#define FIVE_SECONDS		 100
#define ONE_SECONDS_DELAY	 60

/********  For LCD display  ****/
#define RS					p2_3		
#define ENABLE				p2_2
#define INST				0		
#define RAM					1
#define LCD_PORT 			p2

#define INIT_FUNC_SET 		0x30
#define FUNCTION_SET	 	0x20
#define DISP_ON 			0x08
#define CLEAR_DISP			0x01
#define ENTRY_MODE			0x04
#define DISP_CURS_ON		0x0F

#define CURSOR_OFF			0x0C

#define DDRAM_ADDR_2		0x80
#define DDRAM_ADDR_1		0x88
#define DDRAM_ADDR_3		0XC8
#define DDRAM_ADDR_4		0XC0


//#define CLK		 			p0_4
//#define SHLD				p0_5
//#define FNL_SER_OP			p0_6
//#define STROBE  			p0_7
#define HEF4094_CLK    		p1_0
//#define FOOT_LED 		 	p1_1
#define I2C_DATA			p1_2
#define TE_RE_EN 			p1_3
#define TX1 				p1_4
#define RX1 			 	p1_5
#define IRQ 			 	p1_7
#define B_LED9 			 	p3_0
//#define LED_DATA			p6_4
//#define SSI			 		p3_3
//#define CS			 		p3_4
//#define SCK			 		p3_5
#define SSO 			 	p3_7
#define I2C_CLK 			p4_5


#define MTR_ENABLE_ON     	p3_0=0//p0_0=0
#define MTR_ENABLE_OFF     	p3_0=1//p0_0=1

#define MTR_REV_ON			p1_1=1
#define MTR_REV_OFF			p1_1=0

#define MTR_FWD_ON 			p1_2=1
#define MTR_FWD_OFF 		p1_2=0

#define SCALER_ON  		 	p6_2=1//p0_3=1
#define SCALER_OFF  		p6_2=0//p0_3=0

#define XRAY_ON				p1_0=1//p6_1=1
#define XRAY_OFF			p1_0=0//p6_1=0
#define XRAY				p1_0//p6_1

#define AEROTER_OFF		 	p3_1=0//p6_2=0
#define AEROTER_ON		 	p3_1=1//p6_2=1
#define AEROTER		 		p3_1	//p6_2

#define TE_RE_EN			p1_3
#define TE_RE_EN_LOW		p1_3=LOW
#define TE_RE_EN_HIGH		p1_3=HIGH

#define MTR_ENABLE     	    p3_0//p0_0
#define FWD_REV_SW 		 	p2_1
#define PWM					p2_0
//#define FOOT_LED 		 	p1_1
#define SCREEN_ENABLE       p1_7

#define TX 			 		p6_6
#define RX 					p6_7



/*******  MUXTIPLUX **********/
#define LED_KEY_COTROL_PORT		p0

#define KEY_SENSE		p3_7=0
#define LED_OUTPUT		p3_7=1

#define KEY_SENSE_INIT		pd0=0X00
#define LED_OUTPUT_INIT		pd0=0xff

#define COM_KEY1_ON		p6_5=1
#define COM_KEY2_ON		p6_4=1
#define COM_KEY3_ON		p6_3=1

#define COM_KEY1_OFF	p6_5=0
#define COM_KEY2_OFF	p6_4=0
#define COM_KEY3_OFF	p6_3=0

#define COM_KEY4_ON		p3_5=1
#define COM_LED2_ON		p3_3=1//p3_4=1
#define COM_LED3_ON		p3_4=1//p3_3=1

#define COM_KEY4_OFF	p3_5=0
#define COM_LED2_OFF	p3_3=0//p6_4=0
#define COM_LED3_OFF	p3_4=0//p3_3=0


#define LED_COM1_ON					p0_0=1//led_data[0]=led_data[0]|(0X01)
#define LED_COM2_ON					p0_1=1//led_data[1]=led_data[1]|(0X02)

#define LED_COM1_OFF				p0_0=0//led_data[0]=led_data[0]&(~0X01)
#define LED_COM2_OFF				p0_1=0//led_data[1]=led_data[1]&(~0X02)

#define ON_OFF_LED_OFF				led_data[1]=led_data[1]|(0X10)
#define LAMP_LED_OFF				led_data[1]=led_data[1]|(0X04)
#define TUMBLER_LED_OFF				led_data[1]=led_data[1]|(0X80)
#define SPITOON_LED_OFF				led_data[0]=led_data[0]|(0X04)//(0X04)
#define XRAY_LED_OFF				led_data[0]=led_data[0]|(0X08)
#define SIGNAL_LED_OFF				led_data[1]=led_data[1]|(0X20)
#define	AEROTER_LED_OFF				led_data[0]=led_data[0]|(0X40)

	

#define ON_OFF_LED_ON				led_data[1]=led_data[1]&(~0X10)
#define LAMP_LED_ON					led_data[1]=led_data[1]&(~0X04)
#define TUMBLER_LED_ON				led_data[1]=led_data[1]&(~0X80)
#define SPITOON_LED_ON				led_data[0]=led_data[0]&(~0X04)//(~0X04)
#define XRAY_LED_ON					led_data[0]=led_data[0]&(~0X08)
#define SIGNAL_LED_ON				led_data[1]=led_data[1]&(~0X20)
#define	AEROTER_LED_ON				led_data[0]=led_data[0]&(~0X40)
//#define LED7_OFF			led_data[0]=led_data[0]&(~0X40)
//#define LED8_OFF			led_data[0]=led_data[0]&(~0X80)

//#define LED7_ON				led_data[0]=led_data[0]|(0X40)
//#define LED8_ON				led_data[0]=led_data[0]|(0X80)

/*#define LED9_ON				led_data[1]=led_data[1]|(0X01)
#define LED10_ON			led_data[1]=led_data[1]|(0X02)
#define LED11_ON			led_data[1]=led_data[1]|(0X04)
#define LED12_ON			led_data[1]=led_data[1]|(0X08)
#define LED13_ON			led_data[1]=led_data[1]|(0X10)
#define LED14_ON			led_data[1]=led_data[1]|(0X20)
#define LED15_ON			led_data[1]=led_data[1]|(0X40)
#define LED16_ON			led_data[1]=led_data[1]|(0X80)

#define LED17_ON			led_data[2]=led_data[2]|(0X01)
#define LED18_ON			led_data[2]=led_data[2]|(0X02)
#define LED19_ON			led_data[2]=led_data[2]|(0X04)
#define LED20_ON			led_data[2]=led_data[2]|(0X08)
#define LED21_ON			led_data[2]=led_data[2]|(0X10)
#define LED22_ON			led_data[2]=led_data[2]|(0X20)
#define LED23_ON			led_data[2]=led_data[2]|(0X40)
#define LED24_ON			led_data[2]=led_data[2]|(0X80)


#define ON_OFF_LED_OFF			led_data[0]=led_data[0]&(~0X01)
#define LAMP_LED_OFF			led_data[0]=led_data[0]&(~0X02)
#define TUMBLER_LED_OFF			led_data[0]=led_data[0]&(~0X04)
#define SPITOON_LED_OFF			led_data[0]=led_data[0]&(~0X08)
#define XRAY_LED_OFF			led_data[0]=led_data[0]&(~0X10)
#define SIGNAL_LED_OFF			led_data[0]=led_data[0]&(~0X20)
#define LED7_OFF			led_data[0]=led_data[0]&(~0X40)
#define LED8_OFF			led_data[0]=led_data[0]&(~0X80)

#define LED9_OFF			led_data[1]=led_data[1]&(~0X01)
#define LED10_OFF			led_data[1]=led_data[1]&(~0X02)
#define LED11_OFF			led_data[1]=led_data[1]&(~0X04)
#define LED12_OFF			led_data[1]=led_data[1]&(~0X08)
#define LED13_OFF			led_data[1]=led_data[1]&(~0X10)
#define LED14_OFF			led_data[1]=led_data[1]&(~0X20)
#define LED15_OFF			led_data[1]=led_data[1]&(~0X40)
#define LED16_OFF			led_data[1]=led_data[1]&(~0X80)

#define LED17_OFF			led_data[2]=led_data[2]&(~0X01)
#define LED18_OFF			led_data[2]=led_data[2]&(~0X02)
#define LED19_OFF			led_data[2]=led_data[2]&(~0X04)
#define LED20_OFF			led_data[2]=led_data[2]&(~0X08)
#define LED21_OFF			led_data[2]=led_data[2]&(~0X10)
#define LED22_OFF			led_data[2]=led_data[2]&(~0X20)
#define LED23_OFF			led_data[2]=led_data[2]&(~0X40)
#define LED24_OFF			led_data[2]=led_data[2]&(~0X80)*/


//#define EX1			 		p6_4

/*******  ALL LED MACRO **********/


#define LED_O/P_VARIABLE_ALL_OFF           0X00FFF7FF

/*********BAR LED***********/
#define BAR_LED_ONE_ON          	led_op_variable=led_op_variable&(~0x00000001);
#define BAR_LED_ONE_OFF 			led_op_variable=led_op_variable|(0x00000001);

#define	BAR_LED_TWO_ON				led_op_variable=led_op_variable&(~0x00000002);
#define	BAR_LED_TWO_OFF				led_op_variable=led_op_variable|(0x00000002);

#define	BAR_LED_THREE_ON			led_op_variable=led_op_variable&(~0x00000004);
#define BAR_LED_THREE_OFF			led_op_variable=led_op_variable|(0x00000004);

#define	BAR_LED_FOUR_ON				led_op_variable=led_op_variable&(~0x00000008);
#define	BAR_LED_FOUR_OFF			led_op_variable=led_op_variable|(0x00000008);

//#define	ON_OFF_LED_ON				led_op_variable=led_op_variable&(~0x00000010);
//#define ON_OFF_LED_OFF				led_op_variable=led_op_variable|(0x00000010);

#define BAR_LED_FIVE_ON 			led_op_variable=led_op_variable&(~0x00000020);
#define BAR_LED_FIVE_OFF			led_op_variable=led_op_variable|(0x00000020);

#define	BAR_LED_SIX_ON				led_op_variable=led_op_variable&(~0x00000040);
#define	BAR_LED_SIX_OFF				led_op_variable=led_op_variable|(0x00000040);

#define	BAR_LED_SEVEN_ON			led_op_variable=led_op_variable&(~0x00000080);
#define	BAR_LED_SEVEN_OFF			led_op_variable=led_op_variable|(0x00000080);

/********OTHER_LED**********************/

//#define	SPITOON_LED_ON				led_op_variable=led_op_variable&(~0x00080000);	
//#define SPITOON_LED_OFF				led_op_variable=led_op_variable|(0x00080000);

#define PROGRAM2_LED_ON				led_op_variable=led_op_variable&(~0x00000200);
#define PROGRAM2_LED_OFF			led_op_variable=led_op_variable|(0x00000200);

#define	GARGLE_LED_ON				led_op_variable=led_op_variable&(~0x00000400);
#define	GARGLE_LED_OFF				led_op_variable=led_op_variable|(0x00000400);

#define PROGRAM1_LED_ON	 			led_op_variable=led_op_variable&(~0x00004000);
#define PROGRAM1_LED_OFF			led_op_variable=led_op_variable|(0x00004000);

//#define LAMP_LED_ON					led_op_variable=led_op_variable&(~0x00002000);
//#define LAMP_LED_OFF				led_op_variable=led_op_variable|(0x00002000);

//#define TUMBLER_LED_ON				led_op_variable=led_op_variable&(~0x00001000);
//#define TUMBLER_LED_OFF				led_op_variable=led_op_variable|(0x000001000);

#define	SHARK_LED_ON				led_op_variable=led_op_variable&(0xffff7fff);
#define	SHARK_LED_OFF				led_op_variable=led_op_variable|(0x00008000);

#define	PROGRAM3_LED_ON				led_op_variable=led_op_variable&(~0x00010000);	
#define	PROGRAM3_LED_OFF			led_op_variable=led_op_variable|(0x00010000);

//#define	SIGNAL_LED_ON				led_op_variable=led_op_variable&(~0x00020000);
//#define	SIGNAL_LED_OFF				led_op_variable=led_op_variable|(0x00020000);

#define	MAIN_LED_ON					led_op_variable=led_op_variable&(~0x00040000);
#define	MAIN_LED_OFF				led_op_variable=led_op_variable|(0x00040000);

//#define	AEROTER_LED_ON				led_op_variable=led_op_variable&(~0x00000100);
//#define	AEROTER_LED_OFF				led_op_variable=led_op_variable|(0x00000100);	

#define	MTR_FWD_LED_ON				led_op_variable=led_op_variable&(~0x00100000);
#define	MTR_FWD_LED_OFF				led_op_variable=led_op_variable|(0x00100000);

#define	MTR_REV_LED_ON				led_op_variable=led_op_variable&(~0x00200000);
#define	MTR_REV_LED_OFF				led_op_variable=led_op_variable|(0x00200000);

#define	HAND_LED_ON					led_op_variable=led_op_variable&(~0x00400000);
#define	HAND_LED_OFF				led_op_variable=led_op_variable|(0x00400000);

//#define	XRAY_LED_ON					led_op_variable=led_op_variable&(~0x00800000);
//#define	XRAY_LED_OFF				led_op_variable=led_op_variable|(0x00800000);

//#define	FOOT_LED_ON 				p1_1=0;
//#define	FOOT_LED_OFF				p1_1=1;

#define BAR_LED_ALL_OFF				led_op_variable=led_op_variable|(0x000000EF);
//#define PREV_VALUE					led_op_variable=led_op_variable|(0x000000EF);

/* ERROR ID */
#define ACT_MOV_UP				0x01	//0...	
#define ACT_MOV_DOWN			0x02	//1...
#define ACT_MOV_FORWARD			0x03	//2...
#define ACT_MOV_REVERSE			0x04	//3...
#define TMBLR_ON				0x05	//4...
#define SPIT_ON					0x06	//5...
#define X_RAY_ON				0x07	//6...
#define LAMP_ON					0x08	//7...
#define PROG1_SAVED				0x09	//8...
#define PROG2_SAVED				0x0A	//9...
#define ZERO_PGM_SAVED			0x0B	//10...
#define GAUGLE_SAVED			0x0C	//11...
#define TUMBLER_SAVED			0x0D	//12...
#define SPITOON_SAVED			0X0E	//13...
#define FOOT_MODE				0X0F	//14...
#define HAND_MODE				0X10	//15...
#define MTR_FW_MODE				0X11	//16...
#define MTR_REV_MODE			0X12	//17...
#define ZERO_PGM_RUNNING		0X13	//18...
#define PROGRAM1_RUNNING		0X14	//19...
#define PROGRAM2_RUNNING		0X15	//20...
#define GAUGLE_RUNNING			0X16	//21...
#define ACT1_PULSE_ERROR		0x17	//22
#define ACT2_PULSE_ERROR		0x18	//23
#define AEROTOR_ON				0x19	//24
#define SHARK_SAVED				0X1A	//25
#define SHARK_RUNNING			0X1B	//26
#define PROG3_SAVED				0X1C	//27
#define PROGRAM3_RUNNING		0X1D	//28...

/******** DISP_ID *******/
#define  DENTAL_PROJECT            0X01  //1


#define KEYPAD_DATA 0xF8F494BC

/****  KEY_STAUS_DATA ***/

#define ON_OFF_KEY				0X00001000
#define INC_SW_KEY				0X00000400
#define DEC_SW_KEY				0X00008000
#define HAND_FOOR_KEY			0X00000080
#define FWD_REV_KEY				0X00100000
#define XRAY_SW_KEY				0X08000000
#define AERO_SW_KEY				0X40000000
#define TUMB_SW_KEY				8
#define SPIT_SW_KEY				9
#define ZERO_SW_KEY				10
#define GARGLE_SW_KEY			11
#define SHARK_SW_KEY			12
#define PGM1_SW_KEY				13
#define PGM2_SW_KEY				14
#define PGM3_SW_KEY				15
#define LAMP_SW_KEY				16
#define ACT_FWD_KEY				17
#define ACT_REV_KEY				18
#define ACT_UP_KEY				19
#define ACT_DWN_KEY				20			