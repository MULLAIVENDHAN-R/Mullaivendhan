-------- PROJECT GENERATOR --------
PROJECT NAME :	dental_tray
PROJECT DIRECTORY :	D:\sundar\DENT_FLOW\software\dental_tray\dental_tray
CPU SERIES :	R8C/Tiny
CPU GROUP :	25
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.01
GENERATION FILES :
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\typedefine.h
        define scalar types.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\resetprg.c
        initialize for C language.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\resetprg.h
        include some headder files.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\initsct.c
        initialize each sections.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\initsct.h
        define the macro for initialization of sections.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\fvector.c
        define the fixed vector table.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\intprg.c
        define the top address of the interrupt vectors.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\sfr_r825.h
        define the sfr register. (for C language)
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\sfr_r825.inc
        define the sfr register. (for Assembler language)
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\heap.c
        define the size of heap.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\dental_tray.c
        main program file.
    D:\sundar\DENT_FLOW\software\dental_tray\dental_tray\cstartdef.h
        define the size of stack.

SELECT TARGET :
    M16C R8C Simulator
    R8C E8a SYSTEM
DATE & TIME : 9/21/2012 12:47:54 AM
