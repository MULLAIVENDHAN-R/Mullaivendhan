#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include <stdio.h> 

extern __boolean is_valid_data(unsigned char received_buf[],char);
extern void form_send_buf(char,char);
extern void err_resend_fun();
extern void gui_uart_send();
extern void io_status_fun();
extern void temp_update_to_display();
extern void manual_operate_ops();
extern void io_on_off_check();
void rtc_data_splitup();
static unsigned int test,current_baking_time,remaining_time; 
char* temp=0; 
void process_buf_splitup()
{
	received_app_id=app_id;
	received_fun_id=fun_id;
	if((!resend_flag)AND(!frame_err_flag))
	{
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==HANDSHAKE_RES_FUN_ID))
		{
			frame_err_flag=(process_data_buf[DATA]=='D')?is_valid_data(process_data_buf,DISPLAY_READY_DATA):1;
			if(!frame_err_flag)
			{
				handshake_ok_flag=SET;
				form_send_buf(COMMAND_RES,HANDSHAKE_DATA);
			}
		}
		if((received_app_id==BOOTING_TIME_APP_ID)AND(received_fun_id==HEART_BEAT_FUN_ID))
		{
			frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
			if(!frame_err_flag)
			{
				ack_ok_flag=SET;
				waiting_for_ack_flag=CLEAR;
				uart_driver_reset_flag=CLEAR,resend_cnt=0;
			}			
		}
	}
	if((!resend_flag)AND(handshake_ok_flag)AND(!frame_err_flag))
	{
		switch(received_app_id)
		{
			case BAKING_TIME_APP_ID:
							switch(received_fun_id)
							{
								case PROCESS_START_FUN_ID:
											if(process_data_buf[DATA]=='S')
											{
												frame_err_flag=(process_data_buf[DATA]=='S')?is_valid_data(process_data_buf,START_DATA):1;
												if(!frame_err_flag)
												{	
													DOOR_STATUS_APPID_FUNID;
													if(!door_switch_close_flag)
													form_send_buf(COMMAND_RES,CLOSE_DATA);
													else
													form_send_buf(COMMAND_RES,OPEN_DATA);											
													err_occured_flag=CLEAR;
												}
											}
											else if(process_data_buf[DATA]=='A')
											{
												frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
												if(!frame_err_flag)
												{
													ack_ok_flag=SET;
													waiting_for_ack_flag=CLEAR;
													uart_driver_reset_flag=CLEAR,resend_cnt=0;
												}
											}
											else
											frame_err_flag=SET;
											break;
								case PROCESS_DATA_FUN_ID:
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(step_no==0)
											{
												if(!mix_start_flag)
												{
													mix_start_flag=SET;
													temp_low_speed_timing=(unsigned long int)(low_speed_timing)*(1000);
													temp_high_speed_timing=(unsigned long int)(high_speed_timing)*(1000);												
													step_no=1;
													direction_change_flag=SET;
												}
											}
											else
											{
												mix_start_flag=SET;
												temp_low_speed_timing=(unsigned long int)(low_speed_timing)*(1000);
												temp_high_speed_timing=(unsigned long int)(high_speed_timing)*(1000);												
											}
											break;
								case DATA_ACK_FUN_ID	:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;								
								case PROCESS_STOP_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='S')?is_valid_data(process_data_buf,STOP_DATA):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);												
												temp_high_speed_timing=temp_low_speed_timing=0;
												mix_stop_flag=SET;
												mix_start_flag=CLEAR;
											}
											break;
								case DONE_ACK_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
								case UPDATE_DATA_FUN_ID:
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(!door_switch_close_flag)
											{
												if(mix_start_flag)
												{
													if((high_time_minus_data_flag)OR(low_time_minus_data_flag))
													{
														if(low_time_minus_data_flag)
														{
															low_time_minus_data_flag=0;
															temp_low_speed_timing-=(unsigned long int)(low_speed_timing)*(1000);
														}
														else if(high_time_minus_data_flag)
														{
															high_time_minus_data_flag=0;
															temp_high_speed_timing-=(unsigned long int)(high_speed_timing)*(1000);	
														}
														step_no=1;
													}
													else
													{
														temp_low_speed_timing+=(unsigned long int)(low_speed_timing)*(1000);
														temp_high_speed_timing+=(unsigned long int)(high_speed_timing)*(1000);												
														step_no=1;													
													}
												}
											}
											else
											{
												DOOR_STATUS_APPID_FUNID;
												form_send_buf(COMMAND_RES,OPEN_DATA);												
											}
											break;
								case PROCESS_COMPLETE_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='C')?is_valid_data(process_data_buf,COMPLETE_DATA):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);												
											}
											break;
								case ERR_AT_PROCESS_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
								case POPUP_CLOSED_ACK_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;			
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
												err_popup_closed_flag=SET;
											}
											break;
								case POPUP_CLOSED_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='E')?is_valid_data(process_data_buf,ERR_CLOSED_DATA):1;
											if(!frame_err_flag)
											{
												//BUZZER_OFF;
												//BUZZER_OP_OFF;											
												form_send_buf(COMMAND_RES,ACK_DATA);
												err_popup_closed_flag=SET;
											}
											break;
								case RESUME_PROCESS_FUN_ID:
											
											mix_start_flag=SET;
											if(low_speed_timing)
											{
												temp_high_speed_timing=(unsigned long int)(high_speed_timing)*(1000);											
												temp_low_speed_timing=(unsigned long int)(low_speed_timing)*(1000);
												step_no=1;
												direction_change_flag=SET;
											}											
											else
											{
												temp_high_speed_timing=(unsigned long int)(high_speed_timing)*(1000);	
												step_no=3;
												direction_change_flag=SET;
											}
											form_send_buf(COMMAND_RES,ACK_DATA);		//ack for new resume data after power came
											received_app_id=0X02;
											received_fun_id=0X02;
											form_send_buf(COMMAND_RES,ACK_DATA);		//ack for old process data before power off
											break;
											
								case PRCS_DIR_FUN_ID:		
											if(process_data_buf[0]!=0)
											{												
												direction=atoi(process_data_buf);
												direction_change_flag=SET;
											}
											else
											frame_err_flag=SET;
											if(!frame_err_flag)
											form_send_buf(COMMAND_RES,ACK_DATA);
											break;
											
								case PRCS_RESTART_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='R')?is_valid_data(process_data_buf,PROCESS_RESTART_DATA):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);
												restart_set_flag=CLEAR;
												step_no=1;
												direction_change_flag=SET;
											}								
											break;
							}
							break;
			case SETTINGS_APP_ID	:
							switch(received_fun_id)
							{
								case IO_STATUS_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='I')?is_valid_data(process_data_buf,IO_STATUS_DATA):1;
											if(!frame_err_flag)
											io_status_fun();
											break;
								case IO_CHECK_FUN_ID:	
											form_send_buf(COMMAND_RES,ACK_DATA);
											outputs=process_data_buf[DATA];
											status=process_data_buf[DATA+1];
											io_manual_check_flag=SET;											
											break;
								case WATER_FLOW_FUN_ID:
											form_send_buf(COMMAND_RES,ACK_DATA);
								break;
							}
							break;
			case ERROR_APP_ID:
							switch(received_fun_id)
							{
								case ERR_AT_IDLE_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
							}
							break;
			case MESSAGE_POPUP_APP_ID:
							switch(received_fun_id)
							{
								 case EMER_POPUP_ACK_FUN_ID:
								 			frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
											if(!frame_err_flag)
											{
												ack_ok_flag=SET;
												waiting_for_ack_flag=CLEAR;
												uart_driver_reset_flag=CLEAR,resend_cnt=0;
											}
											break;
								 case ALERT_POPUP_FUN_ID:
											frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ALERT_POPUP_MSG):1;
											if(!frame_err_flag)
											{
												form_send_buf(COMMAND_RES,ACK_DATA);																								
											}
											break;
							}
							break;
			case IOT_SEND_DATA_APP_ID:
							if(IOT_SEND_DATA_FUN_ID==received_fun_id)
							{
								frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
								if(!frame_err_flag)
								{
									ack_ok_flag=SET;
									waiting_for_ack_flag=CLEAR;
									uart_driver_reset_flag=CLEAR,resend_cnt=0;
								}
							}
							break;
			case HIGHSPEED_DATA_APP_ID:
							if(HIGHSPEED_PROCESS_DATA_FUN_ID==received_fun_id)
							{
								frame_err_flag=(process_data_buf[DATA]=='H')?is_valid_data(process_data_buf,HIGHSPEED_KEY_DATA):1;
								if(!frame_err_flag)
								{
									temp_low_speed_timing=0;
									form_send_buf(COMMAND_RES,ACK_DATA);
								}
							}
							else if((HIGHSPEED_N_PRO_START_DATA_FUN_ID==received_fun_id))  // holding start data
							{
								if((!high_speed_on_flag)AND(!high_speed_off_flag))
								{
									temp= strtok(process_data_buf, "|");
									direction=atoi(temp);
									temp=strtok(NULL, "|");
									strcpy(process_data_buf, temp);
									frame_err_flag=(process_data_buf[DATA]=='S')?is_valid_data(process_data_buf,START_DATA):1;
									if(!frame_err_flag)
									{
										form_send_buf(COMMAND_RES,ACK_DATA);
										if(door_switch_close_flag)
										{
											high_speed_on_flag=SET;						
										}
									}
								}
							}
							else if((HIGHSPEED_N_PRO_STP_DATA_FUN_ID==received_fun_id))   // holding stop data
							{
								frame_err_flag=(process_data_buf[DATA]=='S')?is_valid_data(process_data_buf,STOP_DATA):1;
								if(!frame_err_flag)
								{
									
									if((!high_speed_on_flag)AND(!high_speed_off_flag))
									{
										if(door_switch_close_flag)
										high_speed_off_flag=SET;
										form_send_buf(COMMAND_RES,ACK_DATA);
									}
								}
							}							
		
		break;	
		
		case SCREEN_FRZ_DATA_APP_ID:
						frame_err_flag=(process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,ACK_DATA):1;
						if(!frame_err_flag)
						{
							ack_ok_flag=SET;
							waiting_for_ack_flag=CLEAR;
							uart_driver_reset_flag=CLEAR,resend_cnt=0;
						}		
		break;
		}
	}	
	if(frame_err_flag)
	{
		resend_flag=SET;
		waiting_for_ack_flag=SET,resend_cnt=0;
		frame_err_flag=CLEAR;
	}
	app_id=fun_id=0;
	ack_ok_flag=CLEAR;
}
