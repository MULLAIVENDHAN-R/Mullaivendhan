extern const unsigned char err_mesg[][16];
extern const unsigned char lcdcode[][16];
extern const unsigned char rotate_mesg[][36];