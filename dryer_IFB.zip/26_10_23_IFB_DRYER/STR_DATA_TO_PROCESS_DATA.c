#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include "string.h"
#include <stdlib.h>
#include "X_variables.h"

char temp_string[10];
unsigned char
pipe_symbol_came,

no_of_steps,
direction,
no_of_steps;

extern unsigned char
temp_send_buf[MAX_SIZE_RX_BUF];

unsigned int
factory_setting_id_no,

step_1_timing,
step_2_timing,
step_3_timing,
step_4_timing,
step_5_timing,
step_1_fwd_direction_on_time,
step_2_fwd_direction_on_time,
step_3_fwd_direction_on_time,
step_4_fwd_direction_on_time,
step_5_fwd_direction_on_time,
step_1_rev_direction_on_time,
step_2_rev_direction_on_time,
step_3_rev_direction_on_time,
step_4_rev_direction_on_time,
step_5_rev_direction_on_time,
step_1_pause_time,
step_2_pause_time,
step_3_pause_time,
step_4_pause_time,
step_5_pause_time,
step_1_set_temp,
step_2_set_temp,
step_3_set_temp,
step_4_set_temp,
step_5_set_temp,
step_1_set_humidity,
step_2_set_humidity,
step_3_set_humidity,
step_4_set_humidity,
step_5_set_humidity,
step_1_rpm_value,
step_2_rpm_value,
step_3_rpm_value,
step_4_rpm_value,
step_5_rpm_value,
split_value,
step_1_split_value,
step_2_split_value,
step_3_split_value,
step_4_split_value,
step_5_split_value,
step_1_direction,
step_2_direction,
step_3_direction,
step_4_direction,
step_5_direction;

static __boolean 
string_process_data_flag;

void str_to_process_data( char str[],unsigned char app,unsigned char fun);
void  get_process_steps_values(unsigned char steps);
extern void uart_process_data(char , char);
extern void frame_send_data(char ,char ,char ,char );
extern void str_process_data();
extern void send_step(); 

void reload_process_cycle_values();

void str_to_process_data(char str[],unsigned char app,unsigned char fun)
{
	
	unsigned char i,j,byte=0;	
	
	pipe_symbol_came=0;
	for(i=0,j=0;i<strlen(str)+1;i++)
	{		
		if((str[i]!='|')AND(str[i]!=':')AND(i!=(strlen(str))))
			temp_string[j++]= str[i];		
		else
		{	
			pipe_symbol_came++;
			str_process_data(app,fun);
			memset(temp_string,0,sizeof(temp_string));
			j=0;
		}
	}		
}
void str_process_data(unsigned char string_app_id,unsigned char string_fun_id)
{	
	switch(string_app_id)
	{
 		case PROCESS_DATA_APP_ID:
		
				switch(string_fun_id)						
				{					
					case DATA_ACK_FUN_ID:
								if(pipe_symbol_came==1)
								{
									if(strcmp(temp_string,"S1")==0)
									no_of_steps=1;
									else if(strcmp(temp_string,"S2")==0)
									no_of_steps=2;
									else if(strcmp(temp_string,"S3")==0)
									no_of_steps=3;
									else if(strcmp(temp_string,"S4")==0)
									no_of_steps=4;
									else if(strcmp(temp_string,"S5")==0)
									no_of_steps=5;									
									
								}
								else if(pipe_symbol_came==2)
								{	
									if(no_of_steps==1)
									step_1_timing=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_timing=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_timing=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_timing=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_timing=atoi(temp_string);
								}
								else if(pipe_symbol_came==3)
								{									
									if(no_of_steps==1)
									step_1_fwd_direction_on_time=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_fwd_direction_on_time=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_fwd_direction_on_time=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_fwd_direction_on_time=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_fwd_direction_on_time=atoi(temp_string);									
								}	
								else if(pipe_symbol_came==4)
								{
									if(no_of_steps==1)
									step_1_rev_direction_on_time=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_rev_direction_on_time=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_rev_direction_on_time=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_rev_direction_on_time=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_rev_direction_on_time=atoi(temp_string);	
								}								
								else if(pipe_symbol_came==5)
								{
									if(no_of_steps==1)
									step_1_pause_time=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_pause_time=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_pause_time=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_pause_time=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_pause_time=atoi(temp_string);	
								}
								else if(pipe_symbol_came==6)
								{
									if(no_of_steps==1)
									step_1_set_temp=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_set_temp=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_set_temp=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_set_temp=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_set_temp=atoi(temp_string);	
								}
								else if(pipe_symbol_came==7)
								{
									if(no_of_steps==1)
									step_1_rpm_value=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_rpm_value=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_rpm_value=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_rpm_value=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_rpm_value=atoi(temp_string);	
								}
								else if(pipe_symbol_came==8)
								{
									if(no_of_steps==1)
									step_1_set_humidity=atoi(temp_string);
									else if(no_of_steps==2)
									step_2_set_humidity=atoi(temp_string);
									else if(no_of_steps==3)
									step_3_set_humidity=atoi(temp_string);
									else if(no_of_steps==4)
									step_4_set_humidity=atoi(temp_string);
									else if(no_of_steps==5)
									step_5_set_humidity=atoi(temp_string);	
								}								
								else if(pipe_symbol_came==9)
								{
									if(strcmp(temp_string,"0")==0)
									split_value=COOLING;
									else if(strcmp(temp_string,"1")==0)
									split_value=HEATING;
									
									if(no_of_steps==1)
									step_1_split_value=split_value;
									else if(no_of_steps==2)
									step_2_split_value=split_value;
									else if(no_of_steps==3)
									step_3_split_value=split_value;
									else if(no_of_steps==4)
									step_4_split_value=split_value;
									else if(no_of_steps==5)
									step_5_split_value=split_value;										
								}								
							 	else if(pipe_symbol_came==10)
								{
									if(strcmp(temp_string,"0")==0)
									direction=UNI_D;
									else if(strcmp(temp_string,"1")==0)
									direction=BI_D;
									
									if(no_of_steps==1)
									step_1_direction=direction;
									else if(no_of_steps==2)
									step_2_direction=direction;
									else if(no_of_steps==3)
									step_3_direction=direction;
									else if(no_of_steps==4)
									step_4_direction=direction;
									else if(no_of_steps==5)
									step_5_direction=direction;	
									pipe_symbol_came=0;
								}
					break;						
				}		 
		break;	
		case SETTING_APP_ID:			
				 if(string_fun_id==FACTOR_SETTING_ACK_FUN_ID)
				 {	
					 if(pipe_symbol_came==1)
					 {
						 factory_setting_id_no=atoi(temp_string);
					 }
					 else if(pipe_symbol_came==2)
					 {
						if(factory_setting_id_no==1)
						Heater_type=atoi(temp_string);
						
						else if(factory_setting_id_no==2)	
						Heater_error_time_limit=atoi(temp_string);
						
						else if(factory_setting_id_no==3)
						Reset_temperature=atoi(temp_string);
						
						else if(factory_setting_id_no==4)
						High_temperature_tolerance=atoi(temp_string);
						
						else if(factory_setting_id_no==5)
						Motor_pully_to_main_pulley_ratio=atof(temp_string);
						
						else if(factory_setting_id_no==6)
						Maximum_speed_contol_fz=atoi(temp_string);
						
						else if(factory_setting_id_no==7)
						motor_nominal_speed_50hz=atoi(temp_string);
						
						else if(factory_setting_id_no==8)
						Standard_speed_for_maximum_frequency=atoi(temp_string);
						
						else if(factory_setting_id_no==9)
						standard_motor_frequnecy=atoi(temp_string);
						
						pipe_symbol_came=0;
					 }
				 }						
		break;
		case OUTPUT_APP_ID:
				if(string_fun_id==OUTPUT_ON_OFF_ACK_FUN_ID)
				{
					if(pipe_symbol_came==1)							
						test_mode_ssid_no=atoi(temp_string);
					
					else if(pipe_symbol_came==2)
					{
						if(strcmp(temp_string,"0")==0)								
						test_mode_ssid_condition=OFF;
						else if(strcmp(temp_string,"1")==0)
						test_mode_ssid_condition=ON;
						pipe_symbol_came=0;								
					}					
				}
				break;
	
	}
}

void get_process_steps_values(unsigned char steps)
{
	
	if(!first_time_load_flag)
	{
		first_time_load_flag=SET;
		total_no_of_steps=no_of_steps;
		steps++;
	}	
	if((total_no_of_steps>0)AND(first_time_load_flag))
	{
		switch(steps)
		{
			case STEP_1:				
				steps_timing=step_1_timing*MINITUES;			
				motor_fwd_on_time=step_1_fwd_direction_on_time*MILI_SECOND;
				motor_rev_on_time=step_1_rev_direction_on_time*MILI_SECOND;
				motor_rev_pause_time=motor_fwd_pause_time=step_1_pause_time*MILI_SECOND;
				set_temperature=step_1_set_temp;
				set_rpm=step_1_rpm_value;
				set_humidity=step_1_set_humidity;
				set_splits=step_1_split_value;
				set_direction=step_1_direction;				
				steps++;				
				break;
			case STEP_2:
				steps_timing=step_2_timing*MINITUES;			
				motor_fwd_on_time=step_2_fwd_direction_on_time*MILI_SECOND;
				motor_rev_on_time=step_2_rev_direction_on_time*MILI_SECOND;
				motor_rev_pause_time=motor_fwd_pause_time=step_2_pause_time*MILI_SECOND;
				set_temperature=step_2_set_temp;
				set_rpm=step_2_rpm_value;
				set_humidity=step_2_set_humidity;
				set_splits=step_2_split_value;
				set_direction=step_2_direction;				
				steps++;				
				break;
			case STEP_3:
				steps_timing=step_3_timing*MINITUES;			
				motor_fwd_on_time=step_3_fwd_direction_on_time*MILI_SECOND;
				motor_rev_on_time=step_3_rev_direction_on_time*MILI_SECOND;
				motor_rev_pause_time=motor_fwd_pause_time=step_3_pause_time*MILI_SECOND;
				set_temperature=step_3_set_temp;
				set_rpm=step_3_rpm_value;
				set_humidity=step_3_set_humidity;
				set_splits=step_3_split_value;
				set_direction=step_3_direction;				
				steps++;				
			break;
			case STEP_4:
				steps_timing=step_4_timing*MINITUES;			
				motor_fwd_on_time=step_4_fwd_direction_on_time*MILI_SECOND;
				motor_rev_on_time=step_4_rev_direction_on_time*MILI_SECOND;
				motor_rev_pause_time=motor_fwd_pause_time=step_4_pause_time*MILI_SECOND;
				set_temperature=step_4_set_temp;
				set_rpm=step_4_rpm_value;
				set_humidity=step_4_set_humidity;
				set_splits=step_4_split_value;
				set_direction=step_4_direction;				
				steps++;				
			break;
			case STEP_5:
				steps_timing=step_5_timing*MINITUES;			
				motor_fwd_on_time=step_5_fwd_direction_on_time*MILI_SECOND;
				motor_rev_on_time=step_5_rev_direction_on_time*MILI_SECOND;
				motor_rev_pause_time=motor_fwd_pause_time=step_5_pause_time*MILI_SECOND;
				set_temperature=step_5_set_temp;
				set_rpm=step_5_rpm_value;
				set_humidity=step_5_set_humidity;
				set_splits=step_5_split_value;
				set_direction=step_5_direction;				
				steps++;				
			break;			
				
		}
		cycle=steps;
		send_step();
		
		
	}	
}
void reload_process_cycle_values()
{				
	if(STEP_1==cycle-1)
	{
		motor_fwd_on_time=step_1_fwd_direction_on_time*MILI_SECOND;
		motor_rev_on_time=step_1_rev_direction_on_time*MILI_SECOND;
		motor_rev_pause_time=motor_fwd_pause_time=step_1_pause_time*MILI_SECOND;		
	}
	else if(STEP_2==cycle-1)
	{
		motor_fwd_on_time=step_2_fwd_direction_on_time*MILI_SECOND;
		motor_rev_on_time=step_2_rev_direction_on_time*MILI_SECOND;
		motor_rev_pause_time=motor_fwd_pause_time=step_2_pause_time*MILI_SECOND;		
	}
	else if(STEP_3==cycle-1)
	{
		motor_fwd_on_time=step_3_fwd_direction_on_time*MILI_SECOND;
		motor_rev_on_time=step_3_rev_direction_on_time*MILI_SECOND;
		motor_rev_pause_time=motor_fwd_pause_time=step_3_pause_time*MILI_SECOND;		
	}
	else if(STEP_4==cycle-1)
	{
		motor_fwd_on_time=step_4_fwd_direction_on_time*MILI_SECOND;
		motor_rev_on_time=step_4_rev_direction_on_time*MILI_SECOND;
		motor_rev_pause_time=motor_fwd_pause_time=step_4_pause_time*MILI_SECOND;		
	}
	else if(STEP_5==cycle-1)
	{
		motor_fwd_on_time=step_5_fwd_direction_on_time*MILI_SECOND;
		motor_rev_on_time=step_5_rev_direction_on_time*MILI_SECOND;
		motor_rev_pause_time=motor_fwd_pause_time=step_5_pause_time*MILI_SECOND;		
	}
}
	
	