#ifndef DATA_ARRAY_H
#define DATA_ARRAY_H

char *send_string_data[]={
			"ACK",
			"HANDSHAKE",
			"DISPLAY READY",
			"DONE",
			"STOP",
			"START",
			"RQT"
			};
						
#endif