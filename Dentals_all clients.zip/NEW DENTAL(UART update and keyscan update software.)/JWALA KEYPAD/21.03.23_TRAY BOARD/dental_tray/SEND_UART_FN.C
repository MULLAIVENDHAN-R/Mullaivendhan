#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"

void serial_sendbyte1();
void serial_sendbyte2();
void calculate_crc_1(void);

void serial_sendbyte1()
{	
//	p6_1=!p6_1;
//	ti_u1c1=1;	
	for(j=0;j<7;j++)
	{
		while(ti_u1c1==0);
		u1tb = char_buffer2[j];	//Wait until buffer becomes empty
	}
//	ti_u1c1=0;			
}

void serial_sendbyte2()
{	
//	p6_1=!p6_1;
//	ti_u1c1=1;	
	for(j=0;j<7;j++)
	{
		while(ti_u1c1==0);
		u1tb = char_buffer3[j];	//Wait until buffer becomes empty
	}
//	ti_u1c1=0;			
}


void calculate_crc(void)
{
	crc = 0xffff;
	temp = packet_length;      // to calculate the crc for data for transmission
	for(array_index=0; array_index<temp;array_index++)
	{
		asm ("NOP");
		//if(!uart_receive_input_flag)
		byte = char_buffer2[array_index];
		//else
		//byte = send_buff[array_index];
		for(bit_counter=0;bit_counter<8;bit_counter++) 
		{
			tmp_crc = ((crc>>15) ^ (byte>>7));	//temp is now MSB of crc XOR�ed with MSB of byte.
			crc<<=1; //left shift one space
			if(tmp_crc)
			{
         		crc ^=  0x1021;
			}
			byte<<=1;
		}
	}
	//if(!uart_receive_input_flag)
	{
		char_buffer2[packet_length] = crc;      // LSB of crc
		char_buffer2[packet_length+1] = crc>>8; // MSB of crc
	}
	/*else
	{
		send_buff[packet_length] = crc;      // LSB of crc
		send_buff[packet_length+1] = crc>>8; // MSB of crc
	}*/
}

void calculate_crc_1(void)
{
	crc = 0xffff;
	temp = packet_length;      // to calculate the crc for data for transmission
	for(array_index=0; array_index<temp;array_index++)
	{
		asm ("NOP");
		/*if(!uart_receive_input_flag)
		byte = char_buffer2[array_index];
		else*/
		byte = send_buff[array_index];
		for(bit_counter=0;bit_counter<8;bit_counter++) 
		{
			tmp_crc = ((crc>>15) ^ (byte>>7));	//temp is now MSB of crc XOR�ed with MSB of byte.
			crc<<=1; //left shift one space
			if(tmp_crc)
			{
         		crc ^=  0x1021;
			}
			byte<<=1;
		}
	}
	/*if(!uart_receive_input_flag)
	{
		char_buffer2[packet_length] = crc;      // LSB of crc
		char_buffer2[packet_length+1] = crc>>8; // MSB of crc
	}
	else*/
	{
		send_buff[packet_length] = crc;      // LSB of crc
		send_buff[packet_length+1] = crc>>8; // MSB of crc
	}
}


_Bool check_crc(void)
{
	crc = 0xffff;
	temp_vaa = 5;
	for(array_index=0; array_index<temp_vaa;array_index++)
	{
		asm ("NOP");
		if(!touch_receive_flag)
		byte = char_buffer[array_index];
		else
		byte = char_buffer1[array_index];
		for(bit_counter=0;bit_counter<8;bit_counter++) 
		{
			tmp_crc = ((crc>>15) ^ (byte>>7));	//temp is now MSB of crc XOR�ed with MSB of byte.
			crc<<=1; //left shift one space
			if(tmp_crc)
			{
         		crc ^=  0X1021;
			}
			byte<<=1;
		}
	}
	//HTPIC has litte endian ie LSB is right side
	if(!touch_receive_flag)
	{
		tmp_crc = char_buffer[temp_vaa+1];  // MSB of received crc
		tmp_crc<<=8;
		tmp_crc = ((tmp_crc)|(char_buffer[temp_vaa]));  // LSB of received crc
	}
	else
	{
		tmp_crc = char_buffer1[temp_vaa+1];  // MSB of received crc
		tmp_crc<<=8;
		tmp_crc = ((tmp_crc)|(char_buffer1[temp_vaa]));  // LSB of received crc
	}
			
	if(tmp_crc EQUAL_TO crc)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}

