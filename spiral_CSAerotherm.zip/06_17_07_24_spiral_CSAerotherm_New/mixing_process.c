#include "r_cg_macrodriver.h"
#include "Macros.h"

#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

void manual_operate_ops();
void io_on_off_check();
void err_occured();
void err_rectified();
void io_status_send_iot();
void heartBeat();
void direction_set( unsigned char );
void bowl_motor();

extern void sensor_open_close_conform();
extern void gui_uart_send();
extern void io_status_fun();
extern void form_send_buf(char,char);
extern void time_date_update();
extern void heartBeat();
extern void sendRTC();

unsigned char iot_compenent_name[10];
boolean iot_send_flag,fwd_rev_flag;

 
void Mixing_process()
{
	if((!door_switch_close_flag)AND(mix_start_flag))
	{		
		if((temp_low_speed_timing>0)OR(temp_high_speed_timing>0))
		{
			if((BOWL_ON_OFF_DELAY<=0))
			direction_set(direction);
				
			if(SPIRAL_ON_OFF_DELAY<=0)
			{
				switch(step_no)
				{
					case LOW_SPEED_ON:
							if(temp_low_speed_timing>0)
							{
								SPRIAL_SLOW_OP_ON;
								step_no=LOW_SPEED_OFF;
							}
							else if(temp_low_speed_timing<=0)
							{
								SPRIAL_SLOW_OP_OFF;
								step_no=HIGH_SPEED_ON;
							}
					break;
					case LOW_SPEED_OFF:
							if(temp_low_speed_timing<=0)
							{
								SPRIAL_SLOW_OP_OFF;
								step_no=HIGH_SPEED_ON;
							}								
					break;					
					case HIGH_SPEED_ON:
							if((temp_high_speed_timing>0)AND(temp_low_speed_timing<=0))
							{
								step_no=0;
								SPRIAL_HIGH_OP_ON;
							}							
							else if(temp_high_speed_timing<=0)
							{
								step_no=0;
								SPRIAL_HIGH_OP_OFF;
							}
					break;
					case HIGH_SPEED_OFF:
							if((temp_high_speed_timing<=0)AND(temp_low_speed_timing<=0))
							{								
								SPRIAL_HIGH_OP_OFF;
								step_no=0;
							}
					break;
				}	
			}
		}
		else if((mix_start_flag)AND(!mix_stop_flag))
		{
			temp_low_speed_timing=0;
			temp_high_speed_timing=0;
			temp_direction=0;
			BOWL_FWD_REV_OFF;	
			SPRIAL_OFF;
			DONE_APPID_FUNID;
			form_send_buf(COMMAND_RES,DONE_DATA);
			mix_start_flag=CLEAR;
			step_no=0;
		}		
	}
	else 
	{		
		if(mix_stop_flag)
		{
			
			BOWL_FWD_REV_OFF;	
			SPRIAL_OFF;				
			temp_low_speed_timing=0;
			temp_high_speed_timing=0;
			temp_direction=0;
			mix_stop_flag=CLEAR;
			step_no=0;
			restart_set_flag=CLEAR;
		}		
		if(io_manual_check_flag)
		{
			io_on_off_check();
			io_manual_check_flag=CLEAR;
		}
		bowl_motor();
	}
}
void direction_set( unsigned char DIR)
{
	if((!high_speed_on_flag)AND(!high_speed_off_flag)AND(direction_change_flag))    // process time
	{
		if((!restart_set_flag)AND(!err_occured_flag))
		{
			if(!fwd_rev_flag)
			{
				if((DIR==FWD)AND(BOWL_REV))
				BOWL_REV_OFF;
				else if((DIR==REV)AND(BOWL_FWD))
				BOWL_FWD_OFF;
				fwd_rev_flag=SET;
				
			}
			else if(fwd_rev_flag)
			{
				if((DIR==FWD)AND(!BOWL_FWD))
				BOWL_FWD_ON;
				else if((DIR==REV)AND(!BOWL_REV))
				BOWL_REV_ON;
				temp_direction=DIR;
				fwd_rev_flag=CLEAR;
				direction_change_flag=CLEAR;
			}
			
			
		}
	}
	else if((high_speed_on_flag)OR(high_speed_off_flag))					////  non process time
	{			
		if((DIR==FWD)AND(!BOWL_FWD))
		BOWL_FWD_ON;
		else if((DIR==REV)AND(!BOWL_REV))
		BOWL_REV_ON;
		temp_direction=DIR;		
	}
}
void bowl_motor()
{
	if((mix_start_flag)AND(BOWL_ON_OFF_DELAY<=0))
	{
		if((high_speed_on_flag)AND(!high_speed_off_flag))
		{
			temp_direction=0;
			direction_set(direction);
			high_speed_on_flag=CLEAR;		
		}
		else if((!high_speed_on_flag)AND(high_speed_off_flag))
		{
			BOWL_FWD_REV_OFF;
			high_speed_off_flag=CLEAR;
			temp_direction=0;
		}
	}
}
void io_status_fun()
{
	temp_send_buf[tx_data++]='I';
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((bowl_trip_switch_close_flag)+0X30);    // blow trip 
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((spiral_trip_switch_close_flag)+0X30);	//spiral trip
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((!door_switch_close_flag)+0X30);	 //limit switch
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((emergency_switch_close_flag)+0X30);	//emergency
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]='O';
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((SPRIAL_HIGH_OP)+0X30);   // spiral high speed
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((SPRIAL_SLOW_OP)+0X30);  // spiral low speed
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((BOWL_FWD)+0X30); //bowl forward
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((BOWL_REV)+0X30); // bowl reverse
	IO_STATUS_APPID_FUNID;
	form_send_buf(DATA_RES,tx_data);
	tx_data=0;
}
void io_status_send_iot()
{
	unsigned char temp_buf[10],M;
	if(iot_send_flag)
	{
		iot_send_flag=CLEAR;
		memset(temp_send_buf,0,sizeof(temp_send_buf));
		if(iot_compenent_name[0]==HIGH)
		{
			iot_compenent_name[0]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='2';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((1)+0X30);	//slow speed data
			
		}		
		else if(iot_compenent_name[1]==HIGH)
		{
			iot_compenent_name[1]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='3';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((1)+0X30);	//fast speed data
		}		
		else if(iot_compenent_name[2]==HIGH)
		{	
			iot_compenent_name[2]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='4';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((spiral_on_off_status)+0X30); //spiral_on_off_status
		}	
		else if(iot_compenent_name[3]==HIGH)
		{
			iot_compenent_name[3]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='5';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((bowl_on_off_status)+0X30);   //bowl on off condtion
		}				
		else if(iot_compenent_name[4]==HIGH)
		{
			iot_compenent_name[4]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='6';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((bowl_trip_switch_close_flag)+0X30);	//bowl trip
		}		
		else if(iot_compenent_name[5]==HIGH)
		{
			iot_compenent_name[5]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='7';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((emergency_switch_close_flag)+0X30);	//emerngy trip
		}		
		else if(iot_compenent_name[6]==HIGH)
		{
			iot_compenent_name[6]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='8';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((!door_switch_close_flag)+0X30);	//door switch
		}		
		else if(iot_compenent_name[7]==HIGH)
		{
			iot_compenent_name[7]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]='9';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((spiral_trip_switch_close_flag)+0X30);	//sprisl trip
		}
		if(temp_send_buf[1]!=0)
		{
			IOT_DATA_APPID_FUNID;
			form_send_buf(DATA_RES,tx_data);
		}
		tx_data=0;	
	}

}
void io_on_off_check()
{
	switch(outputs)
	{
		case BOWL_FWD_ON_OFF:	
					if(status==1)
					BOWL_FWD_ON;
					else
					BOWL_FWD_REV_OFF;					
					break;
		case BOWL_REV_ON_OFF:	
					if((status==1)OR(status==2))
					BOWL_REV_ON;
					else
					BOWL_FWD_REV_OFF;					
					break;				
					
		case SPRIAL_SLOW_ON_OFF:
					if(status==1)
					SPRIAL_SLOW_OP_ON;
					else
					SPRIAL_OFF;
					break;
					
		case  SPRIAL_HIGH_ON_OFF:
					if(status==1)
					SPRIAL_HIGH_OP_ON;
					else
					SPRIAL_HIGH_OP_OFF;
					break;	
		case BOWL_DIRECTION:	
					if(status==1)
					BOWL_FWD_ON;
					else if(status==2)
					BOWL_REV_ON;					
					break;				
					
					
					
	}
}
void trip_switches_condition()
{
	if(!restart_set_flag)
	{
		if(emergency_switch_close_flag)
		{
			if(!err_occured_flag)
			{
				if(!mix_start_flag)
				ERR_SEND_APPID_FUNID;
				else
				ERR_AT_PROCESS_APPID_FUNID;
				form_send_buf(COMMAND_RES,EMERGENCY_DATA);
				ALL_OUTPUTS_OFF;
				emergencyPressed_flag=SET;
				err_occured();			
			}
		}		
		else if(bowl_trip_switch_close_flag)
		{
			if(!err_occured_flag)
			{
				BOWL_FWD_REV_OFF;
				if(!mix_start_flag)
				ERR_SEND_APPID_FUNID;
				else
				ERR_AT_PROCESS_APPID_FUNID;
				form_send_buf(COMMAND_RES,BLOW_TRIP_DATA);
				err_occured();			
			}
		}
		else if(spiral_trip_switch_close_flag)
		{
			if(!err_occured_flag)
			{
				SPRIAL_HIGH_OP_OFF;
				SPRIAL_SLOW_OP_OFF;
				if(!mix_start_flag)
				ERR_SEND_APPID_FUNID;
				else
				ERR_AT_PROCESS_APPID_FUNID;
				form_send_buf(COMMAND_RES,SPIRAL_ERR_DATA);
				err_occured();			
			}	
		}
		else if((door_switch_close_flag)AND(mix_start_flag))
		{
			if((!err_occured_flag))
			{
				ERR_AT_PROCESS_APPID_FUNID;
				form_send_buf(COMMAND_RES,LIMIT_SWITCH_DATA);
				err_occured();			
			}	
		}		
		else
		err_rectified();
	}
}
void err_occured()
{
	err_occured_flag=SET;
	ALL_OUTPUTS_OFF;
	SCREEN_FREZZE_APPID_FUNID;
    	form_send_buf(COMMAND_RES,SCREEN_ON);
}
void err_rectified()
{
	if((err_occured_flag)AND(!restart_set_flag))
	{
		SCREEN_FREZZE_APPID_FUNID;
    		form_send_buf(COMMAND_RES,SCREEN_OFF);
		err_occured_flag=CLEAR;
		if(mix_start_flag)
		restart_set_flag=SET;
		ERR_CLOSED_APPID_FUNID;
		form_send_buf(COMMAND_RES,ERR_CLOSED_DATA);
	}else if((restart_set_flag)AND(mix_start_flag)AND(!err_occured_flag))
	restart_set_flag=CLEAR;
}
void handshake_ok()
{
	while(!handshake_ok_flag)	
	{
		gui_uart_send();
		sensor_open_close_conform();
	}
}
void heartBeat()
{
	if(heart_beat_send_flag)
    	{
	        heart_beat_send_flag=CLEAR;
	        HEART_BEAT_APPID_FUNID;
	        form_send_buf(COMMAND_RES,HEART_BEAT_DATA);
    	}
}