#include "GUI_Macros.h"

/***************************TIMER VAR*********************/
__boolean
heart_beat_send_flag;

unsigned char
one_sec_counter,
hundred_usec_sec_counter,
one_milli_sec_counter,
fifty_milli_sec_counter,
send_temp_with_delay_counter,
heart_beat_counter,
temp_on_delay,
buzzer_on_time;

/***************************TIMER VAR*********************/

/******************************EEPROM********************************/
__boolean
sda_status_flag,
clock_low_flag,
ack_received_flag;
unsigned char
settings[5],
dflt_value,
tmp_var,
received_data,
receive_bit_counter,
*ram_addr,
temp_pr[3];
unsigned int
temp_delay,
disp_addr,
acc;
/******************************EEPROM********************************/


/*************************PROCESS***************************/
__boolean

water_flow_flag,
restart_set_flag,
spiral_on_off_status,
bowl_on_off_status,

high_speed_on_flag,
high_speed_off_flag,

direction_change_flag,

spiral_high_on_flag,
spiral_low_on_flag,

emergencyPressed_flag,
io_manual_check_flag,
manual_opearate_flag,

time_is_over_flag,
err_occured_flag,
door_switch_closed_flag,
mix_start_flag,
mix_stop_flag,

err_popup_closed_flag,

direction_set_flag,

door_switch_close_flag,
emergency_switch_close_flag,
bowl_trip_switch_close_flag,
spiral_trip_switch_close_flag;

unsigned char
step_no,
outputs,
status,
temp_direction,
direction,
door_switch_open_conform_time,
door_switch_close_conform_time,

emergency_switch_open_conform_time,
emergency_switch_close_conform_time,

bowl_trip_switch_open_conform_time,
bowl_trip_switch_close_conform_time,


sprial_trip_switch_open_conform_time,
spiral_trip_switch_close_conform_time;

unsigned long int
temp_total_remaining_timing,
total_remaining_timing,
temp_high_speed_timing,
temp_low_speed_timing;

unsigned  int
water_flow[6],
BOWL_ON_OFF_DELAY,
SPIRAL_ON_OFF_DELAY,
high_speed_timing,
low_speed_timing;

/**************************PWM******************************/
__boolean
blower_pulse_on_flag;

unsigned char
BLOWER_ON_TIME,
BLOWER_OFF_TIME,
blower_motor_speed,
blower_pulse_counter;
/**************************PWM******************************/


/*********************SEND UART***************************/
unsigned char
tx_data,
temp_send_buf[MAX_SIZE_RX_BUF];

unsigned int
delay; 

/***********************TIMER VAR**************************/
__boolean
delayflag;
unsigned char
homeScreenDelay,
key_scan_delay_hm;