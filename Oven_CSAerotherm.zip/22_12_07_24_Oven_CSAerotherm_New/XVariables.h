#include "GUI_Macros.h"

extern unsigned int 
fuel_adc_result,
adc_result;

/***************************TIMER VAR*********************/
extern __boolean
heart_beat_send_flag;

extern unsigned char
one_sec_counter,
one_milli_sec_counter,
fifty_milli_sec_counter,
hundred_usec_sec_counter,
send_temp_with_delay_counter,
heart_beat_counter,
rtc_send_counter,
temp_on_delay,
buzzer_on_time;

/*******************************************RTC**********************************************/
extern __boolean
eeprom_store_flag,
timeDate_save_flag,
time_update_flag;

extern char
year,
receiveRTC[10],
read_rtc_buf[30],
write_rtc_buf[30];

/*******************************************RTC END**********************************************/


/******************************EEPROM********************************/
extern __boolean
sda_status_flag,
clock_low_flag,
ack_received_flag;
extern unsigned char
settings[5],
dflt_value,
tmp_var,
received_data,
receive_bit_counter,
*ram_addr,
temp_pr[3];
extern unsigned int
temp_delay,
disp_addr,
acc;
/******************************EEPROM********************************/


/*************************PROCESS***************************/
extern __boolean
output_mode_flag,
mqqt_test_mode_flag,
fuel_changed_flag,
fuel_adc_read_flag,
adc_read_flag,
emergencyPressed_flag,
io_manual_check_flag,
manual_opearate_flag,
time_is_over_flag,
door_switch_closed_flag,
bake_start_flag,
bake_stop_flag,
steam_release_flag,
temp_send_flag,
temp_changed_flag,
burner_on_flag,
door_switch_close_flag,
tt_switch_close_flag,
err_occured_flag,
blower_trip_switch_close_flag,
tt_trip_switch_close_flag,
thermo_trip_switch_close_flag,
burner_trip_switch_close_flag,
emergency_switch_close_flag,
tt_manual_switch_close_flag,
err_popup_closed_flag,
send_every_one_sec_flag;

extern unsigned char
step_no,
outputs,
status,
hystersis_temp,
door_switch_open_conform_time,
door_switch_close_conform_time,
tt_switch_open_conform_time,
tt_switch_close_conform_time,
blower_trip_switch_open_conform_time,
blower_trip_switch_close_conform_time,
tt_trip_switch_open_conform_time,
tt_trip_switch_close_conform_time,
thermo_trip_switch_open_conform_time,
thermo_trip_switch_close_conform_time,
burner_trip_switch_open_conform_time,
burner_trip_switch_close_conform_time,
emergency_switch_open_conform_time,
emergency_switch_close_conform_time,
tt_manual_switch_open_conform_time,
tt_manual_switch_close_conform_time;

extern unsigned int
set_temperature_for_testing_mqqt_data,
set_baking_for_testing_mqqt_data,
power_consuption,
fuel_tank_capacity,
baking_time,
ctemp,
stemp,
steam_time;

extern unsigned long int
temp_steam_time,
temp_baking_time;

/**************************PWM******************************/
extern __boolean
blower_pulse_on_flag;

extern unsigned char
BLOWER_ON_TIME,
BLOWER_OFF_TIME,
blower_motor_speed,
blower_pulse_counter;
/**************************PWM******************************/


/*********************SEND UART***************************/

extern unsigned char
tx_data,
temp_send_buf[MAX_SIZE_RX_BUF];

extern unsigned int
delay;

/***********************TIMER VAR**************************/
extern __boolean
delayflag;

extern unsigned char
homeScreenDelay,
key_scan_delay_hm;