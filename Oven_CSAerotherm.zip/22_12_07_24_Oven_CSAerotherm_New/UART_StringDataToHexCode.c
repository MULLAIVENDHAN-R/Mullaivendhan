#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include <stdlib.h>

void str_to_process_buf_conversion()
{
	char i,j,byte=0,pipe_symbol_came=0;
	long int val;
	for(i=0,j=0;i<strlen(string_process_data_buf);i++)
	{
		if(!frame_err_flag)
		{
			if(string_process_data_buf[i]!='|')
			temp_string[j++]= string_process_data_buf[i];
			else
			{
				if(strcmp(temp_string,"RESUME")!=0)
				pipe_symbol_came++;
				if(pipe_symbol_came==1)			
				{
					if(strcmp(temp_string,"1")==0)		//turn table
					process_data_buf[byte]=1;
					else if(strcmp(temp_string,"2")==0)   	//blower
					process_data_buf[byte]=2;
					else if(strcmp(temp_string,"3")==0)	//steam value
					process_data_buf[byte]=3;
					else if(strcmp(temp_string,"4")==0)	//Fan
					process_data_buf[byte]=4;
					else if(strcmp(temp_string,"5")==0)	//light
					process_data_buf[byte]=5;
					else if(strcmp(temp_string,"6")==0)	//burner
					process_data_buf[byte]=6;
					else if(strcmp(temp_string,"7")==0)	// set baking time
					process_data_buf[byte]=7;
					else if(strcmp(temp_string,"8")==0)	// set baking temperature 
					process_data_buf[byte]=8;
					else if(strcmp(temp_string,"9")==0)	//  OVEN TEMPERATURE
					process_data_buf[byte]=9;
					else
					stemp=atoi(temp_string);
				}				
				if(pipe_symbol_came==2)
				baking_time=atoi(temp_string);
				if(pipe_symbol_came==3)
				steam_time=atoi(temp_string);
				byte++;
				j=0;
				memset(temp_string,0,sizeof(temp_string));				
			}
		}
	}
	if(!frame_err_flag)
	{
		if(temp_string[0]!='B')	//BOARD_ER Data
		{
			if(temp_string[0]=='O')
			{
				if(strcmp(temp_string,"ON")==0)
				process_data_buf[byte]=1;
				else if(strcmp(temp_string,"OFF")==0)
				process_data_buf[byte]=0;
				else
				frame_err_flag=SET;
			}
			else
			{
				if((app_id==0x03)AND(fun_id==0x02))
				{
					if((pipe_symbol_came==1)AND(process_data_buf[0]==8))
					set_temperature_for_testing_mqqt_data=atoi(temp_string);
					else if((pipe_symbol_came==1)AND(process_data_buf[0]==7))
					set_baking_for_testing_mqqt_data=atoi(temp_string);
				}
				else
				{
					if(pipe_symbol_came>2)			//for resume data
					temp_baking_time=atoi(temp_string);
					else
					steam_time=atoi(temp_string);
				}
			}
		}
		else
		frame_err_flag=SET;
	}
	memset(string_process_data_buf,0,sizeof(string_process_data_buf));
}