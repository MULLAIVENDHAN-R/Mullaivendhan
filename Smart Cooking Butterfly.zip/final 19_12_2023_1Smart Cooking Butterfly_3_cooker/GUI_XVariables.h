extern unsigned char 
main_tx_buf[FIXED_DATA_LENGTH],
tx_buf1[FIXED_DATA_LENGTH],
tx_buf2[FIXED_DATA_LENGTH],
tx_buf3[FIXED_DATA_LENGTH],
send_ack_buffer1[FIXED_DATA_LENGTH],
send_ack_buffer2[FIXED_DATA_LENGTH],
send_ack_buffer3[FIXED_DATA_LENGTH],
send_timer_buffer1[FIXED_DATA_LENGTH],
send_timer_buffer2[FIXED_DATA_LENGTH],
send_timer_buffer3[FIXED_DATA_LENGTH],
send_done_buffer1[FIXED_DATA_LENGTH],
send_done_buffer2[FIXED_DATA_LENGTH],
send_done_buffer3[FIXED_DATA_LENGTH];

extern unsigned char 
send_done_count,
done_buf1_size,
done_buf2_size,
done_buf3_size,
timer_buf1_size,
timer_buf2_size,
timer_buf3_size,
ack_buf1_size,
ack_buf2_size,
ack_buf3_size,
send_timer_count,
send_ack_count,
send_order_count,
tx_send_count,
main_tx_buf_size,
tx_buf1_size,
tx_buf2_size,
tx_buf3_size;
extern boolean 
resend_flag,
frame_formed_flag,
frist_ack_buffer_flag,
second_ack_buffer_flag,
third_ack_buffer_flag,
frist_timer_buffer_flag,
second_timer_buffer_flag,
third_timer_buffer_flag,
frist_done_buffer_flag,
second_done_buffer_flag,
third_done_buffer_flag;
extern char
temp_string[10],
string_process_data_buf[MAX_SIZE_RX_BUF];


extern unsigned char 
test_buf[MAX_SIZE_RX_BUF],
uart_main_buf[MAX_SIZE_RX_BUF],
uart_backup_buf[MAX_SIZE_RX_BUF],
process_data_buf[MAX_SIZE_RX_BUF],
process_data_buf1[MAX_SIZE_RX_BUF],
testing_data_buf[MAX_SIZE_RX_BUF],
string_process_data_backup_buf[MAX_SIZE_RX_BUF],
string_process_data_backup_buf1[MAX_SIZE_RX_BUF],
string_process_data_backup_buf2[MAX_SIZE_RX_BUF],
//string_process_data_buf[MAX_SIZE_RX_BUF],
send_buf[MAX_SIZE_RX_BUF],
total_length,
total_data_bytes,
data;

extern __boolean
first_buffer_flag,second_buffer_flag,third_buffer_flag,fourth_buffer_flag,fifth_buffer_flag,sixth_buffer_flag,
seventh_buffer_flag,eighth_buffer_flag,nineth_buffer_flag,tenth_buffer_flag,eleventh_buffer_flag,twelveth_buffer_flag,
general_data_rcvd_flag,
string_process_data_flag,
data_received_ok_flag,
string_process_data_backup__buf1_set_flag,
string_process_data_backup__buf2_set_flag,
string_process_data_backup__buf3_set_flag,
chk_sum_err_flag,
frame_err_flag,
dlc_err_flag,
appid_err_flag,
funid_err_flag;

extern unsigned char
uart_error_clear_count,
received_app_id,
received_fun_id,
app_id,
fun_id;


/*********************************UART DATA PROCESS *****************************/
extern __boolean
process_data_rcvd_success_flag,
handshake_ok_flag,
ack_ok_flag;

extern unsigned char
is_model_1;


/************************************UART SEND***************************/
extern __boolean
c1_one_time_resend_flag,
c2_one_time_resend_flag,
c3_one_time_resend_flag,
c1_resend_ok_flag,
c2_resend_ok_flag,
c3_resend_ok_flag,
uart_driver_reset_flag,
waiting_for_ack_flag,
resend_flag,
uart_send_flag;

extern unsigned char
resend_cnt,
c1_resend_cnt,
c2_resend_cnt,
c3_resend_cnt,
send_backup_buf[MAX_SIZE_RX_BUF],
C1_send_backup_buf[MAX_SIZE_RX_BUF],
C2_send_backup_buf[MAX_SIZE_RX_BUF],
C3_send_backup_buf[MAX_SIZE_RX_BUF],
c1_backup_total_bytes,
c2_backup_total_bytes,
c3_backup_total_bytes,
backup_total_bytes,
tx_total_send_bytes;

extern unsigned int
trasmit_dly;