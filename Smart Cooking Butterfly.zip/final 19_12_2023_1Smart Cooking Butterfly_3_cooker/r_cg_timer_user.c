/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2021 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_timer_user.c
* Version      : CodeGenerator for RL78/G13 V2.05.06.02 [08 Nov 2021]
* Device(s)    : R5F100PL
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for TAU module.
* Creation Date: 29-06-2023
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTTM00 r_tau0_channel0_interrupt
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_timer.h"
/* Start user code for include. Do not edit comment generated here */
#include "Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
extern void form_send_buf(char,char);
static unsigned int onesec_pul_err_chk_cnt=0;
static __boolean pulse_err_flag;
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: r_tau0_channel0_interrupt
* Description  : This function is INTTM00 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void r_tau0_channel0_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
   /* if(err_flow_pulse>0)
    {
	    if(++onesec_pul_err_chk_cnt>=20000)
	    {
		    if(err_flow_pulse>=60)
		    pulse_err_flag=CLEAR;
		    else
		    pulse_err_flag=SET;
		    onesec_pul_err_chk_cnt=0;
		    err_flow_pulse=0;
	    }
    }*/	
    if(++hundred_usec_sec_counter>=2)
    {			
	if(temp_delay>0)
	temp_delay--;	
	hundred_usec_sec_counter=0;
    }
    if(++one_milli_sec_counter>=20)
    {
	    one_milli_sec_counter=0;
	    
	    
	     if(testing_delay>0)
		    testing_delay--;
		    
/******************ALL OUTPUTS TIMER*****************/
	    if(motor_on_off_delay>0)
	    motor_on_off_delay--;
	    if(temp_oil_pump_time>0)
	    temp_oil_pump_time--;    
	    
    	    if(ing_motor_time>0)
	    ing_motor_time--; 	    
	    
	    if(lid_up_dwn_time>0)
	    lid_up_dwn_time--;
	    if(lid_fwd_rev_time>0)
	    lid_fwd_rev_time--;
	    
	    
	    if(lid1_up_dwn_time>0)
	    lid1_up_dwn_time--;
	    if(lid1_fwd_rev_time>0)
	    lid1_fwd_rev_time--;
	    
	    
	    if(lid2_up_dwn_time>0)
	    lid2_up_dwn_time--;
	    if(lid2_fwd_rev_time>0)
	    lid2_fwd_rev_time--;
	    
	    	    
	    if(kadai_cc_ccw_time>0)
	    kadai_cc_ccw_time--;

	    if(kadai_fwd_rev_time>0)
	    kadai_fwd_rev_time--;
	   
	 //   if(kadai_fwd_on_time>0)
	   // kadai_fwd_on_time--;
	    
	    
	    if(vegtray1_time>0)
	    vegtray1_time--;
 	    if(vegtray2_time>0)
	    vegtray2_time--;
	    if(vegtray3_time>0)
	    vegtray3_time--;
	    if(str1_mtr_time>0)
	    str1_mtr_time--;
	    if(str2_mtr_time>0)
	    str2_mtr_time--;
	    if(str3_mtr_time>0)
	    str3_mtr_time--;
	    if(cooker_mtr_time>0)
	    cooker_mtr_time--;
	    if(temp_htr1_time>0)
	    temp_htr1_time--;
	    if(temp_htr2_time>0)
	    temp_htr2_time--;
	    if(temp_htr3_time>0)
	    temp_htr3_time--;
	    
	    if(temp_fan_time>0)
	    temp_fan_time--;
	    if(c1_idle_time>0)
	    c1_idle_time--;
	    if(c2_idle_time>0)
	    c2_idle_time--;
	    if(c3_idle_time>0)
	    c3_idle_time--;
	    if(idle_lock_time>0)
	    idle_lock_time--;
/******************ALL OUTPUTS TIMER*****************/
/****************UART TIMER**************************/
	    if(trasmit_dly>0)
	    trasmit_dly--;
	    if(uart_error_clear_count>0)
	    {
		uart_error_clear_count--;
		if(uart_error_clear_count<=0)
		data=0;				
	    }
/****************UART TIMER**************************/
/****************SWITCH CLOSE OPEN TIMER*************/
	    if(vegtray1_switch_open_conform_time<250)
	    vegtray1_switch_open_conform_time++;
	    if(vegtray1_switch_close_conform_time<250)
	    vegtray1_switch_close_conform_time++;
	    if(vegtray2_switch_open_conform_time<250)
	    vegtray2_switch_open_conform_time++;
	    if(vegtray2_switch_close_conform_time<250)
	    vegtray2_switch_close_conform_time++;
	    if(vegtray3_switch_open_conform_time<250)
	    vegtray3_switch_open_conform_time++;
	    if(vegtray3_switch_close_conform_time<250)
	    vegtray3_switch_close_conform_time++;
	    
	    
	    if(lid_up_switch_open_conform_time<250)
	    lid_up_switch_open_conform_time++;
	    if(lid_up_switch_close_conform_time<250)
	    lid_up_switch_close_conform_time++;
	    
	    if(lid_dwn_switch_open_conform_time<250)
	    lid_dwn_switch_open_conform_time++;
	    if(lid_dwn_switch_close_conform_time<250)
	    lid_dwn_switch_close_conform_time++;
	    
	    if(lid_fwd_switch_open_conform_time<250)
	    lid_fwd_switch_open_conform_time++;
	    if(lid_fwd_switch_close_conform_time<250)
	    lid_fwd_switch_close_conform_time++;
	    
	    if(lid_rev_switch_open_conform_time<250)
	    lid_rev_switch_open_conform_time++;
	    if(lid_rev_switch_close_conform_time<250)
	    lid_rev_switch_close_conform_time++;
	    
	    
	    
	    if(lid1_up_switch_open_conform_time<250)
	    lid1_up_switch_open_conform_time++;
	    if(lid1_up_switch_close_conform_time<250)
	    lid1_up_switch_close_conform_time++;
	    
	    if(lid1_dwn_switch_open_conform_time<250)
	    lid1_dwn_switch_open_conform_time++;
	    if(lid1_dwn_switch_close_conform_time<250)
	    lid1_dwn_switch_close_conform_time++;
	    
	    if(lid1_fwd_switch_open_conform_time<250)
	    lid1_fwd_switch_open_conform_time++;
	    if(lid1_fwd_switch_close_conform_time<250)
	    lid1_fwd_switch_close_conform_time++;
	    
	    if(lid1_rev_switch_open_conform_time<250)
	    lid1_rev_switch_open_conform_time++;
	    if(lid1_rev_switch_close_conform_time<250)
	    lid1_rev_switch_close_conform_time++;
	    
	    
	    if(lid2_up_switch_open_conform_time<250)
	    lid2_up_switch_open_conform_time++;
	    if(lid2_up_switch_close_conform_time<250)
	    lid2_up_switch_close_conform_time++;
	    
	    if(lid2_dwn_switch_open_conform_time<250)
	    lid2_dwn_switch_open_conform_time++;
	    if(lid2_dwn_switch_close_conform_time<250)
	    lid2_dwn_switch_close_conform_time++;
	    
	    if(lid2_fwd_switch_open_conform_time<250)
	    lid2_fwd_switch_open_conform_time++;
	    if(lid2_fwd_switch_close_conform_time<250)
	    lid2_fwd_switch_close_conform_time++;
	    
	    if(lid2_rev_switch_open_conform_time<250)
	    lid2_rev_switch_open_conform_time++;
	    if(lid2_rev_switch_close_conform_time<250)
	    lid2_rev_switch_close_conform_time++;
	    
	     if(kadai_rev_switch_open_conform_time<250)
	    kadai_rev_switch_open_conform_time++;
	    if(kadai_rev_switch_close_conform_time<250)
	    kadai_rev_switch_close_conform_time++;
	    
	    if(kadai_ccw_switch_open_conform_time<250)
	    kadai_ccw_switch_open_conform_time++;
	    if(kadai_ccw_switch_close_conform_time<250)
	    kadai_ccw_switch_close_conform_time++;
	    
	     if(kadai_cw_switch_open_conform_time<250)
	    kadai_cw_switch_open_conform_time++;
	    if(kadai_cw_switch_close_conform_time<250)
	    kadai_cw_switch_close_conform_time++;
	    
	    
	    
	    
	    if(cooker1_switch_open_conform_time<250)
	    cooker1_switch_open_conform_time++;
	    if(cooker1_switch_close_conform_time<250)
	    cooker1_switch_close_conform_time++;
	    if(cooker2_switch_open_conform_time<250)
	    cooker2_switch_open_conform_time++;
	    if(cooker2_switch_close_conform_time<250)
	    cooker2_switch_close_conform_time++;
	    if(cooker3_switch_open_conform_time<250)
	    cooker3_switch_open_conform_time++;
	    if(cooker3_switch_close_conform_time<250)
	    cooker3_switch_close_conform_time++;
/****************SWITCH CLOSE OPEN TIMER*************/	
	    if(++one_sec_counter>=1000)
	    {
		    one_sec_counter=0;
		    
		   
		    
		    if(handshake_ok_flag)
		    {
			    if(heart_beat_delay_cntr>0)
			    heart_beat_delay_cntr--;
			    
			    if(++heart_beat_counter>=80)	// + 20 sec with rtc
			    {
				    heart_beat_counter=0;
				    heart_beat_send_flag=SET;
			    }
			    
			    if(++one_min_counter>=60)
			    {
				 one_min_counter=0;
				 if((!dish1_preparation_start_flag)AND(!dish2_preparation_start_flag)AND(!dish3_preparation_start_flag))  //NEW UPDATE
				 time_update_flag=SET;
			    }				 
		    }
		     if(buzzer_delay>0)
			    buzzer_delay--;	
			    
		    if((handshake_ok_flag)AND(!prep_pending_restart_flag)AND(!cooker_set_flag))
		    cooker_switch_failure_counter++;
		    else
		    cooker_switch_failure_counter=0;
		    flow_pulse_flag=CLEAR;    
	    }
    }
    if(++fifty_milli_sec_counter>=1000)
    {
    	fifty_milli_sec_counter=0;
	
	if(!adc_read_flag)
	adc_read_flag=SET;	
	
	 if((buzzer_flag)AND(buzzer_delay<=0))
	 {
	   buzzer_flag=CLEAR;
	   buzzer_delay=0;
	   BUZZER_OFF;			    
	}

	/*if(cooker1_start_delay>0)			// cooker start wait delay
	{
		cooker1_start_delay--;
		if(cooker1_start_delay<=0)
		{
			received_app_id=0X05;
			received_fun_id=0X05;
			form_send_buf(COMMAND_RES,COOKER1_ACK_DATA);
		}
	}
	if(cooker2_start_delay>0)
	{
		cooker2_start_delay--;
		if(cooker2_start_delay<=0)
		{
			received_app_id=0X05;
			received_fun_id=0X05;
			form_send_buf(COMMAND_RES,COOKER2_ACK_DATA);
		}
	}
	if(cooker3_start_delay>0)
	{
		cooker3_start_delay--;
		if(cooker3_start_delay<=0)
		{
			received_app_id=0X05;
			received_fun_id=0X05;
			form_send_buf(COMMAND_RES,COOKER3_ACK_DATA);
		}
	}*/
	
	
	
	if(cooker3_switch_close_flag)
	{
		if(water_level_sensor_close_ctr<200)
		water_level_sensor_close_ctr++;
	}
	else
	{
		if(water_level_sensor_open_ctr<200)
		water_level_sensor_open_ctr++;
	}
	
	if(((temp_water_pump_time>0)AND(!flow_pulse_flag)))//OR(pulse_err_flag))
	{
		if(++five_sec_counter>100)
		{
			five_sec_counter=0;
			flow_meter_failure_flag=SET;
			//pulse_err_flag=CLEAR;
		}
	}
	else
	five_sec_counter=0;
	if(delay>0)
	{
		delay--;
		if(cooker_mtr_time>0)
		{
			if(!cooker1_switch_close_flag)
			cooker_not_move_flag=CLEAR;
		}
		if((vegtray1_time>0)AND(VEG_TRAY1_FWD))
		{
			if(!vegtray1_switch_close_flag)
			vegtray1_not_move_flag=CLEAR;
		}
		if((vegtray2_time>0)AND(VEG_TRAY2_FWD))
		{
			if(!vegtray2_switch_close_flag)
			vegtray2_not_move_flag=CLEAR;
		}
		if((vegtray3_time>0)AND(VEG_TRAY3_FWD))
		{
			if(!vegtray3_switch_close_flag)
			vegtray3_not_move_flag=CLEAR;
		}
		if((kadai_fwd_rev_time>0)AND(KADAI_FWD))
		{
			if(!kadai_rev_switch_close_flag)
			ktm1_fwd_not_move_flag=CLEAR;
		}
		if((kadai_cc_ccw_time>0)AND(KADAI_CCW))
		{
			if(!kadai_cw_switch_close_flag)
			ktm2_ccw_not_move_flag=CLEAR;
		}
	}
    }
	    
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
