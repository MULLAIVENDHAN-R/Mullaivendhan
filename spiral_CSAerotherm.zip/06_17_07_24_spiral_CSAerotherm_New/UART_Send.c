 #include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

// 111   flow erroe
char *send_string_data[]={
			"ACK",					/* 0 */
			"DISPLAY_READY",			/* 1 */
			"HANDSHAKE",				/* 2 */
			"CLOSE",				/* 3 */
			"OPEN",					/* 4 */
			"START",				/* 5 */
			"STOP",					/* 6 */
			"IO_ST",				/* 7 */
			"TEMP",					/* 8 */
			"DONE",					/* 9 */
			"108",					/* 10 */   //ERROR CODE FOR "SPIRAL TRIP"
			"109",					/* 11 */   //ERROR CODE FOR "LIMIT SWITCH "
			"110",					/* 12 */   //ERROR CODE FOR " BOWLTRIP"
			"107",					/* 13 */   //ERROR CODE FOR " DUMMY"
			"105",					/* 14 */   //ERROR CODE FOR " DUMMY"
			"106",					/* 15 */   //ERROR CODE FOR "EMERGENCY"
			"HEART_BEAT",				/* 16 */
			"COMPLETED",				/* 17 */
			"ERROR_CLOSED",				/* 18 */
			"EMERGENCY",				/* 19 */
			"ALERT",				/* 20 */
			"ONE_HOUR_REMIND",			/* 21 */
			"RESTART",				/* 22 */
			"FID_ER",				/* 23 */
			"AID_ER",				/* 24 */
			"FRM_ER",				/* 25 */
			"DLC_ER",				/* 26 */
			"HIGH",					/* 27 */
			"ON",					/* 28 */
			"OFF",					/* 29 */

			};	
			
char add_checksum(char);
char add_stuff_byte(char);
void err_resend_fun();
void gui_uart_send();

unsigned char step_count_buf[20];
static unsigned char main_tx_buf[FIXED_DATA_LENGTH],tx_buf1[FIXED_DATA_LENGTH],tx_buf2[FIXED_DATA_LENGTH],tx_buf3[FIXED_DATA_LENGTH],tx_buf4[FIXED_DATA_LENGTH];
static unsigned char send_order_count=0,tx_send_count=0,main_tx_buf_size,tx_buf1_size,tx_buf2_size,tx_buf3_size,tx_buf4_size;
static boolean frame_formed_flag;

void form_send_buf(char respond_format,char index)
{
	unsigned char byte=0,i,j,data_len;
	char *ptr;
	if(respond_format)
	{
		ptr=send_string_data[index];
		for(i=0;i<strlen(send_string_data[index]);i++)
		temp_send_buf[i]=*ptr++;
	}
	else	
	i=index;	
	data_len=i;
	send_buf[byte++]=START_BYTE;
	send_buf[byte++]=0;			
	send_buf[byte++]=0;
	send_buf[byte++]=data_len;	
	send_buf[byte++]=received_app_id;
	send_buf[byte++]=received_fun_id;
	for(i=0;i<data_len;byte++,i++)
	send_buf[byte]=temp_send_buf[i];
	send_buf[byte++]=add_checksum(byte);
	memcpy(temp_send_buf,send_buf,sizeof(send_buf));
	byte=add_stuff_byte(byte);
	send_buf[byte++]=END_BYTE;
	tx_total_send_bytes=byte;
	frame_formed_flag=SET;
	gui_uart_send();
	
}
char add_checksum(char len)
{
	char temp_check_sum=0,count,byte;
	for(byte=START_FROM,count=0;byte<len;byte++,count++)
	temp_check_sum=(temp_check_sum+(count^(send_buf[byte])));
	temp_check_sum=~(temp_check_sum+send_buf[HEADER_BYTE]);
	return temp_check_sum;
}
char add_stuff_byte(char len)
{
	unsigned char byte,i,stuff_byte;
	
	for(byte=1,i=1,stuff_byte=0;byte<(len+stuff_byte);i++,byte++)
	{
		if((temp_send_buf[i]==0X1C)OR(temp_send_buf[i]==0X2A)OR(temp_send_buf[i]==0X23))
		{
			send_buf[byte++]=STUFF_BYTE;
			send_buf[byte]=~temp_send_buf[i];
			stuff_byte++;
		}
		else
		send_buf[byte]=temp_send_buf[i];
	}
	return byte;
}
__boolean is_valid_data(unsigned char received_buf[],char index)
{
	char byte;
	char *ptr;
	ptr=send_string_data[index];
	for(byte=0;byte<strlen(send_string_data[index]);byte++)
	{
		if((*ptr++)!=received_buf[byte])
		return 1;
	}
	return 0;
}
void err_resend_fun()
{
	if((dlc_err_flag)OR(chk_sum_err_flag)OR(appid_err_flag)OR(funid_err_flag)OR(frame_err_flag))
	{
		waiting_for_ack_flag=SET;
		resend_cnt=0;
	}
	dlc_err_flag=chk_sum_err_flag=appid_err_flag=funid_err_flag=frame_err_flag=CLEAR; 
	/*if(dlc_err_flag)
	{
		form_send_buf(COMMAND_RES,DLC_ERR_DATA);
		dlc_err_flag=chk_sum_err_flag=appid_err_flag=funid_err_flag=frame_err_flag=CLEAR;
	}
	if(chk_sum_err_flag)
	{
		form_send_buf(COMMAND_RES,CHKSUM_ERR_DATA);
		dlc_err_flag=chk_sum_err_flag=appid_err_flag=funid_err_flag=frame_err_flag=CLEAR;
	}
	if(appid_err_flag)
	{
		form_send_buf(COMMAND_RES,APPID_ERR_DATA);
		dlc_err_flag=chk_sum_err_flag=appid_err_flag=funid_err_flag=frame_err_flag=CLEAR;
	}
	if(funid_err_flag)
	{
		form_send_buf(COMMAND_RES,FUNID_ERR_DATA);
		dlc_err_flag=chk_sum_err_flag=appid_err_flag=funid_err_flag=frame_err_flag=CLEAR;
	}
	if(frame_err_flag)
	{
		form_send_buf(COMMAND_RES,FRAME_ERR_DATA);
		dlc_err_flag=chk_sum_err_flag=appid_err_flag=funid_err_flag=frame_err_flag=CLEAR;
	}*/
}
void gui_uart_send()
{
	if((uart_send_flag)AND(trasmit_dly<=0))
	{		
		if(send_order_count>0)
		{
			send_order_count--;
			tx_send_count++;
		}
		if(tx_send_count==1)
		{
			memcpy(main_tx_buf,tx_buf1,sizeof(tx_buf1));
			main_tx_buf_size=tx_buf1_size;
			memcpy(tx_buf1,tx_buf2,sizeof(tx_buf2));
			tx_buf1_size=tx_buf2_size;
			
		}
		if(tx_send_count==2)
		{
			memcpy(main_tx_buf,tx_buf2,sizeof(tx_buf2));
			main_tx_buf_size=tx_buf2_size;
			memcpy(tx_buf2,tx_buf3,sizeof(tx_buf3));
			tx_buf2_size=tx_buf3_size;
		}			
		if(tx_send_count==3)
		{
			memcpy(main_tx_buf,tx_buf3,sizeof(tx_buf3));
			main_tx_buf_size=tx_buf3_size;
			memcpy(tx_buf3,tx_buf4,sizeof(tx_buf4));
			tx_buf3_size=tx_buf4_size;
		}
		if(tx_send_count==4)
		{
			memcpy(main_tx_buf,tx_buf4,sizeof(tx_buf4));
			main_tx_buf_size=tx_buf4_size;
		}		
		if(send_order_count<=0)
		{
			uart_send_flag=CLEAR;
			tx_send_count=0;
		}
		backup_total_bytes=main_tx_buf_size;
		memcpy(send_backup_buf,main_tx_buf,sizeof(main_tx_buf));
		R_UART0_Send(main_tx_buf,main_tx_buf_size);
		trasmit_dly=250;
		heart_beat_counter=0;			//For Heart beat reset
	}
	if(frame_formed_flag)
	{
		send_order_count++;
		if(send_order_count==1)
		{
			memcpy(tx_buf1,send_buf,sizeof(send_buf));
			tx_buf1_size=tx_total_send_bytes;
		}
		if(send_order_count==2)
		{
			memcpy(tx_buf2,send_buf,sizeof(send_buf));
			tx_buf2_size=tx_total_send_bytes;
			if(tx_send_count>0)
			tx_send_count--;
		}
		if(send_order_count==3)
		{
			memcpy(tx_buf3,send_buf,sizeof(send_buf));
			tx_buf3_size=tx_total_send_bytes;
			if(tx_send_count>0)
			tx_send_count--;
		}
		if(send_order_count==4)
		{
			memcpy(tx_buf4,send_buf,sizeof(send_buf));
			tx_buf4_size=tx_total_send_bytes;
			if(tx_send_count>0)
			tx_send_count--;
		}
		uart_send_flag=SET;
		frame_formed_flag=CLEAR;
	}		
	if((trasmit_dly<=0)AND(waiting_for_ack_flag)AND(!uart_send_flag))
	{
		if(++resend_cnt>=11)
		{
			if(uart_driver_reset_flag)
			{
				R_UART0_Stop();
				delay=5;
				while(delay);
				R_UART0_Start();
				uart_driver_reset_flag=CLEAR;
				resend_cnt=9;
			}
			else
			{
				resend_cnt=0;
				waiting_for_ack_flag=CLEAR;
			}
		}
		resend_flag=CLEAR;
 		R_UART0_Send(send_backup_buf,backup_total_bytes);
		trasmit_dly=250;
	}	
}				