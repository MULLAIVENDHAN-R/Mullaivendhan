#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/EXTERN_FUN.H"
#include "../HEADER_FILE/IO.H"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SDA_LOW     g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_01,IOPORT_LEVEL_LOW)
#define SDA_HIGH    g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_01,IOPORT_LEVEL_HIGH)

#define SDA_INPUT   g_ioport.p_api->pinDirectionSet(IOPORT_PORT_04_PIN_01,IOPORT_DIRECTION_INPUT)
#define SDA_OUTPUT  g_ioport.p_api->pinDirectionSet(IOPORT_PORT_04_PIN_01,IOPORT_DIRECTION_OUTPUT)

#define SCL_LOW     g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_00,IOPORT_LEVEL_LOW)
#define SCL_HIGH    g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_00,IOPORT_LEVEL_HIGH)

#define  IC_4094_ENABLE_HIGH        g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_04,IOPORT_LEVEL_HIGH)
#define  IC_4094_ENABLE_LOW         g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_04,IOPORT_LEVEL_LOW)

_Bool
fan_on_off_flag;
unsigned char

            send_pop_delay,
            bin,
            delay,
            one_milli_sec_counter,

            one_min_counter,
            hundred_micro_sec_counter,

            heart_beat_delay_cntr;

unsigned int
D,
flag,
I,L,M,
J,
K,
one_sec_counter,
fifty_milli_sec_counter;
extern unsigned char kadai_1_delay,kadai_2_delay,extra_ing_motor_delay_time, kadai_1_veg_delay, kadai_2_veg_delay, ing_temp_delay,kadai_1_tilt_delay,kadai_2_tilt_delay,data,uart_error_clear_count,uart_rx_buff[57];
extern  _Bool dish1_preparation_start_flag,dish2_preparation_start_flag,dish3_preparation_start_flag,extra_ing_motor_delay_flag,handshake_ok_flag,refiiling_and_heatingflag,ing_motor_on_flag;


extern unsigned char water_level_close_counter,water_level_open_counter;
void Main_thread_entry(void)
{
    /* TODO: add your own code here */

    timer.p_api->open (timer.p_ctrl, timer.p_cfg);
    timer.p_api->start (timer.p_ctrl);

//    motor_timer.p_api->open (motor_timer.p_ctrl, motor_timer.p_cfg);
//    motor_timer.p_api->start (motor_timer.p_ctrl);

    flowmeter_read.p_api->open (flowmeter_read.p_ctrl, flowmeter_read.p_cfg);
    flowmeter_read.p_api->enable (flowmeter_read.p_ctrl);

    /*   group   */           /*   group   */      /*   channel*/   /*var*/
    boiler_temp.p_api->open(boiler_temp.p_ctrl,boiler_temp.p_cfg);
    boiler_temp.p_api->scanCfg(boiler_temp.p_ctrl,boiler_temp.p_channel_cfg);
    boiler_temp.p_api->scanStart(boiler_temp.p_ctrl);

    Rod_sensor.p_api->open(Rod_sensor.p_ctrl,Rod_sensor.p_cfg);
    Rod_sensor.p_api->scanCfg(Rod_sensor.p_ctrl,Rod_sensor.p_channel_cfg);
    Rod_sensor.p_api->scanStart(Rod_sensor.p_ctrl);

    Uart.p_api->open (Uart.p_ctrl, Uart.p_cfg);
    Uart.p_api->read (Uart.p_ctrl, uart_rx_buff, 1);
    Uart.p_api->write (Uart.p_ctrl, uart_rx_buff, 1);

    memset(output_data,0,sizeof(output_data));


    IC_4094_ENABLE_HIGH;

    serial_to_parallel_ic_fn();


    eprom_dly=5;
    while(eprom_dly)
       sensor_open_close_conform();


    while (1)
    {
        sensor_open_close_conform();
        check_all_functions();
        serial_to_parallel_ic_fn();
        stro_mtr_speed_ctrl();
        dispensing_vibration();
        cooker_pos_and_lid_pos();
        veg_tray_home_position();
        turmerind_water();
        kadai_tilting_opertion();
        kadai_process();
        kadai_homing();
        store_current_io_status();
    }
}
void timer_interrupt(timer_callback_args_t *p_args)
{
switch(p_args->event)
{
    case TIMER_EVENT_EXPIRED:


            /****************STEPPER MOTOR TIMER*************/
        if(!eeprom_write_start_flag)
        {
                            if(collecting_tray_timer>0)
                            collecting_tray_timer--;


                            if(kadai_1_clk_anti_toggle_timer>0)
                            kadai_1_clk_anti_toggle_timer --;

                            if(kadai_2_clk_anti_toggle_timer>0)
                                kadai_2_clk_anti_toggle_timer --;

                            if(cooker_1_fwd_rev_timer>0)
                                cooker_1_fwd_rev_timer--;

                            if(cooker_2_fwd_rev_timer>0)
                                cooker_2_fwd_rev_timer--;

                            if(cooker_3_fwd_rev_timer>0)
                                cooker_3_fwd_rev_timer--;

                            if(veg_tray_1_fwd_rev_timer>0)
                                veg_tray_1_fwd_rev_timer--;

                            if(veg_tray_2_fwd_rev_timer>0)
                                  veg_tray_2_fwd_rev_timer--;

                            if(veg_tray_3_fwd_rev_timer>0)
                                  veg_tray_3_fwd_rev_timer--;

                            if(lid_1_up_down_timer>0)
                                lid_1_up_down_timer--;

                            if(lid_2_up_down_timer>0)
                                lid_2_up_down_timer--;

                            if(lid_3_up_down_timer>0)
                                lid_3_up_down_timer--;
        }
               /****************STEPPER MOTOR TIMER*************/
                            if(++hundred_micro_sec_counter>=4)  // 200 MILI
                            {
                                hundred_micro_sec_counter=0;
                                stepper_motor();
                            }

                            if(++one_milli_sec_counter>=20)   // 1mili sec
                            {
                                one_milli_sec_counter=0;

                                if(trasmit_dly>0)
                                       trasmit_dly--;

                                if(kadai_1_fwd_rev_pulse>0)
                                    kadai_1_fwd_rev_pulse--;

                                if(kadai_2_fwd_rev_pulse>0)
                                    kadai_2_fwd_rev_pulse--;

                                if((turmerind_water_on_flag)AND(turmerind_water_on_time>0))
                                       turmerind_water_on_time--;

                                if(uart_error_clear_count>0)
                                {
                                    uart_error_clear_count--;
                                    if(uart_error_clear_count<=0)
                                    data=0;
                                }
                                if(++one_sec_counter>=1000)
                                {
                                    one_sec_counter=0;

                                    if(kadai_1_delay>0)
                                        kadai_1_delay--;

                                    if(kadai_2_delay>0)
                                        kadai_2_delay--;

                                    if(handshake_ok_flag)
                                    {
                                        if(str1_delay>0)
                                            str1_delay--;
                                        if(str2_delay>0)
                                            str2_delay--;
                                        if(str3_delay>0)
                                             str3_delay--;
                                        if(++heart_beat_counter>=80)    // + 20 sec with rtc
                                        {
                                            heart_beat_counter=0;
                                            heart_beat_send_flag=SET;
                                        }
//                                        if(water_pump_time>0)
//                                            water_pump_time--;

                                        if(((dish1_preparation_start_flag)OR(dish2_preparation_start_flag)OR(dish3_preparation_start_flag))AND(!fan_on_off_flag))
                                            FAN_ON;
                                        else if((!dish1_preparation_start_flag)AND(!dish2_preparation_start_flag)AND(!dish3_preparation_start_flag)AND(fan_on_off_flag))
                                            FAN_OFF;

                                        if(vibrator_delay>0)
                                            vibrator_delay--;
                                        if(kadai_1_tilt_delay>0)
                                            kadai_1_tilt_delay--;

                                        if(kadai_2_tilt_delay>0)
                                            kadai_2_tilt_delay--;

                                        if(kadai_1_veg_delay>0)
                                        kadai_1_veg_delay--;

                                        if(kadai_2_veg_delay>0)
                                        kadai_2_veg_delay--;

                                        if(ing_temp_delay>0)
                                            ing_temp_delay--;

                                        if((extra_ing_motor_delay_flag)AND(extra_ing_motor_delay_time>0))
                                            extra_ing_motor_delay_time--;

                                        if((!machine_ready_ok_flag)AND(initial_position_ok_flag))
                                        {
                                            send_pop_delay++;
                                            if((heater_on_flag)AND(send_pop_delay>=2))
                                            {
                                                send_pop_delay=0;
                                                form_send_buf(0x09,0x01,COMMAND_RES,C1_HEATING_PROGESS_POP);

                                            }
                                            else if((water_on_flag)AND(send_pop_delay>=2))
                                            {
                                                send_pop_delay=0;
                                                form_send_buf(0x09,0x01,COMMAND_RES,C1_REFILLING_PROGESS_POP);
                                            }
                                        }
                                    }

                                }
                 /******************ALL OUTPUTS TIMER*****************/
                                if((c1_idle_time>0)AND(!cooker1_cooking_time_on_flag))
                                c1_idle_time--;

                                if((c2_idle_time>0)AND(!cooker2_cooking_time_on_flag))
                                c2_idle_time--;

                                if((c3_idle_time>0)AND(!cooker3_cooking_time_on_flag))
                                c3_idle_time--;

                                if(str1_mtr_time>0)
                                str1_mtr_time--;

                                if(str2_mtr_time>0)
                                str2_mtr_time--;

                                if(str3_mtr_time>0)
                                str3_mtr_time--;

                                if((ing_motor_time>0)AND(ing_motor_on_flag))
                                    ing_motor_time--;

                                if(oil_pump_1_on_flag)
                                {
                                    if(oil_pump_1_on_time>0)
                                        oil_pump_1_on_time--;
                                }
                                if(oil_pump_2_on_flag)
                                {
                                    if(oil_pump_2_on_time>0)
                                        oil_pump_2_on_time--;
                                }
                                if(oil_pump_3_on_flag)
                                {
                                    if(oil_pump_3_on_time>0)
                                        oil_pump_3_on_time--;
                                }



                  /****************SWITCH CLOSE OPEN TIMER*************/
                                if(vegtray1_switch_open_conform_time<250)
                                vegtray1_switch_open_conform_time++;

                                if(vegtray1_switch_close_conform_time<250)
                                vegtray1_switch_close_conform_time++;

                                if(vegtray2_switch_open_conform_time<250)
                                vegtray2_switch_open_conform_time++;

                                if(vegtray2_switch_close_conform_time<250)
                                vegtray2_switch_close_conform_time++;

                                if(vegtray3_switch_open_conform_time<250)
                                vegtray3_switch_open_conform_time++;

                                if(vegtray3_switch_close_conform_time<250)
                                vegtray3_switch_close_conform_time++;

                                if(lid_1_switch_open_conform_time<250)
                                lid_1_switch_open_conform_time++;

                                if(lid_2_switch_open_conform_time<250)
                                lid_2_switch_open_conform_time++;

                                if(lid_3_switch_open_conform_time<250)
                                lid_3_switch_open_conform_time++;



                                if(lid_1_switch_close_conform_time<250)
                                lid_1_switch_close_conform_time++;

                                if(lid_2_switch_close_conform_time<250)
                                lid_2_switch_close_conform_time++;

                                if(lid_3_switch_close_conform_time<250)
                                lid_3_switch_close_conform_time++;


                                if(collecting_1_switch_open_conform_time<250)
                                collecting_1_switch_open_conform_time++;

                                if(collecting_2_switch_open_conform_time<250)
                                collecting_2_switch_open_conform_time++;

                                if(collecting_1_switch_close_conform_time<250)
                                collecting_1_switch_close_conform_time++;

                                if(collecting_2_switch_close_conform_time<250)
                                collecting_2_switch_close_conform_time++;

                                if(kadai_1_left_right_switch_open_conform_time<250)
                                kadai_1_left_right_switch_open_conform_time++;

                                if(kadai_2_left_right_switch_open_conform_time<250)
                                kadai_2_left_right_switch_open_conform_time++;


                                if(kadai_1_left_right_switch_close_conform_time<250)
                                kadai_1_left_right_switch_close_conform_time++;

                                if(kadai_2_left_right_switch_close_conform_time<250)
                                kadai_2_left_right_switch_close_conform_time++;


                                if(kadai_1_clock_anticlock_switch_close_conform_time<1000)
                                kadai_1_clock_anticlock_switch_close_conform_time++;

                                if(kadai_2_clock_anticlock_switch_close_conform_time<1000)
                                kadai_2_clock_anticlock_switch_close_conform_time++;

                                if(kadai_1_clock_anticlock_switch_open_conform_time<1000)
                                kadai_1_clock_anticlock_switch_open_conform_time++;

                                if(kadai_2_clock_anticlock_switch_open_conform_time<1000)
                                kadai_2_clock_anticlock_switch_open_conform_time++;

                                if(kadai_homing_switch_open_conform_time<250)
                                    kadai_homing_switch_open_conform_time++;

                                if(kadai_homing_switch_close_conform_time<250)
                                    kadai_homing_switch_close_conform_time++;


                                if(cooker1_switch_open_conform_time<250)
                                cooker1_switch_open_conform_time++;

                                if(cooker1_switch_close_conform_time<250)
                                cooker1_switch_close_conform_time++;

                                if(cooker2_switch_open_conform_time<250)
                                cooker2_switch_open_conform_time++;

                                if(cooker2_switch_close_conform_time<250)
                                cooker2_switch_close_conform_time++;

                                if(cooker3_switch_open_conform_time<250)
                                cooker3_switch_open_conform_time++;

                                if(cooker3_switch_close_conform_time<250)
                                cooker3_switch_close_conform_time++;

                                if(collecting_bin_switch_open_conform_time<5)
                                    collecting_bin_switch_open_conform_time++;
                                if(collecting_bin_switch_close_conform_time<5)
                                    collecting_bin_switch_close_conform_time++;



                /****************SWITCH CLOSE OPEN TIMER*************/
                            }
                            if(++fifty_milli_sec_counter>=1000)   // 50 mili
                            {
                                fifty_milli_sec_counter=0;

                                if(!temperature_read_flag)
                                temperature_read_flag=SET;

                                if(!refiiling_and_heatingflag)
                                    refiiling_and_heatingflag=SET;

                                if(test_mode_on_off_time>0)
                                test_mode_on_off_time--;

                                if(eprom_dly>0)
                                eprom_dly--;

                                if(((adc_rod_level>=WATER_ABSENT)OR(adc_rod_level>WATER_PRESENT+20))AND(water_level_close_counter<=200))
                                    water_level_close_counter++;
                                if((adc_rod_level<WATER_PRESENT)AND(water_level_open_counter<=200))
                                    water_level_open_counter++;

                            }
                            Rod_gen_pulse();


                break;
}
}
void FLOWMETER(external_irq_callback_args_t *p_args)
{
    static _Bool toogle;
    switch(p_args->channel)
    {
        case 15:
            if(water_pump_time>0)
            {
                water_pump_time--;
            }
            break;
    }
}

