#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "string.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"
#include "stdio.h"

void manual_operate_ops();
void io_status_send_iot();
void mqqt_test_process();
void io_on_off_check();
void err_occured();
void err_rectified();
void temp_maintain_fun();

extern void io_status_fun();
extern void form_send_buf(char,char);
extern void time_date_update();
extern void heartBeat();
extern void sendRTC();

 
 unsigned char iot_compenent_name[10];
 boolean iot_send_flag,mqqt_test_set_flag;

void baking_process()
{
	if(!err_occured_flag)
	{
	if(!door_switch_close_flag)
	{
		temp_maintain_fun();
		
		door_switch_closed_flag=SET;
		
		if(EXHAUST_FAN_OP)
		EXHAUST_FAN_OP_OFF;
		
		if((bake_start_flag)AND(temp_baking_time>0))
		{
			time_is_over_flag=CLEAR;			
			if(!steam_release_flag)
			{
				switch(step_no)
				{
					case TURN_TABLE_ON:
								if(!tt_trip_switch_close_flag)
								TURN_TABLE_OP_ON;
								
								EXHAUST_FAN_OP_OFF;
								IND_LIGHT_OP_ON;
								
								step_no=BLOWER_BURNER_ON;
								
								temp_on_delay=TEMP_DELAY;
								break;
					case BLOWER_BURNER_ON:
								if(temp_on_delay<=0)
								{
									if(!blower_trip_switch_close_flag)
									BLOWER_OP_ON;
									
									BURNER_OP_ON;
									
									step_no=TEMP_MAINTAINING;
								}								
								break;
					case TEMP_MAINTAINING:
								if((!TURN_TABLE_OP)AND(!tt_trip_switch_close_flag))
								TURN_TABLE_OP_ON;
								
								if((!BLOWER_OP)AND(!blower_trip_switch_close_flag))
								BLOWER_OP_ON;	
								
								if((ctemp>=stemp)AND(burner_on_flag)AND(!burner_trip_switch_close_flag))
								BURNER_OP_OFF;								
								else if((ctemp<=(stemp-HYSTERSIS_TEMP)AND(!burner_on_flag)))
								BURNER_OP_ON;
								
								break;
				}
			}
			else
			{
				if(!STEAM_SOLE_OP)
				{
					STEAM_SOLE_OP_ON;
					if(!burner_trip_switch_close_flag)
					BURNER_OP_OFF;
					BLOWER_OP_OFF;
					temp_steam_time=(unsigned long)(steam_time)*1000;
				}
				if(temp_steam_time<=0)
				{
					steam_release_flag=CLEAR;
					
					STEAM_SOLE_OP_OFF;
					BURNER_OP_ON;
					if(!blower_trip_switch_close_flag)
					BLOWER_OP_ON;
					
					io_status_fun();
				}				
			}
		}
		else
		{
			if((!time_is_over_flag)AND(bake_start_flag)AND(!bake_stop_flag))
			{
				BUZZER_OP_ON;
				BUZZER_ON;	
				if(!burner_trip_switch_close_flag)       // NEW
				BURNER_OP_OFF;
				
				BLOWER_OP_OFF;
								
				DONE_APPID_FUNID;
				form_send_buf(COMMAND_RES,DONE_DATA);
				time_is_over_flag=SET;
				temp_steam_time=0;
				steam_release_flag=CLEAR;
				STEAM_SOLE_OP_OFF;
				bake_start_flag=CLEAR;temp_baking_time=temp_steam_time=step_no=0;   // NEW
			}
			if(bake_stop_flag)
			{				
				if(!burner_trip_switch_close_flag)
				BURNER_OP_OFF;
				
				BLOWER_OP_OFF;
				STEAM_SOLE_OP_OFF;
				step_no=0;
				bake_stop_flag=CLEAR;
				bake_start_flag=CLEAR;
				temp_baking_time=temp_steam_time=0;
				steam_release_flag=CLEAR;
			
			}
		}	
	}
	else
	{
		if(door_switch_closed_flag)
		{
			EXHAUST_FAN_OP_ON;
			BLOWER_OP_OFF;
			STEAM_SOLE_OP_OFF;			
			if(!burner_trip_switch_close_flag)
			BURNER_OP_OFF;
			
			if(temp_baking_time>0)
			{
				bake_start_flag=SET;
			}
			else
			{
				bake_start_flag=CLEAR;
				temp_baking_time=temp_steam_time=0;
			}
			door_switch_closed_flag=CLEAR;
			steam_release_flag=CLEAR;
		}		
		if((!tt_switch_close_flag)AND(step_no==0)AND((!bake_start_flag)AND(!output_mode_flag)))  // MANUAL MODE
			TURN_TABLE_OP_OFF;				
		
		if(((!tt_switch_close_flag)AND(manual_opearate_flag))OR((bake_start_flag)AND(!tt_switch_close_flag)))
		{
			TURN_TABLE_OP_OFF;
			manual_opearate_flag=CLEAR;
		}
	}
	}
	heartBeat();
	time_date_update();
	sendRTC();
	if(io_manual_check_flag)
	{
		io_on_off_check();
		io_manual_check_flag=CLEAR;
	}
}
void io_status_fun()
{
	temp_send_buf[tx_data++]='I';
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((!door_switch_close_flag)+0X30);
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((!tt_switch_close_flag)+0X30);
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]='O';
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((TURN_TABLE_OP)+0X30);
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((BLOWER_OP)+0X30);
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((STEAM_SOLE_OP)+0X30);
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((EXHAUST_FAN_OP)+0X30);
	temp_send_buf[tx_data++]='|';
	temp_send_buf[tx_data++]=(char)((IND_LIGHT_OP)+0X30);
	IO_STATUS_APPID_FUNID;
	form_send_buf(DATA_RES,tx_data);
	tx_data=0;
}
void io_status_send_iot()
{
	unsigned char temp_buf[10],M;
	if(iot_send_flag)
	{
		iot_send_flag=CLEAR;
		memset(temp_send_buf,0,sizeof(temp_send_buf));
		if(iot_compenent_name[0]==HIGH)
		{
			iot_compenent_name[0]=0;
			temp_send_buf[tx_data++]='1';
			temp_send_buf[tx_data++]=':';
			sprintf(temp_buf,"%d",power_consuption);
			for(M=0;M<strlen(temp_buf);tx_data++,M++)
			temp_send_buf[tx_data]=temp_buf[M];     				//power consumption
		}
		
		else if(iot_compenent_name[1]==HIGH)
		{
			iot_compenent_name[1]=0;
			temp_send_buf[tx_data++]='2';
			temp_send_buf[tx_data++]=':';
			sprintf(temp_buf,"%d",fuel_tank_capacity);
			for(M=0;M<strlen(temp_buf);tx_data++,M++)
			temp_send_buf[tx_data]=temp_buf[M];     			//fuel consumption
		}
		
		else if(iot_compenent_name[2]==HIGH)
		{	
			iot_compenent_name[2]=0;
			temp_send_buf[tx_data++]='3';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((TURN_TABLE_OP)+0X30);			//turn table on off condtion
		}
		
		else if(iot_compenent_name[3]==HIGH)
		{
			iot_compenent_name[3]=0;
			temp_send_buf[tx_data++]='4';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((BLOWER_OP)+0X30);			//blower on off condtion
		}
		
		else if(iot_compenent_name[4]==HIGH)
		{
			iot_compenent_name[4]=0;
			temp_send_buf[tx_data++]='5';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((BURNER_OP)+0X30);			//burner on off condtion
		}
		
		else if(iot_compenent_name[5]==HIGH)
		{
			iot_compenent_name[5]=0;
			temp_send_buf[tx_data++]='6';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((tt_trip_switch_close_flag)+0X30);	//turn table trip
		}
		
		else if(iot_compenent_name[6]==HIGH)
		{
			iot_compenent_name[6]=0;
			temp_send_buf[tx_data++]='7';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((blower_trip_switch_close_flag)+0X30);	//blower trip
		}
		
		else if(iot_compenent_name[7]==HIGH)
		{
			iot_compenent_name[7]=0;
			temp_send_buf[tx_data++]='8';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((burner_trip_switch_close_flag)+0X30);	//burner trip
		}
		
		else if(iot_compenent_name[8]==HIGH)
		{
			iot_compenent_name[8]=0;
			temp_send_buf[tx_data++]='9';
			temp_send_buf[tx_data++]=':';
			temp_send_buf[tx_data++]=(char)((thermo_trip_switch_close_flag)+0X30);	//thermostat trip
		}
		if(temp_send_buf[1]!=0)
		{
			IOT_DATA_APPID_FUNID;
			form_send_buf(DATA_RES,tx_data);
		}
		tx_data=0;
	
	}

}
void io_on_off_check()
{
	switch(outputs)
	{
		case TURN_TABLE_ON_OFF:
					if((status==1)AND(!tt_trip_switch_close_flag))
					{
						TURN_TABLE_OP_ON;
						if((!bake_start_flag))//OR(door_switch_close_flag))
						{
							//manual_opearate_flag=SET;
							output_mode_flag=SET;
							if(!tt_switch_close_flag)
							{
								delay=40;		//delay for turn table ON from the switch
								while(delay);
							}
						}
					}
					else
					{

						TURN_TABLE_OP_OFF;
						output_mode_flag=CLEAR;
						if((err_popup_closed_flag)AND(tt_trip_switch_close_flag))
						{
							err_occured_flag=CLEAR;
							err_popup_closed_flag=CLEAR;
						}
					}											
					break;
		case BLOWER_ON_OFF:
					if((status==1)AND(!blower_trip_switch_close_flag))
					BLOWER_OP_ON;
					else
					{
						BLOWER_OP_OFF;
						if((err_popup_closed_flag)AND(blower_trip_switch_close_flag))
						{
							err_occured_flag=CLEAR;
							err_popup_closed_flag=CLEAR;
						}
					}
					break;
		case STEAM_VAL_ON_OFF:
					if(bake_start_flag)
					steam_release_flag=SET;
					else
					{
						if(status==1)
						STEAM_SOLE_OP_ON;
						else
						STEAM_SOLE_OP_OFF;
					}			
					break;
		case EXHAUST_FAN_ON_OFF:
					if(status==1)
					EXHAUST_FAN_OP_ON;
					else
					EXHAUST_FAN_OP_OFF;
					break;
		case INDI_LIGHT_ON_OFF:
					if(status==1)
					IND_LIGHT_OP_ON;
					else
					IND_LIGHT_OP_OFF;
					break;
		case  BURNER_ON_OFF:
					if(status==1)
					BURNER_OP_ON;
					else
					BURNER_OP_OFF;
		case  MQTT_TEST_MODE_ON_OFF:
					if(status==1)
					mqqt_test_mode_flag=SET;
					else
					{
						mqqt_test_mode_flag=CLEAR;
						mqqt_test_set_flag=CLEAR;
						set_temperature_for_testing_mqqt_data=0;
						set_baking_for_testing_mqqt_data=0;
						TURN_TABLE_OP_OFF;
						BLOWER_OP_OFF;
						BURNER_OP_OFF;
						IND_LIGHT_OP_OFF;
					}
					break;			break;
					
		
	}
}
void trip_switches_condition()
{
	if(emergency_switch_close_flag) 	// emergency error
	{	
		if(!err_occured_flag)
		{
			if(!bake_start_flag)
			ERR_SEND_APPID_FUNID;
			else
			ERR_AT_PROCESS_APPID_FUNID;
			form_send_buf(COMMAND_RES,EMERGENCY_DATA);
			//EMERGENY_POPUP_APPID_FUNID;
			//form_send_buf(COMMAND_RES,EMERGENCY_POPUP_MSG);   
			ALL_OUTPUTS_OFF;
			emergencyPressed_flag=SET;
			err_occured();			
		}
	}
	else if((!emergency_switch_close_flag)AND(emergencyPressed_flag))
	{
		bake_start_flag=SET;
		emergencyPressed_flag=CLEAR;
		IND_LIGHT_OP_ON;
	}
	else if(ctemp>350)		//over temp error
	{
		if(!err_occured_flag)
		{
			if(!bake_start_flag)
			ERR_SEND_APPID_FUNID;
			else
			ERR_AT_PROCESS_APPID_FUNID;
			form_send_buf(COMMAND_RES,TEMP_SENSOR_ERR_DATA);
			err_occured();
		}
	}
	else if(blower_trip_switch_close_flag) // blow error
	{
		if(!err_occured_flag)
		{
			BLOWER_OP_OFF;
			if(!bake_start_flag)
			ERR_SEND_APPID_FUNID;
			else
			ERR_AT_PROCESS_APPID_FUNID;
			form_send_buf(COMMAND_RES,BLOWER_TRIP_DATA);
			err_occured();			
		}
	}
	else if(tt_trip_switch_close_flag) // Turn trip error
	{	
		if(!err_occured_flag)
		{
			TURN_TABLE_OP_OFF;
			if(!bake_start_flag)
			ERR_SEND_APPID_FUNID;
			else
			ERR_AT_PROCESS_APPID_FUNID;
			form_send_buf(COMMAND_RES,TT_TRIP_DATA);
			err_occured();			
		}	
	}	
	else if(thermo_trip_switch_close_flag) // Thermo trip error
	{
		if(!err_occured_flag)
		{
			if(!bake_start_flag)
			ERR_SEND_APPID_FUNID;
			else
			ERR_AT_PROCESS_APPID_FUNID;
			form_send_buf(COMMAND_RES,THERMO_TRIP_DATA);
			err_occured();	
		}
	}
	else if(burner_trip_switch_close_flag) // Burner trip error
	{
		if(!err_occured_flag)
		{
			BURNER_OP_ON;	// it should be ON whenever burner trip error happen,because burner controller needs to reset.So we need power supply
			if(!bake_start_flag)
			ERR_SEND_APPID_FUNID;
			else
			ERR_AT_PROCESS_APPID_FUNID;
			form_send_buf(COMMAND_RES,BURNER_TRIP_DATA);
			err_occured();			
		}	
	}
	else
	err_rectified();
}

void err_occured()
{
	BUZZER_ON;
	BUZZER_OP_ON;
	ALL_OUTPUTS_OFF;
	err_occured_flag=SET;
	SCREEN_FREZZE_APPID_FUNID;
    	form_send_buf(COMMAND_RES,SCREEN_ON);
}
void err_rectified()
{
	if(err_occured_flag)
	{
		SCREEN_FREZZE_APPID_FUNID;
    		form_send_buf(COMMAND_RES,SCREEN_OFF);
		BUZZER_OFF;
		BUZZER_OP_OFF;
		if(bake_start_flag)
		step_no=1;
		err_occured_flag=CLEAR;
		ERR_CLOSED_APPID_FUNID;
		form_send_buf(COMMAND_RES,ERR_CLOSED_DATA);
	}
}
void temp_maintain_fun()
{	
	if((time_is_over_flag)AND(bake_start_flag)AND(step_no==TEMP_MAINTAINING))
	{
		if((!TURN_TABLE_OP)AND(!tt_trip_switch_close_flag))
		TURN_TABLE_OP_ON;
		if((!BLOWER_OP)AND(!blower_trip_switch_close_flag))
		BLOWER_OP_ON;
		if((ctemp>=stemp)AND(burner_on_flag)AND(!burner_trip_switch_close_flag))
		BURNER_OP_OFF;
		else if((ctemp<=(stemp-HYSTERSIS_TEMP)AND(!burner_on_flag)))
		BURNER_OP_ON;
	}
}
void mqqt_test_process()
{
	if((mqqt_test_mode_flag)AND(!bake_start_flag)AND(!mqqt_test_set_flag)AND(set_temperature_for_testing_mqqt_data!=0)AND(set_baking_for_testing_mqqt_data!=0)AND(!door_switch_close_flag))
	{
		TURN_TABLE_OP_ON;
		BLOWER_OP_ON;
		BURNER_OP_ON;
		IND_LIGHT_OP_ON;
		mqqt_test_set_flag=SET;
	}
}