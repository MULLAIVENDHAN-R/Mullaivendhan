/***********************INITIALIZATION*************************/
 unsigned char
machine_ready_delay;

 __boolean
handshake_ok_flag,
machine_ready_ok_flag;
/**********************INITIALIZATION**************************/





/**********************SEND_UART**************************/
 unsigned char
resend_count,
delay,
uart_error_count;

 __boolean
uart_send_flag,
send_ack_flag,
resend_flag;

 unsigned int
current_send_step_count,

send_temperature_counter,
heart_beat_counter,

one_mili_second_counter,
one_sec_counter,
fifty_milli_sec_counter,


trasmit_dly;
/**********************SEND_UART************************/




/**********************PROCESS**************************/

 __boolean
live_enter_ok_flag,

output_status_flag,
input_status_flag,


test_mode_ssid_condition,

cooling_fan_on_flag,

motor_fwd_pin_status,
motor_rev_pin_status,
cooling_pin_status,
heater_pin_status,


heart_beat_send_flag,
first_time_load_flag,
send_temperature_flag,
Door_status_flag,
process_start_flag,
process_stop_flag,

fwd_on_time_flag,
rev_on_time_flag,
fwd_pause_flag_flag,
rev_pause_flag_flag,

waiting_fwd_on_time_flag,
waiting_rev_on_time_flag,
waiting_fwd_pause_flag_flag,
waiting_rev_pause_flag_flag,




cooling_flag,
heating_flag;


 unsigned int
test_mode_ssid_no,

total_no_of_steps,
steps_timing,

waiting_steps_timing,
waiting_total_no_of_steps,

motor_fwd_on_time,
motor_rev_on_time,
motor_rev_pause_time,
motor_fwd_pause_time,
set_temperature,
set_rpm,
set_humidity,
set_splits,
set_direction;


 unsigned char
cycle;

/**********************PROCESS**************************/




/********************** IIC END  ************************/
 __boolean
sda_status_flag,
clock_low_flag
;

 char
received_data,
temp_pr[3],
receive_bit_counter,
*ram_addr
;

 unsigned int 
ACC,
disp_addr
;

 boolean 
ack_received_flag
;
/********************** IIC END  ************************/




/***********************SENSOR **************************/
 unsigned char
sh_count,
one_milli_sec_counter,
channel,
ready_status,
ch1_out[5],
ch2_out[5],
ch3_out[5],
ch4_out[5],

avg_count;

 __boolean
address_ack_flag,
humidity_read_flag,
sensors_read_flag,
address_write_confirm_flag,
read_address_ack_flag,
ready_status_check_flag,
write_ack_flag,
msb_lsb_flag;

 unsigned  int

temp_data,
temperature_degree,
temperature_reading;


/***********************SENSOR **************************/

/**********************SETTINGS**************************/

 unsigned  int
standard_motor_frequnecy,
Standard_speed_for_maximum_frequency,
motor_nominal_speed_50hz,
Maximum_speed_contol_fz,
High_temperature_tolerance,
Reset_temperature,
Heater_error_time_limit,
Heater_type;

 float
Motor_pully_to_main_pulley_ratio;
/**********************SETTINGS**************************/


/**********************INPUT_STATUS**************************/
 unsigned  int
current_temperature,
presure_data,
in_temperature_data,
out_temperature_data,
humidity_data,

door_open_check_timer,
door_close_check_timer,
lint_close_check_timer,
lint_open_check_timer;


 unsigned char
input_status_count;

 __boolean
door_open_flag,
lint_filter_open_flag;
/**********************INPUT_STATUS**************************/