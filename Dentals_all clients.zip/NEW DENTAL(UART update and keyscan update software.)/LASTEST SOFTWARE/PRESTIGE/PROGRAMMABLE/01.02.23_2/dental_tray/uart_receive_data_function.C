#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"


void uart_receive_data_function();			//THIS FUNCTION IS CONCENTRATE TO LED ON-OFF & LCD DISPLAY UPDATE FORM UART DATA


void uart_receive_data_function()
{
	uart_serial_received_data = uart_serial_received_data&0xffffffff;
	temp_uart_serial_received_data=(uart_serial_received_data);
	if((temp_uart_serial_received_data&0x20000000)==0x20000000)
	{
		if(!tumbler_on_flag)					//need to update the display quickly
		{
			error_id=4;
			display_flag=SET;
			TUMBLER_LED_ON;					//TUMBLER_WORKING					
			tumbler_on_flag=SET;
		}		
	}
	else
	{
		if((temp_uart_serial_received_data&0x10000000)==0x10000000)
		{
			if(!tumbler_prgm_on_flag)			//need to update the display quickly
			{
				error_id=4;
				display_flag=SET;
				TUMBLER_LED_ON;					//TUMBLER_SAVED
				tumbler_prgm_on_flag =SET;
			}
		}
		else
		{
		//	if(!tumbler_sw_flag)			//repeated sw pressed need to commend
			{
				TUMBLER_LED_OFF;					
				tumbler_prgm_on_flag =CLEAR;
				tumbler_on_flag =CLEAR;
			}
		}
	}
	if((temp_uart_serial_received_data&0x80000000)==0x80000000)
	{
		if(!spit_on_flag)						//need to update the display quickly
		{
			error_id=5;
			display_flag=SET;
			SPITOON_LED_ON;						//SPIT_WORKING								
			spit_on_flag=SET;
		}
	}
	else
	{
		if((temp_uart_serial_received_data&0x40000000)==0x40000000)
		{
			if(!spitoon_prgm_on_flag)			//need to update the display quickly
			{
				error_id=5;
				display_flag=SET;
				SPITOON_LED_ON;				//SPIT_SAVED
				spitoon_prgm_on_flag=SET;
			}
		}
		else
		{
		//	if(!spit_sw_flag)			//repeated sw pressed need to commend
			{
				SPITOON_LED_OFF;			
				spit_on_flag=CLEAR;
				spitoon_prgm_on_flag=CLEAR;				
			}
		}
	}
	if((temp_uart_serial_received_data&0x08000000)==0x08000000)
	{
		if(!pgm1_on_flag)
		{
		//	PROGRAM1_LED_ON;			//PGM1_WORKING			
			pgm1_on_flag= SET;
			error_id=17;
			display_flag=SET;
		}
	}
	else
	{
		if((temp_uart_serial_received_data&0x04000000)==0x04000000)
		{
			if(!pgm1_prgm_on_flag)
			{
				//PROGRAM1_LED_ON;		//PGM1_SAVED				
				pgm1_prgm_on_flag = SET;
				error_id=17;
				display_flag=SET;
			}
		}
		else
		{
			if(!pgm1_sw_flag)
			{
				//PROGRAM1_LED_OFF;				
				pgm1_on_flag= CLEAR;
				pgm1_prgm_on_flag = CLEAR;
				
			}
		}
	}
	if((temp_uart_serial_received_data&0x02000000)==0x02000000)
	{
		if(!pgm2_on_flag)
		{
			//PROGRAM2_LED_ON;				//PGM2_WORKING
			SIGNAL_LED_ON;
			pgm2_on_flag= SET;
			error_id=18;
			display_flag=SET;
		}
	}
	else
	{
		if((temp_uart_serial_received_data&0x01000000)==0x01000000)
		{
			if(!pgm2_prgm_on_flag)
			{
			//	PROGRAM2_LED_ON;			//PGM2_SAVED
				SIGNAL_LED_ON;
				pgm2_prgm_on_flag = SET;
				error_id=18;
				display_flag=SET;
			}
		}
		else
		{
			if(!pgm2_sw_flag)
			{
			//	PROGRAM2_LED_OFF;				
				pgm2_on_flag= CLEAR;
				pgm2_prgm_on_flag = CLEAR;
				
			}
		}
	}
	if((temp_uart_serial_received_data&0x00800000)==0x00800000)
	{
		if(!pgm3_on_flag)
		{
		//	PROGRAM3_LED_ON;					//PGM3_WORKING
			SIGNAL_LED_ON;
			pgm3_on_flag= SET;
			error_id=19;
			display_flag=SET;
		}
	}
	else
	{
		if((temp_uart_serial_received_data&0x00400000)==0x00400000)
		{
			if(!pgm3_prgm_on_flag)
			{
		//		PROGRAM3_LED_ON;				//PGM3_SAVED
				SIGNAL_LED_ON;
				pgm3_prgm_on_flag = SET;
				error_id=19;
				display_flag=SET;
			}
		}
		else
		{
			if(!pgm3_sw_flag)
			{
			//	PROGRAM3_LED_OFF;			
				pgm3_on_flag= CLEAR;
				pgm3_prgm_on_flag = CLEAR;				
			}
		}
	}
	if((temp_uart_serial_received_data&0x00200000)==0x00200000)
	{
		if(!shark_on_flag)
		{
		//	SHARK_LED_ON;						//SHARK_ON
			SIGNAL_LED_ON;
			shark_on_flag= SET;
			error_id=16;
			display_flag=SET;
		}
	}
	else
	{
		if((temp_uart_serial_received_data&0x00100000)==0x00100000)
		{
			if(!shark_prgm_on_flag)
			{
			//	SHARK_LED_ON;					//SHARK_SAVED
				SIGNAL_LED_ON;
				shark_prgm_on_flag = SET;
				error_id=16;
				display_flag=SET;
			}
			//SIGNAL_LED_ON;
		}
		else
		{
			if(!shark_sw_flag)
			{
				//SHARK_LED_OFF;
			//	SIGNAL_LED_OFF;				
				shark_on_flag= CLEAR;
				shark_prgm_on_flag = CLEAR;			
			}
		}
	}
	if((temp_uart_serial_received_data&0x00080000)==0x00080000)
	{
		if(!gaugle_on_flag)
		{
		//	GARGLE_LED_ON;							//GAUGLE_WORKING
			SIGNAL_LED_ON;
			gaugle_on_flag= SET;
			error_id=15;
			display_flag=SET;
		}
	}
	else
	{
		if((temp_uart_serial_received_data&0x00040000)==0x00040000)
		{
			if(!gaugle_prgm_on_flag)
			{
			//	GARGLE_LED_ON;
				SIGNAL_LED_ON;
				gaugle_prgm_on_flag = SET;			//GAUGLE_SAVED
				error_id=15;
				display_flag=SET;
			}
		}
		else
		{
			if(!gaugle_sw_flag)
			{
			//	GARGLE_LED_OFF;				
				gaugle_on_flag= CLEAR;
				gaugle_prgm_on_flag = CLEAR;			
			}
		}
	}
	if((temp_uart_serial_received_data&0x00020000)==0x00020000)
	{
		if(!zero_sw_flag)
		{
			zero_on_flag= SET;					//ZERO_WORKING
			error_id=20;
			display_flag=SET;
			SIGNAL_LED_ON;
		}
	}
	else
	{	
		zero_on_flag= CLEAR;	
	}
	if((temp_uart_serial_received_data&0x00010000)==0x00010000)
	{
		if(!lamp_second_time_flag)
		{
			error_id=7;
			display_flag=SET;
			lamp_second_time_flag= SET;			//LAMP_LED&DISPALY UPDATE FROM UART
			LAMP_LED_ON;			
		}
	}
	else
	{	
		lamp_second_time_flag= CLEAR;
		LAMP_LED_OFF;			
	}
	if((temp_uart_serial_received_data&0x00008000)==0x00008000)
	{
		if(!foot_signal_flag)
		{			
			if(aeroter_on_flag)
			direct_uart_send_data = ((direct_uart_send_data)&(0xffffffd0));
			foot_signal_flag = SET;			//FOOT_INPUT
		}
	}
	else
	{
		foot_signal_flag = CLEAR;	
	}
	if((temp_uart_serial_received_data&0x00004000)==0x00004000)
	{		
			act_up_flag=SET;
			SIGNAL_LED_ON;
			foot_act_up_flag=SET;			//	ACTUATOR_UP_KEY
			error_id=0;
			display_flag=SET;	
	}
	else
	{	
		act_up_flag=CLEAR;
		foot_act_up_flag=CLEAR;	
		//SIGNAL_LED_OFF;	
		if(!act_fwd_flag&&!act_rev_flag&&!act_dwn_flag&&!act_up_flag&&!zero_on_flag&&!gaugle_on_flag&&!shark_on_flag&&!pgm3_on_flag&&!pgm2_on_flag&&!pgm1_on_flag)
		SIGNAL_LED_OFF;
	}
	if((temp_uart_serial_received_data&0x00002000)==0x00002000)
	{	
			act_dwn_flag=SET;
			SIGNAL_LED_ON;
			foot_act_dwn_flag=SET;			//	ACTUATOR_DWN_KEY
			error_id=1;	
			display_flag=SET;	
	}
	else
	{
		act_dwn_flag=CLEAR;
		foot_act_dwn_flag=CLEAR;
		if(!act_fwd_flag&&!act_rev_flag&&!act_dwn_flag&&!act_up_flag&&!zero_on_flag&&!gaugle_on_flag&&!shark_on_flag&&!pgm3_on_flag&&!pgm2_on_flag&&!pgm1_on_flag)
		SIGNAL_LED_OFF;
	}
	if((temp_uart_serial_received_data&0x00001000)==0x00001000)
	{		
			act_rev_flag=SET;
			SIGNAL_LED_ON;
			foot_act_rev_flag=SET;			//	ACTUATOR_REV_KEY
			error_id=3;
			display_flag=SET;
	}
	else
	{
		act_rev_flag=CLEAR;
		foot_act_rev_flag=CLEAR;
		if(!act_fwd_flag&&!act_rev_flag&&!act_dwn_flag&&!act_up_flag&&!zero_on_flag&&!gaugle_on_flag&&!shark_on_flag&&!pgm3_on_flag&&!pgm2_on_flag&&!pgm1_on_flag)
		SIGNAL_LED_OFF;
		
	}
	if((temp_uart_serial_received_data&0x00000800)==0x00000800)
	{		
			act_fwd_flag=SET;
			SIGNAL_LED_ON;
			foot_act_fwd_flag=SET;
			error_id=2;						//	ACTUATOR_FWD_KEY
			display_flag=SET;	
	}
	else
	{	
		act_fwd_flag=CLEAR;
		foot_act_fwd_flag=CLEAR;
		if(!act_fwd_flag&&!act_rev_flag&&!act_dwn_flag&&!act_up_flag&&!zero_on_flag&&!gaugle_on_flag&&!shark_on_flag&&!pgm3_on_flag&&!pgm2_on_flag&&!pgm1_on_flag)
		SIGNAL_LED_OFF;
	}
	if((temp_uart_serial_received_data&0x00000200)==0x00000200)
	{
		if(!up_dn_pulse_error_flag)			//ACT1_PULSE_ERROR
		{
			up_dn_pulse_error_flag=SET;
			error_id=8;	
			display_flag=SET;
		}					
	}
	else
	{	
		up_dn_pulse_error_flag=CLEAR;
	}
	if((temp_uart_serial_received_data&0x00000400)==0x00000400)
	{
		if(!fwd_rev_pulse_error_flag)		//ACT2_PULSE_ERROR
		{
			fwd_rev_pulse_error_flag=SET;
			error_id=9;	
			display_flag=SET;				
		}
	}
	else
	{	
		fwd_rev_pulse_error_flag=CLEAR;
	}
	uart_serial_received_data1=(temp_uart_serial_received_data);
}