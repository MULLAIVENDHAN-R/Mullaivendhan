#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

void is_this_pending_restart();
extern void eeprom_write(unsigned int, unsigned char);
extern unsigned char eeprom_read(unsigned char);
void is_this_pending_restart()
{
	if(prep_pending_restart_flag)
	{
		htr1_on_flag=eeprom_read(eeprom_htr1_on_off_state);
		if(htr1_on_flag)
		HEATER_A_ON;
		htr2_on_flag=eeprom_read(eeprom_htr2_on_off_state);
		if(htr2_on_flag)
		HEATER_B_ON;
		htr3_on_flag=eeprom_read(eeprom_htr3_on_off_state);
		if(htr3_on_flag)
		HEATER_C_ON;
		htr4_on_flag=eeprom_read(eeprom_htr4_on_off_state);
		if(htr4_on_flag)
		HEATER_D_ON;
		wtr_htr_on_flag=eeprom_read(eeprom_water_htr_on_off_state);
		if(wtr_htr_on_flag)
		MOTOR9_FWD_ON;
		dc_fan_on_flag=eeprom_read(eeprom_dc_fan_on_off_state);
		if(dc_fan_on_flag)
		DC_FAN_ON;
		c1_in_idle_condition_flag=eeprom_read(eeprom_c1_idle);
		c2_in_idle_condition_flag=eeprom_read(eeprom_c2_idle);
		c3_in_idle_condition_flag=eeprom_read(eeprom_c3_idle);
		c1_lock_flag=eeprom_read(eeprom_c1_lock);			// new update
		c2_lock_flag=eeprom_read(eeprom_c2_lock);
		c3_lock_flag=eeprom_read(eeprom_c3_lock);
		
	}
	else
	{
		eeprom_write(eeprom_htr1_on_off_state,0);
		eeprom_write(eeprom_htr2_on_off_state,0);
		eeprom_write(eeprom_htr3_on_off_state,0);
		eeprom_write(eeprom_htr4_on_off_state,0);
		eeprom_write(eeprom_water_htr_on_off_state,0);
		eeprom_write(eeprom_dc_fan_on_off_state,0);
		eeprom_write(eeprom_c1_idle,1);
		eeprom_write(eeprom_c2_idle,1);
		eeprom_write(eeprom_c3_idle,1);
		eeprom_write(eeprom_c1_lock,0);
		eeprom_write(eeprom_c2_lock,0);
		eeprom_write(eeprom_c3_lock,0);
		
		if(!is_model_1)
    		c1_in_idle_condition_flag=c2_in_idle_condition_flag=c3_in_idle_condition_flag=SET;
	}
}
void store_output_status()
{
	if(htr1_eeprom_store_flag)
	{
		htr1_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_htr1_on_off_state,htr1_on_flag);
	}
	if(htr2_eeprom_store_flag)
	{
		htr2_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_htr2_on_off_state,htr2_on_flag);
	}
	if(htr3_eeprom_store_flag)
	{
		htr3_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_htr3_on_off_state,htr3_on_flag);
	}
	if(htr4_eeprom_store_flag)
	{
		htr4_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_htr4_on_off_state,htr4_on_flag);
	}	
	if(water_htr_eeprom_store_flag)
	{
		water_htr_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_water_htr_on_off_state,wtr_htr_on_flag);
	}
	if(dc_fan_eeprom_store_flag)
	{
		dc_fan_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_dc_fan_on_off_state,dc_fan_on_flag);
	}
	if(c1_idle_eeprom_store_flag)
	{
		c1_idle_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_c1_idle,c1_in_idle_condition_flag);
	}
	if(c2_idle_eeprom_store_flag)
	{
		c2_idle_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_c2_idle,c2_in_idle_condition_flag);
	}
	if(c3_idle_eeprom_store_flag)
	{
		c3_idle_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_c3_idle,c3_in_idle_condition_flag);
	}
	if(c1_lock_eeprom_store_flag)
	{
		c1_lock_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_c1_lock,c1_lock_flag);
	}
	if(c2_lock_eeprom_store_flag)
	{
		c2_lock_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_c2_lock,c2_lock_flag);
	}
	if(c3_lock_eeprom_store_flag)
	{
		c3_lock_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_c3_lock,c3_lock_flag);
	}
	if(cooker_model_eeprom_store_flag)
	{
		cooker_model_eeprom_store_flag=CLEAR;
		eeprom_write(eeprom_cooker_model,is_model_1);
	}
}