#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

extern void gui_uart_send();
extern void sensor_open_close_conform();
extern unsigned char eeprom_read(unsigned char);

void handshake_ok()
{
	while(!handshake_ok_flag)
	{
		gui_uart_send();
		sensor_open_close_conform();
	}
	year=eeprom_read(eeprom_rtc_year);
}