#pragma interrupt INTSR0 uart_receive
#include "r_cg_macrodriver.h"
#include "UART_MACROS.h"
#include "MACROS.h"
#include <stdlib.h>
#include "string.h"
#include "X_variables.h"
#include "r_cg_serial.h"


unsigned char 
						
			received_app_id,
			received_fun_id,
			app_id,
			fun_id,			
			
			total_length,
			total_length_byte,
			total_data_bytes,
			buf_length,check_sum,data,
			uart_main_buf[MAX_SIZE_RX_BUF],
			uart_recived_data[MAX_SIZE_RX_BUF],
			uart_recived_backup_buf[MAX_SIZE_RX_BUF],
			string_process_data_buf[MAX_SIZE_RX_BUF],
			process_data_buf[MAX_SIZE_RX_BUF];	
			
static __boolean 	
			check_sum_err_flag,
			str_process_data_flag,
			general_data_recevied_flag,
			appid_err_flag,
			funid_err_flag,
			total_byte_err_flag,
			checksum_err_flag;

int remove_stuff_byte(char);
int recevice_checksum( unsigned char);
void check_app_fun_id();
void received_fine_buf( char);
void app_id_fun_id();

extern void str_to_process_data(unsigned char str[],unsigned char app,unsigned char fun);
extern void uart_process_data( unsigned char data[],unsigned char received_app_id, unsigned char received_fun_id);



/**********************  sender_functions  ***********************/

void uart_receive()
{

	static __boolean 	
	receive_complete_flag;		
	
	uart_main_buf[data] = RXD0;	
	uart_error_count=10;                 // 10 ms
	
	buf_length=(((uart_main_buf[0]==START_BYTE)/*AND(uart_main_buf[1]==0x08)*/)AND(data<MAX_SIZE_RX_BUF))?((uart_main_buf[data]==END_BYTE)?(receive_complete_flag=SET,data+1):++data):(data=0);
	if(receive_complete_flag)
	{
		receive_complete_flag=CLEAR;
		data=uart_error_count=0;		
		total_length=(char)remove_stuff_byte(buf_length);
		total_data_bytes=uart_recived_backup_buf[4];
		if(total_data_bytes>FIXED_DATA_LENGTH)
		total_byte_err_flag=SET;
		if(!total_byte_err_flag)
		{			
			check_sum_err_flag=recevice_checksum(total_length);
			app_id_fun_id();
			if((!appid_err_flag)AND(!funid_err_flag)AND(!check_sum_err_flag))
			received_fine_buf(total_length);
			memset(uart_recived_backup_buf,0,sizeof(uart_recived_backup_buf));			
		}		
	}
}
int recevice_checksum( unsigned char total_len)
{
	char temp_check_sum=0,count,byte;
	for(byte=START_FROM,count=0;byte<total_len-2;byte++,count++)
	temp_check_sum=(temp_check_sum+(count^(uart_recived_backup_buf[byte])));
	temp_check_sum=~(temp_check_sum+uart_recived_backup_buf[HEADER]);
	if(temp_check_sum==uart_recived_backup_buf[total_len-2])
	return 0;
	else
	return 1;
}
int remove_stuff_byte(char len)
{
	unsigned char i=0,j=0;
	for(i=0,j=0;i<len;i++,j++)
	{
		if(uart_main_buf[i]==STUFF_BYTE)
		uart_recived_backup_buf[j]=(~uart_main_buf[++i]);
		else
		{
			uart_recived_backup_buf[j]=uart_main_buf[i];
			if(uart_main_buf[i]==END_BYTE)
			break;
		}		
	}
	memset(uart_main_buf,0,sizeof(uart_main_buf));
	return j+1; 
}
void app_id_fun_id()
{
	unsigned char i,j,app_fun_id[TOTAL_APP_ID][MAX_FUN_ID+1]={
									{0X01,0X01,0X02},	//here this has all appid and fun id
				      			    	    	{0X02,0X01},
	                              			    	    	{0X03,0X01},
								    	{0X04,0X01,0X02},
									{0X05,0X01},
									{0X06,0X01,0X02},
									{0X07,0X01,0X02,0X03},
									{0X08,0X01,0X02,0X03,0x04},
									{0X09,0X01},
								    	{0X0A,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C},							
								    	{0X0B,0X01,0X02}									
								  };
	
	if(((app_id=uart_recived_backup_buf[4])>0)AND((fun_id=uart_recived_backup_buf[5])>0))
	{	
		appid_err_flag=funid_err_flag=1;
		for(i=0;i<TOTAL_APP_ID;i++)
		{
			if(app_fun_id[i][0]==app_id)
			{
		        	appid_err_flag=0;
			    	for(j=0;j<(MAX_FUN_ID+1);j++)
			    	{
			       		if((j>0)AND(app_fun_id[i][j]==fun_id))
					{
			        		funid_err_flag=0;
						break;
					}
			    	}
				break;
			}
		        
		}
	}
	else
	{
		if(app_id==0)
		appid_err_flag=1;
		if(fun_id==0)
		funid_err_flag=1;
	}
}
void received_fine_buf( char total_len)
{
	unsigned char i,j,byte1,byte2;	
	total_length=total_len;
	if(((app_id==0x0A)AND(fun_id==0x04))OR((app_id==0x06)AND(fun_id==0x02))OR((app_id==0x05)AND(fun_id==0x01)))
	{
		for(byte1=DATA_START,i=0;byte1<total_len-2;byte1++,i++)
		{
			string_process_data_buf[i]=uart_recived_backup_buf[byte1];
		}
		str_process_data_flag=SET;					
	}
	else 
	{		
		for(byte2=DATA_START,j=0;byte2<total_len-2;byte2++,j++)
		{
			process_data_buf[j]=uart_recived_backup_buf[byte2];			
		}
		general_data_recevied_flag=SET;
	}
	
}
void dataRcvd_to_process_buf_conversion()
{
	
	if(str_process_data_flag)
	{
		str_to_process_data(string_process_data_buf,app_id,fun_id);
		//if(!error_flag)
		uart_process_data(string_process_data_buf,app_id,fun_id);
		str_process_data_flag=CLEAR;
		memset(string_process_data_buf,0,sizeof(string_process_data_buf));
	}
	else if(general_data_recevied_flag)
	{		
		uart_process_data(process_data_buf,app_id,fun_id);
		general_data_recevied_flag=CLEAR;
		memset(process_data_buf,0,sizeof(process_data_buf));
	}
}

