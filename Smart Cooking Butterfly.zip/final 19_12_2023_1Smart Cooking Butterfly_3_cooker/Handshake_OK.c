#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"

extern void kadai_home_position();
extern void cookers_home_position();
extern void init_lid_home_position();
extern void init_veg_tray_home_position();
extern void form_send_buf(char,char);
extern void process_buf_splitup();
extern void allTime_check_fun();

void handshake_approve()
{
	while((!handshake_ok_flag)OR(!cooker_set_flag))
	{
		allTime_check_fun();
		if(handshake_ok_flag)
		{
			if(!is_model_1)
			{
				if(!cooker_set_flag)
				{
					kadai_home_position(); 				// kadai home position
    					kadai_home_position_ok_flag=CLEAR;
				   	init_lid_home_position();  			// lid
    					lid_position_flag=CLEAR;					
					cookers_home_position();			// cooker		
					init_veg_tray_home_position();			//veg tray
					veg_tray_position_ok_flag=CLEAR;
					cooker_set_flag=SET;
					received_app_id=0X01;
					received_fun_id=0X01;
					waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
					form_send_buf(COMMAND_RES,HANDSHAKE_DATA);
				}
			}
			else
			{
				cooker_set_flag=SET;
				received_app_id=0X01;
				received_fun_id=0X01;
				//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
				form_send_buf(COMMAND_RES,HANDSHAKE_DATA);
			}				
		}
	}
}