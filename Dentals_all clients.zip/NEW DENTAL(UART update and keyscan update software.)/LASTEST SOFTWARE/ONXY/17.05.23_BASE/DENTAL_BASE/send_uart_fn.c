#include "sfr_r825.h" 
#include "xvariables.h"
#include "macro.h"

void serial_sendbyte1();
void resend_uart_function();
void serial_sendbyte2();

void serial_sendbyte1()
{
	te_u0c1=1;
	for(k=0;k<=6;k++)
	{
		u0tb = char_buffer2[k];
		while(ti_u0c1 == 0);
		
		
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
	/*	asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");*/
	}
	te_u0c1=0;
//	while(ti_u0c1 == 0);
		
}
void serial_sendbyte2()
{
	te_u0c1=1;
	for(k=0;k<=6;k++)
	{
		u0tb = char_buffer3[k];
		while(ti_u0c1 == 0);
		
		
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");
	/*	asm ("NOP");
		asm ("NOP");
		asm ("NOP");
		asm ("NOP");*/
	}
	te_u0c1=0;
//	while(ti_u0c1 == 0);
		
}
void resend_uart_function()
{
	resend_bit=0x00;
	resend_data_status=0x00000000;
	
	while(resend_bit<32)
	//for(resend_bit=0x00;resend_bit<32;resend_bit++)
	{
		switch(resend_bit)
		{
			case 0:	
						if(spit_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 1:		
						if(spit_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
																							
			case 2:
						if(tumbler_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR; 
						break;						
			case 3:
						if(tumbler_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;       
						break;				
			case 4:
						if((pgm1_fwd_rev_disp_flag)OR(pgm1_up_dwn_disp_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;						
			case 5:
						if(pgm1_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;					
			case 6:
						if((pgm2_up_dwn_disp_flag)OR(pgm2_fwd_rev_disp_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;						
			case 7:
						if(pgm2_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
						
			case 8:
						if((pgm3_up_dwn_disp_flag)OR(pgm3_fwd_rev_disp_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;											
			case 9:
						if(pgm3_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;	
			case 10:
						if((shark_up_dwn_disp_flag)OR(shark_fwd_rev_disp_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 11:
						if(shark_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;	
			case 12:
						if(gaugle_fwd_rev_disp_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 13:
						if(gaugle_prgm_on_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
						
			case 14:
						if((zero_fwd_rev_disp_flag)OR(zero_up_dwn_disp_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 15:
						if((lamp_low_sw_flag)OR(lamp_high_sw_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 16:
						if(FOOT_INPUT==0)
						{
							send_key_bit = SET; 							
						}  
						else
						send_key_bit = CLEAR;        
						break;
			case 17:
						if(((foot_up_sw_flag)OR(up_act_display_send_flag)OR(asst_act_up_flag))AND(!up_dn_pulse_error_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;	
			case 18:
						if(((foot_dwn_sw_flag)OR(dwn_act_display_send_flag)OR(aast_act_dwn_flag))AND(!up_dn_pulse_error_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 19:
						if(((foot_rev_sw_flag)OR(rev_act_display_send_flag)OR(asst_act_rev_flag))AND(!fwd_rev_pulse_error_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 20:
						if(((foot_fwd_sw_flag)OR(fwd_act_display_send_flag)OR(asst_act_fwd_flag))AND(!fwd_rev_pulse_error_flag))
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 21:
						if(fwd_rev_pulse_error_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
			case 22:
						if(up_dn_pulse_error_flag)
						send_key_bit = SET;    
						else
						send_key_bit = CLEAR;        
						break;
																	
			default :  
						send_key_bit = CLEAR;
						break;
		}
	
		if(resend_bit<=30)
		{
			resend_data_status = (resend_data_status|send_key_bit);	
			resend_data_status = (resend_data_status<<1);
		}
		else
		resend_data_status = (resend_data_status|send_key_bit);
		resend_bit=(resend_bit+1);
	}
		
	//	resend_data_status = (resend_data_status&0xFFffffff);
		resend_data_status = (resend_data_status&0x00FFFFFFFF);
		uart_resend_data_status = resend_data_status;	
		if(send_data_status!=uart_resend_data_status)
		{			
			send_data_status=uart_resend_data_status;
			temp_send_data_status=send_data_status;
			send_uart_data_flag=SET;
		}
}

void calculate_crc(void)
{
	crc = 0xffff;
	temp = packet_length;      // to calculate the crc for data for transmission
	for(array_index=0; array_index<temp;array_index++)
	{
		asm ("NOP");
		byte = char_buffer2[array_index];
		for(bit_counter=0;bit_counter<8;bit_counter++) 
		{
			tmp_crc = ((crc>>15) ^ (byte>>7));	//temp is now MSB of crc XOR�ed with MSB of byte.
			crc<<=1; //left shift one space
			if(tmp_crc)
			{
         		crc ^=  0X1021;
			}
			byte<<=1;
		}
	}
	char_buffer2[packet_length] = crc;      // LSB of crc
	char_buffer2[packet_length+1] = crc>>8; // MSB of crc
}


_Bool check_crc(void)
{
	crc = 0xffff;
	temp_vaa = 5;
	for(array_index=0; array_index<temp_vaa;array_index++)
	{
		asm ("NOP");
		byte = char_buffer[array_index];
		for(bit_counter=0;bit_counter<8;bit_counter++) 
		{
			tmp_crc = ((crc>>15) ^ (byte>>7));	//temp is now MSB of crc XOR�ed with MSB of byte.
			crc<<=1; //left shift one space
			if(tmp_crc)
			{
         		crc ^=  0X1021;
			}
			byte<<=1;
		}
	}
	//HTPIC has litte endian ie LSB is right side
	tmp_crc = char_buffer[temp_vaa+1];  // MSB of received crc
	tmp_crc<<=8;
	tmp_crc = ((tmp_crc)|(char_buffer[temp_vaa]));  // LSB of received crc
			
	if(tmp_crc EQUAL_TO crc)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}

