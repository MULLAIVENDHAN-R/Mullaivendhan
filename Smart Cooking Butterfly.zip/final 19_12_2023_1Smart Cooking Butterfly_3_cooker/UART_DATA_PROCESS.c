#include "r_cg_macrodriver.h"
#include "r_cg_serial.h"
#include "string.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "GUI_XVariables.h"



extern __boolean is_valid_data(unsigned char received_buf[],char);
extern void form_send_buf(char,char);
extern void veg_tray_home_position();
extern void lid_home_position();
extern void receipe_prep_process();
extern void err_resend_fun();
extern void is_err_data_came();
extern void load_test_fun();
extern void dish1_prep_process();
extern void check_idle_condition();
extern void dish2_prep_process();
extern void dish3_prep_process();
extern void cookers_home_position();
extern void gui_uart_send();
extern void init_veg_tray_home_position();

static unsigned char chk_frame_err=0;

void process_buf_splitup()
{
	received_app_id=app_id;
	received_fun_id=fun_id;
	if((!resend_flag)AND(!frame_err_flag))
	{
		if((received_app_id==HANDSHAKE_APP_ID)AND(received_fun_id==DISPLAY_ST_FUN_ID))
		{
			frame_err_flag=(process_data_buf1[DATA]=='D')?is_valid_data(process_data_buf1,DISPLAY_READY_DATA):1;
			if(!frame_err_flag)
			{
				if(!handshake_ok_flag)
				{
					handshake_ok_flag=SET;
					heart_beat_delay_cntr=60;
					one_min_counter=60;	// for initial RTC send
				}
				//form_send_buf(COMMAND_RES,HANDSHAKE_DATA);	//Here it is blocked to complete the cooker home position set.
			}
		}
		if((received_app_id==HANDSHAKE_APP_ID)AND(received_fun_id==PENDING_RESTART_FUN_ID))
		{
			frame_err_flag=(process_data_buf1[DATA]=='R')?is_valid_data(process_data_buf1,PREP_PENDING_RESTART):1;
			if(!frame_err_flag)
			{
				handshake_ok_flag=SET;
				one_min_counter=60;	// for initial RTC send
				cooker_set_flag=SET;
				initial_position_ok_flag=SET;
				prep_pending_restart_flag=SET;
				restart_cooker_move_flag=SET;
				//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
				form_send_buf(COMMAND_RES,ACK_DATA);
			}
		}
	}
	if((!resend_flag)AND(handshake_ok_flag)AND(!frame_err_flag))//AND(cooker_set_flag))
	{
		switch(received_app_id)
		{
			case VEG_TRAY_ADJ_APP_ID:
							switch(received_fun_id)
							{
								case POS_REQ_FUN_ID:
											frame_err_flag=(process_data_buf1[DATA]=='R')?is_valid_data(process_data_buf1,REQUEST_DATA):1;
											if(!frame_err_flag)
											{
												tray_pos_rqt_acpt_flag=SET;
												veg_tray_home_position();
											}
											break;
								case ADJ_DATA_FUN_ID:
											//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
											form_send_buf(COMMAND_RES,ACK_DATA);											
											if(!tray_pos_adj_data_flag)
											{
												memcpy(cooker1_buf,process_data_buf,sizeof(process_data_buf));
												tray_pos_adj_data_flag=SET;												
												veg_tray_home_position();												
											}											
											break;
							}	
							break;
			case LID_ADJ_APP_ID	:
							switch(received_fun_id)
							{
								case POS_REQ_FUN_ID:
											frame_err_flag=(process_data_buf1[DATA]=='R')?is_valid_data(process_data_buf1,REQUEST_DATA):1;
											if(!frame_err_flag)
											{
												lid_pos_rqt_acpt_flag=SET;
												lid_home_position();
											}
											break;
								case ADJ_DATA_FUN_ID:	
											//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
											form_send_buf(COMMAND_RES,ACK_DATA);											
											if(!lid_pos_adj_data_flag)
											{
												memcpy(cooker1_buf,process_data_buf,sizeof(process_data_buf));
												lid_pos_adj_data_flag=SET;												
												lid_home_position();	
											}											
											break;
							}
							break;
			case LOAD_TEST_APP_ID	:
							switch(received_fun_id)
							{
								case TEST_DATA_FUN_ID:
											//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(!load_test_start_flag)
											{
												memcpy(load_test_buf,process_data_buf,sizeof(process_data_buf));												
												load_test_fun();
											}
											break;
								case TEST_STOP_FUN_ID:
											//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(load_test_start_flag)
											{
												memcpy(load_test_buf,process_data_buf1,sizeof(process_data_buf1));												
												load_test_fun();
											}
											break;
								case SINGLE_MULTI_COOKER_SELECT_FUN_ID:
											//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
											form_send_buf(COMMAND_RES,ACK_DATA);
											if(process_data_buf1[0]=='S')
											is_model_1=1;
											else if(process_data_buf1[0]=='M')
											{
												is_model_1=0;
												c1_in_idle_condition_flag=c2_in_idle_condition_flag=c3_in_idle_condition_flag=SET;
												c1_idle_eeprom_store_flag=c2_idle_eeprom_store_flag=c3_idle_eeprom_store_flag=SET;
											}
											else
											frame_err_flag=SET;
											//eeprom_store_flag=SET;
											cooker_model_eeprom_store_flag=SET;
											break;
											
							}
							break;
			case RECEIPE_PREP_APP_ID:					
							
							switch(received_fun_id)
							{
								case STEP_DATA_FUN_ID:
											switch(process_data_buf[DATA])
											{
												case COOKER1:	
														current_send_step_count=c1_step_count;														
														form_send_buf(COMMAND_RES,COOKER1_ACK_DATA);													
														if(!dish1_data_flag)
														{															
															memcpy(cooker1_buf,process_data_buf,sizeof(process_data_buf));				
															dish1_data_flag=SET;
															dish1_prep_process();
														}															
														break;
												case COOKER2:	
														current_send_step_count=c2_step_count;
														form_send_buf(COMMAND_RES,COOKER2_ACK_DATA);														
														if(!dish2_data_flag)
														{
															memcpy(cooker2_buf,process_data_buf,sizeof(process_data_buf));														
															dish2_data_flag=SET;
															dish2_prep_process();
														}
														break;
												case COOKER3:	
														current_send_step_count=c3_step_count;
														form_send_buf(COMMAND_RES,COOKER3_ACK_DATA);														
														if(!dish3_data_flag)
														{
															memcpy(cooker3_buf,process_data_buf,sizeof(process_data_buf));														
															dish3_data_flag=SET;
															dish3_prep_process();
														}														
														break;
												default:
														frame_err_flag=SET;
											}										
											break;
								case DONE_ACK_FUN_ID:								
											switch(process_data_buf1[DATA+1])		//here compare 1/2/3 in ascii format
											{
												case CKR1_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER1_ACK_DATA);
														if(!frame_err_flag)
														{
															c1_resend_cnt=0;
															c1_resend_ok_flag=CLEAR;
															c1_one_time_resend_flag=CLEAR;
														}
														break;
												case CKR2_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER2_ACK_DATA);
														if(!frame_err_flag)
														{
															c2_resend_cnt=0;
															c2_resend_ok_flag=CLEAR;
															c2_one_time_resend_flag=CLEAR;
														}
														break;
												case CKR3_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER3_ACK_DATA);
														if(!frame_err_flag)
														{
															c3_resend_cnt=0;
															c3_resend_ok_flag=CLEAR;
															c3_one_time_resend_flag=CLEAR;
														}
														break;
												default:
														frame_err_flag=SET;
											}
											if(!frame_err_flag)
											{
												//if(!ack_ok_flag)
												{
													//resend_not_ok_flag=CLEAR;													
													waiting_for_ack_flag=CLEAR;
													uart_driver_reset_flag=CLEAR;
													resend_cnt=0;
													ack_ok_flag=SET;
												}
											}
											break;												
																						
								case PREP_STOP_FUN_ID:
								
											switch(process_data_buf1[DATA+1])		//here compare 1/2/3 in ascii format
											{
												case CKR1_STR:
														frame_err_flag=is_valid_data(process_data_buf1,COOKER1_STOP_DATA);
														if(!frame_err_flag)
														{
															//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here										
															
															form_send_buf(COMMAND_RES,COOKER1_ACK_DATA);
															if(!process1_stop_flag)
															{
																process1_stop_flag=SET;
																dish1_preparation_start_flag=CLEAR;
															}
														}
														break;
												case CKR2_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER2_STOP_DATA);
														if(!frame_err_flag)
														{
															//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
															form_send_buf(COMMAND_RES,COOKER2_ACK_DATA);
															if(!process2_stop_flag)
															{
																process2_stop_flag=SET;
																dish2_preparation_start_flag=CLEAR;
															}
														}
														break;
												case CKR3_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER3_STOP_DATA);
														if(!frame_err_flag)
														{
															//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
															form_send_buf(COMMAND_RES,COOKER3_ACK_DATA);
															if(!process3_stop_flag)
															{
																process3_stop_flag=SET;
																dish3_preparation_start_flag=CLEAR;
															}
														}
														break;
												default:
														frame_err_flag=SET;
												
											}										
											break;
								case ALL_STEPS_DONE:
											switch(process_data_buf1[DATA+1])		//here compare 1/2/3 in ascii format
											{
												case CKR1_STR:
														frame_err_flag=is_valid_data(process_data_buf1,COOKER1_COMPLETE_DATA);
														if(!frame_err_flag)
														{
															//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
															form_send_buf(COMMAND_RES,COOKER1_ACK_DATA);
															if(dish1_preparation_start_flag)
															{
																dish1_preparation_start_flag=CLEAR;
																if(!c1_in_idle_condition_flag)
																{
																	c1_in_idle_condition_flag=SET;																
																	c1_idle_eeprom_store_flag=SET;
																}
																//if((c2_in_idle_condition_flag)AND(c3_in_idle_condition_flag))		//new update
																check_idle_condition();
																check_idle_condition();
															}
														}
														break;
												case CKR2_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER2_COMPLETE_DATA);
														if(!frame_err_flag)
														{
															//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
															form_send_buf(COMMAND_RES,COOKER2_ACK_DATA);
															if(dish2_preparation_start_flag)
															{
																dish2_preparation_start_flag=CLEAR;
																if(!c2_in_idle_condition_flag)
																{
																	c2_in_idle_condition_flag=SET;																
																	c2_idle_eeprom_store_flag=SET;
																}
																//if((c1_in_idle_condition_flag)AND(c3_in_idle_condition_flag))		//new update
																check_idle_condition();
																check_idle_condition();
															}
														}
														break;
												case CKR3_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER3_COMPLETE_DATA);
														if(!frame_err_flag)
														{
															//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
															form_send_buf(COMMAND_RES,COOKER3_ACK_DATA);
															if(dish3_preparation_start_flag)
															{
																dish3_preparation_start_flag=CLEAR;
																if(!c3_in_idle_condition_flag)
																{
																	c3_in_idle_condition_flag=SET;																
																	c3_idle_eeprom_store_flag=SET;
																}
																//if((c1_in_idle_condition_flag)AND(c2_in_idle_condition_flag))		//new update
																check_idle_condition();
																check_idle_condition();
															}
														}
														break;
												default:
														frame_err_flag=SET;
												
											}										
											break;
								case STEPS_START:
											switch(process_data_buf1[DATA+1])		//here compare 1/2/3 in ascii format
											{
												case CKR1_STR:
														//cooker1_start_delay=20;
														dish1_preparation_start_flag=SET;
														restart_cooker_move_flag=CLEAR;
														//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
														form_send_buf(COMMAND_RES,COOKER1_ACK_DATA);
														break;
												case CKR2_STR:
														//cooker2_start_delay=20;
														dish2_preparation_start_flag=SET;
														restart_cooker_move_flag=CLEAR;
														//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
														form_send_buf(COMMAND_RES,COOKER2_ACK_DATA);
														break;
												case CKR3_STR:
														//cooker3_start_delay=20;
														dish3_preparation_start_flag=SET;
														restart_cooker_move_flag=CLEAR;
														//waiting_for_ack_flag=SET,resend_cnt=0;			//It is used for retry mechanism for all commands send from here
														form_send_buf(COMMAND_RES,COOKER3_ACK_DATA);
														break;
												default:
														frame_err_flag=SET;
												
											}										
											break;
								case STEP_TIMER_ACK:
											switch(process_data_buf1[DATA+1])		//here compare 1/2/3 in ascii format
											{
												case CKR1_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER1_ACK_DATA);
														if(!frame_err_flag)
														{
															c1_resend_cnt=0;
															c1_resend_ok_flag=CLEAR;
															c1_one_time_resend_flag=CLEAR;
														}
														break;
												case CKR2_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER2_ACK_DATA);
														if(!frame_err_flag)
														{
															c2_resend_cnt=0;
															c2_resend_ok_flag=CLEAR;
															c2_one_time_resend_flag=CLEAR;
														}
														break;
												case CKR3_STR:														
														frame_err_flag=is_valid_data(process_data_buf1,COOKER3_ACK_DATA);
														if(!frame_err_flag)
														{
															c3_resend_cnt=0;
															c3_resend_ok_flag=CLEAR;
															c3_one_time_resend_flag=CLEAR;
														}
														break;
												default:
														frame_err_flag=SET;
											}
											if(!frame_err_flag)
											{
												//if(!ack_ok_flag)
												{
													//resend_not_ok_flag=CLEAR;
													waiting_for_ack_flag=CLEAR;
													uart_driver_reset_flag=CLEAR;
													resend_cnt=0;
													ack_ok_flag=SET;
												}
											} 
											break;
												
												
							}			
							break;
			case ERR_APP_ID:
							switch(received_fun_id)
							{
								case ERR_FUN_ID:
										frame_err_flag=is_valid_data(process_data_buf1,ACK_DATA);
										if(!frame_err_flag)
										{
											//if(!ack_ok_flag)
											{
												//resend_not_ok_flag=CLEAR;
												waiting_for_ack_flag=CLEAR;
												resend_cnt=0;
												ack_ok_flag=SET;
												uart_driver_reset_flag=CLEAR;
											}
										}
										break;
							}
							break;
			case HEART_BEAT_APP_ID:
							switch(received_fun_id)
							{
								case HEART_BEAT_FUN_ID:
										frame_err_flag=is_valid_data(process_data_buf1,ACK_DATA);
										if(!frame_err_flag)
										{
											//if(!ack_ok_flag)
											{
												//resend_not_ok_flag=CLEAR;
												waiting_for_ack_flag=CLEAR;
												resend_cnt=0;
												ack_ok_flag=SET;
												uart_driver_reset_flag=CLEAR;
											}
										}
										break;
								case RTC_SEND_ACK_FUNID:
										frame_err_flag=is_valid_data(process_data_buf1,ACK_DATA);
										if(!frame_err_flag)
										{
											//if(!ack_ok_flag)
											{
												waiting_for_ack_flag=CLEAR;
												resend_cnt=0;
												ack_ok_flag=SET;
												uart_driver_reset_flag=CLEAR;
											}
										}
										break;											
								case RTC_RECEIVE_FUNID:
										receiveRTC[0]=process_data_buf[0];
										receiveRTC[1]=process_data_buf[1];
										receiveRTC[2]=process_data_buf[2];
										receiveRTC[3]=process_data_buf[3];
										receiveRTC[4]=process_data_buf[4];
										form_send_buf(COMMAND_RES,ACK_DATA);
										break;
										
							}
							break;			
			
		
		}
	}	
	if(frame_err_flag)
	{
		//resend_flag=SET;
		waiting_for_ack_flag=SET,resend_cnt=10;
		frame_err_flag=CLEAR;
	}
	app_id=fun_id=0;
}
/*void is_err_data_came()
{
	resend_flag=((process_data_buf[DATA]=='C')?is_valid_data(process_data_buf,CHKSUM_ERR_DATA):resend_flag);	
	resend_flag=((process_data_buf[DATA]=='F')?is_valid_data(process_data_buf,FUNID_ERR_DATA):resend_flag);	
	resend_flag=((process_data_buf[DATA]=='A')?is_valid_data(process_data_buf,APPID_ERR_DATA):resend_flag);	
	resend_flag=(((process_data_buf[DATA]=='F')AND(!resend_flag))?is_valid_data(process_data_buf,FRAME_ERR_DATA):resend_flag);	
	resend_flag=((process_data_buf[DATA]=='D')?is_valid_data(process_data_buf,DLC_ERR_DATA):resend_flag);
	if(resend_flag)
	frame_err_flag=CLEAR;
}*/