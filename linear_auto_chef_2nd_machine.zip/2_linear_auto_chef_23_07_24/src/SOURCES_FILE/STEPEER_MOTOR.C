/*
 * STEPEER_MOTOR.C
 *
 *  Created on: Dec 13, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/IO.H"
#include "HEADER_FILE/EXTERN_FUN.H"
unsigned char buzzer_on_time, vibrator_delay, kadai_1_homing_step=0,kadai_2_homing_step=0,kadai_1_veg_delay,kadai_2_veg_delay,kadai_1_tilt_delay,kadai_2_tilt_delay,vibration_count,step1,step2;
unsigned char kadai_1_delay,kadai_2_delay,cooker_A_steps=0,cooker_B_steps=0,cooker_C_steps=0,tilt_A_steps=0,tilt_B_steps=0;
unsigned int

            collecting_tray_tilt_time,
            kadai_1_fwd_rev_timer,
            kadai_2_fwd_rev_timer,

            cooker_1_fwd_rev_timer,
            cooker_2_fwd_rev_timer,
            cooker_3_fwd_rev_timer,

            veg_tray_1_fwd_rev_timer,
            veg_tray_2_fwd_rev_timer,
            veg_tray_3_fwd_rev_timer,

            lid_1_up_down_timer,
            lid_2_up_down_timer,
            lid_3_up_down_timer,

            kadai_1_clk_anti_toggle_timer,
            kadai_2_clk_anti_toggle_timer,

            collecting_tray_fwd_rev_pulse,

            collecting_tray_timer;

bool
buzzer_on_flag,
test_flag,
        vibration_fwd_flag,
        vibration_rev_flag,
        pause_flag,
//
//        kadai_osillation_fwd,
//        kadai_osillation_fwd,
//        kadai_osillation_pause,

        kadai_1_tilting_flag,
        kadai_2_tilting_flag,

        collecting_tray_tilt_fwd_flag,
        collecting_tray_tilt_rev_flag,
        collecting_tray_tilt_delay_flag,

        cooker_1_fwd_rev_toggle_flag,
        cooker_2_fwd_rev_toggle_flag,
        cooker_3_fwd_rev_toggle_flag,

        lid_1_up_down_toggle_flag,
        lid_2_up_down_toggle_flag,
        lid_3_up_down_toggle_flag,

        veg_tray_1_fwd_rev_toggle_flag,
        veg_tray_2_fwd_rev_toggle_flag,
        veg_tray_3_fwd_rev_toggle_flag,

        kadai_1_fwd_rev_toggle_flag,
        kadai_2_fwd_rev_toggle_flag,
        kadai_1_clk_anti_toggle_flag,
        kadai_2_clk_anti_toggle_flag,

        collecting_tray_toggle_flag,
        collecting_tilt_toggle_flag;
extern unsigned char dish1_outputs_on,dish2_outputs_on,dish3_outputs_on ,motor_code1,motor_code2,motor_code3, temp_tray_position, veg_tray_1_position,veg_tray_2_position,veg_tray_3_position;
extern bool
turmerind_water_collecting_flag,
cooker_1_ing_motor_used_flag,
cooker_2_ing_motor_used_flag,
cooker_3_ing_motor_used_flag,
dish1_step_complete_flag,
dish2_step_complete_flag,
dish3_step_complete_flag,
veg1_tray_rev_ok_flag,
veg2_tray_rev_ok_flag,
veg3_tray_rev_ok_flag;


void stepper_motor();
void collecting_tray_step_load_fun(unsigned char);
void Go_cooker_pos(unsigned char);
void collecting_tray_tilt();
void veg_tray_home_position();
void motor_error_detection();
void collecting_tray_set_position(unsigned char);
void tilt_correspondig_direction(unsigned char );
void tilt_motor_home_position(unsigned char , unsigned char );
void dispensing_vibration();

void cooker_pos_and_lid_pos();
void kadai_process();
void turmerind_water();
void kadai_tilting_opertion();
void buzzer();
/*********************************STEPPER MOTOR ***************************************/
void stepper_motor()
{
 if(!eeprom_write_start_flag)
 {
    if((collecting_tray_ok_flag)AND(collecting_tray_timer<= 0)AND(collecting_tray_fwd_rev_pulse>0))                                              // collecting tray fwd rev
    {
            if(collecting_tray_toggle_flag)
            {
                MC_FWD_REV_STEP_LOW;
                collecting_tray_timer =10; //5//50 //200  //6
                collecting_tray_toggle_flag = CLR;
                collecting_tray_fwd_rev_pulse--;
            }
            else if(!collecting_tray_toggle_flag)
            {
                MC_FWD_REV_STEP_HIGH;
                collecting_tray_timer =10;//15 //60//300 //35
                collecting_tray_toggle_flag = SET;
            }
    }
    if((collecting_tray_tilt_ok_flag)AND(collecting_tray_timer<=0)AND(collecting_tray_clk_anticlk_pulse>0))        // collecting tray tilt
    {
            if(collecting_tilt_toggle_flag)
            {
                MC_CW_ACW_STEP_LOW;
                if(tilt_dispending_vibration_on_flag)
                collecting_tray_timer = 40;
                else
                collecting_tray_timer = 3;
                collecting_tilt_toggle_flag = CLR;
                collecting_tray_clk_anticlk_pulse--;
            }
            else if(!collecting_tilt_toggle_flag)
            {
                MC_CW_ACW_STEP_HIGH;
                if(tilt_dispending_vibration_on_flag)
                collecting_tray_timer = 50;
                else
                collecting_tray_timer = 38;
               collecting_tilt_toggle_flag = SET;
            }
        }
//    if((kadai_1_fwd_rev_flag)AND(kadai_1_fwd_rev_timer<= 0)AND(kadai_1_fwd_rev_pulse>0))        // kadai 1 fwd rev
//    {
//            if(kadai_1_fwd_rev_toggle_flag)
//            {
//                K1_FWD_REV_STEP_LOW;
//                kadai_1_fwd_rev_timer = 1;//50;
//                kadai_1_fwd_rev_toggle_flag = CLR;
//                kadai_1_fwd_rev_pulse--;
//            }
//            else if(!kadai_1_fwd_rev_toggle_flag)
//            {
//               K1_FWD_REV_STEP_HIGH;
//               kadai_1_fwd_rev_timer = 35;//50;
//               kadai_1_fwd_rev_toggle_flag = SET;
//            }
//    }
//    if((kadai_2_fwd_rev_flag)AND(kadai_2_fwd_rev_timer<= 0)AND(kadai_2_fwd_rev_pulse>0))        // kadai 1 fwd rev                // kadai 2 fwd rev
//    {
//            if(kadai_2_fwd_rev_toggle_flag)
//            {
//                K2_FWD_REV_STEP_LOW;
//                kadai_2_fwd_rev_timer = 50;//50;
//                kadai_2_fwd_rev_toggle_flag = CLR;
//                kadai_2_fwd_rev_pulse--;
//            }
//            else if(!kadai_2_fwd_rev_toggle_flag)
//            {
//               K2_FWD_REV_STEP_HIGH;
//               kadai_2_fwd_rev_timer =50; //100;
//               kadai_2_fwd_rev_toggle_flag = SET;
//            }
//    }
        if((kadai_1_clk_anti_flag)AND(kadai_1_clk_anti_toggle_timer<= 0)AND(kadai_1_clk_anti_pulse>0))        // kadai 1 fwd rev
        {
                if(kadai_1_clk_anti_toggle_flag)
                {
                    K1_CW_ACW_STEP_LOW;
                    kadai_1_clk_anti_toggle_timer = 1;//50;
                    kadai_1_clk_anti_toggle_flag = CLR;
                    kadai_1_clk_anti_pulse--;
                }
                else if(!kadai_1_clk_anti_toggle_flag)
                {
                    K1_CW_ACW_STEP_HIGH;
                   kadai_1_clk_anti_toggle_timer = 35;//50;
                   kadai_1_clk_anti_toggle_flag = SET;
                }
        }
        if((kadai_2_clk_anti_flag)AND(kadai_2_clk_anti_toggle_timer<= 0)AND(kadai_2_clk_anti_pulse>0))        // kadai 1 fwd rev
        {
                if(kadai_2_clk_anti_toggle_flag)
                {
                    K2_CW_ACW_STEP_LOW;
                    kadai_2_clk_anti_toggle_timer = 1;//50;
                    kadai_2_clk_anti_toggle_flag = CLR;
                    kadai_2_clk_anti_pulse--;
                }
                else if(!kadai_2_clk_anti_toggle_flag)
                {
                    K2_CW_ACW_STEP_HIGH;
                   kadai_2_clk_anti_toggle_timer = 35;//50;
                   kadai_2_clk_anti_toggle_flag = SET;
                }
        }

    if((cooker_1_fwd_rev_flag)AND(cooker_1_fwd_rev_timer <= 0)AND(cooker_1_fwd_rev_pulse>0))               // cooker 1 fwd rev
    {
            if(cooker_1_fwd_rev_toggle_flag)
            {
                COOKER_1_STEP_LOW;
                cooker_1_fwd_rev_timer = 2; //
                cooker_1_fwd_rev_toggle_flag = CLR;
                cooker_1_fwd_rev_pulse--;
            }
            else if(!cooker_1_fwd_rev_toggle_flag)
            {
                COOKER_1_STEP_HIGH;
                cooker_1_fwd_rev_timer =20;//20
                cooker_1_fwd_rev_toggle_flag = SET;
            }
    }
    if((cooker_2_fwd_rev_flag)AND(cooker_2_fwd_rev_timer<=0)AND(cooker_2_fwd_rev_pulse>0))               // cooker 1 fwd rev
    {
            if(cooker_2_fwd_rev_toggle_flag)
            {
                COOKER_2_STEP_LOW;
                cooker_2_fwd_rev_timer = 2; //2
                cooker_2_fwd_rev_toggle_flag = CLR;
                cooker_2_fwd_rev_pulse--;
            }
            else if(!cooker_2_fwd_rev_toggle_flag)
            {
                COOKER_2_STEP_HIGH;
                cooker_2_fwd_rev_timer = 20;//20
                cooker_2_fwd_rev_toggle_flag = SET;
            }
    }
    if((cooker_3_fwd_rev_flag) AND(cooker_3_fwd_rev_timer<=0)AND(cooker_3_fwd_rev_pulse>0))               // cooker 1 fwd rev
    {
            if(cooker_3_fwd_rev_toggle_flag)
            {
                COOKER_3_STEP_LOW;
                cooker_3_fwd_rev_timer = 2;
                cooker_3_fwd_rev_toggle_flag = CLR;
                cooker_3_fwd_rev_pulse--;
            }
            else if(!cooker_3_fwd_rev_toggle_flag)
            {
                COOKER_3_STEP_HIGH;
                cooker_3_fwd_rev_timer = 20;
                cooker_3_fwd_rev_toggle_flag = SET;
            }
    }
    if((veg_tray_1_fwd_rev_flag)AND(veg_tray_1_fwd_rev_timer <= 0)AND(veg_tray_1_fwd_rev_pulse>0))              // vegtray 1  fwd rev
    {
            if(veg_tray_1_fwd_rev_toggle_flag)
            {
                VEG_TRAY_1_STEP_LOW;
              //  VEG_TRAY_1_SLEEP_LOW;
                veg_tray_1_fwd_rev_timer =150;//140
                veg_tray_1_fwd_rev_toggle_flag = CLR;
                veg_tray_1_fwd_rev_pulse--;
            }
            else if(!veg_tray_1_fwd_rev_toggle_flag)
            {
                VEG_TRAY_1_STEP_HIGH;
              //  VEG_TRAY_1_SLEEP_HIGH;
                veg_tray_1_fwd_rev_timer = 90;//160
                veg_tray_1_fwd_rev_toggle_flag = SET;
            }
    }
    if((veg_tray_2_fwd_rev_flag)AND(veg_tray_2_fwd_rev_timer<=0)AND(veg_tray_2_fwd_rev_pulse>0))                // vegtray 2  fwd rev
    {
            if(veg_tray_2_fwd_rev_toggle_flag)
            {
                VEG_TRAY_2_STEP_LOW;
                veg_tray_2_fwd_rev_timer = 150;
                veg_tray_2_fwd_rev_toggle_flag = CLR;
                veg_tray_2_fwd_rev_pulse--;
            }
            else if(!veg_tray_2_fwd_rev_toggle_flag)
            {
                VEG_TRAY_2_STEP_HIGH;
                veg_tray_2_fwd_rev_timer = 90;
                veg_tray_2_fwd_rev_toggle_flag = SET;
            }
    }
    if((veg_tray_3_fwd_rev_flag)AND(veg_tray_3_fwd_rev_timer<=0)AND(veg_tray_3_fwd_rev_pulse>0))               // vegtray 3  fwd re
    {
            if(veg_tray_3_fwd_rev_toggle_flag)
            {
                VEG_TRAY_3_STEP_LOW;
                veg_tray_3_fwd_rev_timer = 150;
                veg_tray_3_fwd_rev_toggle_flag = CLR;
                veg_tray_3_fwd_rev_pulse--;
            }
            else if(!veg_tray_3_fwd_rev_toggle_flag)
            {
                VEG_TRAY_3_STEP_HIGH;
                veg_tray_3_fwd_rev_timer = 90;
                veg_tray_3_fwd_rev_toggle_flag = SET;
            }
    }
    if((lid_1_up_down_flag)AND(lid_1_up_down_timer<=0)AND(lid_1_up_down_on_pluse>0))                // lid_1_up_down
    {
            if(lid_1_up_down_toggle_flag)
            {
                LID_1_STEP_LOW;
                lid_1_up_down_timer = 2;
                lid_1_up_down_toggle_flag = CLR;
                lid_1_up_down_on_pluse--;
            }
            else if(!lid_1_up_down_toggle_flag)
            {
                LID_1_STEP_HIGH;
                lid_1_up_down_timer = 20;
                lid_1_up_down_toggle_flag = SET;
            }
    }
    if((lid_2_up_down_flag)AND(lid_2_up_down_timer<=0)AND(lid_2_up_down_on_pluse>0))               // lid_2_up_down
    {
           if(lid_2_up_down_toggle_flag)
           {
               LID_2_STEP_LOW;
               lid_2_up_down_timer = 2;
               lid_2_up_down_toggle_flag = CLR;
               lid_2_up_down_on_pluse--;
           }
           else if(!lid_2_up_down_toggle_flag)
           {
               LID_2_STEP_HIGH;
               lid_2_up_down_timer = 20;
               lid_2_up_down_toggle_flag = SET;
           }
   }
    if((lid_3_up_down_flag)AND(lid_3_up_down_timer<=0)AND(lid_3_up_down_on_pluse>0))                // lid_3_up_down
    {
       if(lid_3_up_down_timer <= 0)
       {
           if(lid_3_up_down_toggle_flag)
           {
               LID_3_STEP_LOW;
               lid_3_up_down_timer = 2;
               lid_3_up_down_toggle_flag = CLR;
               lid_3_up_down_on_pluse--;
           }
           else if(!lid_3_up_down_toggle_flag)
           {
               LID_3_STEP_HIGH;
               lid_3_up_down_timer = 20;
               lid_3_up_down_toggle_flag = SET;
           }
       }
    }
 }
}

/*********************************STEPPER MOTOR ***************************************/

/********************************* COLLECTING INGRIDENTS HANDLING ***************************************/

void collecting_tray_step_load_fun(unsigned char tray_position)
{

     if(!temp_tray_position)
        {
            switch(tray_position-1)                         //
            {
                case 1:
                    collecting_tray_fwd_rev_pulse=900;
                        break;
                case 2:
                    collecting_tray_fwd_rev_pulse=1800;
                        break;
                case 3:
                    collecting_tray_fwd_rev_pulse=2700;
                        break;
                case 4:
                    collecting_tray_fwd_rev_pulse=3600;
                        break;
                case 5:
                    collecting_tray_fwd_rev_pulse=4500;
                        break;
                case 6:
                    collecting_tray_fwd_rev_pulse=5600;
                        break;
                case 7:
                    collecting_tray_fwd_rev_pulse=6300;
                        break;
                case 8:
                    collecting_tray_fwd_rev_pulse=7000;
                        break;
                case 9:
                    collecting_tray_fwd_rev_pulse=7700;
                        break;
                case 10:
                    collecting_tray_fwd_rev_pulse=8400;
                        break;
                case 11:
                    collecting_tray_fwd_rev_pulse=9100;
                        break;
                case 12:
                    collecting_tray_fwd_rev_pulse=9800;
                        break;
                case 13:
                    collecting_tray_fwd_rev_pulse=10500;
                        break;
                case 14:
                    collecting_tray_fwd_rev_pulse=10850;
                        break;
            }
            if(collecting_tray_fwd_rev_pulse)
               MC_FWD;
        }
        else if((temp_tray_position>=1)AND(temp_tray_position<=22)) // NEW
        {
                unsigned char temp=0,temp_bin=0,temp_bin_1=0,temp_bin_2=0,temp_bin_3=0,no_of_pos;

                if((tray_position>=16)AND(tray_position<=22))
               {
                   tray_position=tray_position-7;
                   if(temp_tray_position<tray_position)
                   {
                       no_of_pos=tray_position-temp_tray_position;
                   }
                   else if(temp_tray_position>tray_position)
                   {
                       no_of_pos=temp_tray_position-tray_position;
                   }
               }
               else if((tray_position>=1)AND(tray_position<=15))
                   no_of_pos=tray_position-temp_tray_position;

                if(temp_tray_position<tray_position)
                {

                    temp_bin=tray_position;
                    if(temp_tray_position<8)
                    {
                        if(tray_position>=8)
                        temp_bin=8-temp_tray_position;
                        else
                            temp_bin=no_of_pos;
                    }
                    else if(temp_tray_position==8)
                    temp_bin=1;
                    else if((temp_tray_position>=9)AND(temp_tray_position<14))
                    {
                        temp_bin=tray_position-temp_tray_position;
                        if(tray_position==15)
                            temp_bin=temp_bin-1;
                    }
                    collecting_tray_fwd_rev_pulse=0;

                    if((temp_bin)AND(temp_tray_position<=8))
                    {
                        collecting_tray_fwd_rev_pulse=900*temp_bin;
                        //if(temp_tray_position>8)
                        temp_bin=no_of_pos-temp_bin;
                        if(tray_position==15)
                            temp_bin=temp_bin-1;
                    }
                    if((temp_bin)AND(temp_tray_position<=14))
                    {
                        collecting_tray_fwd_rev_pulse=(collecting_tray_fwd_rev_pulse)+(650*temp_bin);
                        no_of_pos=temp_bin;
                        temp_bin=no_of_pos-temp_bin;
                        if(tray_position==15)
                            temp_bin=temp_bin+1;
                    }
                    if(temp_bin)
                    {
                        collecting_tray_fwd_rev_pulse=collecting_tray_fwd_rev_pulse+300;//350
                    }
                    if((temp_tray_position<8)AND(tray_position>=9)AND(tray_position<=15)AND(collecting_tray_fwd_rev_pulse)) //NEW
                        collecting_tray_fwd_rev_pulse=collecting_tray_fwd_rev_pulse+190;
                    if((temp_tray_position==8)AND(tray_position>=9)AND(tray_position<=15)AND(collecting_tray_fwd_rev_pulse)) //NEW
                        collecting_tray_fwd_rev_pulse=collecting_tray_fwd_rev_pulse-60;
                    if(collecting_tray_fwd_rev_pulse)
                        MC_FWD;
                }
                else if(temp_tray_position>tray_position)
                {
                    temp_bin=no_of_pos=temp_tray_position-tray_position;
                    collecting_tray_fwd_rev_pulse=0;

                    if(temp_tray_position==15)
                    {
                        temp_bin_1=1;
                        temp_bin=temp_bin-1;
                        if((temp_bin>7)AND(tray_position<8))
                         temp_bin_3=temp_bin-7;
                        temp_bin_2=no_of_pos-temp_bin_3-1;
                    }
                    else if(temp_tray_position<=14)
                    {
                        temp_bin_1=0;
                        if((temp_tray_position>=9)AND(tray_position<8))
                        {
                            temp=15-temp_tray_position;
                            temp_bin=no_of_pos-7;
                            if(tray_position<8)
                                temp_bin_3=temp_bin+(temp);
                            else
                            temp_bin_3=temp_bin+(temp-1);
                        }
                        if(tray_position<8)
                            temp_bin_3=temp_bin+(temp);

                        temp_bin_2=(no_of_pos-temp_bin_3);
                    }
                    if(temp_bin_1)
                    {
                        collecting_tray_fwd_rev_pulse=(collecting_tray_fwd_rev_pulse)+(300*temp_bin_1); //350
                    }
                    if(temp_bin_2)
                    {
                        collecting_tray_fwd_rev_pulse=(collecting_tray_fwd_rev_pulse)+(650*temp_bin_2);
                    }
                    if(temp_bin_3)
                    {
                        collecting_tray_fwd_rev_pulse=(collecting_tray_fwd_rev_pulse)+(900*temp_bin_3);
                    }
                    if((temp_tray_position<=15)AND(temp_tray_position>=9)AND(tray_position<=8)AND(collecting_tray_fwd_rev_pulse)) //NEW
                       collecting_tray_fwd_rev_pulse=collecting_tray_fwd_rev_pulse+190;

                    if((temp_tray_position==15)AND(tray_position<8)AND(collecting_tray_fwd_rev_pulse)) //NEW
                        collecting_tray_fwd_rev_pulse=collecting_tray_fwd_rev_pulse+250;

                    if(collecting_tray_fwd_rev_pulse)
                    MC_REV;
               }
        }
     if(!initial_position_ok_flag)
         collecting_tray_fwd_rev_pulse=collecting_tray_fwd_rev_pulse+700;
        if((ing_motor_used_flag)AND(!test_flag)AND(!go_dispensing_correspond_cooker_flag)) // NEW
        go_corresponding_ingredient_motor_flag=SET;
        collecting_tray_ok_flag=SET;
        temp_tray_position=tray_position;
        target_position=temp_tray_position;
}
void Go_cooker_pos(unsigned char cooker_no)
{
    unsigned char pos;
    switch(cooker_no)
    {
        case COOKER1:
//                    if(using_bin_no==1)
//                    pos=4;
//                    else if(using_bin_no==2)
                    pos=3;
                    break;

        case COOKER2:
//                    if(using_bin_no==1)
//                    pos=8;
//                    else if(using_bin_no==2)
                    pos=7;
                    break;
        case COOKER3:
//                    if(using_bin_no==1)
//                    pos=11;
//                    else if(using_bin_no==2)
                    pos=12;
                    break;
        default:
            cooker_no=0;
            break;
    }
    if(cooker_no)
    {
        go_dispensing_correspond_cooker_flag=SET;
        collecting_tray_step_load_fun(pos);
    }
}
void tilt_correspondig_direction(unsigned char cooker_no)
{
    if((cooker_no==COOKER1)OR(cooker_no==COOKER2))
    {
        MC_ACW;
        collecting_tray_clk_anticlk_pulse=330; //80
    }
    else if(cooker_no==COOKER3)
    {
        MC_CW;
        collecting_tray_clk_anticlk_pulse=330;
    }
    if(collecting_tray_clk_anticlk_pulse)
    {
        ingredient_dispensed_ok_flag=SET;
        collecting_tray_tilt_ok_flag=SET;
    }
}
void dispensing_vibration()
{
    if((tilt_dispending_vibration_on_flag)AND(collecting_tray_clk_anticlk_pulse<=0))
    {
         if((vibration_fwd_flag)AND(vibration_rev_flag))
         {
           if((vibration_count>=2)) // 4
           {
                    if(cooker_1_ing_motor_used_flag)
                        STIRRER_1_MOTOR_STOP;

                    else if(cooker_2_ing_motor_used_flag)
                        STIRRER_2_MOTOR_STOP;

                    else if(cooker_3_ing_motor_used_flag)
                        STIRRER_3_MOTOR_STOP;

                   tilt_dispending_vibration_on_flag=CLR;
                   MC_CW_ACW_STOP;
                   vibration_fwd_flag=CLR;
                   vibration_rev_flag=CLR;
                   vibration_count=0;
                   tilt_motor_process_ok=SET;
                   vibrator_delay=2;
                   collecting_tray_tilt_ok_flag=1;
                   vibrator_delay=2;
                 //  collecting_tray_clk_anticlk_pulse=10;
           }
           else
           {
               vibration_count++;
               MC_CW_ACW_STOP;
               vibration_fwd_flag=CLR;
               vibration_rev_flag=CLR;
           }
        }
        else if((!vibration_fwd_flag)AND(!vibration_rev_flag))
        {
            vibration_fwd_flag=SET;
            MC_ACW;
            collecting_tray_clk_anticlk_pulse=20;//5

            if(cooker_1_ing_motor_used_flag)
                STIRRER_1_FWD_FULL_SPEED;

            else if(cooker_2_ing_motor_used_flag)
                STIRRER_2_FWD_FULL_SPEED;

            else if(cooker_3_ing_motor_used_flag)
                STIRRER_3_FWD_FULL_SPEED;
        }
        else if((vibration_fwd_flag)AND(!vibration_rev_flag))
        {
            vibration_rev_flag=SET;
            MC_CW;
            collecting_tray_clk_anticlk_pulse=20; //5
        }
        if(collecting_tray_clk_anticlk_pulse)
            collecting_tray_tilt_ok_flag=SET;
    }



}
void tilt_motor_home_position(unsigned char cooker, unsigned char bin_no)
{
    collecting_tray_clk_anticlk_pulse=0;
    if((cooker==COOKER1)OR(cooker==COOKER2))
    {
        switch(bin_no)
        {
            case 1:
                    collecting_tray_clk_anticlk_pulse=600; //600
                    MC_ACW;
            break;
            case 2:
                    collecting_tray_clk_anticlk_pulse=220;    //10
                    MC_ACW;
            break;
        }
    }
    else if(cooker==COOKER3)
    {
        switch(bin_no)
        {
            case 1:
                    collecting_tray_clk_anticlk_pulse=520;//
                    MC_ACW;
            break;
            case 2:
                    collecting_tray_clk_anticlk_pulse=150;//
                    MC_ACW;
            break;
        }
    }
    if(collecting_tray_clk_anticlk_pulse)
    {
        collecting_tray_tilt_ok_flag=SET;
       collecting_bin_switch_flag=SET;     //BIN SENSOR ON
        ingredient_motor_process_ok_flag=SET;
    }
}
void collecting_tray_set_position(unsigned char position_code)
{
    if(collecting_bin_switch_close_flag)   //comparing the tilting sensor
    {
        using_bin_no=0;
         if((position_code>=IGM1)AND(position_code<=IGM8))//OR((position_code>=IGM16)AND(position_code<=IGM22)))
         {
             MC_CW;
             collecting_tray_clk_anticlk_pulse=160;  //180
             using_bin_no=1;
             collecting_tray_tilt_ok_flag=SET;
         }
         else if((position_code>=IGM9)AND(position_code<=22)) // 15
         {
             MC_ACW;
             collecting_tray_clk_anticlk_pulse=200; // 180
             using_bin_no=2;
             collecting_tray_tilt_ok_flag=SET;
         }
         if(collecting_tray_clk_anticlk_pulse)
         {
             collecting_tray_tilt_ok_flag=SET;
             select_collecting_bin=SET;
         }
    }
    else
    {
        // error impletemented
    }
}

/********************************* COLLECTING INGRIDENTS HANDLING ***************************************/

/*********************************KADAI COLLECTING INGRIDENTS & DISPENSING HANDLING ***************************************/
void kadai_process()
{
    if(((kadai_1_process_flag)OR(kadai_2_process_flag))AND(!collecting_tray_ok_flag)AND(collecting_tray_fwd_rev_pulse<=0)AND(!collecting_tray_tilt_ok_flag)AND(collecting_tray_clk_anticlk_pulse<=0))
    {
        if(kadai_1_process_flag)
        {
            if((cooker_1_kadai_using_flag)AND(kadai_1_fwd_rev_pulse<=0)AND(kadai_1_veg_delay<=0)AND(!oil_pump_1_on_flag)AND(!veg_tray_1_fwd_rev_flag))
            {
                if(!cooker_A_steps)
                    cooker_A_steps++;
                if(cooker_A_steps>=8)
                {
                    kadai_1_process_flag=CLR;
                    cooker_A_steps=0;
                    dish1_step_complete_flag=SET;
                    dishes_complete();
                }
                switch(cooker_A_steps)
                {
                    case 1:
                            test_flag=SET;
                            collecting_tray_step_load_fun(5);
                            test_flag=CLR;
                            cooker_A_steps++;
                    break;
                    case 2:
                            K1_FWD;
                            //if(motor_code1==VTM)   // common all
                                kadai_1_fwd_rev_pulse=1750;
//                            else
//                            kadai_1_fwd_rev_pulse=1600;
                            kadai_1_fwd_rev_flag=SET;
                            cooker_A_steps++;
                    break;
                    case 3:
                            kadai_1_veg_delay=2;
                            cooker_A_steps++;
                    break;
                    case 4:
                            if((motor_code1>=IGM1)AND(motor_code1<=IGM22))
                            {
                                collecting_tray_set_position(motor_code1);
                                cooker_A_steps++;
                            }
                            else
                            {
                                cooker_A__outputs(motor_code1);
                                cooker_A_steps++;
                            }
                    break;
                    case 5:
                            kadai_1_veg_delay=15;
                            if((motor_code1>=IGM1)AND(motor_code1<=IGM22))
                            {
                                cooker_A_steps++;
                            }else
                            {
                                cooker_A_steps++;
                                cooker_A_steps++;
                            }
                            break;
                    case 6:
                            if(!ing_motor_used_flag)
                            {
                                test_flag=SET;
                                collecting_tray_step_load_fun(5);
                                test_flag=CLR;
                                cooker_A_steps++;
                            }
                    break;
                    case 7:
                           K1_REV;
                           //if(motor_code1==VTM)
                               kadai_1_fwd_rev_pulse=1750;  // commom all
                         //  else
                         //  kadai_1_fwd_rev_pulse=1600;
                           kadai_1_fwd_rev_flag=SET;
                           kadai_1_switch_flag=SET;
                           cooker_A_steps++;
                    break;
                }
            }
            else if((cooker_2_kadai_using_flag)AND(kadai_1_fwd_rev_pulse<=0)AND(kadai_1_veg_delay<=0)AND(!oil_pump_2_on_flag)AND(!veg_tray_2_fwd_rev_flag))
            {
                if(!cooker_B_steps)
                    cooker_B_steps++;
                if(cooker_B_steps>=8)
                {
                    kadai_1_process_flag=CLR;
                    dish2_step_complete_flag=SET;
                    dishes_complete();
                    cooker_B_steps=0;
                }
                switch(cooker_B_steps)
                {
                    case 1:
                            test_flag=SET;
                            collecting_tray_step_load_fun(5);
                            test_flag=CLR;
                            cooker_B_steps++;
                    break;
                    case 2:
                            K1_REV;
                            kadai_1_fwd_rev_flag=SET;
                            kadai_1_fwd_rev_pulse=1700; //1750
                            cooker_B_steps++;
                    break;
                    case 3:
                            kadai_1_veg_delay=2;
                            cooker_B_steps++;
                    break;
                    case 4:
                            if((motor_code2>=IGM1)AND(motor_code2<=IGM22))
                            {
                                collecting_tray_set_position(motor_code2);
                                cooker_B_steps++;
                            }
                            else
                            {
                                cooker_B__outputs(motor_code2);
                                cooker_B_steps++;
                                //cooker_B_steps++;
                            }

                    break;
                    case 5:
                        kadai_1_veg_delay=15;
                        if((motor_code2>=IGM1)AND(motor_code2<=IGM22))
                        {
                            cooker_B_steps++;
                        }else
                        {
                            cooker_B_steps++;
                            cooker_B_steps++;
                        }
                    break;
                    case 6:
                            if(!ing_motor_used_flag)
                            {
                                test_flag=SET;
                                collecting_tray_step_load_fun(5);
                                test_flag=CLR;
                                cooker_B_steps++;
                            }
                    break;
                    case 7:
                            K1_FWD;
                            kadai_1_fwd_rev_flag=SET;
                            kadai_1_fwd_rev_pulse=1700;
                            kadai_1_switch_flag=SET;
                            cooker_B_steps++;
                    break;
                }
            }
        }
        if(kadai_2_process_flag)
        {
            if((cooker_3_kadai_using_flag)AND(kadai_2_fwd_rev_pulse<=0)AND(kadai_2_veg_delay<=0)AND(!oil_pump_3_on_flag)AND(!veg_tray_3_fwd_rev_flag))
            {
                if(!cooker_C_steps)
                    cooker_C_steps++;
                if(cooker_C_steps>=8)
                {
                    kadai_2_process_flag=CLR;
                    cooker_C_steps=0;
                    dish3_step_complete_flag=SET;
                    dishes_complete();
                }
                switch(cooker_C_steps)
                {
                    case 1:
                            test_flag=SET;
                            collecting_tray_step_load_fun(5);
                            test_flag=CLR;
                            cooker_C_steps++;
                    break;
                    case 2:
                            K2_REV;
                            kadai_2_fwd_rev_flag=SET;
                          //  if(motor_code3==VTM)
                                kadai_2_fwd_rev_pulse=1950;  //2000//commomn all
                          //  else
                          //  kadai_2_fwd_rev_pulse=1800;
                            cooker_C_steps++;
                    break;
                    case 3:
                            kadai_2_veg_delay=2;
                            cooker_C_steps++;
                    break;
                    case 4:
                            if((motor_code3>=IGM1)AND(motor_code3<=IGM22))
                            {
                                collecting_tray_set_position(motor_code3);
                                cooker_C_steps++;
                            }
                            else
                            {
                                cooker_C__outputs(motor_code3);
                                cooker_C_steps++;
                            }
                    break;
                    case 5:
                        kadai_2_veg_delay=15;
                        if((motor_code3>=IGM1)AND(motor_code3<=IGM22))
                        {
                            cooker_C_steps++;
                        }else
                        {
                            cooker_C_steps++;
                            cooker_C_steps++;
                        }
                    break;
                    case 6:
                            if(!ing_motor_used_flag)
                            {
                                test_flag=SET;
                                collecting_tray_step_load_fun(5);
                                test_flag=CLR;
                                cooker_C_steps++;
                            }
                    break;
                    case 7:
                            K2_FWD;
                           // if(motor_code3==VTM)
                                 kadai_2_fwd_rev_pulse=1950;  // common all
//                             else
//                                 kadai_2_fwd_rev_pulse=1800;
                            kadai_2_fwd_rev_flag=SET;
                            kadai_2_switch_flag=SET;
                            cooker_C_steps++;
                    break;
                }
            }
        }
    }
}
/*********************************KADAI COLLECTING INGRIDENTS & DISPENSING HANDLING ***************************************/

/*********************************KADAI COLLECTING TUMARIND & DISPENSING HANDLING ***************************************/
void turmerind_water()
{
    if(turmerind_water_collecting_flag)
    {
        if((!turmerind_water_on_flag)AND(cooker_1_kadai_using_flag)AND(kadai_1_fwd_rev_pulse<=0)AND(kadai_1_clk_anti_pulse<=0)AND(!kadai_1_tilting_flag)AND(motor_code1==TWPB))
        {
            if(!cooker_A_steps)
            cooker_A_steps++;
            else if(cooker_A_steps>=5)
            {
                cooker_A_steps=0;
                turmerind_water_collecting_flag=0;
                cooker_1_kadai_using_flag=CLR;
                c1_kadai_epprom_store_flag=SET;
                dish1_step_complete_flag=SET;
                dishes_complete();
            }
            switch(cooker_A_steps)
            {
                case 1:
                        K1_REV;
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_fwd_rev_pulse=1950;
                        cooker_A_steps++;
                    break;
                case 2:
                        VALVE_5_ON;
                        turmerind_water_on_flag=SET;
                        cooker_A_steps++;
                    break;
                case 3:
                        kadai_1_fwd_rev_pulse=1950;
                        K1_FWD;
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_switch_flag=SET;
                        cooker_A_steps++;
                    break;

                case 4:
                        if(!kadai_1_tilting_flag)
                        {
                            kadai_1_tilting_flag=SET;
                            cooker_A_steps++;
                        }
                break;
            }
        }
        else if((!turmerind_water_on_flag)AND(cooker_3_kadai_using_flag)AND(kadai_2_fwd_rev_pulse<=0)AND(kadai_2_clk_anti_pulse<=0)AND(!kadai_2_tilting_flag)AND(motor_code3==TWPB))
        {
            if(!cooker_C_steps)
            cooker_C_steps++;
            else if(cooker_C_steps>=5)
            {
                cooker_C_steps=0;
                turmerind_water_collecting_flag=0;
                cooker_3_kadai_using_flag=CLR;
                c3_kadai_epprom_store_flag=SET;
                dish3_step_complete_flag=SET;
                dishes_complete();
            }
            switch(cooker_C_steps)
            {
                case 1:
                        K2_FWD;
                        kadai_2_fwd_rev_flag=SET;
                        kadai_2_fwd_rev_pulse=1950;
                        cooker_C_steps++;
                    break;
                case 2:
                        VALVE_5_ON;
                        turmerind_water_on_flag=SET;
                        cooker_C_steps++;
                    break;
                case 3:
                        kadai_2_fwd_rev_pulse=1950;
                        K2_REV;
                        kadai_2_fwd_rev_flag=SET;
                        cooker_C_steps++;
                    break;

                case 4:
                        if(!kadai_2_tilting_flag)
                        {
                            kadai_2_tilting_flag=SET;
                            cooker_C_steps++;
                        }
                break;
            }
        }
    }
}
/*********************************KADAI COLLECTING TUMARIND & DISPENSING HANDLING ***************************************/


/*********************************KADAI TILTING IN COOKERS HANDLING ***************************************/
 void kadai_tilting_opertion()
 {
     if((kadai_1_tilting_flag)OR(kadai_2_tilting_flag))
     {
         if(kadai_1_tilting_flag)
         {
             if((!collecting_tray_ok_flag)AND(collecting_tray_fwd_rev_pulse<=0)AND(cooker_1_kadai_using_flag)AND(kadai_1_clk_anti_pulse<=0)AND(kadai_1_tilt_delay<=0)AND(kadai_1_fwd_rev_pulse<=0))
             {
                if(!tilt_A_steps)
                    tilt_A_steps++;
                else if(tilt_A_steps>=7)
                {
                    tilt_A_steps=0;
                    kadai_1_tilting_flag=0;
                    if((cooker_1_kadai_using_flag)AND(!turmerind_water_collecting_flag))
                    {
                        cooker_1_kadai_using_flag=CLR;
                        c1_kadai_epprom_store_flag=SET;
                        dish1_step_complete_flag=SET;
                        dishes_complete();
                    }
                }
                 switch(tilt_A_steps)
                 {
                     case 1:
                         test_flag=SET;
                         collecting_tray_step_load_fun(5);
                         test_flag=CLR;
                         tilt_A_steps++;
                    break;
                    case 2:
                            if(kadai_1_left_right_switch_close_flag)
                            {
                                K1_FWD;
                                kadai_1_fwd_rev_flag=SET;
                                kadai_1_fwd_rev_pulse=1700; // 1600 -22/07/24
                                tilt_A_steps++;
                            }
                    break;
                    case 3:
                        K1_ACW;
                        kadai_1_clk_anti_flag=SET;
                        kadai_1_clk_anti_pulse=1300;
                        tilt_A_steps++;
                    break;
                    case 4:
                        kadai_1_tilt_delay=10;
                        tilt_A_steps++;
                    break;
                    case 5:
                        K1_CW;
                        kadai_1_clk_anti_flag=SET;
                        kadai_1_clk_anti_pulse=1300;
                        kadai_1_cw_acw_switch_flag=SET;
                        tilt_A_steps++;
                    break;
                    case 6:
                        K1_REV;
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_fwd_rev_pulse=1700; // 1600 -22/07/24
                        kadai_1_switch_flag=SET;
                        tilt_A_steps++;
                    break;
                    default:
                        break;
                 }
             }
             else if((!collecting_tray_ok_flag)AND(collecting_tray_fwd_rev_pulse<=0)AND(cooker_2_kadai_using_flag)AND(kadai_1_clk_anti_pulse<=0)AND(kadai_1_tilt_delay<=0)AND(kadai_1_fwd_rev_pulse<=0))
             {
                if(!tilt_A_steps)
                    tilt_A_steps++;
                else if(tilt_A_steps>=7)
                {
                    tilt_A_steps=0;
                    kadai_1_tilting_flag=0;
                    if((cooker_2_kadai_using_flag)AND(!turmerind_water_collecting_flag))
                    {
                        cooker_2_kadai_using_flag=CLR;
                        c2_kadai_epprom_store_flag=SET;
                        dish2_step_complete_flag=SET;
                        dishes_complete();
                    }
                }
                 switch(tilt_A_steps)
                 {
                     case 1:
                         test_flag=SET;
                         collecting_tray_step_load_fun(5);
                         test_flag=CLR;
                         tilt_A_steps++;
                    break;
                    case 2:
                          if(kadai_1_left_right_switch_close_flag)
                            {
                                K1_REV;
                                kadai_1_fwd_rev_flag=SET;
                                kadai_1_fwd_rev_pulse=1950;
                                tilt_A_steps++;
                            }
                    break;
                    case 3:
                        K1_CW;
                        kadai_1_clk_anti_flag=SET;
                        kadai_1_clk_anti_pulse=1300;
                        tilt_A_steps++;
                    break;
                    case 4:
                        kadai_1_tilt_delay=10;
                        tilt_A_steps++;
                    break;
                    case 5:
                        K1_ACW;
                        kadai_1_clk_anti_flag=SET;
                        kadai_1_clk_anti_pulse=1300;
                        kadai_1_cw_acw_switch_flag=SET;
                        tilt_A_steps++;
                    break;
                    case 6:
                        K1_FWD;
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_fwd_rev_pulse=1950;
                        kadai_1_switch_flag=SET;
                        tilt_A_steps++;
                    break;
                    default:
                        break;
                 }
             }
         }
         if(kadai_2_tilting_flag)
         {
             if((!collecting_tray_ok_flag)AND(collecting_tray_fwd_rev_pulse<=0)AND(cooker_3_kadai_using_flag)AND(kadai_2_clk_anti_pulse<=0)AND(kadai_2_tilt_delay<=0)AND(kadai_2_fwd_rev_pulse<=0))
              {
                 if(!tilt_B_steps)
                     tilt_B_steps++;
                 else if(tilt_B_steps>=7)
                 {
                     tilt_B_steps=0;
                     kadai_2_tilting_flag=0;
                     if((cooker_3_kadai_using_flag)AND(!turmerind_water_collecting_flag))
                     {
                         cooker_3_kadai_using_flag=CLR;
                         c3_kadai_epprom_store_flag=SET;
                         dish3_step_complete_flag=SET;
                         dishes_complete();
                     }
                 }
                  switch(tilt_B_steps)
                  {

                      case 1:
                          test_flag=SET;
                          collecting_tray_step_load_fun(5);
                          test_flag=CLR;
                          tilt_B_steps++;
                          break;
                     case 2:
                         if(kadai_2_left_right_switch_close_flag)
                         {
                             K2_REV;
                             kadai_2_fwd_rev_flag=SET;
                             kadai_2_fwd_rev_pulse=2200;
                             tilt_B_steps++;
                         }
                     break;

                     case 3:
                         K2_CW;
                         kadai_2_clk_anti_flag=SET;
                         kadai_2_clk_anti_pulse=1300;
                         tilt_B_steps++;
                     break;
                     case 4:
                         kadai_2_tilt_delay=10;
                         tilt_B_steps++;
                     break;
                     case 5:
                         K2_ACW;
                         kadai_2_clk_anti_flag=SET;
                         kadai_2_clk_anti_pulse=1300;
                         kadai_2_cw_acw_switch_flag=SET;
                         tilt_B_steps++;
                     break;
                     case 6:
                         K2_FWD;
                         kadai_2_fwd_rev_flag=SET;
                         kadai_2_fwd_rev_pulse=2200;
                         kadai_2_switch_flag=SET;
                         tilt_B_steps++;
                     break;
                     default:
                         break;
                  }
              }
          }
     }
 }
/*********************************KADAI TILTING IN COOKERS HANDLING ***************************************/


/*********************************COOKERS POS & LIDS POS HANDLING ***************************************/
void cooker_pos_and_lid_pos()
{

    if((cooker_1_fwd_rev_pulse<=0)AND(lid_1_up_down_on_pluse<=0)AND((cooker1_cooking_process_start_flag)OR(cooker1_cooking_time_on_flag)OR(cooker1_cooking_time_off_flag)OR(cooker1_cooking_process_complete_flag)))
    {
        if(cooker1_cooking_process_start_flag)
        {
            if(!cooker_A_steps)
            cooker_A_steps++;
            if(cooker_A_steps>=5)
            {
                cooker1_cooking_process_start_flag=CLR;
                cooker_A_steps=0;
            }
            switch(cooker_A_steps)
            {
                case 1:
                       // if(lid_1_switch_close_flag)
                        {
                            LID_1_REV;
                            lid_1_up_down_on_pluse=LID_REV_PULSE;
                            lid_1_up_down_flag=SET;
                            cooker_A_steps++;
                        }
                break;
                case 2:
                        if(cooker1_switch_close_flag)
                        {
                            COOKER_1_REV;
                            cooker_1_fwd_rev_pulse=COOKER_HOMING_TO_LID_POS_PULSE;
                            cooker_1_fwd_rev_flag=SET;
                            cooker_A_steps++;
                        }
                break;
                case 3:
                        LID_1_FWD;
                        lid_1_up_down_on_pluse=LID_FWD_PULSE;
                        lid_1_up_down_flag=SET;
                        cooker_A_steps++;

                break;
                case 4:
                        COOKER_1_FWD;
                        cooker_1_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_1_fwd_rev_flag=SET;
                        cooker_A_steps++;
                break;
                default:

                    break;
            }
        }
        else if(cooker1_cooking_time_on_flag)
        {
            if(!cooker_A_steps)
            cooker_A_steps++;
            if(cooker_A_steps>=3)
            {
                cooker1_cooking_time_on_flag=CLR;
                cooker_A_steps=0;
            }
            switch(cooker_A_steps)
            {
                case 1:
                        COOKER_1_REV;
                        cooker_1_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_1_fwd_rev_flag=SET;
                        cooker_A_steps++;
                break;
                case 2:
                    //    if(lid_1_switch_close_flag)
                        {
                            LID_1_REV;
                            lid_1_up_down_on_pluse=LID_REV_PULSE;
                            lid_1_up_down_flag=SET;
                            cooker_A_steps++;
                        }
                break;
                default:

                    break;
            }
        }
        else if(cooker1_cooking_time_off_flag)
        {
            if(!cooker_A_steps)
            cooker_A_steps++;
            if(cooker_A_steps>=3)
            {
                cooker1_cooking_time_off_flag=CLR;
                if(cooking_time_1_flag)
                {
                    cooking_time_1_flag=CLR;
                    dish1_step_complete_flag=SET;
                    dishes_complete();
                }
                cooker_A_steps=0;
            }
            switch(cooker_A_steps)
            {
                case 1:
                            LID_1_FWD;
                            lid_1_up_down_on_pluse=LID_FWD_PULSE;
                            lid_1_up_down_flag=SET;
                            cooker_A_steps++;
                break;
                case 2:
                            COOKER_1_FWD;
                            cooker_1_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                            cooker_1_fwd_rev_flag=SET;
                            cooker_A_steps++;
                    break;
                default:

                    break;
            }
        }
        if(cooker1_cooking_process_complete_flag)
        {
            if(!cooker_A_steps)
            cooker_A_steps++;
            if(cooker_A_steps>=5)
            {
                cooker1_cooking_process_complete_flag=CLR;
                form_send_buf(0X05,ALL_STEPS_DONE,COMMAND_RES,COOKER1_ACK_DATA);
                cooker_A_steps=0;
            }
            switch(cooker_A_steps)
            {
                case 1:

                        COOKER_1_REV;
                        cooker_1_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_1_fwd_rev_flag=SET;
                        cooker_A_steps++;

                break;
                case 2:
                      //  if(lid_1_switch_close_flag)
                        {
                            LID_1_REV;
                            lid_1_up_down_on_pluse=LID_REV_PULSE;
                            lid_1_up_down_flag=SET;
                            cooker_A_steps++;
                        }
                break;
                case 3:
                        COOKER_1_FWD;
                        cooker_1_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                        cooker_1_fwd_rev_flag=SET;
                        cooker_A_steps++;
                break;
                case 4:
                        LID_1_FWD;
                        lid_1_up_down_on_pluse=LID_FWD_PULSE;
                        lid_1_up_down_flag=SET;
                        cooker_A_steps++;
                break;
            }
        }
    }

    if((cooker_2_fwd_rev_pulse<=0)AND(lid_2_up_down_on_pluse<=0)AND((cooker2_cooking_process_start_flag)OR(cooker2_cooking_time_on_flag)OR(cooker2_cooking_time_off_flag)OR(cooker2_cooking_process_complete_flag)))
    {
        if(cooker2_cooking_process_start_flag)
        {
           if(!cooker_B_steps)
               cooker_B_steps++;
            if(cooker_B_steps>=5)
            {
                cooker2_cooking_process_start_flag=CLR;
                cooker_B_steps=0;
            }
            switch(cooker_B_steps)
            {
                case 1:
                      //  if(lid_2_switch_close_flag)
                        {
                            LID_2_REV;
                            lid_2_up_down_on_pluse=LID_REV_PULSE;
                            lid_2_up_down_flag=SET;
                            cooker_B_steps++;
                        }
                break;
                case 2:
                        if(cooker2_switch_close_flag)
                        {
                            COOKER_2_REV;
                            cooker_2_fwd_rev_pulse=COOKER_HOMING_TO_LID_POS_PULSE;
                            cooker_2_fwd_rev_flag=SET;
                            cooker_B_steps++;
                        }
                break;
                case 3:
                        LID_2_FWD;
                        lid_2_up_down_on_pluse=LID_FWD_PULSE;
                        lid_2_up_down_flag=SET;
                        cooker_B_steps++;

                break;
                case 4:
                        COOKER_2_FWD;
                        cooker_2_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_2_fwd_rev_flag=SET;
                        cooker_B_steps++;
                break;
            }
        }
        else if(cooker2_cooking_time_on_flag)
        {
            if(!cooker_B_steps)
                          cooker_B_steps++;
            if(cooker_B_steps>=3)
            {
                cooker2_cooking_time_on_flag=CLR;
                cooker_B_steps=0;
            }
            switch(cooker_B_steps)
            {
                case 1:
                        COOKER_2_REV;
                        cooker_2_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_2_fwd_rev_flag=SET;
                        cooker_B_steps++;
                break;
                case 2:
                  //      if(lid_2_switch_close_flag)
                        {
                            LID_2_REV;
                            lid_2_up_down_on_pluse=LID_REV_PULSE;
                            lid_2_up_down_flag=SET;
                            cooker_B_steps++;
                        }
                break;
            }
        }
        else if(cooker2_cooking_time_off_flag)
        {
            if(!cooker_B_steps)
                          cooker_B_steps++;
            if(cooker_B_steps>=3)
            {
                cooker2_cooking_time_off_flag=CLR;
                if(cooking_time_2_flag)
                {
                    cooking_time_2_flag=CLR;
                    dish2_step_complete_flag=SET;
                    dishes_complete();
                }
                cooker_B_steps=0;
            }
            switch(cooker_B_steps)
            {
                case 1:
                            LID_2_FWD;
                            lid_2_up_down_on_pluse=LID_FWD_PULSE;
                            lid_2_up_down_flag=SET;
                            cooker_B_steps++;
                break;
                case 2:
                            COOKER_2_FWD;
                            cooker_2_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                            cooker_2_fwd_rev_flag=SET;
                            cooker_B_steps++;
                    break;
            }
        }
        if(cooker2_cooking_process_complete_flag)
        {
            if(!cooker_B_steps)
                          cooker_B_steps++;
            if(cooker_B_steps>=5)
            {
                cooker2_cooking_process_complete_flag=CLR;
                form_send_buf(0X05,ALL_STEPS_DONE,COMMAND_RES,COOKER2_ACK_DATA);
                cooker_B_steps=0;
            }
            switch(cooker_B_steps)
            {
                case 1:

                        COOKER_2_REV;
                        cooker_2_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_2_fwd_rev_flag=SET;
                        cooker_B_steps++;

                break;
                case 2:
                 //       if(lid_2_switch_close_flag)
                        {
                            LID_2_REV;
                            lid_2_up_down_on_pluse=LID_REV_PULSE;
                            lid_2_up_down_flag=SET;
                            cooker_B_steps++;
                        }
                break;
                case 3:
                        COOKER_2_FWD;
                        cooker_2_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                        cooker_2_fwd_rev_flag=SET;
                        cooker_B_steps++;
                break;
                case 4:
                        LID_2_FWD;
                        lid_2_up_down_on_pluse=LID_FWD_PULSE;
                        lid_2_up_down_flag=SET;
                        cooker_B_steps++;
                break;
            }
        }
    }
    if((cooker_3_fwd_rev_pulse<=0)AND(lid_3_up_down_on_pluse<=0)AND((cooker3_cooking_process_start_flag)OR(cooker3_cooking_time_on_flag)OR(cooker3_cooking_time_off_flag)OR(cooker3_cooking_process_complete_flag)))
    {
        if(cooker3_cooking_process_start_flag)
        {
            if(!cooker_C_steps)
            cooker_C_steps++;
            if(cooker_C_steps>=5)
            {
                cooker3_cooking_process_start_flag=CLR;
                cooker_C_steps=0;
            }
            switch(cooker_C_steps)
            {
                case 1:
                       // if(lid_3_switch_close_flag)
                        {
                            LID_3_REV;
                            lid_3_up_down_on_pluse=LID_REV_PULSE;
                            lid_3_up_down_flag=SET;
                            cooker_C_steps++;
                        }
                break;
                case 2:
                        if(cooker3_switch_close_flag)
                        {
                            COOKER_3_REV;
                            cooker_3_fwd_rev_pulse=COOKER_HOMING_TO_LID_POS_PULSE;
                            cooker_3_fwd_rev_flag=SET;
                            cooker_C_steps++;
                        }
                break;
                case 3:
                        LID_3_FWD;
                        lid_3_up_down_on_pluse=LID_FWD_PULSE;
                        lid_3_up_down_flag=SET;
                        cooker_C_steps++;

                break;
                case 4:
                        COOKER_3_FWD;
                        cooker_3_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_3_fwd_rev_flag=SET;
                        cooker_C_steps++;
                break;
            }
        }
        else if(cooker3_cooking_time_on_flag)
        {
            if(!cooker_C_steps)
            cooker_C_steps++;
            if(cooker_C_steps>=3)
            {
                cooker3_cooking_time_on_flag=CLR;
                cooker_C_steps=0;
            }
            switch(cooker_C_steps)
            {
                case 1:
                        COOKER_3_REV;
                        cooker_3_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_3_fwd_rev_flag=SET;
                        cooker_C_steps++;
                break;
                case 2:
                  //      if(lid_3_switch_close_flag)
                        {
                            LID_3_REV;
                            lid_3_up_down_on_pluse=LID_REV_PULSE;
                            lid_3_up_down_flag=SET;
                            cooker_C_steps++;
                        }
                break;
            }
        }
        else if(cooker3_cooking_time_off_flag)
        {
            if(!cooker_C_steps)
            cooker_C_steps++;
            if(cooker_C_steps>=3)
            {
                cooker3_cooking_time_off_flag=CLR;
                if(cooking_time_3_flag)
                {
                    cooking_time_3_flag=CLR;
                    dish3_step_complete_flag=SET;
                    dishes_complete();
                }
                cooker_C_steps=0;
            }
            switch(cooker_C_steps)
            {
                case 1:
                            LID_3_FWD;
                            lid_3_up_down_on_pluse=LID_FWD_PULSE;
                            lid_3_up_down_flag=SET;
                            cooker_C_steps++;
                break;
                case 2:
                            COOKER_3_FWD;
                            cooker_3_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                            cooker_3_fwd_rev_flag=SET;
                            cooker_C_steps++;
                break;
            }
        }
        if(cooker3_cooking_process_complete_flag)
        {
            if(!cooker_C_steps)
            cooker_C_steps++;
            if(cooker_C_steps>=5)
            {
                cooker3_cooking_process_complete_flag=CLR;
                cooker_C_steps=0;
                form_send_buf(RECEIPE_PREP_APP_ID,ALL_STEPS_DONE,COMMAND_RES,COOKER3_ACK_DATA);
            }
            switch(cooker_C_steps)
            {
                case 1:

                        COOKER_3_REV;
                        cooker_3_fwd_rev_pulse=COOKER_LID_TO_COLLECTING_POS_PULSE;
                        cooker_3_fwd_rev_flag=SET;
                        cooker_C_steps++;

                break;
                case 2:
                     //   if(lid_3_switch_close_flag)
                        {
                            LID_3_REV;
                            lid_3_up_down_on_pluse=LID_REV_PULSE;
                            lid_3_up_down_flag=SET;
                            cooker_C_steps++;
                        }
                break;
                case 3:
                        COOKER_3_FWD;
                        cooker_3_fwd_rev_pulse=COOKER_LID_TO_HOMING_POS_PULSE;
                        cooker_3_fwd_rev_flag=SET;
                        cooker_C_steps++;
                break;
                case 4:
                        LID_3_FWD;
                        lid_3_up_down_on_pluse=LID_FWD_PULSE;
                        lid_3_up_down_flag=SET;
                        cooker_C_steps++;
                break;
            }
        }
    }
}
/*********************************COOKERS POS & LIDS POS HANDLING ***************************************/



/********************************* VEG TRAYS HANDLING ***************************************/
void veg_tray_home_position()
{
    if((veg1_tray_rev_ok_flag)OR(veg2_tray_rev_ok_flag)OR(veg3_tray_rev_ok_flag))
    {
        if(veg1_tray_rev_ok_flag)
        {
            veg1_tray_rev_ok_flag=CLR;
            if(veg_tray_1_position)
            {
                veg_tray_1_fwd_rev_pulse=810;
                if(veg_tray_1_fwd_rev_pulse)
                {
                    VEG_TRAY_1_REV;
                    veg_tray_1_fwd_rev_flag=SET;
                  //  veg_1_switch_flag=SET;
                    veg_tray_1_position=0;
                }
            }

        }
        if(veg2_tray_rev_ok_flag)
        {
            veg2_tray_rev_ok_flag=CLR;
            if(veg_tray_2_position)
            {
                veg_tray_2_fwd_rev_pulse=810;
                if(veg_tray_2_fwd_rev_pulse)
                {
                    VEG_TRAY_2_REV;
                    veg_tray_2_fwd_rev_flag=SET;
                    veg_tray_2_position=0;
               //     veg_2_switch_flag=SET;
                }
            }

        }
        if(veg3_tray_rev_ok_flag)
        {
            veg3_tray_rev_ok_flag=CLR;
            if(veg_tray_3_position)
            {
                veg_tray_3_fwd_rev_pulse=810;
                if(veg_tray_3_fwd_rev_pulse)
                {
                    VEG_TRAY_3_REV;
                    veg_tray_3_fwd_rev_flag=SET;
                    veg_tray_3_position=0;
                  //  veg_3_switch_flag=SET;
                }
            }
        }
    }
}

/********************************* VEG TRAYS HANDLING ***************************************/

void kadai_homing()
{
    if((kadai_1_homing_flag)OR(kadai_2_homing_flag))
    {
        if((kadai_1_homing_flag)AND(!kadai_2_homing_flag)AND(kadai_1_delay<=0)AND(kadai_1_fwd_rev_pulse<=0)AND(!kadai_1_left_right_switch_close_flag))
        {
            if(!kadai_1_homing_step)
                kadai_1_homing_step++;

            switch(kadai_1_homing_step)
            {
                case 1:
                        if(kadai_homing_position_close_flag)
                        {
                            kadai_1_fwd_rev_pulse=2200;
                            K1_FWD;
                            kadai_1_switch_flag=SET;
                        }
                        else
                        {
                            K1_REV;
                            kadai_1_fwd_rev_pulse=1900;
                            kadai_1_switch_flag=SET;
                            kadai_homing_switch_flag=SET;
                        }
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_homing_step++;
                break;
                case 2:
                        kadai_1_delay=2;
                        kadai_1_homing_step++;
                break;

                case 3:
                        if(kadai_homing_position_close_flag)
                        {
                            kadai_1_fwd_rev_pulse=2200;
                            K1_FWD;
                           kadai_1_switch_flag=SET;
                        }
                        kadai_1_fwd_rev_flag=SET;
                        kadai_1_homing_step++;
                break;
            }
        }
        else if((kadai_1_left_right_switch_close_flag)AND(kadai_1_homing_flag))
        {
            kadai_1_homing_flag=CLR;
            kadai_1_homing_step=0;
            kadai_1_fwd_rev_pulse=10;
            kadai_1_fwd_rev_flag=SET;
        }
        if((kadai_2_homing_flag)AND(!kadai_1_homing_flag)AND(kadai_2_delay<=0)AND(kadai_2_fwd_rev_pulse<=0)AND(!kadai_2_left_right_switch_close_flag))
        {
            if(!kadai_2_homing_step)
                kadai_2_homing_step++;

            switch(kadai_2_homing_step)
            {
                case 1:
                        if(kadai_homing_position_close_flag)
                        {
                            kadai_2_fwd_rev_pulse=1950;
                            K2_REV;
                           kadai_2_switch_flag=SET;
                        }
                        else
                        {
                            K2_FWD;
                            kadai_2_fwd_rev_pulse=2200;
                            kadai_2_switch_flag=SET;
                            kadai_homing_switch_flag=SET;
                        }
                        kadai_2_fwd_rev_flag=SET;
                        kadai_2_homing_step++;
                break;
                case 2:
                        kadai_2_delay=2;
                        kadai_2_homing_step++;
                break;
                case 3:
                        if(kadai_homing_position_close_flag)
                        {
                            kadai_2_fwd_rev_pulse=1950;
                            K2_REV;
                            kadai_2_switch_flag=SET;
                        }
                        kadai_2_fwd_rev_flag=SET;
                        kadai_2_homing_step++;
                break;
            }
        }
        else if((kadai_2_left_right_switch_close_flag)AND(kadai_2_homing_flag))
        {
            kadai_2_homing_flag=CLR;
            kadai_2_homing_step=0;
            kadai_2_fwd_rev_pulse=10;
            kadai_2_fwd_rev_flag=SET;
        }
    }
}

/*********************************  STEPPER MOTOR ERRORS ***************************************/
void motor_error_detection()
{
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&VEG_TRAY1_SWITCH);     //fault_1
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&VEG_TRAY2_SWITCH);     //fault_2
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&VEG_TRAY3_SWITCH);     //fault_3
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&LID1_SWITCH);          //fault_4
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&LID2_SWITCH);          //fault_5
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&LID3_SWITCH);          //fault_6
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&COOKER1_SWITCH);       //fault_7
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&COOKER2_SWITCH);       //fault_8
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&COOKER3_SWITCH);       //fault_9
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_1_LR_SWITCH);    //fault_10
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_1_CA_SWITCH);    //fault_11
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_LR_SWITCH);    //fault_12
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_CA_SWITCH);    //fault_13
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_1_CA_SWITCH);    //fault_14
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_LR_SWITCH);    //fault_15
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_CA_SWITCH);    //fault_16
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_1_CA_SWITCH);    //fault_17
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_LR_SWITCH);    //fault_18

//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_1_CA_SWITCH);    //LO 1
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_LR_SWITCH);    //LO 2
//
//        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&KADAI_2_LR_SWITCH);    //LO 3
}
/*********************************  STEPPER MOTOR ERRORS ***************************************/
//void kadai_oscillation()
//{
//    if(kadai_1_oscillation_flag)
//    {
//
//    }
//}

void buzzer()
{
    bool buzzer_on;

   if((buzzer_on_flag)AND(!buzzer_on))
   {
       buzzer_on=SET;
       buzzer_on_time=BUZZER_SEC;
       BUZZER_ON;
       buzzer_on_flag=CLR;
   }
   else if((buzzer_on)AND(!buzzer_on_time))
   {
       buzzer_on=CLR;
       BUZZER_OFF;
   }
}
