/*
 * SEND_UART.C
 *
 *  Created on: Dec 11, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include "HEADER_FILE/Macros.H"
#include "HEADER_FILE/UART_SEND_HEADER.H"
#include "string.h"
#include <stdio.h>
#include <stdlib.h>

#include "HEADER_FILE/EXTERN_FUN.H"

char *send_string_data[]={
            "ACK",                              /* 0 */
            "HANDSHAKE",                        /* 1 */
            "DISPLAY_READY",                    /* 2 */
            "READY",                             /* 3 */
            "START",                            /* 4 */
            "DONE",                             /* 5 */
            "STOP",                             /* 6 */
            "C1|DONE",                          /* 7 */
            "C2|DONE",                          /* 8 */
            "C3|DONE",                          /* 9 */
            "C1|STOP",                          /* 10 */
            "C2|STOP",                          /* 11 */
            "C3|STOP",                          /* 12 */
            "C1|START",                         /* 13 */
            "C2|START",                         /* 14 */
            "C3|START",                         /* 15 */
            "C1|ACK",                           /* 16 */
            "C2|ACK",                           /* 17 */
            "C3|ACK",                           /* 18 */
            "CHK_ER",                           /* 19 */
            "FID_ER",                           /* 20 */
            "AID_ER",                           /* 21 */
            "FRM_ER",                           /* 22 */
            "DLC_ER",                           /* 23 */
            "C1|COOKER 1 SENSOR FAILURE|10",    /* 24 */
            "C2|COOKER 2 SENSOR FAILURE|11",    /* 25 */
            "C3|COOKER 3 SENSOR FAILURE|12",    /* 26 */
            "LID 1 UP SENSOR FAILURE|2",        /* 27 */
            "LID 1 DWN SENSOR FAILURE|3",       /* 28 */
            "LID 1 FWD SENSOR FAILURE|4",       /* 29 */
            "LID 1 REV SENSOR FAILURE|5",       /* 30 */
            "VEG TRAY 1 SENSOR FAILURE|7",      /* 31 */
            "VEG TRAY 2 SENSOR FAILURE|8",      /* 32 */
            "VEG TRAY 3 SENSOR FAILURE|9",      /* 33 */
            "FLOW METER FAILURE|6",             /* 34 */
            "C1|COMPLETE",                      /* 35 */
            "C2|COMPLETE",                      /* 36 */
            "C3|COMPLETE",                      /* 37 */
            "C1|VEG TRAY 1 SENSOR FAILURE|13",  /* 38 */
            "C2|VEG TRAY 2 SENSOR FAILURE|14",  /* 39 */
            "C3|VEG TRAY 3 SENSOR FAILURE|15",  /* 40 */
            "RESTART",                          /* 41 */
            "COOKER PROX SENSOR FAILURE|16",    /* 42 */
            "COOKER HOME SWITCH FAILURE|17",    /* 43 */
            "C1|TIMER",                         /* 44 */
            "C2|TIMER",                         /* 45 */
            "C3|TIMER",                         /* 46 */
            "HEART_BEAT",                       /* 47 */

            "LID 2 UP SENSOR FAILURE|18",       /* 48 */
            "LID 2 DWN SENSOR FAILURE|19",      /* 49 */
            "LID 2 FWD SENSOR FAILURE|20",      /* 50 */
            "LID 2 REV SENSOR FAILURE|21",      /* 51 */

            "LID 3 UP SENSOR FAILURE|22",       /* 52 */
            "LID 3 DWN SENSOR FAILURE|23",      /* 53 */
            "LID 3 FWD SENSOR FAILURE|24",      /* 54 */
            "LID 3 REV SENSOR FAILURE|25",      /* 55 */

            "C1|LID 1 UP SENSOR FAILURE|26",    /* 56 */
            "C1|LID 1 DWN SENSOR FAILURE|27",   /* 57 */
            "C1|LID 1 FWD SENSOR FAILURE|28",   /* 58 */
            "C1|LID 1 REV SENSOR FAILURE|29",   /* 59 */

            "C2|LID 2 UP SENSOR FAILURE|30",    /* 60 */
            "C2|LID 2 DWN SENSOR FAILURE|31",   /* 61 */
            "C2|LID 2 FWD SENSOR FAILURE|32",   /* 62 */
            "C2|LID 2 REV SENSOR FAILURE|33",   /* 63 */

            "C3|LID 3 UP SENSOR FAILURE|34",    /* 64 */
            "C3|LID 3 DWN SENSOR FAILURE|35",   /* 65 */
            "C3|LID 3 FWD SENSOR FAILURE|36",   /* 66 */
            "C3|LID 3 REV SENSOR FAILURE|37",   /* 67 */

            "COOKER MOTOR NOT WORKING|38",          /* 68 */
            "C1|VEGTRAY 1 MOTOR NOT WORKING|39",    /* 69 */
            "C2|VEGTRAY 2 MOTOR NOT WORKING|40",    /* 70 */
            "C3|VEGTRAY 3 MOTOR NOT WORKING|41",    /* 71 */

            "KADAI_CW_SENSOR_FAILURE",              /* 72*/
            "KADAI_REV_SENSOR_FAILURE",             /* 73*/
            "KADAI_ACW_FAILURE",                    /* 74*/
            "KADAI_FWD_FAILURE",                    /* 75*/

            "C1|KADAI_CW_SENSOR_FAILURE|42",        /*76*/
            "C1|KADAI_REV_SENSOR_FAILURE|43",       /*77*/
            "C1|KADAI_ACW_MOTOR NOT WORKING|44",    /*78*/
            "C1|KADAI_FWD_MOTOR NOT WORKING|45",    /*79*/

            "C2|KADAI_CW_SENSOR_FAILURE|46",        /*80*/
            "C2|KADAI_REV_SENSOR_FAILURE|47",       /*81*/
            "C2|KADAI_ACW_MOTOR NOT WORKING|48",    /*82*/
            "C2|KADAI_FWD_MOTOR NOT WORKING|49",    /*83*/

            "C3|KADAI_CW_SENSOR_FAILURE|50",        /*84*/
            "C3|KADAI_REV_SENSOR_FAILURE|51",       /*85*/
            "C3|KADAI_ACW_MOTOR NOT WORKING|52",    /*86*/
            "C3|KADAI_FWD_MOTOR NOT WORKING|53",    /*87*/

            "INIT",                                 /*88*/
            "START",                                /*89*/
            "COMPLETE",                             /*90*/

            "C1|Please wait water refilling ......|54", /*91*/
            "C1|Please wait water heating ......|55",   /*92*/
            "C2|Please wait water refilling ......|56", /*93*/
            "C2|Please wait water heating ......|57",   /*94*/
            "C3|Please wait water refilling ......|58", /*95*/
            "C3|Please wait water heating ......|59",   /*96*/

           };

bool int_step_ok_flag;
void err_resend_fun();
void gui_uart_send();
void uart_retry();
char add_checksum(char);
char add_stuff_byte(char len);
bool is_valid_data(unsigned char [],char );
void form_send_buf(unsigned char,unsigned char,char ,char );

void form_send_buf(unsigned char app,unsigned char fun,char respond_format,char index)
{
    unsigned char byte=0,a,j,i,data_len;
    char *ptr,step_count_buf[10];

    memset(send_buf,0,sizeof(send_buf));

    if((app==0x03)AND(fun==0X03))  // INIT ACK ADDED WITH STEP COUNT
    {
        char count_buf[20];
        memset(temp_send_buf,0,sizeof(temp_send_buf));
        sprintf(count_buf,"%d",init_step_count);
        for(j=i=0;j<strlen(count_buf);i++,j++)
        temp_send_buf[i]=count_buf[j];
        temp_send_buf[i++]='|';
        ptr=send_string_data[index];
        for(a=0;a<strlen(send_string_data[index]);a++,i++)
        temp_send_buf[i]=*ptr++;
        respond_format=CLR;
        int_step_ok_flag=CLR;
    }
    if(respond_format)
    {
        ptr=send_string_data[index];
        for(i=0;i<strlen(send_string_data[index]);i++)
            temp_send_buf[i]=*ptr++;
    }
    if(((app==0X05)AND(fun==0X02))OR((app==0X05)AND(fun==0X01))OR((app==0X05)AND(fun==0X06)))    //send ack and done data with step count
    {
        temp_send_buf[i++]='|';
        sprintf(step_count_buf,"%d",current_send_step_count);
        for(j=0;j<strlen(step_count_buf);i++,j++)
        temp_send_buf[i]=step_count_buf[j];
    }
    data_len=i;
    send_buf[byte++]=START_BYTE;
    send_buf[byte++]=0x08;
    send_buf[byte++]=0;
    send_buf[byte++]=data_len;
    send_buf[byte++]=app;
    send_buf[byte++]=fun;
    for(i=0;i<data_len;byte++,i++)
    send_buf[byte]=temp_send_buf[i];
    send_buf[byte++]=add_checksum(byte);
    memcpy(temp_send_buf,send_buf,sizeof(send_buf));
    byte=add_stuff_byte(byte);
    send_buf[byte++]=END_BYTE;
    tx_total_send_bytes=byte;
    byte=0;
    frame_formed_flag=SET;
    gui_uart_send();

}
char add_checksum(char len)
{
    char temp_check_sum=0,count,byte;
    for(byte=START_FROM,count=0;byte<len;byte++,count++)
    temp_check_sum=(temp_check_sum+(count^(send_buf[byte])));
    temp_check_sum=~(temp_check_sum+send_buf[HEADER_BYTE]);
    return temp_check_sum;
}
char add_stuff_byte(char len)
{
    unsigned char byte,i,stuff_byte;

    for(byte=1,i=1,stuff_byte=0;byte<(len+stuff_byte);i++,byte++)
    {
        if((temp_send_buf[i]==0X1C)OR(temp_send_buf[i]==0X2A)OR(temp_send_buf[i]==0X23))
        {
            send_buf[byte++]=STUFF_BYTE;
            send_buf[byte]=~temp_send_buf[i];
            stuff_byte++;
        }
        else
        send_buf[byte]=temp_send_buf[i];
    }
    return byte;
}
bool is_valid_data(unsigned char received_buf[],char index)
{
    char byte;
    char *ptr;
    ptr=send_string_data[index];
    for(byte=0;byte<strlen(send_string_data[index]);byte++)
    {
        if((*ptr++)!=received_buf[byte])
        return 1;
    }
    return 0;
}

void gui_uart_send()
{
    if((uart_send_flag)AND(trasmit_dly<=0))
    {
        main_tx_buf_size=0;
        memset(main_tx_buf,0,sizeof(main_tx_buf));
//        if(retry_buffer_flag)
//            uart_retry();

        if((frist_ack_buffer_flag)OR(second_ack_buffer_flag)OR(third_ack_buffer_flag))
        {
            if(frist_ack_buffer_flag)
            {
                memcpy(main_tx_buf,send_ack_buffer1,sizeof(send_ack_buffer1));
                main_tx_buf_size=ack_buf1_size;
                memset(send_ack_buffer1,0,sizeof(send_ack_buffer1));
                ack_buf1_size=0;
                frist_ack_buffer_flag = CLR;
            }
            else if(second_ack_buffer_flag)
            {
                memcpy(main_tx_buf,send_ack_buffer2,sizeof(send_ack_buffer2));
                main_tx_buf_size=ack_buf2_size;
                memset(send_ack_buffer2,0,sizeof(send_ack_buffer2));
                ack_buf2_size=0;
                second_ack_buffer_flag=CLR;

            }
            else if(third_ack_buffer_flag)
            {
                memcpy(main_tx_buf,send_ack_buffer3,sizeof(send_ack_buffer3));
                main_tx_buf_size=ack_buf3_size;
                memset(send_ack_buffer3,0,sizeof(send_ack_buffer3));
                ack_buf3_size=0;
                third_ack_buffer_flag=CLR;
            }
        }
        else if((frist_timer_buffer_flag)OR(second_timer_buffer_flag)OR(third_timer_buffer_flag)OR(c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag))
        {
            if((c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag))
                uart_retry();

            else if(frist_timer_buffer_flag)
            {
                memcpy(main_tx_buf,send_timer_buffer1,sizeof(send_timer_buffer1));
                main_tx_buf_size=timer_buf1_size;
                memset(send_timer_buffer1,0,sizeof(send_timer_buffer1));
                timer_buf1_size=0;
                frist_timer_buffer_flag = CLR;
            }
            else if(second_timer_buffer_flag)
            {
                memcpy(main_tx_buf,send_timer_buffer2,sizeof(send_timer_buffer2));
                main_tx_buf_size=timer_buf2_size;
                memset(send_timer_buffer2,0,sizeof(send_timer_buffer2));
                timer_buf2_size=0;
                second_timer_buffer_flag=CLR;

            }
            else if(third_timer_buffer_flag)
            {
                memcpy(main_tx_buf,send_timer_buffer3,sizeof(send_timer_buffer3));
                main_tx_buf_size=timer_buf3_size;
                memset(send_timer_buffer3,0,sizeof(send_timer_buffer3));
                timer_buf3_size=0;
                third_timer_buffer_flag=CLR;
            }
        }
        else if((frist_done_buffer_flag)OR(second_done_buffer_flag)OR(third_done_buffer_flag)OR(c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag))
        {
            if((c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag))
                uart_retry();

            else if(frist_done_buffer_flag)
            {
                memcpy(main_tx_buf,send_done_buffer1,sizeof(send_done_buffer1));
                main_tx_buf_size=done_buf1_size;
                memset(send_done_buffer1,0,sizeof(send_done_buffer1));
                done_buf1_size=0;
                frist_done_buffer_flag = CLR;
            }
            else if(second_done_buffer_flag)
            {
                memcpy(main_tx_buf,send_done_buffer2,sizeof(send_done_buffer2));
                main_tx_buf_size=done_buf2_size;
                memset(send_done_buffer2,0,sizeof(send_done_buffer2));
                done_buf2_size=0;
                second_done_buffer_flag=CLR;

            }
            else if(third_done_buffer_flag)
            {
                memcpy(main_tx_buf,send_done_buffer3,sizeof(send_done_buffer3));
                main_tx_buf_size=done_buf3_size;
                memset(send_done_buffer3,0,sizeof(send_done_buffer3));
                done_buf3_size=0;
                third_done_buffer_flag=CLR;
            }
        }
        else if((first_buffer_flag)OR(second_buffer_flag)OR(third_buffer_flag))
        {
            if(first_buffer_flag)
            {
                memcpy(main_tx_buf,tx_buf1,sizeof(tx_buf1));
                main_tx_buf_size=tx_buf1_size;
                memset(tx_buf1,0,sizeof(tx_buf1));
                tx_buf1_size=0;
                first_buffer_flag = CLR;
            }
            else if(second_buffer_flag)
            {
                memcpy(main_tx_buf,tx_buf2,sizeof(tx_buf2));
                main_tx_buf_size=tx_buf2_size;
                memset(tx_buf2,0,sizeof(tx_buf2));
                tx_buf2_size=0;
                second_buffer_flag=CLR;

            }
            else if(third_buffer_flag)
            {
                memcpy(main_tx_buf,tx_buf3,sizeof(tx_buf3));
                main_tx_buf_size=tx_buf3_size;
                memset(tx_buf3,0,sizeof(tx_buf3));
                tx_buf3_size=0;
                third_buffer_flag=CLR;
            }
        }
        if((!retry_buffer_flag)AND(!frist_ack_buffer_flag)AND(!second_ack_buffer_flag)AND(!third_ack_buffer_flag)AND(!third_buffer_flag)AND(!second_buffer_flag)AND(!first_buffer_flag)
        AND(!frist_timer_buffer_flag)AND(!second_timer_buffer_flag)AND(!third_timer_buffer_flag)
        AND(!frist_done_buffer_flag)AND(!second_done_buffer_flag)AND(!third_done_buffer_flag))
        uart_send_flag=CLR;


        if((main_tx_buf[4]==0X05)AND((main_tx_buf[5]==0X02)OR(main_tx_buf[5]==0X06)))
        {
            if((main_tx_buf[7]==0x31)AND(!c1_one_time_resend_flag))
            {
                c1_backup_total_bytes=0;
                memset(C1_send_backup_buf,0,sizeof(C1_send_backup_buf));
                c1_backup_total_bytes=main_tx_buf_size;
                memcpy(C1_send_backup_buf,main_tx_buf,sizeof(main_tx_buf));
                c1_resend_cnt=0;
                c1_resend_ok_flag=SET;
                c1_one_time_resend_flag=SET;
            }
            if((main_tx_buf[7]==0x32)AND(!c2_one_time_resend_flag))
            {
                c2_backup_total_bytes=0;
                memset(C2_send_backup_buf,0,sizeof(C2_send_backup_buf));
                c2_backup_total_bytes=main_tx_buf_size;
                memcpy(C2_send_backup_buf,main_tx_buf,sizeof(main_tx_buf));
                c2_resend_cnt=0;
                c2_resend_ok_flag=SET;
                c2_one_time_resend_flag=SET;
            }
            if((main_tx_buf[7]==0x33)AND(!c3_one_time_resend_flag))
            {
                c3_backup_total_bytes=0;
                memset(C3_send_backup_buf,0,sizeof(C3_send_backup_buf));
                c3_backup_total_bytes=main_tx_buf_size;
                memcpy(C3_send_backup_buf,main_tx_buf,sizeof(main_tx_buf));
                c3_resend_cnt=0;
                c3_resend_ok_flag=SET;
                c3_one_time_resend_flag=SET;
            }
        }
//        if((!retry_buffer_flag)AND((((main_tx_buf[4]==0x01)OR(main_tx_buf[4]==0x06)OR(main_tx_buf[4]==0x09))AND(main_tx_buf[5]==0x01))OR((main_tx_buf[4]==0x09)AND(main_tx_buf[5]==0x02))OR((main_tx_buf[4]==0x03)AND((main_tx_buf[5]==0x03)OR(main_tx_buf[5]==0x04)))))
//        {
//            memset(retry_send_backup_buf,0,sizeof(retry_send_backup_buf));
//            retry_send_backup_buf_size=0;
//            retry_send_backup_buf_size=main_tx_buf_size;
//            memcpy(retry_send_backup_buf,main_tx_buf,sizeof(main_tx_buf));
//            retry_buffer_flag=SET;
//        }
        if(!resend_flag)
        {
            Uart.p_api->write (Uart.p_ctrl, main_tx_buf, main_tx_buf_size);
            trasmit_dly=250;
            heart_beat_counter=0;           //For Heart beat reset
        }
        else
        resend_flag=CLR;
    }
    if(frame_formed_flag)
    {
        if((send_buf[4]==0X05)AND((send_buf[5]>=0X01)AND(send_buf[5]<=0X06))AND(send_buf[9]=='A')AND(send_buf[11]=='K'))
        {
            send_ack_count++;
            if(send_ack_count>3)
            send_ack_count=1;

            if((send_ack_count==1)AND(!frist_ack_buffer_flag))
            {
                ack_buf1_size=0;
                memset(send_ack_buffer1,0,sizeof(send_ack_buffer1));
                memcpy(send_ack_buffer1,send_buf,sizeof(send_buf));
                ack_buf1_size=tx_total_send_bytes;
                frist_ack_buffer_flag = SET;
            }
            if((send_ack_count==2)AND(!second_ack_buffer_flag))
            {
                ack_buf2_size=0;
                memset(send_ack_buffer2,0,sizeof(send_ack_buffer2));
                memcpy(send_ack_buffer2,send_buf,sizeof(send_buf));
                ack_buf2_size=tx_total_send_bytes;
                second_ack_buffer_flag = SET;
            }
            if((send_ack_count==3)AND(!third_ack_buffer_flag))
            {
                ack_buf3_size=0;
                memset(send_ack_buffer3,0,sizeof(send_ack_buffer3));
                memcpy(send_ack_buffer3,send_buf,sizeof(send_buf));
                ack_buf3_size=tx_total_send_bytes;
                third_ack_buffer_flag = SET;
            }
        }
        else if((send_buf[4]==0X05)AND(send_buf[5]==0X06)AND(send_buf[9]=='T')AND(send_buf[13]=='R'))
        {
            send_timer_count++;
            if(send_timer_count>3)
            send_timer_count=1;

            if((send_timer_count==1)AND(!frist_timer_buffer_flag))
            {
                timer_buf1_size=0;
                memset(send_timer_buffer1,0,sizeof(send_timer_buffer1));
                memcpy(send_timer_buffer1,send_buf,sizeof(send_buf));
                timer_buf1_size=tx_total_send_bytes;
                frist_timer_buffer_flag = SET;
            }
            if((send_timer_count==2)AND(!second_timer_buffer_flag))
            {
                timer_buf2_size=0;
                memset(send_timer_buffer2,0,sizeof(send_timer_buffer2));
                memcpy(send_timer_buffer2,send_buf,sizeof(send_buf));
                timer_buf2_size=tx_total_send_bytes;
                second_timer_buffer_flag = SET;
            }
            if((send_timer_count==3)AND(!third_timer_buffer_flag))
            {
                timer_buf3_size=0;
                memset(send_timer_buffer3,0,sizeof(send_timer_buffer3));
                memcpy(send_timer_buffer3,send_buf,sizeof(send_buf));
                timer_buf3_size=tx_total_send_bytes;
                third_timer_buffer_flag = SET;
            }
        }
        else if((send_buf[4]==0X05)AND(send_buf[5]==0X02)AND(send_buf[9]=='D')AND(send_buf[12]=='E'))
        {
            send_done_count++;
            if(send_done_count>3)
            send_done_count=1;
            if((send_done_count==1)AND(!frist_done_buffer_flag))
            {
                done_buf1_size=0;
                memset(send_done_buffer1,0,sizeof(send_done_buffer1));
                memcpy(send_done_buffer1,send_buf,sizeof(send_buf));
                done_buf1_size=tx_total_send_bytes;
                frist_done_buffer_flag = SET;
            }
            if((send_done_count==2)AND(!second_done_buffer_flag))
            {
                done_buf2_size=0;
                memset(send_done_buffer2,0,sizeof(send_done_buffer2));
                memcpy(send_done_buffer2,send_buf,sizeof(send_buf));
                done_buf2_size=tx_total_send_bytes;
                second_done_buffer_flag = SET;
            }
            if((send_done_count==3)AND(!third_done_buffer_flag))
            {
                done_buf3_size=0;
                memset(send_done_buffer3,0,sizeof(send_done_buffer3));
                memcpy(send_done_buffer3,send_buf,sizeof(send_buf));
                done_buf3_size=tx_total_send_bytes;
                third_done_buffer_flag = SET;
            }
        }
//        else if(((send_buf[4]==0X01)OR(send_buf[4]==0X06))AND(send_buf[5]==0X01))
//        {
//            if(!retry_first_buffer_flag)
//            {
//                retry_send_buf_size=0;
//                memset(retry_send_buf,0,sizeof(retry_send_buf));
//                memcpy(retry_send_buf,send_buf,sizeof(send_buf));
//                retry_send_buf_size=tx_total_send_bytes;
//                retry_first_buffer_flag = SET;
//            }
//        }
        else
        {
            send_order_count++;
            if(send_order_count>3)
            send_order_count=1;
            if((send_order_count==1)AND(!first_buffer_flag))
            {
                tx_buf1_size=0;
                memset(tx_buf1,0,sizeof(tx_buf1));
                memcpy(tx_buf1,send_buf,sizeof(send_buf));
                tx_buf1_size=tx_total_send_bytes;
                first_buffer_flag = SET;
            }
            if((send_order_count==2)AND(!second_buffer_flag))
            {
                tx_buf2_size=0;
                memset(tx_buf2,0,sizeof(tx_buf2));
                memcpy(tx_buf2,send_buf,sizeof(send_buf));
                tx_buf2_size=tx_total_send_bytes;
                second_buffer_flag=SET;
            }
            if((send_order_count==3)AND(!third_buffer_flag))
            {
                tx_buf3_size=0;
                memset(tx_buf3,0,sizeof(tx_buf3));
                memcpy(tx_buf3,send_buf,sizeof(send_buf));
                tx_buf3_size=tx_total_send_bytes;
                third_buffer_flag=SET;
            }
        }
        uart_send_flag=SET;
        frame_formed_flag=CLR;
    }
    if((!uart_send_flag)AND(trasmit_dly<=0)AND((c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag)OR(retry_buffer_flag)))  // NEW UPDATE
    uart_send_flag=SET;

}
void uart_retry()
{
    if((trasmit_dly<=0)AND((c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag)OR(retry_buffer_flag)))
    {
        backup_total_bytes=0;
        memset(send_backup_buf,0,sizeof(send_backup_buf));
        if(c1_resend_ok_flag)
        {
            if(++c1_resend_cnt>3)
            {
                c1_resend_cnt=0;
                c1_resend_ok_flag=CLR;
                memset(C1_send_backup_buf,0,sizeof(C1_send_backup_buf));
                c1_backup_total_bytes=0;
            }
            backup_total_bytes=c1_backup_total_bytes;
            memcpy(send_backup_buf,C1_send_backup_buf,sizeof(C1_send_backup_buf));

        }
        else if(c2_resend_ok_flag)
        {
            if(++c2_resend_cnt>3)
            {
                c2_resend_cnt=0;
                c2_resend_ok_flag=CLR;
                memset(C2_send_backup_buf,0,sizeof(C2_send_backup_buf));
                c2_backup_total_bytes=0;
            }
            backup_total_bytes=c2_backup_total_bytes;
            memcpy(send_backup_buf,C2_send_backup_buf,sizeof(C2_send_backup_buf));

        }
        else if(c3_resend_ok_flag)
        {
            if(++c3_resend_cnt>3)
            {
                c3_resend_cnt=0;
                c3_resend_ok_flag=CLR;
                memset(C3_send_backup_buf,0,sizeof(C3_send_backup_buf));
                c3_backup_total_bytes=0;
            }
            backup_total_bytes=c3_backup_total_bytes;
            memcpy(send_backup_buf,C3_send_backup_buf,sizeof(C3_send_backup_buf));
        }
        else if(retry_buffer_flag)
        {
            if(++retry_send_cnt>3)
            {
                retry_send_cnt=0;
                retry_buffer_flag=CLR;
                memset(retry_send_backup_buf,0,sizeof(retry_send_backup_buf));
                retry_send_backup_buf_size=0;
            }
            backup_total_bytes=retry_send_backup_buf_size;
            memcpy(send_backup_buf,retry_send_backup_buf,sizeof(retry_send_backup_buf));
        }
        if((c1_resend_ok_flag)OR(c2_resend_ok_flag)OR(c3_resend_ok_flag)OR(retry_buffer_flag))
        {
            Uart.p_api->write (Uart.p_ctrl, send_backup_buf, backup_total_bytes);
            trasmit_dly=250;
            resend_flag=SET;
        }
    }
}
