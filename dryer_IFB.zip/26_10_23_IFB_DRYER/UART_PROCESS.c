#include "r_cg_macrodriver.h"
#include <string.h>
#include <stdlib.h>
#include "MACROS.h"
#include "XVARIABLES.h"

void uart_transmit(const char,const char);
void parameter_send();
void time_date_update();
void door_lock_process();
void R_WDT_Restart(void);
void eeprom_write_int(unsigned char,unsigned int);
unsigned int eeprom_read_int(unsigned char);
void error_process();

void receive_process()
{
	int r,s,l;
	for(r=0;r <= 7;r++)							//HERE-1
	{
		if(!(strcmp(processed_string_data,receiving_message_check[r])))
		break;
	}
	if((received_app_id == app_id) AND (received_function_id == fun_id))  
	{
		if(r == 0)
		{
			retry_count = 0; 
			retry_flag  = CLEAR;
		}
	}
	else
	{
		ACK_ID;
		switch(received_app_id)
		{
			case 0X01	:switch(received_function_id)
					{
						case 0X01	:if(r == 1)
								{
									if(handshake_ok_flag)
									{
										mcu_restart_flag= SET;
										unknown_uart_data_flag = SET;
									}
									else
									{
										error_process();
										handshake_ok_flag = SET;
										uart_transmit(ACK,HANDSHAKE);
									}
								}
								break;
						default		:unknown_uart_data_flag = SET;
					}
					break;
					
			case 0X02	:switch(received_function_id)
					{
						case 0X03	:dryer_process_temperature = receive_parameter[0];
								dryer_process_heating_time = (receive_parameter[1] + 120);
								dryer_process_cooling_time = receive_parameter[2];
								if(door_open_flag)
								{
									dryer_process_resume_flag = CLEAR;
									uart_transmit(ACK,DOOR_OPEN);
								}
								else
								{
									dryer_process_resume_flag = SET;
									uart_transmit(ACK,DOOR_CLOSE);
								}
								dryer_process_start = SET;
								timer_seconds = 0;
								dryer_spin_timer = 0;
								dryer_interval_timer = 0;
								break;
								
						case 0X04	:if(r == 2)
								{
									dryer_process_start = CLEAR;
									heater_end_flag = CLEAR;
									cooler_end_flag = CLEAR;
									dryer_process_resume_flag = CLEAR;
									ALARM_OUTPUT_OFF;
									uart_transmit(ACK,ACK);	
								}
								break;
							
						case 0X05	:if(r == 3)
								{
									heater_end_flag = SET;
									uart_transmit(ACK,ACK);	
								}
								break;
								
						case 0X06	:if(r == 4)
								{
									cooler_end_flag = SET;
									uart_transmit(ACK,ACK);	
								}
								break;
						case 0X08	:door_lock_type = receive_parameter[0];
								dryer_process_door_lock_time = receive_parameter[1];
								mode_key_type = receive_parameter[2];
								spin_mode_type = receive_parameter[3];
								dryer_process_spin_interval_time = receive_parameter[4];
								dryer_process_spin_duration_time = receive_parameter[5];
								uart_transmit(ACK,ACK);
								break;
						default		:unknown_uart_data_flag = SET;
					}
					break;
					
			case 0X03	:switch(received_function_id)
					{
						case 0X01	:if(r == 5)
								{
									parameter_send();
								}
								break;
								
						case 0X02	:if(r == 6)
								{
									switch(receive_parameter[0])
									{
										case	1:	ALARM_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	2:	DOOR_LOCK_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	3:	TILT_DOWN_MOTOR_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	4:	TILT_UP_MOTOR_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	5:	FAN_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	6:	HEATER_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	7:	LEFT_SPIN_MOTOR_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	8:	RIGHT_SPIN_MOTOR_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										case	9:	COOLER_OUTPUT_ON;
												uart_transmit(ACK,ACK);
												break;
										default	 :	unknown_uart_data_flag = SET;
									}
								}
								if(r == 7)
								{	switch(receive_parameter[0])
									{
										case	1:	ALARM_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	2:	DOOR_LOCK_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	3:	TILT_DOWN_MOTOR_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	4:	TILT_UP_MOTOR_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	5:	FAN_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	6:	HEATER_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	7:	LEFT_SPIN_MOTOR_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	8:	RIGHT_SPIN_MOTOR_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										case	9:	COOLER_OUTPUT_OFF;
												uart_transmit(ACK,ACK);
												break;
										default	 :	unknown_uart_data_flag = SET;
									}
								}
								break;
						case 0X04	:time_date_update();
								time_update_flag = SET;	// FOR UPDATED DATE AND TIME
								uart_transmit(ACK,ACK);
								break;
						default		:unknown_uart_data_flag = SET;
					}
					break;
			default		:unknown_uart_data_flag = SET;
		}
	}
	CLEAR_ID;
}


void parameter_send()
{
	char inc;
	transmit_data_para[0] = 'I'; 
	transmit_data_para[2] =  (0X30 + ~DOOR_LOCK_INPUT); 
	transmit_data_para[4] =  (0X30 + ~MOTOR_OVER_HEAT_INPUT); 
	transmit_data_para[6] =  (0X30 + ~SPIN_MOTOR_INPUT); 
	transmit_data_para[8] =  (0X30 + ~PHASE_PROTECTION_INPUT); 
	transmit_data_para[10] = 'O'; 
	transmit_data_para[12] =  (0X30 + ~ALARM_OUTPUT); 
	transmit_data_para[14] =  (0X30 + ~DOOR_LOCK_OUTPUT); 
	transmit_data_para[16] =  (0X30 +  ~TILT_DOWN_MOTOR_OUTPUT); 
	transmit_data_para[18] =  (0X30 + ~TILT_UP_MOTOR_OUTPUT); 
	transmit_data_para[20] =  (0X30 + ~FAN_OUTPUT); 
	transmit_data_para[22] =  (0X30 + ~HEATER_OUTPUT); 
	transmit_data_para[24] =  (0X30 + ~LEFT_SPIN_MOTOR_OUTPUT); 
	transmit_data_para[26] =  (0X30 + ~RIGHT_SPIN_MOTOR_OUTPUT);
	for(inc=1;inc < 26;inc++,inc++)
	transmit_data_para[inc] = '|';
	transmit_data[9] = transmit_data_para;
	uart_transmit(ACK,IO_STATUS);
}