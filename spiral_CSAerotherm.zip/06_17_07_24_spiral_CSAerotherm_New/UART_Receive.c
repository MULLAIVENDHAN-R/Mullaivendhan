#pragma interrupt INTSR0 gui_uart_receive
#include "r_cg_macrodriver.h"
#include "Macros.h"
#include "GUI_Macros.h"
#include "XVariables.h"
#include "string.h"
#include "GUI_XVariables.h"

int remove_stuff_byte(char);
int received_check_sum(char);
void check_app_fun_id();
void received_fine_buf(char);
extern void process_buf_splitup();
extern void err_resend_fun();
extern void is_err_data_came();
extern void str_to_process_buf_conversion();

void gui_uart_receive()
{
	static __boolean receive_complete_flag;
	static unsigned char buf_length,check_sum;
	uart_main_buf[data]=RXD0;
	uart_error_clear_count=10;
	buf_length=((uart_main_buf[0]==START_BYTE)AND(data<MAX_SIZE_RX_BUF))?((uart_main_buf[data]==END_BYTE)?(receive_complete_flag=SET,data+1):++data):(data=0);
	if(receive_complete_flag)
	{
		receive_complete_flag=CLEAR;
		uart_error_clear_count=0,data=0,heart_beat_counter=0;		//For Heart beat reset
		total_length=(char)remove_stuff_byte(buf_length);
		total_data_bytes=uart_backup_buf[3];
		if(total_data_bytes>FIXED_DATA_LENGTH)
		dlc_err_flag=SET;
		if(!dlc_err_flag)
		{
			chk_sum_err_flag=received_check_sum(total_length);
			check_app_fun_id();
			if((!chk_sum_err_flag)AND(!appid_err_flag)AND(!funid_err_flag)AND(!dlc_err_flag))
			received_fine_buf(total_length);
		}
		err_resend_fun();
				
	}	
	
}
int remove_stuff_byte(char len)
{
	unsigned char i=0,j=0;
	for(i=0,j=0;i<len;i++,j++)
	{
		if(uart_main_buf[i]==STUFF_BYTE)
		uart_backup_buf[j]=~uart_main_buf[++i];
		else
		{
			uart_backup_buf[j]=uart_main_buf[i];
			if(uart_main_buf[i]==END_BYTE)
			break;
		}		
	}
	memset(uart_main_buf,0,sizeof(uart_main_buf));
	return j+1;    					//here +1 for include endbyte	
}
int received_check_sum(char total_len)
{
	char temp_check_sum=0,count,byte;
	for(byte=START_FROM,count=0;byte<total_len-2;byte++,count++)
	temp_check_sum=(temp_check_sum+(count^(uart_backup_buf[byte])));
	temp_check_sum=~(temp_check_sum+uart_backup_buf[HEADER_BYTE]);
	if(temp_check_sum==uart_backup_buf[total_len-2])
	return 0;
	else
	return 1;
}
void check_app_fun_id()
{
	unsigned char i,j,app_fun_id[TOTAL_APP_ID][MAX_FUN_ID+1]={
									{0X01,0X01,0X02,0X03,0X04,0X05},		//here this has all appid and fun id
				      			    	    	{0X02,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,0X0E},
	                              			    	    	{0X03,0X01,0X02,0X04},
									{0X04,0X01},
									{0X05,0X01,0X02},
									{0X06,0X01},
									{0X07,0X01,0X02,0x03},
									
								  };
	
	if(((app_id=uart_backup_buf[4])>0)AND((fun_id=uart_backup_buf[5])>0))
	{	
		appid_err_flag=funid_err_flag=1;
		for(i=0;i<TOTAL_APP_ID;i++)
		{
			if(app_fun_id[i][0]==app_id)
			{
		        	appid_err_flag=0;
			    	for(j=0;j<(MAX_FUN_ID+1);j++)
			    	{
			       		if((j>0)AND(app_fun_id[i][j]==fun_id))
					{
			        		funid_err_flag=0;
						break;
					}
			    	}
				break;
			}
		        
		}
	}
	else
	{
		if(app_id==0)
		appid_err_flag=1;
		if(fun_id==0)
		funid_err_flag=1;
	}
}
	
void received_fine_buf(char total_len)
{
	unsigned char i,byte;
	if(((app_id==0X03)AND(fun_id==0X02))OR((app_id==0X02)AND(fun_id==0X02))OR((app_id==0X02)AND(fun_id==0X07))OR((app_id==0X02)AND(fun_id==0X0C))OR((app_id==0X03)AND(fun_id==0X04)))
	{
		for(byte=DATA_START,i=0;byte<total_len-2;byte++,i++)
		string_process_data_buf[i]=uart_backup_buf[byte];
		memset(temp_string,0,sizeof(temp_string));
		str_to_process_buf_conversion();
	}
	else
	{
		for(byte=DATA_START,i=0;byte<total_len-2;byte++,i++)
		process_data_buf[i]=uart_backup_buf[byte];
	}
	memset(uart_backup_buf,0,sizeof(uart_backup_buf));	
	process_buf_splitup();
	memset(process_data_buf,0,sizeof(process_data_buf));
}

