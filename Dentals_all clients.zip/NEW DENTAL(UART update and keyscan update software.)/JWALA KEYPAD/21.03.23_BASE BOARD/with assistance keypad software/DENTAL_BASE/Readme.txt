-------- PROJECT GENERATOR --------
PROJECT NAME :	DENTAL_BASE
PROJECT DIRECTORY :	C:\WorkSpace\DENTAL_BASE\DENTAL_BASE
CPU SERIES :	R8C/Tiny
CPU GROUP :	25
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.01
GENERATION FILES :
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\typedefine.h
        define scalar types.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\resetprg.c
        initialize for C language.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\resetprg.h
        include some headder files.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\initsct.c
        initialize each sections.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\initsct.h
        define the macro for initialization of sections.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\fvector.c
        define the fixed vector table.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\intprg.c
        define the top address of the interrupt vectors.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\sfr_r825.h
        define the sfr register. (for C language)
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\sfr_r825.inc
        define the sfr register. (for Assembler language)
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\heap.c
        define the size of heap.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\DENTAL_BASE.c
        main program file.
    C:\WorkSpace\DENTAL_BASE\DENTAL_BASE\cstartdef.h
        define the size of stack.

SELECT TARGET :
    R8C E8a SYSTEM
DATE & TIME : 10/7/2012 10:05:44 AM
