/*
 * SERIAL TO PARELLEL.C
 *
 *  Created on: Dec 21, 2023
 *      Author: kl
 */
#include "Main_thread.h"
#include "bsp_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 //gpt_pin_level_t  OUTPUT_DATA_1;  // synergy


/****************************4094*************************************/
#define STROBE_HIGH             g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_03,IOPORT_LEVEL_HIGH)
#define STROBE_LOW              g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_03,IOPORT_LEVEL_LOW)

#define HEF4094_CLK_HIGH        g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_01,IOPORT_LEVEL_HIGH)
#define HEF4094_CLK_LOW         g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_01,IOPORT_LEVEL_LOW)



#define NO_OF_OUTPUT_4094          6
/****************************4094*************************************/

bool
toggle_flag1;

unsigned char

OUTPUT_DATA_1,
ser_bits,
intt_var,
intt_var1,
intt_var2,
output_data[185];

unsigned int
test,
temp_intt_var2;

void serial_to_parallel_ic_fn(void);



void serial_to_parallel_ic_fn()
{
    STROBE_LOW;
    for(unsigned char i=184;i>0;i--)
    {

        if(output_data[i]==0x01)
        g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_02,IOPORT_LEVEL_HIGH);
        else
        g_ioport.p_api->pinWrite(IOPORT_PORT_03_PIN_02,IOPORT_LEVEL_LOW);

        HEF4094_CLK_LOW;
        __asm("NOP");
        HEF4094_CLK_HIGH;
    }
    STROBE_HIGH;
}

